# Mod "Automationen": Wenn-Dann-Regeln (Uhrzeit / Programm startet / Programm endet / A.R.I startet) mit Aktionen wie Lautstaerke,
# Programme oeffnen, Spotify, Spielmodus oder einer Ansage. Regeln liegen in data/automations.json.
# Alle Namen des Hubs (app, run_tool, _hud_command, psutil, ...) stehen hier schon zur Verfuegung (siehe _mods_load im Hub).

# ---------------------------------------------------------------------------
# Automationen (Wenn-Dann): Ausloeser Uhrzeit / Programm startet / Programm endet / A.R.I startet
# ---------------------------------------------------------------------------
AUTOMATIONS_FILE = os.path.join(DATA_DIR, "automations.json")
_auto_lock = threading.Lock()
_AUTO_TOOLS = ("control_volume", "control_media", "open_app", "close_app", "play_spotify", "set_spotify_volume", "open_url", "set_timer", "manage_window", "take_screenshot")
_AUTO_DAYS = ["mo", "di", "mi", "do", "fr", "sa", "so"]
_AUTO_MAX = 40


def _auto_load():
    try:
        with open(AUTOMATIONS_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def _auto_save(lst):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = AUTOMATIONS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(lst, f, ensure_ascii=False, indent=1)
    os.replace(tmp, AUTOMATIONS_FILE)


def _auto_app_norm(a):
    return re.sub(r"[^a-z0-9]", "", str(a or "").lower().replace(".exe", ""))[:40]


def _auto_clean_action(a):
    """Eine Aktion pruefen und auf erlaubte Felder reduzieren (None = ungueltig)."""
    if not isinstance(a, dict):
        return None
    t = a.get("type")
    if t == "say":
        txt = str(a.get("text") or "").strip()[:200]
        return {"type": "say", "text": txt} if txt else None
    if t == "hud":
        if a.get("do") == "gamemode":
            return {"type": "hud", "do": "gamemode", "value": bool(a.get("value", True))}
        return None
    if t == "tool" and a.get("tool") in _AUTO_TOOLS:
        tool = a["tool"]
        inp = {}
        for k in ("action", "app", "query", "url", "label"):
            if a.get(k) not in (None, ""):
                inp[k] = str(a[k])[:200]
        for k in ("percent", "seconds"):
            if a.get(k) not in (None, ""):
                try:
                    inp[k] = int(a[k])
                except (TypeError, ValueError):
                    pass
        if isinstance(a.get("input"), dict):   # aus dem HUD-Editor
            for k, v in a["input"].items():
                if k in ("action", "app", "query", "url", "label", "percent", "seconds", "steps"):
                    inp[k] = v
        if tool in ("open_app", "close_app") and not inp.get("app"):
            return None
        if tool == "play_spotify" and not inp.get("query"):
            return None
        if tool == "open_url" and not re.match(r"https?://", str(inp.get("url", ""))):
            return None
        if tool == "control_volume" and inp.get("action") not in ("up", "down", "mute", "set"):
            return None
        if tool == "control_media" and inp.get("action") not in ("play_pause", "next", "previous"):
            return None
        if tool == "set_spotify_volume" and "percent" not in inp:
            return None
        if tool == "set_timer" and "seconds" not in inp:
            return None
        if tool == "manage_window" and inp.get("action") not in ("minimize_active", "show_desktop"):
            return None
        return {"type": "tool", "tool": tool, "input": inp}
    return None


def _auto_clean_rule(d):
    """Regel pruefen -> (Regel, Fehlertext)."""
    if not isinstance(d, dict):
        return None, "Ungueltige Regel."
    name = re.sub(r"\s+", " ", str(d.get("name") or "").strip())[:60] or "Automation"
    tr = d.get("trigger") or {}
    ttype = tr.get("type")
    trigger = {"type": ttype}
    if ttype == "time":
        at = str(tr.get("at") or "").strip()
        m = re.fullmatch(r"(\d{1,2}):(\d{2})", at)
        if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
            return None, "Uhrzeit unklar (erwartet HH:MM)."
        trigger["at"] = f"{int(m.group(1)):02d}:{m.group(2)}"
        days = []
        for x in (tr.get("days") or []):
            if isinstance(x, int) and 0 <= x <= 6:
                days.append(x)
            elif str(x).lower()[:2] in _AUTO_DAYS:
                days.append(_AUTO_DAYS.index(str(x).lower()[:2]))
        trigger["days"] = sorted(set(days))
    elif ttype in ("app_start", "app_stop"):
        app = _auto_app_norm(tr.get("app"))
        if len(app) < 2:
            return None, "Programmname fehlt."
        trigger["app"] = app
    elif ttype == "ari_start":
        pass
    else:
        return None, "Unbekannter Ausloeser."
    actions = [x for x in (_auto_clean_action(a) for a in (d.get("actions") or [])[:8]) if x]
    if not actions:
        return None, "Keine gueltige Aktion."
    rid = str(d.get("id") or "") if re.fullmatch(r"[a-f0-9]{6,12}", str(d.get("id") or "")) else uuid.uuid4().hex[:10]
    return {"id": rid, "name": name, "enabled": d.get("enabled") is not False, "trigger": trigger, "actions": actions, "last_run": 0}, None


def _auto_describe(r):
    t = r.get("trigger") or {}
    if t.get("type") == "time":
        days = t.get("days") or []
        when = "jeden Tag" if not days or len(days) == 7 else ", ".join(_AUTO_DAYS[i].capitalize() for i in days)
        trig = f"{when} um {t.get('at')} Uhr"
    elif t.get("type") == "app_start":
        trig = f"wenn {t.get('app')} startet"
    elif t.get("type") == "app_stop":
        trig = f"wenn {t.get('app')} beendet wird"
    else:
        trig = "wenn A.R.I startet"
    acts = []
    for a in r.get("actions", []):
        if a["type"] == "say":
            acts.append(f"sagt \"{a['text'][:40]}\"")
        elif a["type"] == "hud":
            acts.append("Spielmodus " + ("an" if a.get("value") else "aus"))
        else:
            i = a.get("input") or {}
            t, ac = a["tool"], i.get("action")
            if t == "control_volume":
                acts.append(f"Lautstärke {i.get('percent')} %" if ac == "set" else {"down": "Leiser", "up": "Lauter", "mute": "Stumm umschalten"}.get(ac, "Lautstärke"))
            elif t == "set_spotify_volume":
                acts.append(f"Spotify-Lautstärke {i.get('percent')} %")
            elif t == "control_media":
                acts.append({"play_pause": "Pause/Play", "next": "Nächster Titel", "previous": "Voriger Titel"}.get(ac, "Medien"))
            elif t == "open_app":
                acts.append("öffnet " + str(i.get("app")))
            elif t == "close_app":
                acts.append("schließt " + str(i.get("app")))
            elif t == "play_spotify":
                acts.append("Spotify: " + str(i.get("query")))
            elif t == "open_url":
                acts.append("öffnet " + str(i.get("url")))
            elif t == "set_timer":
                acts.append(f"Timer {i.get('seconds')} s")
            elif t == "manage_window":
                acts.append("Fenster minimieren" if ac == "minimize_active" else "Desktop zeigen")
            else:
                acts.append("Screenshot" if t == "take_screenshot" else t)
    return f"{trig}: " + " -> ".join(acts)


def _tool_create_automation(d):
    acts = d.get("actions") or []
    rule, err = _auto_clean_rule({
        "name": d.get("name"),
        "trigger": {"type": d.get("trigger_type"), "at": d.get("time"), "days": d.get("days"), "app": d.get("app")},
        "actions": acts,
    })
    if err:
        return f"Automation nicht angelegt: {err}"
    with _auto_lock:
        lst = [r for r in _auto_load() if str(r.get("name", "")).lower() != rule["name"].lower()]   # gleicher Name = ersetzen
        if len(lst) >= _AUTO_MAX:
            return "Automation nicht angelegt: Es gibt schon zu viele (max. 40)."
        lst.append(rule)
        _auto_save(lst)
    return f"Automation \"{rule['name']}\" angelegt: {_auto_describe(rule)}."


def _tool_list_automations():
    lst = _auto_load()
    if not lst:
        return "Es gibt noch keine Automationen."
    return "; ".join(f"{r.get('name')} ({'an' if r.get('enabled', True) else 'aus'}): {_auto_describe(r)}" for r in lst)


def _tool_delete_automation(name=""):
    n = str(name or "").strip().lower()
    with _auto_lock:
        lst = _auto_load()
        if n in ("", "alle", "alles", "all"):
            keep = []
        else:
            keep = [r for r in lst if not (n == str(r.get("name", "")).lower() or (len(n) >= 3 and n in str(r.get("name", "")).lower()))]
        gone = len(lst) - len(keep)
        if gone:
            _auto_save(keep)
    return f"{gone} Automation(en) geloescht." if gone else "Keine passende Automation gefunden."


def _auto_run(rule):
    """Aktionen einer Regel der Reihe nach ausfuehren."""
    out = []
    for a in rule.get("actions", []):
        try:
            if a["type"] == "say":
                _hud_command("say", {"text": a["text"]}, wait=0)
            elif a["type"] == "hud":
                _hud_command("gamemode", {"value": bool(a.get("value", True))}, wait=0)
            else:
                out.append(str(run_tool(a["tool"], dict(a.get("input") or {})))[:100])
        except Exception as e:
            out.append(f"Fehler: {e}")
        time.sleep(0.4)
    print(f"[automation] {rule.get('name')}: {out}")
    return out


def _auto_fire(rid):
    with _auto_lock:
        lst = _auto_load()
        r = next((x for x in lst if x.get("id") == rid), None)
        if not r:
            return
        r["last_run"] = time.time()
        _auto_save(lst)
    _stats_track("ui:automation_run")
    _auto_run(r)


def _auto_procs():
    names = set()
    for p in psutil.process_iter(["name"]):
        n = (p.info.get("name") or "").lower()
        if n:
            names.add(re.sub(r"[^a-z0-9]", "", n.replace(".exe", "")))
    return names


def _auto_has(procs, app):
    return any(app in n for n in procs)


def _auto_loop():
    fired = {}
    prev = None
    started = False
    t0 = time.time()
    while True:
        time.sleep(4)
        try:
            rules = [r for r in _auto_load() if r.get("enabled", True)]
            now = datetime.datetime.now()
            procs = _auto_procs() if any((r.get("trigger") or {}).get("type") in ("app_start", "app_stop") for r in rules) else None
            for r in rules:
                t = r.get("trigger") or {}
                fire = False
                if t.get("type") == "time":
                    key = now.strftime("%Y-%m-%d %H:%M")
                    days = t.get("days") or []
                    if now.strftime("%H:%M") == t.get("at") and (not days or now.weekday() in days) and fired.get(r["id"]) != key:
                        fired[r["id"]] = key
                        fire = True
                elif t.get("type") in ("app_start", "app_stop") and procs is not None and prev is not None:
                    was, isnow = _auto_has(prev, t["app"]), _auto_has(procs, t["app"])
                    fire = (isnow and not was) if t["type"] == "app_start" else (was and not isnow)
                elif t.get("type") == "ari_start" and not started and time.time() - t0 > 20:
                    fire = True
                if fire and time.time() - float(r.get("last_run") or 0) > 20:
                    threading.Thread(target=_auto_fire, args=(r["id"],), daemon=True).start()
            if time.time() - t0 > 20:
                started = True
            prev = procs
        except Exception as e:
            print(f"[automation] Schleife: {e}")


@app.route("/automations", methods=["GET"])
@app.route("/phone/api/automations", methods=["GET"])   # fuer die Handy-App (das Anmelde-Tor des Hubs prueft das gekoppelte Geraet)
def automations_list():
    return jsonify({"rules": [dict(r, text=_auto_describe(r)) for r in _auto_load()]})


@app.route("/automations/save", methods=["POST"])
def automations_save():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    rule, err = _auto_clean_rule((request.get_json(silent=True) or {}).get("rule"))
    if err:
        return jsonify({"ok": False, "error": err})
    with _auto_lock:
        lst = _auto_load()
        old = next((r for r in lst if r.get("id") == rule["id"]), None)
        if old:
            lst = [rule if r.get("id") == rule["id"] else r for r in lst]
        elif len(lst) >= _AUTO_MAX:
            return jsonify({"ok": False, "error": "Zu viele Automationen (max. 40)."})
        else:
            lst.append(rule)
        _auto_save(lst)
    return jsonify({"ok": True, "id": rule["id"]})


@app.route("/automations/delete", methods=["POST"])
@app.route("/phone/api/automations/delete", methods=["POST"])   # fuer die Handy-App (das Anmelde-Tor des Hubs prueft das gekoppelte Geraet)
def automations_delete():
    rid = str((request.get_json(silent=True) or {}).get("id") or "")
    with _auto_lock:
        _auto_save([r for r in _auto_load() if r.get("id") != rid])
    return jsonify({"ok": True})


@app.route("/automations/toggle", methods=["POST"])
@app.route("/phone/api/automations/toggle", methods=["POST"])   # fuer die Handy-App (das Anmelde-Tor des Hubs prueft das gekoppelte Geraet)
def automations_toggle():
    d = request.get_json(silent=True) or {}
    with _auto_lock:
        lst = _auto_load()
        for r in lst:
            if r.get("id") == d.get("id"):
                r["enabled"] = bool(d.get("enabled"))
        _auto_save(lst)
    return jsonify({"ok": True})


@app.route("/automations/test", methods=["POST"])
@app.route("/phone/api/automations/test", methods=["POST"])   # fuer die Handy-App (das Anmelde-Tor des Hubs prueft das gekoppelte Geraet)
def automations_test():
    rid = str((request.get_json(silent=True) or {}).get("id") or "")
    r = next((x for x in _auto_load() if x.get("id") == rid), None)
    if not r:
        return jsonify({"ok": False, "error": "nicht gefunden"})
    threading.Thread(target=_auto_run, args=(r,), daemon=True).start()
    return jsonify({"ok": True})


_AUTO_TOOL_DEFS = [
    {
        "name": "create_automation",
        "description": "Legt eine Automation (Wenn-Dann-Regel) an: 'Wenn ich Steam starte, dann Spielmodus an und Discord leiser', 'jeden Tag um 22 Uhr leiser', 'wenn Spotify schliesst, sag Tschuess'. Ausloeser: time (Uhrzeit, optional nur bestimmte Wochentage), app_start (Programm wird gestartet), app_stop (Programm wird beendet), ari_start (A.R.I startet). Aktionen laufen der Reihe nach. Nur fuer dauerhafte Regeln - einmalige Dinge macht A.R.I direkt oder mit einem Timer.",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Kurzer Name der Regel, z.B. 'Steam-Abend'."},
                "trigger_type": {"type": "string", "enum": ["time", "app_start", "app_stop", "ari_start"]},
                "time": {"type": "string", "description": "Nur bei time: Uhrzeit HH:MM (24 h), z.B. '22:00'."},
                "days": {"type": "array", "items": {"type": "string", "enum": ["mo", "di", "mi", "do", "fr", "sa", "so"]}, "description": "Nur bei time: Wochentage. Weglassen = jeden Tag."},
                "app": {"type": "string", "description": "Nur bei app_start/app_stop: Programmname, z.B. 'steam', 'discord', 'spotify'."},
                "actions": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string", "enum": ["tool", "say", "hud"], "description": "tool = A.R.I-Werkzeug ausfuehren, say = A.R.I sagt/zeigt einen Text, hud = HUD-Aktion."},
                            "tool": {"type": "string", "enum": ["control_volume", "control_media", "open_app", "close_app", "play_spotify", "set_spotify_volume", "open_url", "set_timer", "manage_window", "take_screenshot"]},
                            "action": {"type": "string", "description": "Fuer control_volume: up, down, mute, set. Fuer control_media: play_pause, next, previous. Fuer manage_window: minimize_active, show_desktop."},
                            "percent": {"type": "integer", "description": "Prozent fuer control_volume (action=set) oder set_spotify_volume."},
                            "app": {"type": "string", "description": "Programm fuer open_app/close_app."},
                            "query": {"type": "string", "description": "Suchbegriff fuer play_spotify."},
                            "url": {"type": "string", "description": "Adresse fuer open_url."},
                            "seconds": {"type": "integer", "description": "Sekunden fuer set_timer."},
                            "label": {"type": "string", "description": "Name fuer set_timer."},
                            "text": {"type": "string", "description": "Text fuer type=say."},
                            "do": {"type": "string", "enum": ["gamemode"], "description": "Fuer type=hud: gamemode = Spielmodus."},
                            "value": {"type": "boolean", "description": "Fuer type=hud: true = an, false = aus."},
                        },
                        "required": ["type"],
                    },
                },
            },
            "required": ["name", "trigger_type", "actions"],
        },
    },
    {
        "name": "list_automations",
        "description": "Zeigt alle Automationen (Wenn-Dann-Regeln) des Nutzers.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "delete_automation",
        "description": "Loescht eine Automation (nach Name) oder alle (name leer oder 'alle').",
        "input_schema": {"type": "object", "properties": {"name": {"type": "string"}}},
    },
]


def _auto_tool_handler(name, inp):
    if name == "create_automation":
        return _tool_create_automation(inp)
    if name == "list_automations":
        return _tool_list_automations()
    if name == "delete_automation":
        return _tool_delete_automation(inp.get("name", ""))
    return "Unbekanntes Werkzeug."


def register(ctx):
    ctx.add_tools(_AUTO_TOOL_DEFS, _auto_tool_handler,
                  keywords=r"automati|wenn ich .{1,60}(starte|[oö]ffne|schlie[sß]e|beende)|immer wenn|jedes mal|jeden (tag|morgen|abend|montag|dienstag|mittwoch|donnerstag|freitag|samstag|sonntag)|t[aä]glich|regel|bedingung|wenn .{1,40} dann")
    threading.Thread(target=_auto_loop, daemon=True, name="automationen").start()
