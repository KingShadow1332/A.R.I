// Mod "Automationen" - Oberflaeche (Einstellungen > AUTOMATIONEN). Laeuft per eval im HUD und nutzt dessen Hilfen (escapeHtml ...).
ARI_MODS.slot('modSlotSettings', `    <details class="set-section" id="secAuto">
      <summary>AUTOMATIONEN</summary>
      <div class="set-section-body">
        <div class="dim">Wenn-Dann-Regeln, die A.R.I von selbst ausführt – zum Beispiel „wenn Steam startet: Spielmodus an und Lautstärke 30 %“. Du kannst sie auch einfach sagen: <b>„Ari, wenn ich Steam starte, schalte den Spielmodus an.“</b></div>
        <div id="autoList" style="margin:10px 0;"></div>
        <div style="font:700 10px/1 var(--font-mono);letter-spacing:.14em;opacity:.7;margin:10px 0 8px;">NEUE AUTOMATION</div>
        <div class="field"><label>Name</label><input type="text" id="autoName" placeholder="z. B. Steam-Abend" autocomplete="off" maxlength="60"></div>
        <div class="field"><label>WENN</label>
          <select id="autoTrig">
            <option value="time">es eine Uhrzeit ist</option>
            <option value="app_start">ein Programm gestartet wird</option>
            <option value="app_stop">ein Programm beendet wird</option>
            <option value="ari_start">A.R.I startet</option>
          </select>
          <input type="time" id="autoTime" value="22:00" style="margin-top:6px;">
          <input type="text" id="autoApp" placeholder="Programm, z. B. steam" autocomplete="off" style="margin-top:6px;display:none;">
          <div id="autoDays" style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;font-size:12px;"></div>
        </div>
        <div class="field"><label>DANN (der Reihe nach)</label>
          <div id="autoActs" style="display:flex;flex-direction:column;gap:4px;margin-bottom:6px;"></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <select id="autoActSel" style="flex:1 1 150px;"></select>
            <input type="text" id="autoActVal" placeholder="" autocomplete="off" style="flex:1 1 150px;">
            <button class="btn" type="button" id="autoActAdd">+ AKTION</button>
          </div>
        </div>
        <div class="field"><button class="btn primary" type="button" id="autoSave" style="width:100%;">AUTOMATION SPEICHERN</button>
          <div id="autoMsg" style="font-size:11px;opacity:.75;margin-top:6px;min-height:14px;"></div></div>
      </div>
    </details>`);
  (function () {
    const $a = id => document.getElementById(id);
    const ACT = [
      { k: 'say', label: 'A.R.I sagt …', ph: 'Text', make: v => ({ type: 'say', text: v }) },
      { k: 'vol_set', label: 'Lautstärke setzen auf … %', ph: '30', make: v => ({ type: 'tool', tool: 'control_volume', action: 'set', percent: Math.max(0, Math.min(100, parseInt(v, 10) || 0)) }) },
      { k: 'vol_down', label: 'Leiser', make: () => ({ type: 'tool', tool: 'control_volume', action: 'down' }) },
      { k: 'vol_up', label: 'Lauter', make: () => ({ type: 'tool', tool: 'control_volume', action: 'up' }) },
      { k: 'vol_mute', label: 'Stumm umschalten', make: () => ({ type: 'tool', tool: 'control_volume', action: 'mute' }) },
      { k: 'open', label: 'Programm öffnen', ph: 'Programmname', make: v => ({ type: 'tool', tool: 'open_app', app: v }) },
      { k: 'close', label: 'Programm schließen', ph: 'Programmname', make: v => ({ type: 'tool', tool: 'close_app', app: v }) },
      { k: 'spotify', label: 'Spotify spielen', ph: 'Lied, Playlist oder Künstler', make: v => ({ type: 'tool', tool: 'play_spotify', query: v }) },
      { k: 'pause', label: 'Wiedergabe Pause/Play', make: () => ({ type: 'tool', tool: 'control_media', action: 'play_pause' }) },
      { k: 'url', label: 'Webseite öffnen', ph: 'https://…', make: v => ({ type: 'tool', tool: 'open_url', url: /^https?:\/\//i.test(v) ? v : 'https://' + v }) },
      { k: 'gm_on', label: 'Spielmodus an', make: () => ({ type: 'hud', do: 'gamemode', value: true }) },
      { k: 'gm_off', label: 'Spielmodus aus', make: () => ({ type: 'hud', do: 'gamemode', value: false }) },
    ];
    const DAYS = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
    let acts = [];
    const actText = a => a.type === 'say' ? 'Sagt: ' + a.text : a.type === 'hud' ? 'Spielmodus ' + (a.value ? 'an' : 'aus') :
      ({ control_volume: a.action === 'set' ? 'Lautstärke ' + a.percent + ' %' : a.action === 'down' ? 'Leiser' : a.action === 'up' ? 'Lauter' : 'Stumm umschalten', open_app: 'Öffnet ' + a.app, close_app: 'Schließt ' + a.app, play_spotify: 'Spotify: ' + a.query, control_media: 'Pause/Play', open_url: 'Öffnet ' + a.url })[a.tool] || a.tool;
    $a('autoActSel').innerHTML = ACT.map(x => '<option value="' + x.k + '">' + x.label + '</option>').join('');
    $a('autoDays').innerHTML = DAYS.map((d, i) => '<label style="display:inline-flex;align-items:center;justify-content:flex-start;width:auto;gap:4px;margin:0;"><input type="checkbox" class="autoDay" value="' + i + '" style="width:auto;accent-color:var(--pink);">' + d + '</label>').join('') + '<span style="opacity:.55;font-size:11px;">(keiner = jeden Tag)</span>';
    function syncForm() {
      const t = $a('autoTrig').value;
      $a('autoTime').style.display = $a('autoDays').style.display = t === 'time' ? '' : 'none';
      $a('autoApp').style.display = (t === 'app_start' || t === 'app_stop') ? '' : 'none';
      const a = ACT.find(x => x.k === $a('autoActSel').value);
      $a('autoActVal').style.display = a && a.ph ? '' : 'none';
      if (a && a.ph) $a('autoActVal').placeholder = a.ph;
    }
    $a('autoTrig').addEventListener('change', syncForm); $a('autoActSel').addEventListener('change', syncForm); syncForm();
    function renderActs() {
      $a('autoActs').innerHTML = acts.length ? acts.map((a, i) => '<div style="display:flex;justify-content:space-between;gap:8px;padding:4px 8px;border-radius:8px;background:rgba(255,255,255,.06);font-size:12px;"><span>' + (i + 1) + '. ' + escapeHtml(actText(a)) + '</span><span data-del="' + i + '" style="cursor:pointer;opacity:.7;">✕</span></div>').join('') : '<div style="font-size:11px;opacity:.5;">Noch keine Aktion.</div>';
      $a('autoActs').querySelectorAll('[data-del]').forEach(el => el.addEventListener('click', () => { acts.splice(+el.dataset.del, 1); renderActs(); }));
    }
    renderActs();
    $a('autoActAdd').addEventListener('click', () => {
      const a = ACT.find(x => x.k === $a('autoActSel').value), v = $a('autoActVal').value.trim();
      if (!a) return;
      if (a.ph && !v) { $a('autoMsg').textContent = 'Bitte „' + a.ph + '“ eintragen.'; return; }
      acts.push(a.make(v)); $a('autoActVal').value = ''; $a('autoMsg').textContent = ''; renderActs();
    });
    async function autoLoad() {
      let d; try { d = await (await fetch('/automations')).json(); } catch (e) { return; }
      const rules = d.rules || [];
      $a('autoList').innerHTML = rules.length ? rules.map(r => '<div style="padding:8px 10px;margin-bottom:6px;border-radius:10px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);">' +
        '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;"><b style="font-size:13px;">' + escapeHtml(r.name) + '</b>' +
        '<span style="display:flex;gap:6px;align-items:center;"><label style="font-size:11px;display:flex;gap:4px;align-items:center;"><input type="checkbox" data-tg="' + r.id + '" ' + (r.enabled !== false ? 'checked' : '') + ' style="width:auto;accent-color:var(--pink);">an</label>' +
        '<button class="btn" type="button" data-test="' + r.id + '" style="padding:2px 8px;">TEST</button><button class="btn danger" type="button" data-rm="' + r.id + '" style="padding:2px 8px;">✕</button></span></div>' +
        '<div style="font-size:11px;opacity:.7;margin-top:4px;">' + escapeHtml(r.text || '') + '</div></div>').join('') : '<div style="font-size:12px;opacity:.55;">Noch keine Automationen.</div>';
      const post = (u, b) => fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) });
      $a('autoList').querySelectorAll('[data-tg]').forEach(el => el.addEventListener('change', async () => { await post('/automations/toggle', { id: el.dataset.tg, enabled: el.checked }); }));
      $a('autoList').querySelectorAll('[data-test]').forEach(el => el.addEventListener('click', async () => { await post('/automations/test', { id: el.dataset.test }); $a('autoMsg').textContent = 'Test gestartet.'; }));
      $a('autoList').querySelectorAll('[data-rm]').forEach(el => el.addEventListener('click', async () => { await post('/automations/delete', { id: el.dataset.rm }); autoLoad(); }));
    }
    $a('autoSave').addEventListener('click', async () => {
      const t = $a('autoTrig').value;
      const rule = { name: $a('autoName').value.trim() || 'Automation', trigger: { type: t }, actions: acts };
      if (t === 'time') { rule.trigger.at = $a('autoTime').value; rule.trigger.days = [...document.querySelectorAll('.autoDay:checked')].map(x => +x.value); }
      if (t === 'app_start' || t === 'app_stop') rule.trigger.app = $a('autoApp').value.trim();
      let d; try { d = await (await fetch('/automations/save', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rule }) })).json(); } catch (e) { d = { error: e.message }; }
      if (!d.ok) { $a('autoMsg').textContent = 'Nicht gespeichert: ' + (d.error || 'unbekannt'); return; }
      $a('autoMsg').textContent = 'Gespeichert.'; acts = []; renderActs(); $a('autoName').value = ''; autoLoad();
    });
    $a('secAuto').addEventListener('toggle', function () { if (this.open) autoLoad(); });
  })();
if (window.ARI_NEW) ARI_NEW.add({ id: 'mod-automationen-ui', rel: 105, el: '#secAuto > summary' });
