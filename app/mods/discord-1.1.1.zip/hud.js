// Mod "Discord" - Oberflaeche: Kachel mit Sprachkanal, Planet <-> Stream-Schalter, Einstellungen, DEV-Tests.
// Wird vom HUD per eval in seinem eigenen Programm gestartet - hat also Zugriff auf logLine, escapeHtml, closeSettings ...
(function () {
  const dcPost = (what, body) => fetch('/discord/' + what, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }).then(r => r.json());

  // ---- Kachel ----
  const tile = document.createElement('div');
  tile.className = 'panel';
  tile.id = 'panelDiscord';
  tile.dataset.pid = 'discord';
  tile.innerHTML = '<div class="panel-h"><span class="ico"><svg class="fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M19.3 5.4A17.6 17.6 0 0 0 14.9 4l-.6 1.2a16.3 16.3 0 0 0-4.6 0L9.1 4A17.6 17.6 0 0 0 4.7 5.4C1.9 9.6 1.1 13.7 1.5 17.7a17.8 17.8 0 0 0 5.4 2.8l1.2-1.9a11.6 11.6 0 0 1-1.9-.9l.5-.4a12.7 12.7 0 0 0 10.8 0l.5.4c-.6.4-1.2.7-1.9.9l1.2 1.9a17.8 17.8 0 0 0 5.4-2.8c.5-4.6-.8-8.6-3.2-12.3zM8.7 15.3c-1 0-1.9-.9-1.9-2.1s.8-2.1 1.9-2.1 1.9.9 1.9 2.1-.8 2.1-1.9 2.1zm6.6 0c-1 0-1.9-.9-1.9-2.1s.8-2.1 1.9-2.1 1.9.9 1.9 2.1-.8 2.1-1.9 2.1z"/></svg></span><span class="t">DISCORD</span><span class="tag" id="dcTag">AUS</span></div><div class="dc-body" id="dcBody"></div>';
  ARI_MODS.addPanel(tile, 'colRight');
  const bodyEl = tile.querySelector('#dcBody'), tagEl = tile.querySelector('#dcTag');
  const avatarHtml = m => {   // Profilbild, bei Fehler/ohne Bild ein Kreis mit dem Anfangsbuchstaben
    const ini = escapeHtml((m.name || '?').trim().charAt(0).toUpperCase() || '?');
    const ph = '<span class="av">' + ini + '</span>';
    if (!m.avatar) return ph;
    return '<span class="avw" data-ph="' + escapeHtml(ph) + '"><img src="' + escapeHtml(m.avatar) + '" alt="" onerror="this.parentNode.innerHTML=this.parentNode.dataset.ph"></span>';
  };
  const STATUS = { 'aus': 'AUS', 'nicht-eingerichtet': 'NICHT EINGERICHTET', 'suche': 'SUCHE DISCORD', 'warten': 'DISCORD NICHT DA', 'anmelden': 'ANMELDEN',
    'warte-bestaetigung': 'IN DISCORD BESTÄTIGEN', 'verbunden': 'VERBUNDEN', 'fehler': 'FEHLER' };
  let last = null, lastStatic = {}, live = null, sseOk = false;
  const cur = () => (sseOk && live ? Object.assign({}, lastStatic, live) : lastStatic);   // Live-Daten haben Vorrang vor dem langsamen Status-Abruf
  const liveSig = d => JSON.stringify([d.status, d.error, d.channel, d.server, d.configured, (d.members || []).map(m => [m.id, m.name, m.avatar, m.muted, m.deaf])]);
  function renderTile(d) {
    if (!d || !d.status) return;
    const sig = liveSig(d);
    if (sig === last) {   // nur "wer spricht" hat sich geaendert: Ringe umschalten, nichts neu aufbauen (kein Flackern der Bilder)
      bodyEl.querySelectorAll('li[data-id]').forEach(li => { const m = (d.members || []).find(x => x.id === li.dataset.id); li.classList.toggle('sp', !!(m && m.speaking)); });
      return;
    }
    last = sig;
    tagEl.textContent = STATUS[d.status] || String(d.status || '').toUpperCase();
    tagEl.className = d.status === 'verbunden' ? 'tag dc-ok' : (d.status === 'fehler' ? 'tag dc-bad' : 'tag');
    let h = '';
    if (d.error) h += '<div class="dc-note dc-err">' + escapeHtml(d.error) + '</div>';
    if (d.channel) h += '';
    else if (!d.configured) h += '<div class="dc-note">Noch nicht eingerichtet.</div><button type="button" class="btn dc-auto" style="width:100%;margin-top:6px;">AUTOMATISCH EINRICHTEN</button>';
    else if (d.status === 'warte-bestaetigung') h += '<div class="dc-note">Bestätige jetzt in <b>Discord</b> den Knopf <b>„Autorisieren“</b>.</div>';
    if (d.channel) {
      h += '<div class="dc-chan"><b>' + escapeHtml(d.channel) + '</b><span>' + escapeHtml(d.server || '') + '</span></div><ul class="dc-list">' +
        d.members.map(m => '<li data-id="' + escapeHtml(m.id) + '" class="' + (m.speaking ? 'sp' : '') + '">' + avatarHtml(m) + '<span class="n">' + escapeHtml(m.name) + '</span>' +
          (m.deaf ? '<i title="Taub">🙉</i>' : m.muted ? '<i title="Stumm">🔇</i>' : '') + '</li>').join('') + '</ul>';
    } else if (d.connected && !h) h += '<div class="dc-note">Du bist in keinem Sprachkanal.</div>';
    bodyEl.innerHTML = h || '<div class="dc-note">Warte auf Discord …</div>';
    const ab = bodyEl.querySelector('.dc-auto'); if (ab) ab.addEventListener('click', () => { if (window.__ariAutoSetup) window.__ariAutoSetup.start('discord'); });
  }
  // Live-Verbindung: der Hub schickt jede Aenderung sofort (Sprechen, Beitreten, Stummschalten) - kein Warten auf den Status-Abruf.
  if (window.EventSource) {
    const es = new EventSource('/discord/live');
    es.onmessage = e => { try { live = JSON.parse(e.data); sseOk = true; renderTile(cur()); } catch (err) {} };
    es.onerror = () => { sseOk = false; };   // der Browser verbindet sich von selbst neu; bis dahin gilt der normale Status-Abruf
  }
  // Automatisch auf das Discord-Bild schalten, solange im Sprachkanal gesprochen wird; nach 20 s Stille zurueck zum Planeten.
  // Ein Klick auf den Knopf (manuell) hat Vorrang: 10 Minuten lang schaltet dann nichts von allein um.
  let autoOn = false, lastSpeak = 0, manualUntil = 0, spkTicks = [], noStreamSince = 0, noStreamUntil = 0;
  setInterval(() => {
    const d = cur();
    if (!d || !d.opts || !window.__dcSetView) return;
    const now = Date.now();
    // Kein Stream gefunden (Automatik-Modus, Aufnahme laeuft, aber kein laufendes Bild): nach 8 s von allein zurueck zum Planeten
    if (view === 'stream' && d.opts.crop == null && d.cap_running && d.streaming === false) {
      if (!noStreamSince) noStreamSince = now;
      if (now - noStreamSince > 8000) { window.__dcSetView('planet'); autoOn = false; noStreamSince = 0; noStreamUntil = now + 60000; return; }
    } else noStreamSince = 0;
    if (d.popout && view !== 'stream' && now > manualUntil && now > noStreamUntil) { window.__dcSetView('stream'); autoOn = true; }
    if (!d.popout && autoOn && view === 'stream' && d.cap_running === false) { if (!noStreamSince) noStreamSince = now; if (now - noStreamSince > 8000) { window.__dcSetView('planet'); autoOn = false; noStreamSince = 0; noStreamUntil = now + 60000; return; } }
    if (d.opts.auto_live === false) return;
    const speaking = !!(d.connected && d.channel && (d.members || []).some(m => m.speaking));
    spkTicks.push(speaking ? 1 : 0); if (spkTicks.length > 4) spkTicks.shift();   // Fenster: 4 x 0,5 s
    if (speaking) lastSpeak = now;
    if (d.popout && spkTicks.filter(Boolean).length >= 2 && view !== 'stream' && now > manualUntil && now > noStreamUntil) { window.__dcSetView('stream'); autoOn = true; }
    else if (autoOn && view === 'stream' && now - lastSpeak > 20000) { window.__dcSetView('planet'); autoOn = false; }
    else if (autoOn && view !== 'stream') autoOn = false;
  }, 500);
  ARI_MODS.on('status', d => { if (!d.discord) return; lastStatic = d.discord; const c = cur(); renderTile(c); if (settingsOpenInfo) fillStatusLine(Object.assign({}, lastStatic, c)); });

  // ---- Planet <-> Stream: das Stream-Bild fuellt die GANZE Master-Kachel (Hero), der Knopf ⇄ schaltet um ----
  const heroPanel = document.querySelector('.panel.hero'), orb = document.getElementById('orb');
  let view = 'planet', offTimer = null, img = null, noPopSince = 0;
  const popoutOn = () => { const d = cur(); return !!(d && d.popout); };   // Discords Pop-out-Fenster existiert: wird direkt benutzt statt gespiegelt
  try { view = localStorage.getItem('ari-dc-view') === 'stream' ? 'stream' : 'planet'; } catch (e) {}
  if (heroPanel && orb) {
    img = document.createElement('img');
    img.className = 'dc-stream'; img.alt = 'Discord-Stream'; img.style.display = 'none';
    heroPanel.appendChild(img);
    const sw = document.createElement('button');
    sw.type = 'button'; sw.className = 'dc-switch'; sw.id = 'dcSwitch'; sw.title = 'Planet / Discord-Stream umschalten'; sw.textContent = '⇄ STREAM';
    sw.style.display = 'none';   // nur sichtbar, solange ein Stream laeuft
    const gmb = document.getElementById('modSlotBadge');   // Platz fuer Kopfleisten-Anzeigen der Mods (rechts neben dem Spielmodus)
    if (gmb) gmb.insertAdjacentElement('afterend', sw); else heroPanel.appendChild(sw);   // oben in der Leiste neben dem Spielmodus
    const showSw = () => { const d = cur(); const has = !!(d && d.popout); const vis = has || view === 'stream'; sw.style.display = vis ? '' : 'none'; sw.textContent = view === 'stream' ? '⇄ PLANET' : '⇄ STREAM'; };
    setInterval(showSw, 150);
    const apply = () => {
      const stream = view === 'stream';
      heroPanel.classList.toggle('dc-live', stream);
      img.style.display = stream && !popoutOn() ? 'block' : 'none';
      sw.classList.toggle('on', stream);
      clearTimeout(offTimer);
      if (!stream) heroPanel.style.minHeight = '';
      img.removeAttribute('src');   // es wird nichts mehr gespiegelt (kostet Leistung): die Kachel zeigt direkt Discords Pop-out-Fenster
      if (!stream) dcPost('embed', { hide: true }).catch(() => {});   // sofort: Pop-out wieder weg (nicht erst nach Ablauf der Meldefrist)
      else {
        if (popoutOn()) heroPanel.style.minHeight = Math.round(Math.min(window.innerHeight * 0.8, Math.max(260, heroPanel.clientWidth * 9 / 16))) + 'px';
        requestAnimationFrame(() => requestAnimationFrame(() => { if (window.__dcSendRect) window.__dcSendRect(); }));
      }
    };
    sw.addEventListener('click', () => { manualUntil = Date.now() + 600000; autoOn = false; view = view === 'stream' ? 'planet' : 'stream'; try { localStorage.setItem('ari-dc-view', view); } catch (e) {} apply(); });
    window.__dcSetView = v => { view = v; apply(); };
    // Lage der Kachel an den Hub melden (auch sofort beim Scrollen); ist die Kachel nicht ganz zu sehen, wird das Pop-out versteckt
    let rafPending = false;
    const sendRect = () => {
      if (view !== 'stream' || !popoutOn()) return;
      const r = heroPanel.getBoundingClientRect(), tb = document.querySelector('.topbar'), top = tb ? tb.getBoundingClientRect().bottom : 0;
      const fully = r.width > 50 && r.height > 50 && r.top >= top - 1 && r.bottom <= window.innerHeight + 1 && r.left >= -1 && r.right <= window.innerWidth + 1;
      dcPost('embed', fully ? { x: r.left, y: r.top, w: r.width, h: r.height, dpr: window.devicePixelRatio || 1 } : { hide: true }).catch(() => {});
    };
    const onMove = () => { if (rafPending) return; rafPending = true; requestAnimationFrame(() => { rafPending = false; sendRect(); }); };
    window.__dcSendRect = sendRect;
    // Astro (das Maskottchen) soll vor dem Pop-out bleiben: sein Bild (mit Transparenz) wird als PNG an den Hub geschickt, der zeigt es in einem Fenster darueber
    const MPROPS = ['fill', 'stroke', 'stroke-width', 'opacity', 'transform', 'transform-origin', 'display', 'visibility', 'fill-opacity', 'stroke-opacity'];
    let mBusy = false;
    function snapMascot() {
      return new Promise(res => {
        const m = document.getElementById('ariMascot'), svg = m && m.querySelector('svg');
        if (!svg) return res(null);
        const sr = svg.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
        const clone = svg.cloneNode(true), srcs = [svg].concat(Array.from(svg.querySelectorAll('*'))), dsts = [clone].concat(Array.from(clone.querySelectorAll('*')));
        srcs.forEach((n, i) => {
          const cs = getComputedStyle(n); let st = '';
          MPROPS.forEach(p => { if (i === 0 && (p === 'transform' || p === 'transform-origin')) return; st += p + ':' + cs.getPropertyValue(p).replace(/url\("?[^"#)]*#([^")]+)"?\)/g, 'url(#$1)') + ';'; });   // Verlaeufe (url(#id)) muessen im eigenstaendigen Bild relativ bleiben
          dsts[i].setAttribute('style', st); dsts[i].removeAttribute('class');
        });
        clone.setAttribute('width', sr.width); clone.setAttribute('height', sr.height); clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        const img = new Image();
        img.onload = () => {
          const c = document.createElement('canvas'); c.width = Math.max(2, Math.round(sr.width * dpr)); c.height = Math.max(2, Math.round(sr.height * dpr));
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          res({ png: c.toDataURL('image/png'), r: sr });
        };
        img.onerror = () => res(null);
        img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(clone));
      });
    }
    setInterval(async () => {
      if (mBusy) return;
      if (view !== 'stream' || !popoutOn()) return;
      const t = heroPanel.getBoundingClientRect(), m = document.getElementById('ariMascot');
      const dpr = window.devicePixelRatio || 1;
      if (!m || getComputedStyle(m).display === 'none') { dcPost('embed', { mascot: null, dpr }).catch(() => {}); return; }
      const r = m.getBoundingClientRect();
      const inside = r.width > 4 && r.height > 4 && r.right > t.left && r.left < t.right && r.bottom > t.top && r.top < t.bottom;
      if (!inside) { dcPost('embed', { mascot: null, dpr }).catch(() => {}); return; }
      mBusy = true;
      try {
        const sn = await snapMascot();
        if (sn) dcPost('embed', { mascot: { x: sn.r.left, y: sn.r.top, w: sn.r.width, h: sn.r.height }, sprite: sn.png, dpr }).catch(() => {});
      } catch (e) {}
      mBusy = false;
    }, 60);
    window.addEventListener('scroll', onMove, true);
    window.addEventListener('resize', onMove);
    // Pop-out-Fenster direkt benutzen: A.R.I meldet dem Hub, wo die Hauptkachel liegt, der legt das Fenster genau darueber
    setInterval(() => {
      const pop = popoutOn();
      if (view === 'stream' && pop) {
        if (img.getAttribute('src')) img.removeAttribute('src');
        img.style.display = 'none';
        const want = Math.round(Math.min(window.innerHeight * 0.8, Math.max(260, heroPanel.clientWidth * 9 / 16)));
        if (Math.abs(want - heroPanel.clientHeight) > 6) heroPanel.style.minHeight = want + 'px';
        sendRect();
        noPopSince = 0;
      } else if (view === 'stream' && !pop) {   // Pop-out weg (Stream beendet / zurueckgeholt): zurueck zum Planeten
        if (!noPopSince) noPopSince = Date.now();
        if (Date.now() - noPopSince > 2500) { noPopSince = 0; view = 'planet'; try { localStorage.setItem('ari-dc-view', 'planet'); } catch (e) {} apply(); }
      } else noPopSince = 0;
    }, 150);
    // Kachelform an das Stream-Bild anpassen: so fuellt es die ganze Kachel, ohne dass Teile abgeschnitten werden oder Raender entstehen
    setInterval(() => {
      if (view !== 'stream' || !img.naturalWidth) return;
      const want = Math.round(Math.min(window.innerHeight * 0.8, Math.max(260, heroPanel.clientWidth * img.naturalHeight / img.naturalWidth)));
      if (Math.abs(want - heroPanel.clientHeight) > 6) heroPanel.style.minHeight = want + 'px';
    }, 1000);
    apply();
  }

  // ---- Einstellungen ----
  ARI_MODS.slot('modSlotSettings', `<details class="set-section" id="dcSection">
      <summary>DISCORD</summary>
      <div class="set-section-body">
        <div style="font-size:11px;opacity:.7;margin-bottom:8px;">So verbindest du A.R.I mit deiner Discord-App (einmalig, kostenlos):
          <ol style="margin:6px 0 0 16px;padding:0;">
            <li>Auf <b>discord.com/developers/applications</b> eine neue App anlegen.</li>
            <li>Dort <b>OAuth2</b> öffnen und bei „Redirects“ <b>http://localhost</b> hinzufügen. Unter „App Testers“ dich selbst eintragen.</li>
            <li>Die <b>Client-ID</b> und das <b>Client-Secret</b> (OAuth2) unten einfügen und auf VERBINDEN klicken. <i>Oder einfach AUTOMATISCH EINRICHTEN klicken.</i></li>
            <li>Discord fragt dich dann – klicke <b>Autorisieren</b>.</li>
          </ol></div>
        <div class="field"><label>Client-ID</label><input type="text" id="dcClientId" placeholder="z. B. 123456789012345678" autocomplete="off"></div>
        <div class="field"><label>Client-Secret</label><input type="password" id="dcClientSecret" placeholder="wird nur auf diesem PC gespeichert" autocomplete="off"></div>
        <div class="field"><button class="btn primary" type="button" id="dcAuto" style="width:100%;">AUTOMATISCH EINRICHTEN</button>
          <div style="font-size:11px;opacity:.55;margin-top:4px;">A.R.I öffnet das Discord-Entwicklerportal, legt die App an und trägt alles ein. Anmelden und „Autorisieren“ machst du selbst.</div></div>
        <div style="font-size:11px;opacity:.6;margin:4px 0;">Oder von Hand:</div>
        <div class="field" style="display:flex;gap:6px;flex-wrap:wrap;">
          <button class="btn primary" type="button" id="dcConnect">VERBINDEN</button>
          <button class="btn" type="button" id="dcDisconnect">TRENNEN</button>
        </div>
        <div id="dcStatusLine" style="font-size:11px;opacity:.8;margin:4px 0 10px;min-height:14px;"></div>
        <div class="field"><label style="display:flex;align-items:center;gap:8px;justify-content:flex-start;"><input type="checkbox" id="dcOptTr" style="width:auto;accent-color:var(--pink);"> Nachrichten in anderen Sprachen ins Deutsche übersetzen</label>
          <div style="font-size:11px;opacity:.55;margin-top:4px;">Gilt für Discord-Nachrichten in den Benachrichtigungen: Die Übersetzung steht in der Meldung und wird vorgelesen. Dafür geht der Text an Gemini (wenn ein Schlüssel eingetragen ist) oder an deinen KI-Anbieter.</div></div>
        <div class="field"><label style="display:flex;align-items:center;gap:8px;justify-content:flex-start;"><input type="checkbox" id="dcOptAuto" style="width:auto;accent-color:var(--pink);"> Planet schaltet automatisch auf Discord, wenn jemand spricht</label>
          <div style="font-size:11px;opacity:.55;margin-top:4px;">Nach 20 Sekunden Stille geht es zurück zum Planeten. Ein Klick auf ⇄ hat 10 Minuten lang Vorrang.</div></div>
        <div class="field"><label style="display:flex;align-items:center;gap:8px;justify-content:flex-start;"><input type="checkbox" id="dcOptPop" style="width:auto;accent-color:var(--pink);"> Stream automatisch als Pop-out herauslösen und in der Hauptkachel zeigen</label>
          <div style="font-size:11px;opacity:.55;margin-top:4px;">Sobald du in Discord einen Stream anschaust, klickt A.R.I dort für dich auf „Pop-out“ (ohne deine Maus zu bewegen). Ist der Stream zu Ende, wird das leere Fenster geschlossen.</div></div>
        <div class="field"><label style="display:flex;align-items:center;gap:8px;justify-content:flex-start;"><input type="checkbox" id="dcOptRoles" style="width:auto;accent-color:var(--pink);"> Auch Erwähnungen von Rollen melden</label></div>
        <div class="field"><label style="display:flex;align-items:center;gap:8px;justify-content:flex-start;"><input type="checkbox" id="dcOptEveryone" style="width:auto;accent-color:var(--pink);"> Auch @everyone / @here melden</label></div>
        <div class="field"><label>Stream-Spiegel</label>
          <select id="dcOptFps"><option value="schonend">Schonend (bis 30 Bilder/s, Prozessor, keine Grafikkarte)</option><option value="60">60 Bilder/s (belastet die Grafikkarte etwas)</option></select>
          <select id="dcOptWidth" style="margin-top:6px;"><option value="640">Klein (640 px)</option><option value="960">Mittel (960 px)</option><option value="1280">Groß (1280 px)</option><option value="1600">Sehr groß (1600 px)</option><option value="1920">Voll (1920 px)</option></select>
          <div style="font-size:11px;opacity:.55;margin-top:4px;">Bei hoher Auslastung oder laufendem Spiel senkt A.R.I die Bildrate automatisch (60 › 45 › 30 › 20 › 10).</div>
          <div style="margin-top:10px;font-size:12px;">Gezeigt wird <b>nur das Stream-Bild</b> (ohne Seitenleisten und Chat):</div>
          <div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;">
            <button class="btn primary" type="button" id="dcDetect">AUTOMATISCH</button>
            <button class="btn" type="button" id="dcPick">VON HAND WÄHLEN</button>
            <button class="btn" type="button" id="dcFull">GANZES FENSTER</button>
          </div>
          <div id="dcCropInfo" style="font-size:11px;opacity:.7;margin-top:4px;min-height:14px;"></div>
          <div style="display:none;">   <!-- Stream-Fix wird nicht mehr gebraucht (kein Spiegeln mehr) -->
<div style="margin-top:10px;font-size:12px;"><b>Stream-Fix:</b> Discord zeichnet auch weiter, wenn es von anderen Fenstern verdeckt ist.</div>
          <div id="dcFixInfo" style="font-size:11px;opacity:.75;margin-top:4px;min-height:14px;"></div>
          <label style="display:flex;align-items:center;gap:8px;justify-content:flex-start;margin-top:6px;"><input type="checkbox" id="dcOptFix" style="width:auto;accent-color:var(--pink);"> Stream-Fix automatisch anwenden (startet Discord neu, wenn du nicht im Sprachkanal bist)</label>
          <div style="margin-top:6px;"><button class="btn" type="button" id="dcFixBtn">JETZT MIT STREAM-FIX NEU STARTEN</button></div>
          </div>
          <div style="font-size:11px;opacity:.55;margin-top:2px;">Automatisch: A.R.I findet das laufende Bild selbst und passt sich an, wenn du das Fenster änderst. Läuft kein Stream, zeigt die Kachel nur einen Hinweis.</div>
        </div>
      </div></details>`);
  let settingsOpenInfo = false;
  const $dc = id => document.getElementById(id);
  function fillStatusLine(d) {
    const el = $dc('dcStatusLine'); if (!el) return;
    el.style.color = d.error ? 'var(--pink)' : '';
    el.textContent = d.error || ({ 'verbunden': 'Verbunden' + (d.me ? ' als ' + d.me : '') + '.', 'warte-bestaetigung': 'Bestätige jetzt in Discord auf „Autorisieren“.', 'anmelden': 'Melde an …',
      'suche': 'Suche Discord …', 'warten': 'Discord läuft nicht – A.R.I versucht es weiter.', 'nicht-eingerichtet': 'Noch nicht eingerichtet.', 'aus': 'Nicht verbunden.' }[d.status] || '');
    if (d.capture && d.capture.running) el.textContent += '  ·  Stream: ' + d.capture.fps + ' Bilder/s (' + d.capture.backend + ', Stufe ' + d.capture.stage + ')';
  }
  function showFix(f, elev) {
    const el = $dc('dcFixInfo'); if (!el) return;
    el.style.color = '';
    el.textContent = f === true ? '✓ Aktiv – der Stream läuft auch bei verdecktem Discord-Fenster.' : f === false ? 'Nicht aktiv – ist Discord verdeckt, friert der Stream ein.' : 'Discord läuft gerade nicht.';
    if (elev === true) { el.style.color = 'var(--pink)'; el.textContent += '  ⚠ Discord läuft mit Administrator-Rechten – Stream Deck und andere Programme kommen dann nicht heran. Mit dem Knopf unten startet es wieder normal.'; }
  }
  function showCrop(c, cap) {
    const el = $dc('dcCropInfo'); if (!el) return;
    el.style.color = '';
    if (c === 'full') el.textContent = 'Aktuell: das ganze Discord-Fenster.';
    else if (c) el.textContent = 'Aktuell: von Hand gewählt (' + Math.round(c.w * 100) + ' % × ' + Math.round(c.h * 100) + ' % des Fensters).';
    else el.textContent = 'Aktuell: automatisch – ' + (cap && cap.auto_crop ? 'Stream-Bild erkannt (' + Math.round(cap.auto_crop.w * 100) + ' % × ' + Math.round(cap.auto_crop.h * 100) + ' % des Fensters).' : 'A.R.I sucht, sobald die Kachel den Stream zeigt.');
  }
  function pickCrop() {
    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.88);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:16px;';
    ov.innerHTML = '<div style="color:#fff;font-size:13px;">Ziehe mit der Maus einen Rahmen um das Stream-Bild.</div>' +
      '<div style="position:relative;line-height:0;"><img id="dcPickImg" draggable="false" style="max-width:92vw;max-height:74vh;display:block;user-select:none;cursor:crosshair;">' +
      '<div id="dcPickRect" style="position:absolute;border:2px solid #29d3f5;background:rgba(41,211,245,.15);display:none;pointer-events:none;"></div></div>' +
      '<div id="dcPickMsg" style="color:#ff7a9c;font-size:12px;min-height:14px;"></div>' +
      '<div style="display:flex;gap:8px;"><button class="btn primary" id="dcPickOk" type="button">ÜBERNEHMEN</button><button class="btn" id="dcPickCancel" type="button">ABBRECHEN</button></div>';
    document.body.appendChild(ov);
    const im = ov.querySelector('#dcPickImg'), rect = ov.querySelector('#dcPickRect'), msg = ov.querySelector('#dcPickMsg');
    im.src = '/discord/frame?t=' + Date.now();
    let a = null, b = null;
    const pos = e => { const r = im.getBoundingClientRect(); return { x: Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), y: Math.min(1, Math.max(0, (e.clientY - r.top) / r.height)) }; };
    const box = () => ({ x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(a.x - b.x), h: Math.abs(a.y - b.y) });
    const draw = () => { if (!a || !b) return; const r = im.getBoundingClientRect(), q = box(); Object.assign(rect.style, { display: 'block', left: q.x * r.width + 'px', top: q.y * r.height + 'px', width: q.w * r.width + 'px', height: q.h * r.height + 'px' }); };
    im.addEventListener('pointerdown', e => { e.preventDefault(); a = pos(e); b = a; im.setPointerCapture(e.pointerId); draw(); });
    im.addEventListener('pointermove', e => { if (a && e.buttons) { b = pos(e); draw(); } });
    ov.querySelector('#dcPickCancel').onclick = () => ov.remove();
    ov.querySelector('#dcPickOk').onclick = async () => {
      if (!a || !b || box().w < 0.08 || box().h < 0.08) { msg.textContent = 'Bitte einen größeren Rahmen aufziehen.'; return; }
      const d = await saveOpts({ crop: box() });
      if (d && d.error) { msg.textContent = d.error; return; }
      showCrop(d.opts && d.opts.crop, null); ov.remove();
    };
  }
  async function loadOpts() {
    settingsOpenInfo = true;
    try {
      const d = await (await fetch('/discord/state')).json();
      const idEl = $dc('dcClientId'), secEl = $dc('dcClientSecret');   // gespeicherte Zugangsdaten anzeigen (Secret nie im Klartext)
      if (d.client_id && !idEl.value) idEl.value = d.client_id;
      secEl.placeholder = d.has_secret ? '●●●●●●●●●●●●●●●●  gespeichert (zum Ändern neu eingeben)' : 'wird nur auf diesem PC gespeichert';
      $dc('dcOptTr').checked = d.opts.translate !== false; showCrop(d.opts.crop, d.capture); showFix(d.fix, d.elevated); $dc('dcOptFix').checked = d.opts.auto_fix !== false; $dc('dcOptPop').checked = d.opts.auto_popout !== false; $dc('dcOptAuto').checked = d.opts.auto_live !== false; $dc('dcOptRoles').checked = !!d.opts.mentions_roles; $dc('dcOptEveryone').checked = !!d.opts.mentions_everyone;
      $dc('dcOptFps').value = d.opts.fps_mode; $dc('dcOptWidth').value = String(d.opts.width);
      fillStatusLine(d);
    } catch (e) {}
  }
  ARI_MODS.on('settings', loadOpts);
  const curOpts = () => ({ translate: $dc('dcOptTr').checked, auto_fix: $dc('dcOptFix').checked, auto_live: $dc('dcOptAuto').checked, auto_popout: $dc('dcOptPop').checked, mentions_roles: $dc('dcOptRoles').checked, mentions_everyone: $dc('dcOptEveryone').checked, fps_mode: $dc('dcOptFps').value, width: +$dc('dcOptWidth').value });
  const saveOpts = extra => dcPost('options', Object.assign(curOpts(), extra || {})).catch(() => ({ error: 'Das hat nicht geklappt – läuft der Hub?' }));
  ['dcOptTr', 'dcOptPop', 'dcOptFix', 'dcOptAuto', 'dcOptRoles', 'dcOptEveryone', 'dcOptFps', 'dcOptWidth'].forEach(id => $dc(id).addEventListener('change', () => saveOpts()));
  $dc('dcConnect').addEventListener('click', async () => {
    const msg = $dc('dcStatusLine'); msg.style.color = '';
    const id = $dc('dcClientId').value.trim(), sec = $dc('dcClientSecret').value.trim();
    msg.textContent = 'Wird gespeichert …';
    try {
      const d = sec ? await dcPost('configure', { client_id: id, client_secret: sec }) : await dcPost('connect');   // ohne neues Secret: mit den gespeicherten Daten verbinden
      if (d.error) { msg.style.color = 'var(--pink)'; msg.textContent = d.error; return; }
      $dc('dcClientSecret').value = '';
      msg.textContent = 'Gespeichert. Falls Discord fragt: bestätige auf „Autorisieren“.';
    } catch (e) { msg.style.color = 'var(--pink)'; msg.textContent = 'Das hat nicht geklappt – läuft der Hub?'; }
  });
  $dc('dcDetect').addEventListener('click', async () => { const d = await saveOpts({ crop: null }); if (d && !d.error) showCrop(null, null); });
  $dc('dcPick').addEventListener('click', pickCrop);
  $dc('dcFixBtn').addEventListener('click', async () => {
    let ok = false;
    try {
      ok = await ariConfirm('Discord neu starten?', 'Discord wird beendet und gleich mit dem Stream-Fix wieder gestartet. Du verlässt dabei kurz den Sprachkanal und den Stream. Es wird keine Verknüpfung verändert.', 'JA, NEU STARTEN', 'ABBRECHEN');
    } catch (e) {}
    if (!ok) return;
    const el = $dc('dcFixInfo'); el.style.color = ''; el.textContent = 'Discord wird neu gestartet …';
    try {
      const d = await dcPost('fix', { confirm: true });
      if (d.error) { el.style.color = 'var(--pink)'; el.textContent = d.error; return; }
      el.textContent = 'Discord startet neu – A.R.I verbindet sich gleich wieder.';
      setTimeout(loadOpts, 15000);
    } catch (e) { el.style.color = 'var(--pink)'; el.textContent = 'Das hat nicht geklappt – läuft der Hub?'; }
  });
  $dc('dcFull').addEventListener('click', async () => { const d = await saveOpts({ crop: 'full' }); if (d && !d.error) showCrop('full'); });
  $dc('dcAuto').addEventListener('click', () => { closeSettings(); if (window.__ariAutoSetup) window.__ariAutoSetup.start('discord'); else logLine('error', 'Die automatische Einrichtung ist nicht verfügbar.'); });
  $dc('dcDisconnect').addEventListener('click', async () => { try { await dcPost('disconnect'); $dc('dcStatusLine').textContent = 'Getrennt.'; } catch (e) {} });

  // ---- DEV-Tests ----
  ARI_MODS.slot('modSlotDev', `<details class="dev-group"><summary>DISCORD</summary><div class="dev-tests">
      <button class="btn" type="button" data-dcdev="voice">SPRACHKANAL MIT LEUTEN</button>
      <button class="btn" type="button" data-dcdev="voice-clear">KEIN SPRACHKANAL</button>
      <button class="btn" type="button" data-dcdev="dm">PRIVATE NACHRICHT</button>
      <button class="btn" type="button" data-dcdev="mention">ERWÄHNUNG</button>
      <button class="btn" type="button" data-dcdev="testbild">STREAM: TESTBILD</button>
      <button class="btn" type="button" data-dcdev="error">FEHLERMELDUNG</button>
      <button class="btn" type="button" data-dcdev="reset">ZURÜCKSETZEN</button>
    </div></details>`);
  document.querySelectorAll('[data-dcdev]').forEach(b => b.addEventListener('click', async () => {
    const what = b.dataset.dcdev;
    try {
      await dcPost('dev/' + what, { on: true });
      if (what === 'testbild' && window.__dcSetView) { closeSettings(); window.__dcSetView('stream'); logLine('system', 'Test: Das Testbild läuft jetzt in der Planeten-Kachel (⇄ schaltet zurück).'); }
      if (what === 'dm' || what === 'mention') { closeSettings(); logLine('system', 'Test: Die Nachricht erscheint gleich unter Benachrichtigungen.'); }
      if (what === 'reset' && window.__dcSetView) window.__dcSetView('planet');
    } catch (e) { logLine('error', 'Discord-Test fehlgeschlagen.'); }
  }));


  // Uebersetzer: neue Discord-Meldungen in anderer Sprache bekommen eine deutsche Uebersetzung (Meldung, Dialog und Vorlesen nutzen sie)
  let trOn = true;
  ARI_MODS.on('status', d => { if (d.discord && d.discord.opts) trOn = d.discord.opts.translate !== false; });
  ARI_MODS.on('notif', async n => {
    if (!trOn || !/discord/i.test(String(n.app || '')) || !n.text) return;
    try {
      const gk = settings.apiKeys.gemini || '';
      const prov = settings.provider;
      const r = await dcPost('translate', { text: n.text, gemini_api_key: gk, provider: prov, api_key: prov === 'groq' ? '' : (settings.apiKeys[prov] || ''), groq_api_keys: (settings.apiKeys.groq || []).filter(Boolean) });
      if (r && r.translation) { n.translation = r.translation; n.origLang = r.lang || ''; }
    } catch (e) {}
  });
})();
