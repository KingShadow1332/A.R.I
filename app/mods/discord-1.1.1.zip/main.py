# Mod "Discord": Sprachkanal-Kachel, private/erwaehnte Nachrichten, Stream-Spiegel.
# Spricht ueber die lokale RPC-Schnittstelle (Named Pipe) mit der laufenden Discord-App - ohne Bot und ohne Token-Weitergabe an Dritte.
# Alle Namen des Hubs (app, psutil, _load_secrets, _PHONE_NOTIFS ...) stehen hier schon zur Verfuegung (siehe _mods_load im Hub).
import struct
import uuid
import ctypes.wintypes
import io as _io
import urllib.parse as _urlparse

_DC_OPTS_DEFAULT = {"mentions_roles": False, "mentions_everyone": False, "fps_mode": "schonend", "width": 1280, "auto_live": True, "crop": None, "auto_fix": False, "translate": True, "auto_popout": True}
_DC_SCOPES = ["rpc", "rpc.notifications.read", "identify"]
_DC_REDIRECT = "http://localhost"
_DC_LOCK = threading.RLock()
_DC = {
    "gen": 0, "status": "aus", "error": "", "connected": False, "authorized": False, "me": None,
    "channel": None, "server": "", "members": {}, "speaking": set(), "sub_channel": None, "thread": None,
}
_DC_OPEN = None   # Test-Haken: Funktion, die statt der Named Pipe eine Verbindung (read/write) liefert


# ---------------------------------------------------------------- Einstellungen ----
def _dc_cfg():
    return dict(_load_secrets().get("discord") or {})


def _dc_opts():
    o = dict(_DC_OPTS_DEFAULT)
    o.update((_dc_cfg().get("opts") or {}))
    return o


def _dc_set(**kw):
    with _DC_LOCK:
        _DC.update(kw)


# ------------------------------------------------------------------ RPC-Verbindung ----
class _DcConn:
    """Eine Verbindung zur Discord-App. Alles laeuft in EINEM Thread (lesen und schreiben abwechselnd) - eine Named Pipe mit
    synchronem Handle verklemmt sich sonst, wenn ein Thread liest, waehrend ein anderer schreibt."""

    def __init__(self, io, gen):
        self.io, self.gen, self.queue = io, gen, []

    def _read_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.io.read(n - len(buf))
            if not chunk:
                raise ConnectionError("Verbindung zu Discord beendet")
            buf += chunk
        return buf

    def send(self, op, payload):
        data = json.dumps(payload).encode("utf-8")
        self.io.write(struct.pack("<II", op, len(data)) + data)
        try:
            self.io.flush()
        except Exception:
            pass

    def recv(self):
        op, ln = struct.unpack("<II", self._read_exact(8))
        raw = self._read_exact(ln) if ln else b"{}"
        return op, json.loads(raw.decode("utf-8", errors="replace") or "{}")

    def call(self, cmd, args=None, evt=None):
        """Befehl senden und auf die passende Antwort warten; zwischendurch eintreffende Ereignisse kommen in die Warteschlange."""
        nonce = uuid.uuid4().hex
        msg = {"cmd": cmd, "nonce": nonce, "args": args or {}}
        if evt:
            msg["evt"] = evt
        self.send(1, msg)
        while True:
            op, d = self.recv()
            if op == 3:
                self.send(4, d)
                continue
            if op == 2:
                raise ConnectionError("Discord hat die Verbindung geschlossen")
            if d.get("nonce") == nonce:
                if d.get("evt") == "ERROR":
                    dd = d.get("data") or {}
                    raise _DcError(dd.get("code"), dd.get("message") or "")
                return d.get("data")
            if d.get("cmd") == "DISPATCH":
                self.queue.append(d)


class _DcError(Exception):
    def __init__(self, code, message):
        super().__init__(f"{code}: {message}")
        self.code, self.message = code, message


def _dc_open_pipe():
    if _DC_OPEN:
        return _DC_OPEN()
    last = None
    for i in range(10):
        try:
            f = open(r"\\?\pipe\discord-ipc-%d" % i, "r+b", buffering=0)
            return f
        except OSError as e:
            last = e
    raise ConnectionError("Discord läuft nicht") from last


def _dc_token_request(form):
    data = _urlparse.urlencode(form).encode("utf-8")
    req = urllib.request.Request("https://discord.com/api/oauth2/token", data=data, headers={"Content-Type": "application/x-www-form-urlencoded", "User-Agent": "A.R.I"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _dc_save_token(tok):
    exp = int(time.time()) + int(tok.get("expires_in") or 3600)
    _update_secrets("discord", lambda old: {**(old or {}), "token": {"access": tok["access_token"], "refresh": tok.get("refresh_token", ""), "expires_at": exp}})


def _dc_get_access_token(conn, cfg):
    """Gueltiges Token liefern: gespeichert, erneuert oder (beim ersten Mal) ueber AUTHORIZE - dann bestaetigt der Nutzer selbst in Discord."""
    tok = cfg.get("token") or {}
    if tok.get("access") and int(tok.get("expires_at", 0)) > time.time() + 120:
        return tok["access"]
    if tok.get("refresh"):
        try:
            new = _dc_token_request({"client_id": cfg["client_id"], "client_secret": cfg["client_secret"], "grant_type": "refresh_token", "refresh_token": tok["refresh"]})
            _dc_save_token(new)
            return new["access_token"]
        except Exception as e:
            print(f"[mod:discord] Token-Erneuerung: {e}")
    _dc_set(status="warte-bestaetigung", error="")
    d = conn.call("AUTHORIZE", {"client_id": cfg["client_id"], "scopes": _DC_SCOPES})
    new = _dc_token_request({"client_id": cfg["client_id"], "client_secret": cfg["client_secret"], "grant_type": "authorization_code", "code": d["code"], "redirect_uri": _DC_REDIRECT})
    _dc_save_token(new)
    return new["access_token"]


def _dc_friendly(e):
    s = str(e)
    if isinstance(e, _DcError):
        if e.code == 5000 or "denied" in s.lower() or "cancel" in s.lower():
            return "Du hast die Verbindung in Discord abgelehnt."
        if e.code in (4006, 4009):
            return "Die Anmeldung bei Discord ist abgelaufen. Bitte neu verbinden."
        return "Discord hat die Anfrage abgelehnt."
    if isinstance(e, urllib.error.HTTPError):
        return "Client-ID, Secret oder Weiterleitung (http://localhost) stimmen nicht."
    if isinstance(e, (ConnectionError, OSError)):
        return "Discord läuft nicht oder wurde beendet."
    return "Die Verbindung zu Discord hat nicht geklappt."


# ------------------------------------------------------------------ Zustand / Ereignisse ----
def _dc_avatar(user):
    uid, av = str(user.get("id") or ""), user.get("avatar")
    if uid and av:
        return f"https://cdn.discordapp.com/avatars/{uid}/{av}.png?size=64"
    try:
        return f"https://cdn.discordapp.com/embed/avatars/{(int(uid) >> 22) % 6}.png"
    except ValueError:
        return ""


def _dc_member(entry):
    u = entry.get("user") or {}
    vs = entry.get("voice_state") or {}
    uid = str(u.get("id") or "")
    return uid, {"id": uid, "name": str(entry.get("nick") or u.get("global_name") or u.get("username") or "?")[:40], "avatar": _dc_avatar(u),
                 "muted": bool(vs.get("self_mute") or vs.get("mute") or entry.get("mute")), "deaf": bool(vs.get("self_deaf") or vs.get("deaf"))}


def _dc_load_channel(conn):
    """Aktuellen Sprachkanal samt Leuten lesen und die Ereignisse dieses Kanals abonnieren."""
    old = _DC.get("sub_channel")
    if old:
        for evt in ("VOICE_STATE_CREATE", "VOICE_STATE_UPDATE", "VOICE_STATE_DELETE", "SPEAKING_START", "SPEAKING_STOP"):
            try:
                conn.call("UNSUBSCRIBE", {"channel_id": old}, evt)
            except Exception:
                pass
    ch = conn.call("GET_SELECTED_VOICE_CHANNEL")
    if not ch:
        _dc_set(channel=None, server="", members={}, speaking=set(), sub_channel=None)
        return
    server = ""
    if ch.get("guild_id"):
        try:
            server = str((conn.call("GET_GUILD", {"guild_id": ch["guild_id"]}) or {}).get("name") or "")
        except Exception:
            server = ""
    else:
        server = "Privatanruf"
    members = dict(_dc_member(e) for e in (ch.get("voice_states") or []))
    _dc_set(channel=str(ch.get("name") or "Sprachkanal")[:60], server=server[:60], members=members, speaking=set(), sub_channel=ch["id"])
    for evt in ("VOICE_STATE_CREATE", "VOICE_STATE_UPDATE", "VOICE_STATE_DELETE", "SPEAKING_START", "SPEAKING_STOP"):
        conn.call("SUBSCRIBE", {"channel_id": ch["id"]}, evt)


def _dc_push_notification(author, channel_label, text, key, kind, open_url=""):
    """Eintrag in die Benachrichtigungen legen - mit denselben Schutzmassnahmen wie die Handy-Meldungen."""
    now = int(time.time())
    app_name = "Discord"
    if app_name in _phone_notif_blocked_apps():
        return False
    title = author if kind == "dm" else f"{author} ({channel_label})" if channel_label else author
    text = text.strip()[:300] or "(Anhang)"
    for t in list(_PHONE_TOMB):
        if t["app"] == app_name and t["title"] == title and t["text"] == text and now - t["ts"] < 600:
            return False
    def _norm(t):
        return re.sub(r"[^a-z0-9äöüß]+", " ", str(t).lower()).strip()
    nt = _norm(text)
    for n in _PHONE_NOTIFS:
        if n["key"] == key:
            return False
        if "discord" in n["app"].lower() and now - n["ts"] < 150:
            ot = _norm(n["text"])
            if ot and nt and (ot == nt or (min(len(ot), len(nt)) >= 8 and (ot in nt or nt in ot))):
                return False   # dieselbe Nachricht kam schon vom Handy (oder doppelt)
    _PHONE_NOTIFS.append({"id": _pysecrets.token_hex(6), "app": app_name, "title": title[:200], "text": text, "ts": now, "key": key, "can_reply": False, "open_url": open_url})
    del _PHONE_NOTIFS[:-_PHONE_NOTIFS_MAX]
    return True


def _dc_clean_text(text, mentions):
    names = {str(m.get("id")): (m.get("global_name") or m.get("username") or "") for m in (mentions or [])}
    return re.sub(r"<@!?(\d+)>", lambda m: "@" + (names.get(m.group(1)) or "jemand"), text or "")


def _dc_handle_notification(conn, data):
    msg = data.get("message") or {}
    author = msg.get("author") or {}
    me = (_DC.get("me") or {}).get("id")
    if not me or str(author.get("id")) == str(me):
        return
    opts = _dc_opts()
    mentions = [str(m.get("id")) for m in (msg.get("mentions") or [])]
    mentioned = str(me) in mentions or (opts["mentions_everyone"] and bool(msg.get("mention_everyone"))) or (opts["mentions_roles"] and bool(msg.get("mention_roles")))
    kind, label, open_url = "", "", ""
    try:
        ch = conn.call("GET_CHANNEL", {"channel_id": data.get("channel_id")}) or {}
        if ch.get("type") in (1, 3):
            kind = "dm"
        label = ("#" + str(ch.get("name"))) if ch.get("name") else ""
        cid, gid = str(ch.get("id") or data.get("channel_id") or ""), str(ch.get("guild_id") or "")
        if re.fullmatch(r"\d{5,25}", cid):   # Link, der genau diese Unterhaltung in Discord oeffnet
            open_url = f"discord://-/channels/{gid if re.fullmatch(r'[0-9]{5,25}', gid) else '@me'}/{cid}"
    except Exception:
        pass
    if kind != "dm" and not mentioned:
        return   # weder privat noch erwaehnt
    name = str(author.get("global_name") or author.get("username") or data.get("title") or "Discord")
    text = _dc_clean_text(msg.get("content") or data.get("body") or "", msg.get("mentions"))
    key = "discord:" + str(msg.get("id") or uuid.uuid4().hex)
    # 4 s warten: kommt dieselbe Nachricht vom Handy (mit Antwort-Knopf), bleibt die Handy-Meldung - so kann man direkt aus dem HUD antworten
    threading.Timer(4.0, _dc_push_notification, args=(name, label, text, key, kind or "mention", open_url)).start()


def _dc_handle_event(conn, d):
    evt, data = d.get("evt"), d.get("data") or {}
    if evt == "VOICE_CHANNEL_SELECT":
        _dc_load_channel(conn)
    elif evt in ("VOICE_STATE_CREATE", "VOICE_STATE_UPDATE"):
        uid, m = _dc_member(data)
        with _DC_LOCK:
            _DC["members"][uid] = m
    elif evt == "VOICE_STATE_DELETE":
        uid, _m = _dc_member(data)
        with _DC_LOCK:
            _DC["members"].pop(uid, None)
            _DC["speaking"].discard(uid)
    elif evt == "SPEAKING_START":
        with _DC_LOCK:
            _DC["speaking"].add(str(data.get("user_id")))
    elif evt == "SPEAKING_STOP":
        with _DC_LOCK:
            _DC["speaking"].discard(str(data.get("user_id")))
    elif evt == "NOTIFICATION_CREATE":
        _dc_handle_notification(conn, data)


def _dc_session(gen):
    """Eine komplette Sitzung: verbinden, anmelden, abonnieren, Ereignisse verarbeiten. Endet bei Fehler oder wenn gen veraltet ist."""
    cfg = _dc_cfg()
    io = _dc_open_pipe()
    conn = _DcConn(io, gen)
    try:
        conn.send(0, {"v": 1, "client_id": str(cfg["client_id"])})
        while True:
            op, d = conn.recv()
            if d.get("evt") == "READY":
                break
            if d.get("evt") == "ERROR":
                raise _DcError((d.get("data") or {}).get("code"), "")
        _dc_set(connected=True, status="anmelden", error="")
        token = _dc_get_access_token(conn, cfg)
        auth = conn.call("AUTHENTICATE", {"access_token": token}) or {}
        me = auth.get("user") or {}
        _dc_set(authorized=True, me={"id": str(me.get("id")), "name": str(me.get("global_name") or me.get("username") or "")}, status="verbunden", error="")
        for evt in ("VOICE_CHANNEL_SELECT", "NOTIFICATION_CREATE"):
            conn.call("SUBSCRIBE", {}, evt)
        _dc_load_channel(conn)
        while _DC["gen"] == gen:
            op, d = conn.recv()
            if op == 3:
                conn.send(4, d)
            elif op == 2:
                raise ConnectionError("geschlossen")
            elif d.get("cmd") == "DISPATCH":
                _dc_handle_event(conn, d)
            while conn.queue:
                _dc_handle_event(conn, conn.queue.pop(0))
    finally:
        try:
            io.close()
        except Exception:
            pass
        if _DC["gen"] == gen:
            _dc_set(connected=False, authorized=False, channel=None, server="", members={}, speaking=set(), sub_channel=None)


def _dc_loop(gen):
    """Haelt die Verbindung am Leben: Discord nicht da -> alle 10 s neu versuchen; bei Anmeldefehlern nicht endlos wiederholen."""
    while _DC["gen"] == gen:
        cfg = _dc_cfg()
        if not cfg.get("client_id") or not cfg.get("client_secret"):
            _dc_set(status="nicht-eingerichtet", error="")
            return
        try:
            _dc_set(status="suche")
            _dc_session(gen)
        except Exception as e:
            if _DC["gen"] != gen:
                return
            msg = _dc_friendly(e)
            print(f"[mod:discord] {type(e).__name__}: {e}")
            if isinstance(e, (_DcError, urllib.error.HTTPError)):
                _dc_set(status="fehler", error=msg)
                return   # Zugangsdaten/Ablehnung: erst nach neuem Klick auf VERBINDEN weiter
            _dc_set(status="warten", error=msg)
        for _ in range(100):   # 10 s warten, aber abbrechbar
            if _DC["gen"] != gen:
                return
            time.sleep(0.1)


def _dc_start():
    with _DC_LOCK:
        _DC["gen"] += 1
        gen = _DC["gen"]
    t = threading.Thread(target=_dc_loop, args=(gen,), daemon=True)
    _DC["thread"] = t
    t.start()


def _dc_stop():
    with _DC_LOCK:
        _DC["gen"] += 1
        _DC.update(connected=False, authorized=False, channel=None, server="", members={}, speaking=set(), sub_channel=None, status="aus", error="")


def _dc_public():
    with _DC_LOCK:
        cfg = _dc_cfg()
        members = [dict(m, speaking=(uid in _DC["speaking"])) for uid, m in _DC["members"].items()]
        members.sort(key=lambda m: m["name"].lower())
        status = "verbunden" if (_DC["connected"] and _DC["authorized"] and _DC["status"] in ("aus", "suche", "warten", "anmelden")) else _DC["status"]
        return {"status": status, "error": _DC["error"], "connected": _DC["connected"], "authorized": _DC["authorized"], "me": (_DC["me"] or {}).get("name", ""),
                "client_id": str(cfg.get("client_id") or ""), "has_secret": bool(cfg.get("client_secret")),
                "channel": _DC["channel"], "server": _DC["server"], "members": members, "configured": bool(cfg.get("client_id") and cfg.get("client_secret")),
                "opts": _dc_opts(), "capture": _DCCAP.info(), "fix": _dc_fix_active(), "autostart": _dc_autostart_state(), "elevated": _dc_elevated()}


# ------------------------------------------------------------- Stream-Fix: Discord laeuft auch verdeckt weiter ----
# Discord (Chrome-Technik) hoert auf zu zeichnen, wenn sein Fenster ganz verdeckt ist - der Stream friert dann ein. Mit dieser Startoption
# schaltet Discord das ab. A.R.I startet Discord auf Wunsch selbst damit neu (keine Verknuepfung wird veraendert).
_DC_FIX_FLAG = "--disable-features=CalculateNativeWinOcclusion"
_dc_fix_cache = {"ts": 0.0, "val": None}


def _dc_fix_active(fresh=False):
    """True/False = laufendes Discord hat die Option / hat sie nicht; None = Discord laeuft nicht. Kurz zwischengespeichert."""
    now = time.time()
    if not fresh and now - _dc_fix_cache["ts"] < 20:
        return _dc_fix_cache["val"]
    val = None
    try:
        for p in psutil.process_iter(["name", "cmdline"]):
            if (p.info["name"] or "").lower() == "discord.exe":
                val = bool(val) or any(_DC_FIX_FLAG in (a or "") for a in (p.info["cmdline"] or []))
                if val:
                    break
                val = False
    except Exception:
        val = None
    _dc_fix_cache.update(ts=now, val=val)
    return val


_DC_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def _dc_autostart_state():
    """'ok' = Discord startet beim Windows-Start schon mit dem Stream-Fix, 'fehlt' = Eintrag ohne Fix, 'keiner' = kein Autostart-Eintrag, 'fremd' = unbekanntes Format."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _DC_RUN_KEY, 0, winreg.KEY_READ) as k:
            val, _typ = winreg.QueryValueEx(k, "Discord")
    except FileNotFoundError:
        return "keiner"
    except Exception:
        return "fremd"
    if _DC_FIX_FLAG in str(val):
        return "ok"
    return "fehlt" if ("Update.exe" in str(val) and "--processStart" in str(val)) else "fremd"


def _dc_autostart_apply(on=True):
    """Windows-Autostart von Discord: Stream-Fix anhaengen (on) bzw. den urspruenglichen Eintrag wiederherstellen (off). Der alte Wert wird vorher gesichert."""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _DC_RUN_KEY, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
            val, typ = winreg.QueryValueEx(k, "Discord")
            val = str(val)
            if on:
                if _DC_FIX_FLAG in val:
                    return "ok"
                if "Update.exe" not in val or "--processStart" not in val:
                    return "fremd"   # unbekanntes Format: nichts anfassen
                if not _dc_cfg().get("autostart_backup"):
                    _update_secrets("discord", lambda old: {**(old or {}), "autostart_backup": val})
                winreg.SetValueEx(k, "Discord", 0, typ, val + ' --process-start-args "' + _DC_FIX_FLAG + '"')
                print("[mod:discord] Autostart von Discord mit dem Stream-Fix eingerichtet.")
                return "ok"
            old = _dc_cfg().get("autostart_backup")
            if old and _DC_FIX_FLAG in val:
                winreg.SetValueEx(k, "Discord", 0, typ, old)
                print("[mod:discord] Autostart von Discord wiederhergestellt.")
            return "fehlt"
    except FileNotFoundError:
        return "keiner"
    except Exception as e:
        print(f"[mod:discord] Autostart: {type(e).__name__}: {e}")
        return "fremd"


def _dc_elevated():
    """True = Discord laeuft mit Administrator-Rechten (dann kommen Stream Deck & Co. nicht mehr heran), False = normal, None = Discord laeuft nicht / unbekannt."""
    try:
        adv, k32 = ctypes.windll.advapi32, ctypes.windll.kernel32
        seen = None
        for p in psutil.process_iter(["name", "pid"]):
            if (p.info["name"] or "").lower() != "discord.exe":
                continue
            hproc = k32.OpenProcess(0x1000, False, p.info["pid"])
            if not hproc:
                seen = True if seen is None else seen   # Zugriff verweigert = hoeher berechtigter Prozess
                continue
            tok = ctypes.wintypes.HANDLE()
            if adv.OpenProcessToken(hproc, 0x8, ctypes.byref(tok)):
                el, sz = ctypes.wintypes.DWORD(), ctypes.wintypes.DWORD()
                if adv.GetTokenInformation(tok, 20, ctypes.byref(el), 4, ctypes.byref(sz)) and el.value:
                    k32.CloseHandle(tok)
                    k32.CloseHandle(hproc)
                    return True
                k32.CloseHandle(tok)
                seen = False if seen is None else seen
            k32.CloseHandle(hproc)
        return seen
    except Exception:
        return None


def _dc_launch_normal(update, args):
    """Startet ein Programm ueber den Explorer (normale Benutzerrechte) - als Kind des Administrator-Hubs wuerde es selbst Administrator-Rechte bekommen."""
    lnk = os.path.join(DATA_DIR, "discord-start.lnk")
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + lnk.replace("'", "''") + "'); $s.TargetPath='" + update.replace("'", "''") +
          "'; $s.Arguments='" + args.replace("'", "''") + "'; $s.WorkingDirectory='" + os.path.dirname(update).replace("'", "''") + "'; $s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps], timeout=25, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    subprocess.Popen(["explorer.exe", lnk])


def _dc_restart_with_fix(dry_run=False):
    """Beendet Discord und startet es mit der Option neu (ueber Update.exe, wie die Verknuepfungen). Gibt (ok, meldung) zurueck."""
    update = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Discord", "Update.exe")
    if not os.path.exists(update):
        return False, "Discord ist nicht an der üblichen Stelle installiert."
    cmd = [update, "--processStart", "Discord.exe", "--process-start-args", _DC_FIX_FLAG]
    if dry_run:
        return True, " ".join(cmd)
    procs = [p for p in psutil.process_iter(["name"]) if (p.info["name"] or "").lower() == "discord.exe"]
    for p in procs:
        try:
            p.terminate()
        except Exception:
            pass
    gone, alive = psutil.wait_procs(procs, timeout=8)
    for p in alive:
        try:
            p.kill()
        except Exception:
            pass
    time.sleep(1.0)
    try:
        _dc_launch_normal(update, '--processStart Discord.exe --process-start-args "' + _DC_FIX_FLAG + '"')
    except Exception as e:
        print(f"[mod:discord] Neustart: {e}")
        return False, "Discord konnte nicht gestartet werden."
    _dc_fix_cache.update(ts=0.0, val=None)
    return True, "Discord startet neu."


# ------------------------------------------------------------------ Stream-Spiegel (Fenster von Discord) ----
_FPS_STAGES = [60, 45, 30, 20, 10]


def _dc_find_window():
    """Hauptfenster von Discord.exe (Titel endet auf "Discord", sonst das groesste) -> (hwnd, titel) oder None."""
    wins = _dc_windows()
    if not wins:
        return None
    main = [w for w in wins if w[2].rstrip().lower().endswith("discord")]
    pick = max(main or wins)
    return pick[1], pick[2]


def _dc_find_popout():
    """Pop-out-Fenster des Streams (ein weiteres Discord-Fenster neben dem Hauptfenster, nur der Stream) -> (hwnd, titel) oder None."""
    wins = _dc_windows()
    main = _dc_find_window()
    others = [w for w in wins if main and w[1] != main[0] and w[0] >= 200 * 120]
    if not others:
        return None
    pick = max(others)
    return pick[1], pick[2]


def _dc_hud_hwnd():
    """Fenster des A.R.I-HUDs (hwnd) oder 0."""
    user32 = ctypes.windll.user32
    hud = []
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(h, _):
        if user32.IsWindowVisible(h):
            n = user32.GetWindowTextLengthW(h)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(h, buf, n + 1)
            if buf.value.startswith("A.R.I") and "Command Center" in buf.value:
                hud.append(h)
        return True
    user32.EnumWindows(EnumProc(cb), 0)
    return hud[0] if hud else 0


_DC_EMBED = {"rect": None, "ts": 0.0, "popout": False, "sig": None}


class _DwmProps(ctypes.Structure):
    _fields_ = [("flags", ctypes.c_ulong), ("dest", ctypes.wintypes.RECT), ("src", ctypes.wintypes.RECT), ("opacity", ctypes.c_ubyte),
                ("visible", ctypes.c_int), ("client_only", ctypes.c_int)]


_DC_OV = {"hwnd": 0, "proc": None}


def _dc_overlay(slot="hwnd"):
    """Kleines rahmenloses Fenster, das die Vorschau eines HUD-Ausschnitts zeigt (Streifen ueber der Titelleiste, Astro). Windows erlaubt Vorschauen nur im eigenen Prozess."""
    if _DC_OV.get(slot) and ctypes.windll.user32.IsWindow(_DC_OV[slot]):
        return _DC_OV[slot]
    user32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t)
    user32.DefWindowProcW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
    user32.DefWindowProcW.restype = ctypes.c_ssize_t
    if not _DC_OV.get("proc"):
        _DC_OV["proc"] = WNDPROC(lambda h, m, w, l: user32.DefWindowProcW(h, m, w, l))   # am Leben halten (die Fensterklasse zeigt dauerhaft darauf)
    proc = _DC_OV["proc"]

    class WNDCLASS(ctypes.Structure):
        _fields_ = [("style", ctypes.c_uint), ("proc", WNDPROC), ("cb", ctypes.c_int), ("wnd", ctypes.c_int), ("inst", ctypes.c_void_p), ("icon", ctypes.c_void_p),
                    ("cursor", ctypes.c_void_p), ("bg", ctypes.c_void_p), ("menu", ctypes.c_wchar_p), ("name", ctypes.c_wchar_p)]
    wc = WNDCLASS()
    wc.proc = proc
    wc.inst = k32.GetModuleHandleW(None)
    wc.name = "AriDiscordStream"
    wc.bg = ctypes.windll.gdi32.GetStockObject(4)   # BLACK_BRUSH
    user32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASS)]
    if not _DC_OV.get("cls"):
        user32.RegisterClassW(ctypes.byref(wc))
        _DC_OV["cls"] = True
    user32.CreateWindowExW.restype = ctypes.c_void_p
    user32.CreateWindowExW.argtypes = [ctypes.c_ulong, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                       ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    # WS_POPUP | TOOLWINDOW | NOACTIVATE | LAYERED (fängt Klicks ab)
    h = user32.CreateWindowExW(0x80 | 0x08000000 | 0x80000, "AriDiscordStream", "", 0x80000000, 0, 0, 10, 10, None, None, wc.inst, None)
    if h and slot == "hwnd":
        user32.SetLayeredWindowAttributes(ctypes.c_void_p(h), 0, 255, 2)
    _DC_OV[slot] = h or 0
    return _DC_OV[slot]


def _dc_thumb_drop():
    th = _DC_EMBED.pop("thumb", None)
    if th:
        try:
            ctypes.windll.dwmapi.DwmUnregisterThumbnail(ctypes.c_void_p(th))
        except Exception:
            pass
    _DC_EMBED["thumb_key"] = None
    for sl in ("hwnd", "mascot"):
        if _DC_OV.get(sl):
            ctypes.windll.user32.ShowWindow(ctypes.c_void_p(_DC_OV[sl]), 0)
    _DC_EMBED["sprite_done"] = None


def _dc_click_main(hwnd, off_right, off_bottom):
    """Klick ins Discord-Hauptfenster, OHNE die echte Maus zu bewegen (Nachricht direkt an die Chromium-Flaeche). off_* = Abstand von rechts/unten in Pixeln bei 100 %."""
    user32 = ctypes.windll.user32
    kids = []
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(h, _):
        cls = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(h, cls, 64)
        if cls.value == "Chrome_RenderWidgetHostHWND":
            kids.append(h)
        return True
    user32.EnumChildWindows(hwnd, EnumProc(cb), 0)
    if not kids:
        return False
    tgt = kids[0]
    cr = ctypes.wintypes.RECT()
    user32.GetClientRect(tgt, ctypes.byref(cr))
    try:
        sc = (user32.GetDpiForWindow(hwnd) or 96) / 96.0
    except Exception:
        sc = 1.0
    x, y = int(cr.right - off_right * sc), int(cr.bottom - off_bottom * sc)
    lp = (y << 16) | (x & 0xFFFF)
    user32.PostMessageW(ctypes.c_void_p(tgt), 0x200, 0, lp)   # WM_MOUSEMOVE: Knoepfe einblenden
    time.sleep(0.15)
    user32.PostMessageW(ctypes.c_void_p(tgt), 0x200, 0, lp)
    user32.PostMessageW(ctypes.c_void_p(tgt), 0x201, 1, lp)   # WM_LBUTTONDOWN
    time.sleep(0.06)
    user32.PostMessageW(ctypes.c_void_p(tgt), 0x202, 0, lp)   # WM_LBUTTONUP
    return True


def _dc_autopop_loop():
    """Laeuft ein Stream im Discord-Hauptfenster (bewegtes Bild auf schwarzer Buehne), wird er per Klick auf den Pop-out-Knopf von selbst herausgeloest."""
    try:
        ctypes.windll.user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    import numpy as np
    user32 = ctypes.windll.user32
    last_try, tries = 0.0, 0
    still_since = time.time()
    while True:
        time.sleep(1.0)
        try:
            if not _dc_opts().get("auto_popout", True) or not _DC.get("channel") or _dc_find_popout():
                tries = 0 if not _dc_find_popout() else tries
                continue
            found = _dc_find_window()
            if not found or user32.IsIconic(found[0]):
                continue
            hwnd = found[0]
            a = _WGC.get(hwnd)
            if a is None:
                continue
            with _WGC.lock:
                _WGC._stop()   # nur kurz aufnehmen
            H, W = a.shape[:2]
            reg = a[:90, int(W * 0.3):, :3].astype("int16")   # Kopfleiste der Stream-Ansicht rechts: rotes "LIVE"-Schild (BGRA: Kanal 2 = Rot)
            red = ((reg[..., 2] > 180) & (reg[..., 1] < 90) & (reg[..., 0] < 100) & (reg[..., 2] - reg[..., 1] > 110)).sum()
            black = float((a[::8, ::8, :3].sum(axis=2) < 36).mean())
            if red > 120 and black > 0.15:
                still_since = time.time()
                if time.time() - last_try > 12 and tries < 3:   # hoechstens zweimal je Stream, mit Pause
                    last_try = time.time()
                    tries += 1
                    _dc_click_main(hwnd, 72, 42)   # Pop-out-Knopf unten rechts am Stream
                    print("[mod:discord] Stream erkannt: Pop-out wird geoeffnet.")
            elif time.time() - still_since > 30:
                tries = 0
        except Exception as e:
            print(f"[mod:discord] Auto-Pop-out: {type(e).__name__}: {e}")


def _dc_embed_place(hwnd, hud, rect):
    """Das Pop-out-Fenster wird direkt benutzt (echtes Fenster, bedienbar, laeuft normal): es liegt genau ueber der Hauptkachel des HUDs und gehoert dem HUD.
    Seine Titelleiste ragt oben ueber die Kachel hinaus; ein Streifen mit der Vorschau des HUD-Hintergrunds deckt sie unsichtbar ab.
    rect = (x, y, b, h) der Kachel in Pixeln des HUD-Fensterinhalts."""
    user32, dwm = ctypes.windll.user32, ctypes.windll.dwmapi
    if user32.IsIconic(hwnd) or user32.IsZoomed(hwnd):
        user32.ShowWindow(hwnd, 9)   # SW_RESTORE
    try:
        dpi = user32.GetDpiForWindow(hwnd) or 96
    except Exception:
        dpi = 96
    bar = int(round(26 * dpi / 96))   # Discords eigene Titelleiste im Fensterinhalt
    ov = _dc_overlay()
    if not ov:
        return
    pt = ctypes.wintypes.POINT(0, 0)
    user32.ClientToScreen(hud, ctypes.byref(pt))
    x, y, w, h = [int(float(v)) for v in rect]
    if y < bar:
        return False
    class _MI(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_ulong), ("rc", ctypes.wintypes.RECT), ("work", ctypes.wintypes.RECT), ("fl", ctypes.c_ulong)]
    mi = _MI()
    mi.cb = ctypes.sizeof(_MI)
    mon = user32.MonitorFromWindow(ctypes.c_void_p(hud), 2)
    cl, hr = ctypes.wintypes.RECT(), ctypes.wintypes.RECT()
    user32.GetClientRect(ctypes.c_void_p(hud), ctypes.byref(cl))
    if mon and user32.GetMonitorInfoW(ctypes.c_void_p(mon), ctypes.byref(mi)):
        # Kachel (samt Titelleiste darueber) muss ganz auf dem Monitor UND im sichtbaren HUD liegen, sonst ragt das Fenster heraus
        l, t, rr, b = pt.x + x, pt.y + y - bar, pt.x + x + w, pt.y + y + h
        if l < mi.rc.left or t < mi.rc.top or rr > mi.rc.right or b > mi.rc.bottom or x + w > cl.right + 1 or y + h > cl.bottom + 1:
            return False
    wr, cr, cp = ctypes.wintypes.RECT(), ctypes.wintypes.RECT(), ctypes.wintypes.POINT(0, 0)
    user32.GetWindowRect(hwnd, ctypes.byref(wr))
    user32.GetClientRect(hwnd, ctypes.byref(cr))
    user32.ClientToScreen(hwnd, ctypes.byref(cp))
    fx, fy = cp.x - wr.left, cp.y - wr.top   # unsichtbarer Fensterrahmen
    fw = (wr.right - wr.left) - (cr.right - cr.left)
    fh = (wr.bottom - wr.top) - (cr.bottom - cr.top)
    want = (pt.x + x - fx, pt.y + y - bar - fy, w + fw, h + bar + fh)
    sig = (hwnd, hud, want)
    if _DC_EMBED.get("sig") != sig or _DC_EMBED.get("cur") != (wr.left, wr.top, wr.right - wr.left, wr.bottom - wr.top):
        user32.SetWindowLongPtrW(ctypes.c_void_p(hwnd), -8, ctypes.c_void_p(hud))   # Besitzer = HUD: bleibt darueber, geht mit ihm weg
        user32.SetWindowPos(ctypes.c_void_p(hwnd), ctypes.c_void_p(0), want[0], want[1], want[2], want[3], 0x10 | 0x40)   # NOACTIVATE | SHOWWINDOW
        user32.GetWindowRect(hwnd, ctypes.byref(wr))
        _DC_EMBED["sig"] = sig
        _DC_EMBED["cur"] = (wr.left, wr.top, wr.right - wr.left, wr.bottom - wr.top)
    # Streifen ueber der Titelleiste: zeigt genau den Teil des HUDs, der dort liegt
    user32.SetWindowLongPtrW(ctypes.c_void_p(ov), -8, ctypes.c_void_p(hud))
    user32.SetWindowPos(ctypes.c_void_p(ov), ctypes.c_void_p(0), pt.x + x, pt.y + y - bar, w, bar, 0x10 | 0x40)
    key = (hud, ov)
    if _DC_EMBED.get("thumb_key") != key:
        _dc_thumb_drop()
        th = ctypes.c_void_p()
        res = dwm.DwmRegisterThumbnail(ctypes.c_void_p(ov), ctypes.c_void_p(hud), ctypes.byref(th))
        if res != 0 or not th.value:
            print(f"[mod:discord] Abdeckung der Titelleiste nicht moeglich ({res & 0xffffffff:#x}).")
            return
        _DC_EMBED["thumb"], _DC_EMBED["thumb_key"] = th.value, key
        user32.ShowWindow(ctypes.c_void_p(ov), 4)
    pr = _DwmProps()
    pr.flags = 1 | 2 | 8 | 0x10
    pr.dest = ctypes.wintypes.RECT(0, 0, w, bar)
    pr.src = ctypes.wintypes.RECT(x, y - bar, x + w, y)
    pr.visible, pr.client_only = 1, 1
    dwm.DwmUpdateThumbnailProperties(ctypes.c_void_p(_DC_EMBED["thumb"]), ctypes.byref(pr))
    # Astro bleibt vor dem Pop-out: sein Bild (mit Transparenz) kommt vom HUD und wird in einem eigenen Fenster darueber gezeigt
    _dc_sprite_show(hud, pt)
    return True


class _DcBih(ctypes.Structure):
    _fields_ = [("size", ctypes.c_ulong), ("w", ctypes.c_long), ("h", ctypes.c_long), ("planes", ctypes.c_ushort), ("bits", ctypes.c_ushort), ("comp", ctypes.c_ulong),
                ("img", ctypes.c_ulong), ("xp", ctypes.c_long), ("yp", ctypes.c_long), ("used", ctypes.c_ulong), ("imp", ctypes.c_ulong)]


class _DcBlend(ctypes.Structure):
    _fields_ = [("op", ctypes.c_ubyte), ("flags", ctypes.c_ubyte), ("alpha", ctypes.c_ubyte), ("fmt", ctypes.c_ubyte)]


def _dc_sprite_show(hud, pt):
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
    mr, png = _DC_EMBED.get("mascot"), _DC_EMBED.get("sprite")
    mv = _dc_overlay("mascot")
    if not (mr and png and mv) or time.time() - _DC_EMBED.get("mts", 0) > 1.5:
        if mv:
            user32.ShowWindow(ctypes.c_void_p(mv), 0)
            _DC_EMBED["sprite_done"] = None
        return
    sid = _DC_EMBED.get("sprite_id")
    key = (sid, int(mr[0]), int(mr[1]))
    if _DC_EMBED.get("sprite_done") == key:
        return
    from PIL import Image
    import numpy as np
    im = Image.open(_io.BytesIO(png)).convert("RGBA")
    w, h = im.size
    a = np.asarray(im).astype("uint16")
    al = a[..., 3:4]
    bgra = np.concatenate([a[..., 2:3] * al // 255, a[..., 1:2] * al // 255, a[..., 0:1] * al // 255, al], axis=2).astype("uint8")
    sdc = user32.GetDC(None)
    mdc = gdi32.CreateCompatibleDC(sdc)
    bih = _DcBih(40, w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
    bits = ctypes.c_void_p()
    gdi32.CreateDIBSection.restype = ctypes.c_void_p
    bmp = gdi32.CreateDIBSection(ctypes.c_void_p(sdc), ctypes.byref(bih), 0, ctypes.byref(bits), None, 0)
    if bmp and bits.value:
        ctypes.memmove(bits, bgra.tobytes(), w * h * 4)
        old = gdi32.SelectObject(mdc, ctypes.c_void_p(bmp))
        user32.SetWindowLongPtrW(ctypes.c_void_p(mv), -8, ctypes.c_void_p(hud))
        user32.ShowWindow(ctypes.c_void_p(mv), 4)
        dst, size, src = ctypes.wintypes.POINT(pt.x + int(mr[0]), pt.y + int(mr[1])), ctypes.wintypes.SIZE(w, h), ctypes.wintypes.POINT(0, 0)
        bl = _DcBlend(0, 0, 255, 1)   # AC_SRC_OVER, mit Alphakanal des Bildes
        user32.UpdateLayeredWindow(ctypes.c_void_p(mv), None, ctypes.byref(dst), ctypes.byref(size), ctypes.c_void_p(mdc), ctypes.byref(src), 0, ctypes.byref(bl), 2)
        user32.SetWindowPos(ctypes.c_void_p(mv), ctypes.c_void_p(0), 0, 0, 0, 0, 0x1 | 0x2 | 0x10)   # nach oben, ohne Groesse/Lage zu aendern
        gdi32.SelectObject(mdc, ctypes.c_void_p(old))
        _DC_EMBED["sprite_done"] = key
    if bmp:
        gdi32.DeleteObject(ctypes.c_void_p(bmp))
    gdi32.DeleteDC(mdc)
    user32.ReleaseDC(None, sdc)


def _dc_embed_loop():
    """Das Pop-out-Fenster wird nicht gespiegelt, sondern direkt als Stream-Kachel benutzt (Vorschau im HUD)."""
    try:
        ctypes.windll.user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    user32 = ctypes.windll.user32
    msg = ctypes.wintypes.MSG()
    while True:
        time.sleep(0.03 if _DC_EMBED.get("sig") else 0.05)   # liegt das Pop-out gerade in der Kachel, schnell nachfuehren (Scrollen)
        try:
            while user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):   # Nachrichten des Anzeigefensters abarbeiten
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            pop = _dc_find_popout()
            if not pop:
                _DC_EMBED["popout"] = False
                _DC_EMBED["sig"] = None
                _DC_EMBED["seen"] = 0.0
                _dc_thumb_drop()
                continue
            hwnd = pop[0]
            now = time.time()
            if _DC_EMBED.get("seen_hwnd") != hwnd:
                _DC_EMBED.update(seen_hwnd=hwnd, seen=now, flat_since=0.0, probe=0.0)
            if now - _DC_EMBED["probe"] > 4 and now - _DC_EMBED["seen"] > 10:   # alle 4 s kurz pruefen, ob das Pop-out noch ein Bild zeigt (nicht einfarbig leer)
                _DC_EMBED["probe"] = now
                try:
                    fr = _WGC.get(hwnd)
                    if fr is not None:
                        hh, ww = fr.shape[:2]
                        mid = fr[int(hh * 0.25):int(hh * 0.7), int(ww * 0.1):int(ww * 0.9), :3][::6, ::6]
                        flat = float(mid.std()) < 3.0
                        _DC_EMBED["flat_since"] = (_DC_EMBED["flat_since"] or now) if flat else 0.0
                    if not _DC_EMBED.get("embedding") and not _DC_EMBED.get("keep"):
                        with _WGC.lock:
                            _WGC._stop()   # Aufnahme sofort wieder aus (kostet sonst Leistung)
                except Exception:
                    pass
            if _DC_EMBED.get("flat_since") and now - _DC_EMBED["flat_since"] > 15:   # Stream zu Ende: leeres Pop-out schliessen
                user32.PostMessageW(ctypes.c_void_p(hwnd), 0x10, 0, 0)   # WM_CLOSE
                _DC_EMBED["flat_since"] = 0.0
                _DC_EMBED["popout"] = False
                continue
            _DC_EMBED["popout"] = not (_DC_EMBED.get("flat_since") and now - _DC_EMBED["flat_since"] > 8)
            rect = _DC_EMBED["rect"]
            if _DC_EMBED.get("owned") != hwnd:   # Besitzer/Ausschnitt von frueheren Versuchen entfernen und hinter A.R.I legen
                _DC_EMBED["owned"] = hwnd
                try:
                    user32.SetWindowLongPtrW(ctypes.c_void_p(hwnd), -8, ctypes.c_void_p(0))
                    user32.SetWindowRgn(hwnd, None, True)
                except Exception:
                    pass
                _dc_tuck_popout(hwnd)
            if not (rect and time.time() - _DC_EMBED["ts"] < 1.5):
                _dc_thumb_drop()   # Kachel zeigt den Planeten: Pop-out wieder hinter A.R.I
                if _DC_EMBED.get("sig") is not None:
                    _DC_EMBED["sig"] = None
                    try:
                        user32.SetWindowLongPtrW(ctypes.c_void_p(hwnd), -8, ctypes.c_void_p(0))
                    except Exception:
                        pass
                    _dc_tuck_popout(hwnd)
                continue
            hud = _dc_hud_hwnd()
            if hud and _dc_embed_place(hwnd, hud, rect) is False:   # Kachel ragt aus dem Monitor / HUD heraus: Pop-out ausblenden, bis sie wieder ganz da ist
                _dc_thumb_drop()
                if _DC_EMBED.get("sig") is not None:
                    _DC_EMBED["sig"] = None
                    try:
                        user32.SetWindowLongPtrW(ctypes.c_void_p(hwnd), -8, ctypes.c_void_p(0))
                    except Exception:
                        pass
                    _dc_tuck_popout(hwnd)
        except Exception as e:
            print(f"[mod:discord] Pop-out einbetten: {type(e).__name__}: {e}")


@app.route("/discord/embed", methods=["POST"])
def discord_embed():
    """Das HUD meldet, wo die Hauptkachel auf dem Bildschirm liegt (Anteile des HUD-Fensters in Bildpunkten + Skalierung)."""
    bad = _dc_guard()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    if "mascot" in d:   # Lage von Astro (oder None), unabhaengig von der Kachel
        mr, kk = d.get("mascot"), float(d.get("dpr") or 1)
        if d.get("sprite"):
            try:
                _DC_EMBED["sprite"] = base64.b64decode(str(d["sprite"]).split(",", 1)[-1])
                _DC_EMBED["sprite_id"] = _DC_EMBED.get("sprite_id", 0) + 1
            except Exception:
                pass
        try:
            _DC_EMBED["mascot"] = (float(mr["x"]) * kk, float(mr["y"]) * kk, float(mr["w"]) * kk, float(mr["h"]) * kk) if mr else None
            _DC_EMBED["mts"] = time.time()
        except (KeyError, TypeError, ValueError):
            _DC_EMBED["mascot"] = None
        if "x" not in d and not d.get("hide"):
            return jsonify({"ok": True})
    if d.get("hide"):
        _DC_EMBED["rect"] = None
        return jsonify({"ok": True, "popout": _DC_EMBED["popout"]})
    try:
        k = float(d.get("dpr") or 1)
        _DC_EMBED["rect"] = (float(d["x"]) * k, float(d["y"]) * k, float(d["w"]) * k, float(d["h"]) * k)
        _DC_EMBED["ts"] = time.time()
    except (KeyError, TypeError, ValueError):
        return jsonify({"ok": False})
    return jsonify({"ok": True, "popout": _DC_EMBED["popout"]})


def _dc_tuck_popout(hwnd):
    """Legt das Pop-out-Fenster unsichtbar hinter das A.R.I-Fenster (gleiche Stelle, 16:9), damit es keinen Platz braucht. Aufgenommen wird es trotzdem."""
    try:
        user32 = ctypes.windll.user32
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 4)   # SW_SHOWNOACTIVATE: minimiert liefert keine Bilder
        if user32.IsZoomed(hwnd):
            user32.ShowWindow(hwnd, 9)   # SW_RESTORE: Vollbild/maximiert wuerde alles verdecken
        hud = []
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def cb(h, _):
            if user32.IsWindowVisible(h):
                n = user32.GetWindowTextLengthW(h)
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(h, buf, n + 1)
                if buf.value.startswith("A.R.I") and "Command Center" in buf.value:
                    hud.append(h)
            return True
        user32.EnumWindows(EnumProc(cb), 0)
        x, y, w, h = None, None, 960, 540
        if hud:
            r = ctypes.wintypes.RECT()
            user32.GetWindowRect(hud[0], ctypes.byref(r))
            W, H = r.right - r.left, r.bottom - r.top
            w = max(480, min(W - 40, int((H - 40) * 16 / 9)))
            h = int(w * 9 / 16) + 26
            x, y = r.left + (W - w) // 2, r.top + (H - h) // 2
        if x is None:
            cur = ctypes.wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(cur))
            x, y = cur.left, cur.top
        # HWND_BOTTOM (1), SWP_NOACTIVATE (0x10): hinter alle Fenster, ohne Fokus zu stehlen
        cur = ctypes.wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(cur))
        w, h = cur.right - cur.left, cur.bottom - cur.top   # Groesse unveraendert lassen (Discord malt nach dem Verkleinern nicht neu)
        if hud:
            x, y = r.left + (W - w) // 2, r.top + (H - h) // 2
        user32.SetWindowPos(hwnd, 1, x, y, w, h, 0x10)
    except Exception as e:
        print(f"[mod:discord] Pop-out ablegen: {type(e).__name__}: {e}")


def _dc_client_crop(hwnd):
    """Anteile {x,y,w,h} des Fensterinhalts ohne Rahmen und Titelleiste (Windows-Client-Bereich) oder None."""
    try:
        user32 = ctypes.windll.user32
        wr, cr = ctypes.wintypes.RECT(), ctypes.wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(wr))
        user32.GetClientRect(hwnd, ctypes.byref(cr))
        pt = ctypes.wintypes.POINT(0, 0)
        user32.ClientToScreen(hwnd, ctypes.byref(pt))
        W, H = wr.right - wr.left, wr.bottom - wr.top
        cw, ch = cr.right - cr.left, cr.bottom - cr.top
        if W < 100 or H < 100 or cw < 50 or ch < 50:
            return None
        try:
            dpi = user32.GetDpiForWindow(hwnd) or 96
        except Exception:
            dpi = 96
        bar = int(round(26 * dpi / 96))   # Discord zeichnet die Titelleiste (Minimieren/Maximieren/Schliessen) selbst in den Fensterinhalt
        top = (pt.y - wr.top) + bar
        return {"x": (pt.x - wr.left) / W, "y": top / H, "w": cw / W, "h": max(0.2, (ch - bar) / H)}
    except Exception:
        return None


def _dc_windows():
    """Alle sichtbaren, benannten Chrome-Fenster von Discord.exe -> [(flaeche, hwnd, titel)]."""
    user32 = ctypes.windll.user32
    best = []
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.GetWindowTextLengthW(hwnd) == 0:
                return True
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if psutil.Process(pid.value).name().lower() != "discord.exe":
                return True
            r = ctypes.wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            area = max(0, r.right - r.left) * max(0, r.bottom - r.top)
            cls = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(hwnd, cls, 64)
            if area > 150 * 100 and cls.value == "Chrome_WidgetWin_1":
                n = user32.GetWindowTextLengthW(hwnd)
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                best.append((area, hwnd, buf.value))
        except Exception:
            pass
        return True
    user32.EnumWindows(EnumProc(cb), 0)
    return best


class _DcBmi(ctypes.Structure):
    _fields_ = [("biSize", ctypes.c_ulong), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long), ("biPlanes", ctypes.c_ushort), ("biBitCount", ctypes.c_ushort),
                ("biCompression", ctypes.c_ulong), ("biSizeImage", ctypes.c_ulong), ("a", ctypes.c_long), ("b", ctypes.c_long), ("c", ctypes.c_ulong), ("d", ctypes.c_ulong)]


def _dc_placeholder(text, w=960, h=540, tick=0):
    from PIL import Image, ImageDraw
    im = Image.new("RGB", (w, h), (8, 12, 24))
    dr = ImageDraw.Draw(im)
    try:
        from PIL import ImageFont
        font = ImageFont.truetype("segoeui.ttf", max(14, w // 34))
    except Exception:
        font = None
    box = dr.textbbox((0, 0), text, font=font)
    dr.text(((w - (box[2] - box[0])) // 2, (h - (box[3] - box[1])) // 2), text, fill=(120, 200, 240), font=font)
    out = _io.BytesIO()
    im.save(out, "JPEG", quality=70)
    return out.getvalue()


def _dc_testbild(w, h, n):
    """Bewegtes Testbild fuer den Stream-Weg ohne Discord (DEV)."""
    from PIL import Image, ImageDraw
    im = Image.new("RGB", (w, h), (10, 14, 30))
    dr = ImageDraw.Draw(im)
    x = (n * 12) % (w - 80)
    dr.rectangle([x, h // 2 - 40, x + 80, h // 2 + 40], fill=(41, 211, 245))
    dr.text((20, 20), f"A.R.I Testbild   Bild {n}", fill=(255, 255, 255))
    out = _io.BytesIO()
    im.save(out, "JPEG", quality=70)
    return out.getvalue()


class _DcWgc:
    """Windows Graphics Capture (das moderne Windows-Aufnahmeverfahren): nimmt das Discord-Fenster auch auf, wenn andere Fenster davor liegen,
    laeuft ueber die Grafikkarte und braucht kaum Prozessor. Das noetige Paket (windows-capture) wird bei Bedarf selbst nachinstalliert;
    solange es fehlt, greift der alte Weg."""

    def __init__(self):
        self.lock = threading.Lock()
        self.mod = None
        self.installing = False
        self.hwnd = 0
        self.ctl = None
        self.frame = None
        self.used = 0.0
        self.watch = None

    def available(self):
        if self.mod is not None:
            return True
        try:
            import windows_capture
            self.mod = windows_capture
            return True
        except Exception:
            if not self.installing:
                self.installing = True
                threading.Thread(target=self._install, daemon=True).start()
            return False

    def _install(self):
        try:
            print("[mod:discord] Installiere das Aufnahme-Paket windows-capture ...")
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "windows-capture"], timeout=400,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as e:
            print(f"[mod:discord] windows-capture konnte nicht installiert werden: {e}")
        finally:
            self.installing = False

    def _start(self, hwnd):
        self._stop()
        wc = self.mod
        cap = wc.WindowsCapture(cursor_capture=False, draw_border=False, window_hwnd=int(hwnd))
        me = self

        @cap.event
        def on_frame_arrived(frame, control):
            import numpy as np
            me.frame = np.array(frame.frame_buffer)   # Kopie: der Puffer gilt nur waehrend dieses Aufrufs

        @cap.event
        def on_closed():
            me.ctl = None
        self.frame = None
        self.hwnd = hwnd
        self.ctl = cap.start_free_threaded()
        if not (self.watch and self.watch.is_alive()):
            self.watch = threading.Thread(target=self._watchdog, daemon=True)
            self.watch.start()

    def _stop(self):
        ctl, self.ctl = self.ctl, None
        if ctl is not None:
            try:
                ctl.stop()
            except Exception:
                pass
        self.frame = None

    def _watchdog(self):
        while True:
            time.sleep(1.0)
            if self.ctl is None:
                return
            if time.time() - self.used > 8:   # niemand braucht Bilder mehr
                with self.lock:
                    self._stop()
                return

    def get(self, hwnd):
        """Neuestes Bild des Fensters als BGRA-Array oder None (Paket fehlt / noch kein Bild)."""
        if not self.available():
            return None
        self.used = time.time()
        with self.lock:
            if self.ctl is None or self.hwnd != hwnd:
                self._start(hwnd)
        for _ in range(40):   # direkt nach dem Start kurz auf das erste Bild warten
            if self.frame is not None:
                return self.frame
            time.sleep(0.05)
        return None


_WGC = _DcWgc()


class _DcCapture:
    """Ein Aufnahme-Thread fuer alle Zuschauer. Startet beim ersten Zuschauer, stoppt kurz nach dem letzten."""

    def __init__(self):
        self.cond = threading.Condition()
        self.clients = 0
        self.frame = b""
        self.seq = 0
        self.thread = None
        self.fps = 0.0
        self.stage = 2
        self.mode = "schonend"
        self.test = False
        self.backend = ""
        self.idle_since = 0.0
        self.opts_dirty = False
        self.auto_crop = None      # automatisch erkannter Stream-Bereich (None = noch keiner)
        self.source = ""           # "popout" = Pop-out-Fenster des Streams, "main" = Hauptfenster
        self.det_size = None       # Fenstergroesse, bei der der Bereich erkannt wurde
        self.cur_size = None       # aktuelle Fenstergroesse (aus dem letzten Bild)
        self.redetect = threading.Event()
        self.auto_miss = 0
        self.alive = False
        self.rcond = threading.Condition()   # Rohbild-Uebergabe: Aufnahme -> Kodierer (immer nur das neueste Bild)
        self.raw, self.raw_tw, self.rseq = None, 1280, 0
        self._fps_t0, self._fps_n = time.time(), 0

    def info(self):
        return {"running": bool(self.thread and self.thread.is_alive()), "clients": self.clients, "fps": round(self.fps, 1), "backend": self.backend, "stage": _FPS_STAGES[self.stage],
                "auto_crop": self.auto_crop}

    def add_client(self):
        with self.cond:
            self.clients += 1
            if not (self.thread and self.thread.is_alive()):
                self.thread = threading.Thread(target=self._run, daemon=True)
                self.thread.start()

    def drop_client(self):
        with self.cond:
            self.clients = max(0, self.clients - 1)
            if self.clients == 0:
                self.idle_since = time.time()

    def wait_frame(self, last_seq, timeout=2.0):
        with self.cond:
            self.cond.wait_for(lambda: self.seq != last_seq, timeout)
            return self.seq, self.frame

    def _load_high(self):
        try:
            cpu = psutil.cpu_percent(interval=None)
            gpu = None
            try:
                gpu = _read_temps()[2]
            except Exception:
                pass
            game = bool(_mod_status_extras().get("active_game_mode"))
            return game or cpu > 85 or (gpu is not None and gpu > 85), (cpu < 60 and (gpu is None or gpu < 60) and not game)
        except Exception:
            return False, True

    def _publish(self, jpg):
        with self.cond:
            self.frame = jpg
            self.seq += 1
            self.cond.notify_all()
        self._fps_n += 1
        now = time.time()
        if now - self._fps_t0 >= 1.0:
            self.fps = self._fps_n / (now - self._fps_t0)
            self._fps_t0, self._fps_n = now, 0

    def _push_raw(self, raw, tw):
        with self.rcond:
            self.raw, self.raw_tw = raw, tw
            self.rseq += 1
            self.rcond.notify_all()

    def _encode_loop(self):
        """Zweiter Arbeiter: verkleinert (gute Qualitaet) und kodiert das neueste Rohbild, waehrend der erste schon das naechste abgreift."""
        from PIL import Image
        last = 0
        while self.alive:
            with self.rcond:
                self.rcond.wait_for(lambda: self.rseq != last or not self.alive, 0.5)
                if not self.alive:
                    break
                if self.rseq == last:
                    continue
                last = self.rseq
                raw, tw = self.raw, self.raw_tw
            try:
                if isinstance(raw, tuple):
                    data, w, h = raw
                    im = Image.frombuffer("RGBA", (w, h), data, "raw", "BGRA", 0, 1)
                else:
                    im = raw
                if im.width > tw:
                    im = im.resize((tw, max(2, int(im.height * tw / im.width))), Image.BILINEAR, reducing_gap=2.0)
                q = {640: 80, 960: 83, 1280: 86, 1600: 87, 1920: 88}.get(tw, 85)
                out = _io.BytesIO()
                im.convert("RGB").save(out, "JPEG", quality=q, subsampling=0)
                self._publish(out.getvalue())
            except Exception as e:
                print(f"[mod:discord] Kodieren: {type(e).__name__}: {e}")

    def _run(self):
        user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
        try:
            ctypes.windll.user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))   # nur dieser Thread: echte Pixel statt skalierter Koordinaten
        except Exception:
            pass
        opts = _dc_opts()
        self.mode = opts.get("fps_mode", "schonend")
        top = 0 if self.mode == "60" else 2
        self.stage = top
        tw = int(opts.get("width") or 1280)
        tw = tw if tw in (640, 960, 1280, 1600, 1920) else 1280
        crop = opts.get("crop")   # None = automatisch erkennen, "full" = ganzes Fenster, {x,y,w,h} = von Hand gewaehlt
        last_tune = last_up = 0.0
        self.alive = True
        self.auto_crop, self.auto_miss = None, 0
        if not self.test:
            threading.Thread(target=self._auto_loop, daemon=True).start()
        threading.Thread(target=self._encode_loop, daemon=True).start()
        wait_jpg = None
        n = 0
        res = {}
        dx = None
        if self.mode == "60":
            try:
                import dxcam as _dxcam
                dx = _dxcam
            except Exception:
                dx = None
        self.backend = "dxgi" if dx else "gdi"
        frame_t = time.time()
        try:
            while True:
                now = time.time()
                if self.clients == 0 and now - self.idle_since > 5:
                    break
                if self.opts_dirty:   # Ausschnitt/Breite wurden in den Einstellungen geaendert
                    self.opts_dirty = False
                    o2 = _dc_opts()
                    crop = o2.get("crop")
                    tw = int(o2.get("width") or 1280)
                    tw = tw if tw in (640, 960, 1280, 1600, 1920) else 1280
                if now - last_tune > 2:   # Bildrate an die Auslastung anpassen (nie pausieren, nur langsamer/schneller)
                    last_tune = now
                    high, calm = self._load_high()
                    if high and self.stage < len(_FPS_STAGES) - 1:
                        self.stage += 1
                    elif calm and self.stage > top and now - last_up > 6:
                        self.stage -= 1
                        last_up = now
                fps = _FPS_STAGES[self.stage]
                try:
                    use_crop = crop if isinstance(crop, dict) else (None if crop == "full" else self.auto_crop)
                    if self.test:
                        jpg = _dc_testbild(tw, tw * 9 // 16, n)
                    elif crop is None and use_crop is None and not _dc_find_popout():   # Automatik: weder Pop-out noch Stream gefunden -> nie das ganze Fenster zeigen
                        if wait_jpg is None or wait_jpg[0] != tw:
                            wait_jpg = (tw, _dc_placeholder("Warte auf den Stream … A.R.I sucht das laufende Bild in Discord.", tw, tw * 9 // 16))
                        jpg = wait_jpg[1]
                        time.sleep(0.4)
                    else:
                        raw = self._grab_image(user32, gdi32, tw, res, dx, use_crop, native=True)
                        if isinstance(raw, bytes):
                            jpg = raw   # Hinweisbild ("Discord nicht gefunden" ...)
                        else:
                            self._push_raw(raw, tw)
                            jpg = None
                except Exception as e:
                    print(f"[mod:discord] Aufnahme: {type(e).__name__}: {e}")
                    jpg = _dc_placeholder("Das Bild von Discord ist gerade nicht verfügbar.", tw, tw * 9 // 16)
                    time.sleep(0.5)
                n += 1
                ds, cs_ = self.det_size, self.cur_size
                if self.auto_crop and ds and cs_ and (abs(cs_[0] - ds[0]) > 0.03 * ds[0] or abs(cs_[1] - ds[1]) > 0.03 * ds[1]):
                    self.det_size = cs_
                    self.redetect.set()   # Discord-Fenster wurde in der Groesse veraendert: Stream-Bereich gleich neu bestimmen
                if jpg is not None:
                    self._publish(jpg)
                frame_t += 1.0 / fps
                delay = frame_t - time.time()
                if delay > 0:
                    time.sleep(delay)
                else:
                    frame_t = time.time()
        finally:
            self.alive = False
            self._free(res)
            if res.get("dxcam"):
                try:
                    res["dxcam"].stop()
                except Exception:
                    pass
            self.fps = 0.0
            self.backend = ""

    def _grab(self, user32, gdi32, tw, res, dx, crop=None):
        im = self._grab_image(user32, gdi32, tw, res, dx, crop)
        if isinstance(im, bytes):
            return im   # Platzhalter-Bild (z. B. "Discord nicht gefunden")
        out = _io.BytesIO()
        im.save(out, "JPEG", quality=85)
        return out.getvalue()

    def _grab_image(self, user32, gdi32, tw, res, dx, crop=None, native=False):
        """Bild von Discord als PIL-Bild; crop = {"x","y","w","h"} als Anteile des Fensters (nur der Stream-Bereich), sonst das ganze Fenster."""
        pop = None if crop == "full" or isinstance(crop, dict) or getattr(self, "force_main", False) else _dc_find_popout()
        found = pop or _dc_find_window()
        if not found:
            return _dc_placeholder("Discord wurde nicht gefunden.", tw, tw * 9 // 16)
        hwnd, _title = found
        self.source = "popout" if pop else "main"
        if pop and getattr(self, "tucked", None) != hwnd:
            self.tucked = hwnd
            _dc_tuck_popout(hwnd)   # einmal pro Fenster: hinter A.R.I legen, passend gross
        if pop:
            crop = _dc_client_crop(hwnd)   # nur der Inhalt, ohne Titelleiste und Rahmen (Anteile, daher jede Fenstergroesse)
        if user32.IsIconic(hwnd):
            return _dc_placeholder("Das Discord-Fenster ist minimiert.", tw, tw * 9 // 16)
        r = ctypes.wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        w, h = r.right - r.left, r.bottom - r.top
        if w < 100 or h < 100:
            return _dc_placeholder("Das Discord-Fenster ist zu klein.", tw, tw * 9 // 16)
        try:
            wf = _WGC.get(hwnd)   # moderner Weg: auch bei verdecktem Fenster, kaum Prozessorlast
        except Exception as e:
            print(f"[mod:discord] Windows Graphics Capture: {type(e).__name__}: {e}")
            wf = None
        if wf is not None:
            from PIL import Image
            H2, W2 = wf.shape[:2]
            if abs(W2 - w) > 0.05 * w or abs(H2 - h) > 0.05 * h:   # das Fenster hat seine Groesse geaendert, der Aufnahme-Puffer noch die alte: neu starten
                with _WGC.lock:
                    _WGC._stop()
                time.sleep(0.2)
                wf = _WGC.get(hwnd)
                if wf is None:
                    return _dc_placeholder("Das Bild wird neu aufgebaut …", tw, tw * 9 // 16)
                H2, W2 = wf.shape[:2]
            cx0, cy0, cw, ch = 0, 0, W2, H2
            if isinstance(crop, dict):
                try:
                    cx0 = min(max(0, int(float(crop["x"]) * W2)), W2 - 32)
                    cy0 = min(max(0, int(float(crop["y"]) * H2)), H2 - 32)
                    cw = max(32, min(W2 - cx0, int(float(crop["w"]) * W2)))
                    ch = max(32, min(H2 - cy0, int(float(crop["h"]) * H2)))
                except (KeyError, TypeError, ValueError):
                    cx0, cy0, cw, ch = 0, 0, W2, H2
            part = wf[cy0:cy0 + ch, cx0:cx0 + cw]
            self.cur_size = (W2, H2)
            self.backend = "wgc"
            if native:
                return (part.tobytes(), cw, ch)
            im = Image.frombuffer("RGBA", (cw, ch), part.tobytes(), "raw", "BGRA", 0, 1)
            return im.resize((tw, max(2, int(ch * tw / cw))), Image.BILINEAR, reducing_gap=2.0).convert("RGB")
        self.cur_size = (w, h)
        sx0, sy0, sw, sh = 0, 0, w, h
        if isinstance(crop, dict):
            try:
                sx0 = min(max(0, int(float(crop["x"]) * w)), w - 32)
                sy0 = min(max(0, int(float(crop["y"]) * h)), h - 32)
                sw = max(32, min(w - sx0, int(float(crop["w"]) * w)))
                sh = max(32, min(h - sy0, int(float(crop["h"]) * h)))
            except (KeyError, TypeError, ValueError):
                sx0, sy0, sw, sh = 0, 0, w, h
        if native:
            tw, th = sw, sh   # 1:1 abgreifen; das Verkleinern macht der Kodierer (bessere Qualitaet als beim Abgreifen)
        else:
            th = max(2, int(sh * tw / sw))
        from PIL import Image
        if dx is not None:
            im = self._grab_dxgi(user32, hwnd, r, dx, res)
            if im is not None:
                im = im.crop((sx0, sy0, sx0 + sw, sy0 + sh))
                return im if native else im.resize((tw, th))
        sdc = res.get("sdc") or user32.GetDC(0)
        res["sdc"] = sdc
        key = (tw, th)
        if res.get("size") != key:
            for k in ("mdc", "bmp"):
                if res.get(k):
                    (gdi32.DeleteDC if k == "mdc" else gdi32.DeleteObject)(res[k])
            res["mdc"] = gdi32.CreateCompatibleDC(sdc)
            res["bmp"] = gdi32.CreateCompatibleBitmap(sdc, tw, th)
            gdi32.SelectObject(res["mdc"], res["bmp"])
            gdi32.SetStretchBltMode(res["mdc"], 3)
            res["buf"] = ctypes.create_string_buffer(tw * th * 4)
            res["bmi"] = _DcBmi(40, tw, -th, 1, 32, 0, 0, 0, 0, 0, 0)
            res["size"] = key
        SRC = 0x00CC0020 | 0x40000000
        point = ctypes.wintypes.POINT((r.left + r.right) // 2, (r.top + r.bottom) // 2)
        top = user32.GetAncestor(user32.WindowFromPoint(point), 2)   # GA_ROOT: liegt das Discord-Fenster ganz oben?
        if top == hwnd:
            self.backend = "gdi"
            if native:
                gdi32.BitBlt(res["mdc"], 0, 0, sw, sh, sdc, r.left + sx0, r.top + sy0, SRC)
            else:
                gdi32.StretchBlt(res["mdc"], 0, 0, tw, th, sdc, r.left + sx0, r.top + sy0, sw, sh, SRC)
        else:   # verdeckt: das Fenster selbst abfragen (zeigt nur Discord, etwas langsamer); die Bitmap wird wiederverwendet
            self.backend = "gdi-verdeckt"
            if res.get("fsize") != (w, h):
                for k in ("fdc", "fbmp"):
                    if res.get(k):
                        (gdi32.DeleteDC if k == "fdc" else gdi32.DeleteObject)(res[k])
                res["fdc"] = gdi32.CreateCompatibleDC(sdc)
                res["fbmp"] = gdi32.CreateCompatibleBitmap(sdc, w, h)
                gdi32.SelectObject(res["fdc"], res["fbmp"])
                res["fsize"] = (w, h)
            user32.PrintWindow(hwnd, res["fdc"], 2)
            if native:
                gdi32.BitBlt(res["mdc"], 0, 0, sw, sh, res["fdc"], sx0, sy0, 0x00CC0020)
            else:
                gdi32.StretchBlt(res["mdc"], 0, 0, tw, th, res["fdc"], sx0, sy0, sw, sh, 0x00CC0020)
        gdi32.GetDIBits(res["mdc"], res["bmp"], 0, th, res["buf"], ctypes.byref(res["bmi"]), 0)
        if native:
            return (bytes(res["buf"]), tw, th)   # Rohdaten (BGRA); Umrechnen und Verkleinern macht der Kodierer
        return Image.frombuffer("RGBA", (tw, th), res["buf"], "raw", "BGRA", 0, 1).convert("RGB")

    def _auto_loop(self):
        """Laeuft neben der Aufnahme: sucht den Stream-Bereich selbst (Bereich mit dauernder Bewegung) und prueft ihn alle ~12 s neu.
        Endet der Stream oder aendert sich das Fenster, wird neu gesucht - solange zeigt die Kachel nur einen Hinweis."""
        while self.alive:
            crop_opt = _dc_opts().get("crop")
            if crop_opt is None:   # nur im Automatik-Modus noetig
                try:
                    found, _err = _dc_detect_crop(14)
                except Exception as e:
                    print(f"[mod:discord] Automatik: {type(e).__name__}: {e}")
                    found = None
                if found:
                    old = self.auto_crop
                    self.auto_miss = 0
                    self.det_size = self.cur_size
                    if not old or max(abs(found[k] - old[k]) for k in ("x", "y", "w", "h")) > 0.03:
                        self.auto_crop = found
                else:
                    self.auto_miss += 1
                    if self.auto_miss >= 2:
                        self.auto_crop = None
            for _ in range(30 if self.auto_crop else 8):   # 12 s bzw. (ohne Fund) 3 s warten, abbrechbar - aendert sich die Fenstergroesse, sofort neu suchen
                if not self.alive:
                    return
                if self.redetect.wait(0.4):
                    self.redetect.clear()
                    break

    @staticmethod
    def _free(res):
        user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
        for k in ("mdc", "bmp", "fdc", "fbmp", "sdc"):
            try:
                if k in ("bmp", "fbmp") and res.get(k):
                    gdi32.DeleteObject(res[k])
                elif k in ("mdc", "fdc") and res.get(k):
                    gdi32.DeleteDC(res[k])
                elif k == "sdc" and res.get(k):
                    user32.ReleaseDC(0, res[k])
            except Exception:
                pass

    def _grab_dxgi(self, user32, hwnd, r, dx, res):
        """Optionaler 60-fps-Weg (DXGI-Duplication, belastet die Grafikkarte etwas). Gibt None zurueck, wenn er nicht geht."""
        try:
            from PIL import Image
            if "dxcam" not in res:
                mon = user32.MonitorFromWindow(hwnd, 2)

                class _MI(ctypes.Structure):
                    _fields_ = [("cb", ctypes.c_ulong), ("rc", ctypes.wintypes.RECT), ("work", ctypes.wintypes.RECT), ("fl", ctypes.c_ulong)]
                mi = _MI()
                mi.cb = ctypes.sizeof(_MI)
                user32.GetMonitorInfoW(mon, ctypes.byref(mi))
                idx = 0
                for i, (mleft, mtop) in enumerate(self._monitor_origins(user32)):
                    if (mleft, mtop) == (mi.rc.left, mi.rc.top):
                        idx = i
                cam = dx.create(output_idx=idx, output_color="RGB")
                reg = (max(r.left, mi.rc.left) - mi.rc.left, max(r.top, mi.rc.top) - mi.rc.top, min(r.right, mi.rc.right) - mi.rc.left, min(r.bottom, mi.rc.bottom) - mi.rc.top)
                cam.start(region=reg, target_fps=60)
                res["dxcam"] = cam
            f = res["dxcam"].get_latest_frame()
            if f is None:
                return None
            self.backend = "dxgi"
            return Image.fromarray(f)
        except Exception as e:
            print(f"[mod:discord] 60-fps-Weg nicht moeglich: {e}")
            res.pop("dxcam", None)
            return None

    @staticmethod
    def _monitor_origins(user32):
        out = []
        MonProc = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.wintypes.RECT), ctypes.c_void_p)

        def cb(hm, hdc, rc, _):
            out.append((rc.contents.left, rc.contents.top))
            return 1
        user32.EnumDisplayMonitors(0, 0, MonProc(cb), 0)
        return out


_DCCAP = _DcCapture()


# --------------------------------------------------------------------------- Routen ----
def _dc_guard():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return None


@app.route("/discord/state")
def discord_state():
    bad = _dc_guard()
    return bad or jsonify(_dc_public())


def _dc_live():
    """Nur das, was sich im Sprachkanal aendert (leicht und ohne Dateizugriff) - fuer die Live-Verbindung."""
    with _DC_LOCK:
        members = [dict(m, speaking=(uid in _DC["speaking"])) for uid, m in _DC["members"].items()]
        members.sort(key=lambda m: m["name"].lower())
        status = "verbunden" if (_DC["connected"] and _DC["authorized"] and _DC["status"] in ("aus", "suche", "warten", "anmelden")) else _DC["status"]
        return {"status": status, "error": _DC["error"], "connected": _DC["connected"], "authorized": _DC["authorized"],
                "channel": _DC["channel"], "server": _DC["server"], "members": members,
                "cap_running": bool(_DCCAP.alive), "streaming": _DCCAP.auto_crop is not None or _DCCAP.source == "popout", "source": _DCCAP.source, "popout": _DC_EMBED["popout"]}


@app.route("/discord/live")
def discord_live():
    """Server-Sent Events: schickt jede Aenderung des Sprachkanals sofort an das HUD (Pruefung alle 0,15 s, nur wenn etwas anders ist)."""
    bad = _dc_guard()
    if bad:
        return bad

    def gen():
        last, idle = None, 0
        yield "retry: 1000\n\n"
        while True:
            cur = json.dumps(_dc_live(), ensure_ascii=False, sort_keys=True)
            if cur != last:
                last, idle = cur, 0
                yield "data: " + cur + "\n\n"
            else:
                idle += 1
                if idle >= 100:   # alle ~15 s ein Lebenszeichen, damit die Verbindung offen bleibt
                    idle = 0
                    yield ": ping\n\n"
            time.sleep(0.15)
    return Response(gen(), mimetype="text/event-stream", headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})


@app.route("/discord/configure", methods=["POST"])
def discord_configure():
    bad = _dc_guard()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    cid, sec = str(d.get("client_id") or "").strip(), str(d.get("client_secret") or "").strip()
    if not re.fullmatch(r"\d{15,25}", cid):
        return jsonify({"error": "Die Client-ID besteht nur aus Ziffern (ca. 18 Stellen)."})
    if len(sec) < 16:
        return jsonify({"error": "Das Client-Secret fehlt oder ist zu kurz."})
    _update_secrets("discord", lambda old: {"client_id": cid, "client_secret": sec, "opts": (old or {}).get("opts") or {}})
    _dc_start()
    return jsonify({"error": None})


@app.route("/discord/connect", methods=["POST"])
def discord_connect():
    bad = _dc_guard()
    if bad:
        return bad
    _dc_start()
    return jsonify({"error": None})


@app.route("/discord/disconnect", methods=["POST"])
def discord_disconnect():
    bad = _dc_guard()
    if bad:
        return bad
    _dc_stop()
    _update_secrets("discord", lambda old: {k: v for k, v in (old or {}).items() if k != "token"})
    return jsonify({"error": None})


@app.route("/discord/options", methods=["POST"])
def discord_options():
    bad = _dc_guard()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    o = {"mentions_roles": bool(d.get("mentions_roles")), "mentions_everyone": bool(d.get("mentions_everyone")),
         "auto_live": d.get("auto_live") is not False, "auto_fix": d.get("auto_fix") is True, "auto_popout": d.get("auto_popout") is not False, "translate": d.get("translate") is not False, "fps_mode": "60" if str(d.get("fps_mode")) == "60" else "schonend", "width": int(d.get("width") or 1280) if int(d.get("width") or 1280) in (640, 960, 1280, 1600, 1920) else 1280}
    if "crop" in d:
        c = d.get("crop")
        try:
            o["crop"] = {k: round(min(1.0, max(0.0, float(c[k]))), 4) for k in ("x", "y", "w", "h")} if isinstance(c, dict) else ("full" if c == "full" else None)
        except (KeyError, TypeError, ValueError):
            return jsonify({"error": "Der Ausschnitt ist ungültig."})
    else:
        o["crop"] = _dc_opts().get("crop")   # nicht mitgeschickt: den gespeicherten Ausschnitt behalten
    _update_secrets("discord", lambda old: {**(old or {}), "opts": o})
    _DCCAP.opts_dirty = True
    try:
        _dc_autostart_apply(bool(o.get("auto_fix")))
    except Exception:
        pass
    return jsonify({"error": None, "opts": o})


def _dc_grow_tile(g, x0, y0, x1, y1, look=4, frac=0.12):
    """Vom bewegten Kern aus nach aussen wachsen, bis der schwarze Rand der Buehne beginnt: so wird die GANZE Stream-Flaeche genommen
    (z. B. der komplette geteilte Bildschirm), nicht nur das kleine bewegte Video darin. Koordinaten inklusive. Ein Rand zaehlt erst,
    wenn 'look' Zeilen/Spalten hintereinander (fast) schwarz sind - einzelne dunkle Linien im Bild stoppen das Wachsen nicht."""
    import numpy as np
    H, W = g.shape
    thr = max(4.0, float(np.percentile(g, 3)) + 3.0)
    nb = g > thr
    changed = True
    while changed:
        changed = False
        for k in range(1, look + 1):
            x = x0 - k
            if x >= 0 and nb[y0:y1 + 1, x].mean() >= frac:
                x0, changed = x, True
                break
        for k in range(1, look + 1):
            x = x1 + k
            if x < W and nb[y0:y1 + 1, x].mean() >= frac:
                x1, changed = x, True
                break
        for k in range(1, look + 1):
            y = y0 - k
            if y >= 0 and nb[y, x0:x1 + 1].mean() >= frac:
                y0, changed = y, True
                break
        for k in range(1, look + 1):
            y = y1 + k
            if y < H and nb[y, x0:x1 + 1].mean() >= frac:
                y1, changed = y, True
                break
    return x0, y0, x1, y1


def _dc_content_bbox(mean, stage, motion, bs=4):
    """Genauer Rahmen der Stream-Flaeche: in der schwarzen Buehne die zusammenhaengende, nicht schwarze Flaeche suchen, die den bewegten Bereich enthaelt.
    Dunkle Spielraender gehoeren dazu (sie sind nicht reines Schwarz). Koordinaten im Arbeitsbild; Rueckgabe (x0, y0, x1, y1) exklusiv oder None."""
    import numpy as np
    sx0, sy0, sx1, sy1 = stage
    sub = mean[sy0:sy1, sx0:sx1]
    h2, w2 = sub.shape
    gh, gw = h2 // bs, w2 // bs
    if gh < 3 or gw < 3:
        return None
    cell = (sub[:gh * bs, :gw * bs] > 8).reshape(gh, bs, gw, bs).mean(axis=(1, 3)) > 0.3
    seen = np.zeros_like(cell, dtype=bool)
    mx0, my0, mx1, my1 = motion
    best, best_hit = None, 0
    for yy in range(gh):
        for xx in range(gw):
            if cell[yy, xx] and not seen[yy, xx]:
                todo, comp = [(yy, xx)], []
                seen[yy, xx] = True
                while todo:
                    cy, cx = todo.pop()
                    comp.append((cy, cx))
                    for ny, nx in ((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1)):
                        if 0 <= ny < gh and 0 <= nx < gw and cell[ny, nx] and not seen[ny, nx]:
                            seen[ny, nx] = True
                            todo.append((ny, nx))
                hit = sum(1 for (cy, cx) in comp if mx0 <= sx0 + cx * bs < mx1 and my0 <= sy0 + cy * bs < my1)   # wie viel vom bewegten Bereich liegt darin
                if hit > best_hit:
                    best, best_hit = comp, hit
    if not best:
        return None
    ys = [p[0] for p in best]
    xs = [p[1] for p in best]
    x0, x1 = sx0 + min(xs) * bs, sx0 + (max(xs) + 1) * bs
    y0, y1 = sy0 + min(ys) * bs, sy0 + (max(ys) + 1) * bs
    return x0, y0, x1, y1


def _dc_detect_crop(frames_n=24):
    """Findet den Stream-Bereich im Discord-Fenster: nimmt ca. 3 Sekunden kleine Bilder auf und sucht die groesste zusammenhaengende
    Flaeche, in der sich laufend etwas bewegt (Seitenleisten und Chat bleiben ruhig). Gibt (Ausschnitt, Fehlertext) zurueck."""
    import numpy as np
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
    try:
        ctypes.windll.user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    cap, res, frames = _DcCapture(), {}, []
    cap.force_main = True   # die Suche arbeitet immer im Hauptfenster
    try:
        for _ in range(frames_n):
            im = cap._grab_image(user32, gdi32, 320, res, None, None)
            if isinstance(im, bytes):
                return None, "Discord wurde nicht gefunden oder ist minimiert."
            frames.append(np.asarray(im.convert("L"), dtype=np.int16))
            time.sleep(0.12)
    finally:
        _DcCapture._free(res)
    frames_arr = np.stack(frames)
    st = frames_arr.std(axis=0)
    mean = frames_arr.mean(axis=0)
    H, W = st.shape
    # 1) Buehne = grosse zusammenhaengende, ruhige, fast schwarze Flaeche. Seitenleisten, Kanalliste und Chat sind NICHT schwarz und liegen
    #    damit ausserhalb; Bewegung dort (Verlaeufe, Live-Symbole, laufende Emojis) zaehlt nicht.
    bs = 4
    bh, bw = H // bs, W // bs
    black = ((mean < 6) & (st < 3))[:bh * bs, :bw * bs].reshape(bh, bs, bw, bs).mean(axis=(1, 3)) > 0.8
    seen_b = np.zeros_like(black, dtype=bool)
    stage, stage_n = None, 0
    for yy in range(bh):
        for xx in range(bw):
            if black[yy, xx] and not seen_b[yy, xx]:
                todo, comp_b = [(yy, xx)], []
                seen_b[yy, xx] = True
                while todo:
                    cy, cx = todo.pop()
                    comp_b.append((cy, cx))
                    for ny, nx in ((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1)):
                        if 0 <= ny < bh and 0 <= nx < bw and black[ny, nx] and not seen_b[ny, nx]:
                            seen_b[ny, nx] = True
                            todo.append((ny, nx))
                if len(comp_b) >= 0.015 * bh * bw:
                    stage = (stage or []) + comp_b
                    stage_n += len(comp_b)
    if not stage or stage_n < 0.08 * bh * bw:
        return None, "Ich habe kein laufendes Bild gefunden. Der Stream muss in Discord gerade laufen."   # keine schwarze Buehne = kein Stream-Bild geoeffnet
    sx0, sx1 = min(p[1] for p in stage) * bs, (max(p[1] for p in stage) + 1) * bs
    sy0, sy1 = min(p[0] for p in stage) * bs, (max(p[0] for p in stage) + 1) * bs
    thr = max(5.0, float(np.percentile(st[sy0:sy1, sx0:sx1], 99.5)) * 0.25)
    mask = np.zeros_like(st, dtype=bool)
    mask[sy0:sy1, sx0:sx1] = st[sy0:sy1, sx0:sx1] > thr   # Bewegung nur auf der Buehne
    cs = 8
    gh, gw = H // cs, W // cs
    if gh < 3 or gw < 3:
        return None, "Das Bild war zu klein zum Auswerten."
    cells = mask[:gh * cs, :gw * cs].reshape(gh, cs, gw, cs).mean(axis=(1, 3)) > 0.3
    seen = np.zeros_like(cells, dtype=bool)
    best, best_n = None, 0
    for y0 in range(gh):
        for x0 in range(gw):
            if cells[y0, x0] and not seen[y0, x0]:
                stack, comp = [(y0, x0)], []
                seen[y0, x0] = True
                while stack:
                    cy, cx = stack.pop()
                    comp.append((cy, cx))
                    for ny, nx in ((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1), (cy + 1, cx + 1), (cy - 1, cx - 1), (cy + 1, cx - 1), (cy - 1, cx + 1)):
                        if 0 <= ny < gh and 0 <= nx < gw and cells[ny, nx] and not seen[ny, nx]:
                            seen[ny, nx] = True
                            stack.append((ny, nx))
                if len(comp) > best_n:
                    best, best_n = comp, len(comp)
    if not best or best_n < 0.04 * ((sx1 - sx0) // cs) * ((sy1 - sy0) // cs):
        return None, "Ich habe kein laufendes Bild gefunden. Der Stream muss in Discord gerade laufen."
    ys = [p[0] for p in best]
    xs = [p[1] for p in best]
    x0, x1, y0, y1 = min(xs) * cs, (max(xs) + 1) * cs, min(ys) * cs, (max(ys) + 1) * cs
    sub = mask[y0:y1, x0:x1]   # Raender auf Pixel genau: aeussere Spalten/Zeilen, in denen kaum etwas laeuft, abschneiden
    cols = np.where(sub.mean(axis=0) > 0.35)[0]
    rows = np.where(sub.mean(axis=1) > 0.35)[0]
    if len(cols) and len(rows):
        x0, x1, y0, y1 = x0 + int(cols[0]), x0 + int(cols[-1]) + 1, y0 + int(rows[0]), y0 + int(rows[-1]) + 1
    if (x1 - x0) * (y1 - y0) > 0.9 * W * H:
        return None, "Es bewegt sich fast das ganze Fenster. Dann gibt es keinen eigenen Stream-Bereich."
    motion_area = (x1 - x0) * (y1 - y0)
    gx0, gy0, gx1, gy1 = _dc_grow_tile(mean[sy0:sy1, sx0:sx1], x0 - sx0, y0 - sy0, x1 - 1 - sx0, y1 - 1 - sy0)   # auf die ganze Stream-Flaeche erweitern (nur innerhalb der Buehne)
    gx0, gx1, gy0, gy1 = gx0 + sx0, gx1 + sx0, gy0 + sy0, gy1 + sy0
    grown_area = (gx1 - gx0 + 1) * (gy1 - gy0 + 1)
    if not (grown_area > 0.85 * W * H and motion_area < 0.5 * grown_area):   # schluckt das Wachsen fast das ganze Fenster (keine schwarze Buehne): beim bewegten Bereich bleiben
        x0, y0, x1, y1 = gx0, gy0, gx1 + 1, gy1 + 1
    cb = _dc_content_bbox(mean, (sx0, sy0, sx1, sy1), (x0, y0, x1, y1))
    if cb and (cb[2] - cb[0]) * (cb[3] - cb[1]) >= 0.9 * (x1 - x0) * (y1 - y0) and (cb[2] - cb[0]) * (cb[3] - cb[1]) <= 0.8 * (sx1 - sx0) * (sy1 - sy0) * 1.25:
        x0, y0, x1, y1 = cb   # die ganze Stream-Flaeche inklusive dunkler Spielraender
    crop = {"x": round(x0 / W, 4), "y": round(y0 / H, 4), "w": round((x1 - x0) / W, 4), "h": round((y1 - y0) / H, 4)}
    return crop, None


@app.route("/discord/detect", methods=["POST"])
def discord_detect():
    bad = _dc_guard()
    if bad:
        return bad
    try:
        crop, err = _dc_detect_crop()
    except Exception as e:
        print(f"[mod:discord] Erkennung: {type(e).__name__}: {e}")
        return jsonify({"error": "Die Erkennung hat nicht geklappt."})
    if err:
        return jsonify({"error": err})
    _update_secrets("discord", lambda old: {**(old or {}), "opts": {**((old or {}).get("opts") or {}), "crop": crop}})
    _DCCAP.opts_dirty = True
    return jsonify({"error": None, "crop": crop})


@app.route("/discord/frame")
def discord_frame():
    """Ein Standbild des ganzen Discord-Fensters (zum Auswaehlen des Stream-Bereichs von Hand)."""
    bad = _dc_guard()
    if bad:
        return bad
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
    try:
        ctypes.windll.user32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    res = {}
    try:
        jpg = _DcCapture()._grab(user32, gdi32, 1280, res, None, None)
    finally:
        _DcCapture._free(res)
    return Response(jpg, mimetype="image/jpeg", headers={"Cache-Control": "no-store"})


def _dc_autofix_loop():
    """Wendet den Stream-Fix selbst an: beim ersten Mal nach der Installation sofort (Discord nicht offen -> mit Fix starten, offen ohne Fix -> neu starten),
    danach immer wieder, wenn Discord ohne den Fix laeuft und du nicht im Sprachkanal bist (damit niemand aus einem Gespraech geworfen wird)."""
    first = not _dc_cfg().get("fix_initial_done")
    try:
        if _dc_opts().get("auto_fix", False):
            _dc_autostart_apply(True)   # sofort: ab dem naechsten Windows-Start startet Discord gleich im richtigen Modus
    except Exception as e:
        print(f"[mod:discord] Autostart: {e}")
    time.sleep(2 if first else 25)
    if not first:
        for _ in range(40):   # kurz warten, bis die Verbindung zu Discord steht - dann wissen wir, ob du gerade im Sprachkanal bist
            if _DC.get("authorized") or not (_dc_cfg().get("client_id") and _dc_cfg().get("token")):
                break
            time.sleep(0.5)
    attempts = 0
    while True:
        try:
            if _dc_opts().get("auto_fix", False):
                _dc_autostart_apply(True)
            if _dc_opts().get("auto_fix", False) and attempts < 2:
                state = _dc_fix_active(fresh=True)
                if state is True and _dc_elevated() and not _DC.get("channel") and attempts < 2:
                    ok, msg = _dc_restart_with_fix()   # Discord laeuft mit Administrator-Rechten (Stream Deck & Co. kommen nicht heran): normal neu starten
                    print(f"[mod:discord] Discord mit normalen Rechten neu gestartet: {msg}")
                    attempts += 1
                elif first and state is None:
                    ok, msg = _dc_restart_with_fix()   # Discord ist nicht offen: direkt mit dem Fix starten
                    print(f"[mod:discord] Stream-Fix: {msg}")
                    attempts += 1
                elif state is False and (first or not _DC.get("channel")):   # beim ersten Mal (Installation) sofort, spaeter nie aus einem Sprachkanal werfen
                    ok, msg = _dc_restart_with_fix()
                    print(f"[mod:discord] Stream-Fix: {msg}")
                    attempts += 1
                if first:
                    _update_secrets("discord", lambda old: {**(old or {}), "fix_initial_done": True})
                    first = False
        except Exception as e:
            print(f"[mod:discord] Stream-Fix: {type(e).__name__}: {e}")
        time.sleep(300)


# ------------------------------------------------------------- Uebersetzer: Nachrichten in anderen Sprachen -> Deutsch ----
_DC_DE_WORDS = set("ich du er sie es wir ihr und oder aber nicht kein keine ist sind war waren bin bist habe hab hast hat haben wird werden kann kannst koennen können muss soll will wollen der die das den dem des ein eine einen einem mit auf für fuer von zu im in an bei nach wie was wo wann warum wer wenn dann doch auch noch schon mal ja nein bitte danke hallo moin heute morgen gleich gut okay jo nee gerne klar".split())
_dc_tr_cache = {}


def _dc_looks_german(text):
    t = text.lower()
    if re.search(r"[äöüß]", t):
        return True
    words = re.findall(r"[a-zäöüß]+", t)
    if not words:
        return True   # nur Zahlen/Emojis/Zeichen: nichts zu uebersetzen
    if len(words) == 1 and len(words[0]) <= 4:
        return True   # einzelnes kurzes Wort (lol, gg, hi ...): nicht uebersetzen
    hits = sum(1 for w in words if w in _DC_DE_WORDS)
    return hits >= 2 or (hits >= 1 and len(words) <= 3)


@app.route("/discord/translate", methods=["POST"])
def discord_translate():
    """Uebersetzt eine Nachricht ins Deutsche, falls sie in einer anderen Sprache ist. Der Schluessel kommt vom HUD (wie beim Chat):
    Gemini bevorzugt (kostenlos), sonst der eingestellte Anbieter."""
    bad = _dc_guard()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    text = str(d.get("text") or "").strip()[:1200]
    if len(text) < 3 or _dc_looks_german(text):
        return jsonify({"same": True})
    if text in _dc_tr_cache:
        return jsonify(_dc_tr_cache[text])
    system = ("Du bist ein Uebersetzer. Bekommst du einen Text, der NICHT Deutsch ist, antworte exakt im Format `CODE|Uebersetzung`, wobei CODE die Sprache des Originals "
              "auf Deutsch ausgeschrieben ist (z. B. Englischen, Franzoesischen, Spanischen, Polnischen) und die Uebersetzung natuerliches Deutsch ist. "
              "Ist der Text schon Deutsch (oder besteht nur aus Namen, Zahlen, Emojis, Slang ohne Sprache), antworte exakt `=`. Keine Erklaerungen, keine Anfuehrungszeichen.")
    tries = []
    gem = str(d.get("gemini_api_key") or "").strip()
    if gem:
        tries.append(("gemini", gem, []))
    prov = str(d.get("provider") or "")
    if prov in ("anthropic", "openai", "gemini", "groq") and not (prov == "gemini" and gem):
        tries.append((prov, str(d.get("api_key") or ""), [k for k in (d.get("groq_api_keys") or []) if isinstance(k, str) and k]))
    out = None
    for prov2, key, gkeys in tries:
        try:
            out = _llm_text(prov2, key, gkeys, system, text, None, 400)
            break
        except Exception as e:
            print(f"[mod:discord] Uebersetzer ({prov2}): {str(e)[:120]}")
    if out is None:
        return jsonify({"error": "Keine Übersetzung möglich (kein KI-Schlüssel oder Limit)."})
    out = (out or "").strip().strip("`").strip()
    mt = re.match(r"^([^|]{2,30})\|(.+)$", out, re.S)
    res = {"translation": mt.group(2).strip()[:1500], "lang": mt.group(1).strip()[:30]} if mt and out != "=" else {"same": True}
    _dc_tr_cache[text] = res
    if len(_dc_tr_cache) > 200:
        _dc_tr_cache.pop(next(iter(_dc_tr_cache)))
    return jsonify(res)


@app.route("/discord/open", methods=["POST"])
def discord_open():
    """Oeffnet eine Unterhaltung in Discord (discord://-/channels/...). Nur diese Adressen, nur vom eigenen PC."""
    bad = _dc_guard()
    if bad:
        return bad
    url = str((request.get_json(silent=True) or {}).get("url") or "")
    if not re.fullmatch(r"discord://-/channels/(?:@me|\d{5,25})/\d{5,25}", url):
        return jsonify({"error": "Diese Adresse ist nicht erlaubt."})
    try:
        os.startfile(url)
    except Exception as e:
        print(f"[mod:discord] Oeffnen: {e}")
        return jsonify({"error": "Discord konnte nicht geöffnet werden."})
    return jsonify({"error": None})


@app.route("/discord/fix", methods=["POST"])
def discord_fix():
    bad = _dc_guard()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    if d.get("confirm") is not True:   # nur nach ausdruecklicher Bestaetigung im HUD
        return jsonify({"error": "Bitte erst bestätigen."})
    ok, msg = _dc_restart_with_fix(dry_run=bool(d.get("dry_run")))
    return jsonify({"error": None if ok else msg, "message": msg})


@app.route("/discord/stream")
def discord_stream():
    bad = _dc_guard()
    if bad:
        return bad

    def gen():
        _DCCAP.add_client()
        seq = -1
        try:
            while True:
                seq, frame = _DCCAP.wait_frame(seq)
                if not frame:
                    continue
                yield b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(frame)).encode() + b"\r\n\r\n" + frame + b"\r\n"
        finally:
            _DCCAP.drop_client()
    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame", headers={"Cache-Control": "no-store"})


# DEV-Tests: erfinden Zustand/Meldungen, ohne dass Discord laeuft
@app.route("/discord/dev/<what>", methods=["POST"])
def discord_dev(what):
    bad = _dc_guard()
    if bad:
        return bad
    if what == "voice":
        names = ["Max", "Lena", "Tom", "Anna (stumm)", "Jonas"]
        mem = {}
        for i, n in enumerate(names):
            mem[str(900 + i)] = {"id": str(900 + i), "name": n, "avatar": "", "muted": "stumm" in n, "deaf": False}
        _dc_set(channel="Test-Konvoi", server="TruckersMP Testserver", members=mem, speaking={"900", "902"}, status="verbunden", connected=True)
    elif what == "voice-clear":
        _dc_set(channel=None, server="", members={}, speaking=set())
    elif what == "dm":
        _dc_push_notification("Max Beispiel", "", "Hast du kurz Zeit? (Test-DM)", "discord:dev" + uuid.uuid4().hex[:6], "dm", "discord://-/channels/@me/123456789012345678")
    elif what == "mention":
        _dc_push_notification("Lena", "#konvoi", "@du wir fahren gleich los (Test-Erwähnung)", "discord:dev" + uuid.uuid4().hex[:6], "mention")
    elif what == "testbild":
        _DCCAP.test = bool((request.get_json(silent=True) or {}).get("on", True))
    elif what == "error":
        _dc_set(status="fehler", error="Client-ID, Secret oder Weiterleitung (http://localhost) stimmen nicht.")
    elif what == "reset":
        _DCCAP.test = False
        if not _DC.get("connected"):
            _dc_set(status="aus", error="")
    else:
        return jsonify({"error": "unbekannt"}), 404
    return jsonify({"error": None})


# ------------------------------------------------------------- Automatische Einrichtung (Browser-Ablauf) ----
_DC_PORTAL = "https://discord.com/developers/applications"


def _dc_configure(client_id, client_secret):
    """Zugangsdaten speichern und die Verbindung starten (wie die Route /discord/configure, aber ohne Browser-Umweg)."""
    _update_secrets("discord", lambda old: {"client_id": client_id, "client_secret": client_secret, "opts": (old or {}).get("opts") or {}})
    _dc_start()


def flow_discord(c):
    """Fuehrt durch das Discord-Entwicklerportal: App 'ARI' anlegen, Weiterleitung http://localhost eintragen, Client-Secret auslesen,
    in A.R.I speichern. Anmelden, Sicherheitscodes und (ohne vorab gegebene Erlaubnis) Bedingungen/Bestaetigungen macht der Nutzer selbst."""
    page = c.page
    total = 5

    def I(s):
        return re.compile(s, re.I)

    def logged_in():
        return bool(re.search(r"/developers/applications", page.url)) and "/login" not in page.url and not c.visible(page.locator("input[type=password]"), 0)

    c.step(1, total, "Discord-Entwicklerportal öffnen", "A.R.I öffnet das Discord-Entwicklerportal.")
    page.goto(_DC_PORTAL, wait_until="domcontentloaded")
    page.wait_for_timeout(1500)
    if not logged_in():
        c.step(2, total, "Anmelden", "Bitte melde dich im geöffneten Browserfenster bei Discord an.")
        c.ask_user("Melde dich im Browserfenster bei Discord an (auch ein Sicherheitscode gehört dir). Danach macht A.R.I automatisch weiter.", logged_in)
        if not re.search(r"/developers/applications", page.url):
            page.goto(_DC_PORTAL, wait_until="domcontentloaded")
    holder = {}
    app_url = re.compile(r"/developers/applications/(\d{15,25})")

    c.step(3, total, "App anlegen", "A.R.I legt die Discord-App „ARI“ an …")

    def create():
        existing = page.get_by_text(re.compile(r"^ARI$")).first
        if not app_url.search(page.url):
            if c.visible(existing, 3):
                existing.click()
            else:
                c.click_any(page.get_by_role("button", name=I(r"new application|neue anwendung|neue app|create application|anwendung erstellen")),
                            page.get_by_role("link", name=I(r"new application|neue anwendung|neue app|create application|anwendung erstellen")))
                page.wait_for_timeout(600)
                page.get_by_label(I(r"^name")).first.fill("ARI")
                box = page.get_by_role("checkbox").first
                if c.consent:
                    if c.visible(box, 2):
                        box.check()
                else:
                    c.ask_user("Setze im Browserfenster das Häkchen bei den Discord-Bedingungen und klicke auf „Erstellen“ (Create).", lambda: bool(app_url.search(page.url)))
                if not app_url.search(page.url):
                    c.click_any(page.get_by_role("button", name=I(r"^(create|erstellen|anlegen)$")))
        page.wait_for_url(app_url, timeout=20000)
    c.auto(create, "Lege die App selbst an: „New Application“, Name „ARI“, Bedingungen bestätigen, „Create“. Klicke danach auf „Weiter“.", lambda: bool(app_url.search(page.url)))
    m = app_url.search(page.url)
    if not m:
        raise RuntimeError("Die App-Nummer (Client-ID) wurde nicht gefunden.")
    holder["id"] = m.group(1)

    c.step(4, total, "Weiterleitung und Secret", "A.R.I trägt http://localhost ein und liest das Client-Secret aus …")

    def input_values():
        return page.eval_on_selector_all("input", "els => els.map(e => e.value || '')")

    def redirect_boxes():
        return page.get_by_role("textbox", name=I(r"weiterleitung|redirect"))

    def save_button():
        return page.get_by_role("button", name=I(r"änderungen speichern|save changes|^speichern$|^save$"))

    def oauth():
        page.goto(f"{_DC_PORTAL}/{holder['id']}/oauth2", wait_until="domcontentloaded")
        page.wait_for_timeout(2500)
        if "http://localhost" in input_values():
            return   # schon eingetragen und gespeichert
        target = None
        boxes = redirect_boxes()
        for i in range(boxes.count()):
            el = boxes.nth(i)
            if el.is_visible() and not (el.input_value() or "").strip():
                target = el
                break
        if target is None:   # kein leeres Feld: neue Zeile hinzufuegen ("Andere hinzufuegen" / "Add Another")
            c.click_any(page.get_by_role("button", name=I(r"andere hinzufügen|add another|add redirect|weiterleitung hinzufügen")))
            page.wait_for_timeout(500)
            boxes = redirect_boxes()
            target = boxes.nth(boxes.count() - 1)
        target.fill("http://localhost")
        page.wait_for_timeout(500)
        c.click_any(save_button(), timeout=10)
        c.wait_for(lambda: not c.visible(save_button(), 0), timeout=8)
        page.wait_for_timeout(800)
    c.auto(oauth, "Öffne in der App „OAuth2“, füge unter „Redirects“ die Adresse http://localhost hinzu und klicke „Save Changes“. Klicke danach auf „Weiter“.")

    def read_secret():
        c.click_any(page.get_by_role("button", name=I(r"reset secret|schlüssel zurücksetzen|secret zurücksetzen|geheim\w* .*zurücksetzen|neues secret")))
        page.wait_for_timeout(800)
        # Rueckfrage "Ja, los geht's!" / "Yes, do it!": gehoert zum Erzeugen des Secrets (kein Rechtstext) und wird immer bestaetigt
        confirm = page.get_by_role("button", name=I(r"yes, do it|ja, los|ja, mach|ja, tu|ja, bitte|^yes\b|^ja\b|bestätigen|confirm"))
        if c.visible(confirm, 4):
            confirm.first.click()
            page.wait_for_timeout(800)
        if c.visible(page.locator("input[type=password], input[autocomplete=one-time-code]"), 2):
            c.ask_user("Discord fragt nach deinem Passwort oder Sicherheitscode. Gib ihn selbst im Browserfenster ein und bestätige.",
                       lambda: not c.visible(page.locator("input[type=password], input[autocomplete=one-time-code]"), 0))

        def find():
            cands = [v for v in input_values()] + re.findall(r"[A-Za-z0-9_\-]{32}", c.text())
            for v in cands:
                v = (v or "").strip()
                if len(v) == 32 and re.fullmatch(r"[A-Za-z0-9_\-]{32}", v) and not v.isdigit():
                    holder["secret"] = v
                    return True
            return False
        if not c.wait_for(find, timeout=15):
            raise RuntimeError("Client-Secret nicht gefunden")
    c.auto(read_secret, "Klicke unter „OAuth2“ auf „Reset Secret“, bestätige und lass das neue Secret sichtbar. Klicke danach auf „Weiter“.")
    if "secret" not in holder:
        raise RuntimeError("Das Client-Secret konnte nicht gelesen werden.")

    c.step(5, total, "Mit Discord verbinden", "A.R.I speichert die Daten und verbindet sich mit deiner Discord-App.")
    _dc_configure(holder["id"], holder["secret"])
    c.ask_user("Bestätige jetzt in der Discord-App den Knopf „Autorisieren“.", lambda: bool(_DC.get("authorized")) or _DC.get("status") == "fehler")
    if _DC.get("status") == "fehler":
        raise RuntimeError(_DC.get("error") or "Die Verbindung zu Discord hat nicht geklappt.")
    return {"discord": {"clientId": holder["id"]}}


def register(ctx):
    ctx.add_status(lambda: {"discord": _dc_public()})
    try:
        import browser_setup
        browser_setup.register_flow("discord", flow_discord, "Discord", ["discord.com", "discordapp.com"])
    except Exception as e:
        print(f"[mod:discord] Automatische Einrichtung nicht verfuegbar: {e}")
    try:
        _WGC.available()   # Aufnahme-Paket bei Bedarf gleich im Hintergrund nachinstallieren
    except Exception:
        pass
    threading.Thread(target=_dc_autofix_loop, daemon=True).start()
    threading.Thread(target=_dc_embed_loop, daemon=True).start()
    threading.Thread(target=_dc_autopop_loop, daemon=True).start()
    cfg = _dc_cfg()
    if cfg.get("client_id") and cfg.get("client_secret"):
        _dc_start()
