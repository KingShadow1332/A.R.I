// Mod "Spiel-Integration" - Oberflaeche (Badge, Spielmodus-Menue, Einstellungen > SPIELE, Spiele-Editor).
// Wird vom HUD per eval in seinem eigenen Programm gestartet - hat also Zugriff auf logLine, escapeHtml, devTestActions ...
const __slot = (id, html) => ARI_MODS.slot(id, html);   // Platzhalter bleiben stehen, damit auch andere Mods sie nutzen koennen
__slot('modSlotBadge', "    <button class=\"game-mode-badge off\" id=\"gameModeBadge\" type=\"button\" title=\"Spielmodus umschalten (Standard: aus)\"><span class=\"dot\"></span><span id=\"gameModeBadgeText\">SPIELMODUS: AUS</span></button>");
__slot('modSlotBtn', "      <button class=\"icon-btn off\" id=\"btnGameMode\" title=\"Spielmodus umschalten (Standard: aus)\">\n        <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><rect x=\"2\" y=\"7\" width=\"20\" height=\"10\" rx=\"5\"/><path d=\"M7 10v4M5 12h4\"/><circle cx=\"15\" cy=\"10.5\" r=\"1\"/><circle cx=\"17.5\" cy=\"13\" r=\"1\"/></svg>\n      </button>");
__slot('modSlotSettings', "    <details class=\"set-section\">\n      <summary>SPIELE</summary>\n      <div class=\"set-section-body\">\n        <div class=\"field\">\n          <label style=\"display:flex; align-items:center; gap:8px; justify-content:flex-start;\">\n            <input type=\"checkbox\" id=\"setGameScan\" style=\"width:auto; accent-color:var(--pink);\">\n            Spiele automatisch erkennen (pr\u00fcft alle 10 Sekunden)\n          </label>\n          <div style=\"font-size:11px;opacity:.55;margin-top:4px;\">Aus = keine Pr\u00fcfung (spart Leistung). Dann w\u00e4hlst du hier das Spiel, das du gerade spielst.</div>\n        </div>\n        <div class=\"field\" id=\"manualGameField\" style=\"display:none;\">\n          <label>Ich spiele gerade</label>\n          <select id=\"setManualGame\"></select>\n        </div>\n        <div class=\"field\">\n          <label>Spiel</label>\n          <select id=\"gameSelect\"></select>\n        </div>\n        <button class=\"btn primary\" type=\"button\" id=\"btnEditGame\" style=\"width:100%;\">TASTEN BEARBEITEN</button>\n      </div>\n    </details>");
__slot('modSlotOverlay', "<!-- ===== SPIEL-TASTEN MODAL (gross, eigenes Fenster) ===== -->\n<div class=\"modal-overlay\" id=\"gameEditOverlay\">\n  <div class=\"modal modal-large\">\n    <div class=\"modal-h\">\n      <span class=\"t\" id=\"gameEditTitle\">SPIEL BEARBEITEN</span>\n      <button class=\"modal-close\" id=\"gameEditClose\">\u2715</button>\n    </div>\n    <div class=\"field\">\n      <label>Spielname</label>\n      <input type=\"text\" id=\"gameEditName\" placeholder=\"Spielname, z.B. Star Citizen\">\n    </div>\n    <div class=\"field\">\n      <label>Wartezeit nach dem \u00d6ffnen der Sternenkarte (Sekunden)</label>\n      <input type=\"number\" id=\"gameEditMapWait\" min=\"0.5\" max=\"15\" step=\"0.5\" placeholder=\"3\">\n      <div style=\"font-size:11px;opacity:.55;margin-top:4px;\">Bei der Routenplanung wartet A.R.I so lange, bis die Karte offen ist, bevor es ins Suchfeld klickt. Zu schnell? H\u00f6her stellen (Standard 3).</div>\n      <label style=\"display:flex; align-items:center; gap:8px; justify-content:flex-start; margin-top:10px;\">\n        <input type=\"checkbox\" id=\"gameEditCloseMap\" style=\"width:auto; accent-color:var(--pink);\">\n        Sternenkarte nach der Route wieder schlie\u00dfen\n      </label>\n    </div>\n    <div class=\"field\">\n      <div style=\"display:none\">\n      <label>Prozessname (.exe) f\u00fcr die Spielmodus-Erkennung</label>\n      <input type=\"text\" id=\"gameEditProcessName\" placeholder=\"z.B. StarCitizen.exe\">\n      <button class=\"btn\" type=\"button\" id=\"btnPickExe\" style=\"width:100%; margin-top:8px;\">\ud83d\udcc1 DATEI AUSW\u00c4HLEN</button>\n      <div style=\"font-size:11px;opacity:.55;margin-top:4px;\">Name wie im Task-Manager unter \u201eDetails\u201c. Leer = keine Pr\u00fcfung.</div>\n      </div>\n      <div style=\"font-size:12.5px;opacity:.7;margin-top:6px;\">A.R.I erkennt das Spiel selbst (alle 10 Sekunden) \u2013 der Spielname sollte im Programmnamen vorkommen, z. B. \u201eStar Citizen\u201c \u2192 StarCitizen.exe. Du musst nichts eintragen.</div>\n    </div>\n    <div style=\"font-size:11px;opacity:.55;margin-bottom:10px;\">Taste z.B. \u201eN\u201c oder \u201eStrg+G\u201c. Wird auf dem Hub gespeichert.</div>\n    <div class=\"field\">\n      <input type=\"text\" id=\"gameEditSearch\" placeholder=\"\ud83d\udd0d Aktion oder Taste suchen \u2026\">\n    </div>\n    <div id=\"gameEditCategories\"></div>\n    <div style=\"display:flex; gap:8px; margin-bottom:10px;\">\n      <button class=\"btn\" type=\"button\" id=\"btnAddCategory\" style=\"flex:1;\">+ NEUE KATEGORIE</button>\n      <button class=\"btn\" type=\"button\" id=\"btnAddClick\" style=\"flex:1;\">+ MAUSKLICK</button>\n    </div>\n    <div class=\"modal-actions\">\n      <button class=\"btn danger\" type=\"button\" id=\"btnRemoveGame\">SPIEL ENTFERNEN</button>\n      <button class=\"btn primary\" type=\"button\" id=\"btnSaveGameProfiles\">SPEICHERN</button>\n    </div>\n    <div id=\"gameProfilesStatus\" style=\"font-size:11px;opacity:.7;margin-top:8px;\"></div>\n  </div>\n</div>");
(function () {
  ARI_MODS.slot('modSlotDev', "<details class=\"dev-group\" id=\"devGameGroup\"><summary>SPIELMODUS</summary><div class=\"dev-tests\">\n            <button class=\"btn\" type=\"button\" data-devtest=\"gm-off\">AUS</button>\n            <button class=\"btn\" type=\"button\" data-devtest=\"gm-warn\">GELB</button>\n            <button class=\"btn\" type=\"button\" data-devtest=\"gm-on\">GR\u00dcN</button>\n            <button class=\"btn\" type=\"button\" data-devtest=\"editor\">SPIELE-EDITOR</button>\n          </div></details>");
  document.querySelectorAll('#devGameGroup [data-devtest]').forEach(btn => {
    btn.addEventListener('click', () => { const run = devTestActions[btn.dataset.devtest]; if (!run) return; if (btn.dataset.devtest !== 'editor') closeSettings(); run(); });
  });
})();

  /* ============================================================
     SPIELE — konfigurierbare Sprach-zu-Tastendruck-Aktionen
     (game_action-Tool auf dem Hub). Zustand liegt serverseitig in
     game_profiles.json, NICHT in localStorage — eigenes Laden/Speichern
     unabhaengig vom allgemeinen SPEICHERN-Button, wie bei Kalender/Spotify.
     ============================================================ */
  let gameProfiles = {};
  let currentGameKey = null;
  const gameSelectEl = document.getElementById('gameSelect');
  const gameEditOverlay = document.getElementById('gameEditOverlay');
  const gameEditTitleEl = document.getElementById('gameEditTitle');
  const gameEditNameEl = document.getElementById('gameEditName');
  const gameEditMapWaitEl = document.getElementById('gameEditMapWait');
  const gameEditCloseMapEl = document.getElementById('gameEditCloseMap');
  const gameEditProcessNameEl = document.getElementById('gameEditProcessName');
  const gameEditCategoriesEl = document.getElementById('gameEditCategories');
  const gameProfilesStatusEl = document.getElementById('gameProfilesStatus');
  const NEW_GAME_VALUE = '__new__';
  // Spielmodus: standardmaessig aus (siehe hub.py _load_game_mode_enabled),
  // per Klick auf das Icon ODER auf die Statusanzeige oben um- und wieder
  // abschaltbar (beide steuern denselben Zustand). Zustand liegt serverseitig
  // (secrets.json), nicht im Browser, damit er ueber alle Tabs/Neustarts der
  // HUD konsistent bleibt.
  const btnGameModeEl = document.getElementById('btnGameMode');
  const gameModeBadgeEl = document.getElementById('gameModeBadge');
  let gameAutoShown = false;   // gameModeEnabled liegt im HUD-Kern (wird dort beim Vorlesen von Nachrichten gebraucht)
  function setGameModeUI(enabled) {
    gameModeEnabled = enabled;
    btnGameModeEl.classList.toggle('on', enabled);
    btnGameModeEl.classList.toggle('off', !enabled);
    gameModeBadgeEl.classList.toggle('off', !enabled);
    if (!enabled) {
      gameModeBadgeEl.classList.remove('warn');
      document.getElementById('gameModeBadgeText').textContent = 'SPIELMODUS: AUS';
    } else {
      // Sofort gelb beim Einschalten (noch kein Spiel bestaetigt), statt
      // erst kurz gruen zu zeigen, bis der naechste Status-Poll eintrifft —
      // applyStatus() schaltet dann auf gruen um, sobald ein Spiel wirklich
      // erkannt wird.
      gameModeBadgeEl.classList.add('warn');
      document.getElementById('gameModeBadgeText').textContent = 'SPIELMODUS: KEIN SPIEL';
    }
  }
  let gameScanOn = true, manualGameKey = '';
  function showManualGame() { const f = document.getElementById('manualGameField'); if (f) f.style.display = gameScanOn ? 'none' : ''; }
  async function loadGameModeToggleState() {
    try {
      const res = await fetch('/game-mode');
      const data = await res.json();
      gameScanOn = data.scan !== false;
      manualGameKey = data.manual_game || '';
      const cb = document.getElementById('setGameScan'); if (cb) cb.checked = gameScanOn;
      showManualGame(); populateManualGame();
      setGameModeUI(!!data.enabled);
    } catch (e) {}
  }
  document.getElementById('setManualGame').addEventListener('change', async e => {
    const key = e.target.value;
    try {
      const res = await (await fetch('/game-mode', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: !!key, game: key }) })).json();
      manualGameKey = key; setGameModeUI(!!res.enabled);
      logLine('system', key ? 'Spielmodus: ' + (gameProfiles[key] && gameProfiles[key].display_name || key) + ' (von Hand gewählt).' : 'Spielmodus aus.');
    } catch (err) { logLine('error', 'Spiel konnte nicht gesetzt werden: ' + err.message); }
  });
  document.getElementById('setGameScan').addEventListener('change', async e => {
    const on = e.target.checked;
    try {
      await fetch('/game-scan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: on }) });
      gameScanOn = on; showManualGame();
      logLine('system', on ? 'Spiele werden automatisch erkannt.' : 'Automatische Spielerkennung aus – wähle unter Einstellungen > SPIELE, welches Spiel du spielst.');
    } catch (err) { e.target.checked = !on; }
  });
  loadGameModeToggleState();
  async function toggleGameMode() {
    devGameModePreview = false;
    const wantEnabled = !gameModeEnabled;
    btnGameModeEl.disabled = true;
    gameModeBadgeEl.disabled = true;
    try {
      const res = await fetch('/game-mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: wantEnabled }),
      });
      const data = await res.json();
      setGameModeUI(!!data.enabled);
      logLine('system', data.enabled ? 'Spielmodus aktiviert.' : 'Spielmodus deaktiviert.');
    } catch (e) {
      logLine('error', 'Spielmodus konnte nicht umgeschaltet werden: ' + e.message);
    } finally {
      btnGameModeEl.disabled = false;
      gameModeBadgeEl.disabled = false;
    }
  }
  // Klick auf "Spielmodus": Auswahl der Spiele (statt blind umzuschalten). "Aus" schaltet den Spielmodus ab.
  async function setGameFromMenu(key, enabled) {
    try {
      const res = await (await fetch('/game-mode', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled, game: key }) })).json();
      manualGameKey = key; devGameModePreview = false; setGameModeUI(!!res.enabled);
      const sel = document.getElementById('setManualGame'); if (sel) sel.value = key;
      logLine('system', !enabled ? 'Spielmodus deaktiviert.' : key ? 'Spielmodus: ' + (gameProfiles[key] && gameProfiles[key].display_name || key) + '.' : 'Spielmodus aktiviert (automatische Erkennung).');
    } catch (err) { logLine('error', 'Spielmodus konnte nicht gesetzt werden: ' + err.message); }
  }
  function closeGameMenu() { const m = document.getElementById('gameMenu'); if (m) m.remove(); document.removeEventListener('mousedown', gameMenuOutside, true); }
  function gameMenuOutside(e) { const m = document.getElementById('gameMenu'); if (m && !m.contains(e.target) && e.target !== btnGameModeEl && e.target !== gameModeBadgeEl && !gameModeBadgeEl.contains(e.target)) closeGameMenu(); }
  async function openGameMenu(anchor) {
    if (document.getElementById('gameMenu')) { closeGameMenu(); return; }
    if (!Object.keys(gameProfiles).length) { try { await loadGameProfiles(); } catch (e) {} }
    const items = [];
    if (gameScanOn) items.push({ k: '', t: 'Automatisch erkennen', on: gameModeEnabled && !manualGameKey, en: true });
    Object.entries(gameProfiles).forEach(([k, g]) => items.push({ k, t: g.display_name || k, on: gameModeEnabled && manualGameKey === k, en: true }));
    items.push({ k: '', t: 'Spielmodus aus', on: !gameModeEnabled, en: false, off: true });
    const m = document.createElement('div');
    m.id = 'gameMenu';
    const r = anchor.getBoundingClientRect();
    m.style.cssText = 'position:fixed;z-index:9999;min-width:220px;max-height:60vh;overflow:auto;padding:6px;background:rgba(14,12,24,.97);border:1px solid var(--pink,#ff2d78);border-radius:10px;box-shadow:0 8px 30px rgba(0,0,0,.6);font:13px/1.2 inherit;left:' + Math.max(8, Math.min(r.left, innerWidth - 240)) + 'px;top:' + (r.bottom + 6) + 'px;';
    m.innerHTML = '<div style="font-size:10px;letter-spacing:.12em;opacity:.55;padding:4px 8px 6px;">SPIELMODUS – SPIEL WÄHLEN</div>' + items.map((it, i) =>
      `<div data-i="${i}" style="padding:8px 10px;border-radius:6px;cursor:pointer;color:${it.on ? '#29d3f5' : it.off ? '#ff7a9c' : '#e2e8f5'};${it.on ? 'background:rgba(41,211,245,.1);' : ''}">${it.on ? '● ' : ''}${escapeHtml(it.t)}</div>`).join('');
    m.addEventListener('mouseover', e => { const d = e.target.closest('[data-i]'); [...m.querySelectorAll('[data-i]')].forEach(x => { if (!x.style.background.includes('41, 211')) x.style.background = x === d ? 'rgba(255,45,120,.14)' : ''; }); });
    m.addEventListener('click', e => { const d = e.target.closest('[data-i]'); if (!d) return; const it = items[+d.dataset.i]; closeGameMenu(); setGameFromMenu(it.k, it.en); });
    document.body.appendChild(m);
    document.addEventListener('mousedown', gameMenuOutside, true);
  }
  btnGameModeEl.addEventListener('click', () => openGameMenu(btnGameModeEl));
  gameModeBadgeEl.addEventListener('click', () => openGameMenu(gameModeBadgeEl));
  async function loadGameProfiles() {
    try {
      const res = await fetch('/game-profiles');
      gameProfiles = await res.json();
    } catch (e) {
      gameProfiles = {};
    }
    populateGameSelect();
  }
  // Dropdown genau wie beim KI-Anbieter: immer nur EIN Spiel gleichzeitig im
  // Blick, statt alle als lange Kartenliste untereinander zu zeigen.
  function populateManualGame() {
    const sel = document.getElementById('setManualGame'); if (!sel) return;
    const cur = manualGameKey;
    sel.innerHTML = '<option value="">– kein Spiel –</option>' + Object.entries(gameProfiles).map(([gKey, g]) =>
      `<option value="${escapeHtml(gKey)}">${escapeHtml(g.display_name || gKey)}</option>`).join('');
    sel.value = Object.keys(gameProfiles).includes(cur) ? cur : '';
  }
  function populateGameSelect() {
    populateManualGame();
    const entries = Object.entries(gameProfiles);
    const prevValue = gameSelectEl.value;
    gameSelectEl.innerHTML = entries.map(([gKey, g]) =>
      `<option value="${escapeHtml(gKey)}">${escapeHtml(g.display_name || gKey)}</option>`
    ).join('') + `<option value="${NEW_GAME_VALUE}">+ Neues Spiel …</option>`;
    if (entries.some(([gKey]) => gKey === prevValue)) gameSelectEl.value = prevValue;
  }

  function openGameEditor(gKey) {
    currentGameKey = gKey;
    const g = gameProfiles[gKey];
    gameEditTitleEl.textContent = (g.display_name || 'SPIEL') + ' BEARBEITEN';
    gameEditNameEl.value = g.display_name || '';
    gameEditMapWaitEl.value = g.map_wait != null ? g.map_wait : 3;
    gameEditCloseMapEl.checked = g.close_map_after !== false;
    gameEditProcessNameEl.value = g.process_name || '';
    gameProfilesStatusEl.textContent = '';
    document.getElementById('gameEditSearch').value = '';
    renderGameEditor();
    gameEditOverlay.classList.add('open');
  }
  document.getElementById('gameEditSearch').addEventListener('input', renderGameEditor);
  function closeGameEditor() {
    gameEditOverlay.classList.remove('open');
    if (gameProfiles['__dev_test__']) { delete gameProfiles['__dev_test__']; populateGameSelect(); }
  }

  // Mausklicks sind normale Aktionen mit Feld "click" (Position in % der
  // Bildschirmgroesse) - eigene, einklappbare Gruppe oben, nur sichtbar wenn
  // das Spiel welche hat (Standard: keine, ausser Star Citizen).
  let forceOpenClicks = false;
  function isClickAction(a) { return a && typeof a.click === 'object' && a.click !== null; }
  function clickRowHtml(aKey, a) {
    const c = a.click || {};
    const pct = v => (v != null ? Math.round(v * 100) : '');
    return `
      <div class="action-row" data-action-key="${escapeHtml(aKey)}">
        <input type="text" class="action-label-input" value="${escapeHtml(a.label || '')}" placeholder="Name, z.B. Suchfeld">
        <input type="number" class="click-num click-x" min="0" max="100" placeholder="X %" value="${pct(c.x)}">
        <input type="number" class="click-num click-y" min="0" max="100" placeholder="Y %" value="${pct(c.y)}">
        <button type="button" class="btn btn-capture-click" title="Position erfassen: drücken, dann im Spiel die Stelle anklicken">📍</button>
        <button type="button" class="btn danger btn-remove-action">✕</button>
      </div>`;
  }
  // Aktionen nach ihrer "category" gruppiert (frei editierbar, z.B. Zu Fuss /
  // Im Schiff / Kampf / Mining / Salvage) statt einer langen flachen Liste.
  function renderGameEditor() {
    const g = gameProfiles[currentGameKey];
    if (!g) return;
    const query = (document.getElementById('gameEditSearch').value || '').trim().toLowerCase();
    const byCategory = {};
    const clickEntries = [];
    Object.entries(g.actions || {}).forEach(([aKey, a]) => {
      if (query) {
        const haystack = ((a.label || '') + ' ' + (a.key || '') + ' ' + aKey).toLowerCase();
        if (!haystack.includes(query)) return;
      }
      if (isClickAction(a)) { clickEntries.push([aKey, a]); return; }
      const cat = (a.category || 'Sonstiges').trim() || 'Sonstiges';
      (byCategory[cat] = byCategory[cat] || []).push([aKey, a]);
    });
    const catNames = Object.keys(byCategory).sort((a, b) => a.localeCompare(b, 'de'));
    if (!catNames.length && !clickEntries.length) {
      gameEditCategoriesEl.innerHTML = query
        ? '<div style="font-size:11px;opacity:.55;margin-bottom:10px;">Keine Aktion gefunden für „' + escapeHtml(query) + '“.</div>'
        : '<div style="font-size:11px;opacity:.55;margin-bottom:10px;">Noch keine Aktionen — mit „+ NEUE KATEGORIE“ oder „+ MAUSKLICK“ anfangen.</div>';
      return;
    }
    const clicksHtml = clickEntries.length ? `
      <details class="game-category" data-clicks${(query || forceOpenClicks) ? ' open' : ''}>
        <summary class="game-category-h">MAUSKLICKS (${clickEntries.length})</summary>
        ${clickEntries.map(([aKey, a]) => clickRowHtml(aKey, a)).join('')}
        <div class="click-hint">📍 drücken, dann im Spiel die Stelle anklicken (15 s).</div>
      </details>` : '';
    forceOpenClicks = false;
    gameEditCategoriesEl.innerHTML = clicksHtml + catNames.map(cat => `
      <details class="game-category" data-category="${escapeHtml(cat)}"${query ? ' open' : ''}>
        <summary class="game-category-h">${escapeHtml(cat)} (${byCategory[cat].length})</summary>
        ${byCategory[cat].map(([aKey, a]) => `
          <div class="action-row" data-action-key="${escapeHtml(aKey)}">
            <input type="text" class="action-label-input" value="${escapeHtml(a.label || '')}" placeholder="Aktion, z.B. Fahrwerk ausfahren">
            <input type="text" class="action-key-input" value="${escapeHtml(a.key || '')}" placeholder="Taste, z.B. N">
            <button type="button" class="btn danger btn-remove-action">✕</button>
          </div>`).join('')}
        <button type="button" class="btn btn-add-action">+ Aktion in „${escapeHtml(cat)}“</button>
      </details>`).join('');
  }

  gameEditCloseMapEl.addEventListener('change', () => { if (currentGameKey) gameProfiles[currentGameKey].close_map_after = gameEditCloseMapEl.checked; });
  gameEditMapWaitEl.addEventListener('input', () => {
    const v = parseFloat(gameEditMapWaitEl.value);
    if (currentGameKey && isFinite(v)) gameProfiles[currentGameKey].map_wait = Math.max(0.5, Math.min(15, v));
  });
  gameEditNameEl.addEventListener('input', () => {
    if (currentGameKey) gameProfiles[currentGameKey].display_name = gameEditNameEl.value;
  });
  gameEditProcessNameEl.addEventListener('input', () => {
    if (currentGameKey) gameProfiles[currentGameKey].process_name = gameEditProcessNameEl.value.trim();
  });
  document.getElementById('btnPickExe').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    const prevLabel = btn.textContent;
    btn.textContent = 'Ordner-Browser öffnet sich …';
    try {
      const res = await fetch('/pick-exe', { method: 'POST' });
      const data = await res.json();
      if (data.error) {
        gameProfilesStatusEl.textContent = 'Fehler: ' + data.error;
      } else {
        gameEditProcessNameEl.value = data.filename;
        if (currentGameKey) gameProfiles[currentGameKey].process_name = data.filename;
        gameProfilesStatusEl.textContent = `Ausgewählt: ${data.filename} — nicht vergessen zu speichern.`;
      }
    } catch (err) {
      gameProfilesStatusEl.textContent = 'Fehler: ' + err.message;
    } finally {
      btn.disabled = false;
      btn.textContent = prevLabel;
    }
  });
  // Event-Delegation statt eines Listeners pro Feld — funktioniert fuer
  // beliebig viele, dynamisch hinzugefuegte Kategorien/Aktionen ohne
  // erneutes Verdrahten nach jedem renderGameEditor().
  gameEditCategoriesEl.addEventListener('input', (e) => {
    const row = e.target.closest('[data-action-key]');
    if (!row) return;
    const action = gameProfiles[currentGameKey].actions[row.dataset.actionKey];
    if (e.target.classList.contains('action-label-input')) action.label = e.target.value;
    else if (e.target.classList.contains('action-key-input')) action.key = e.target.value;
    else if (e.target.classList.contains('click-num')) updateClickFromRow(row, action);
  });
  function updateClickFromRow(row, action) {
    const x = parseFloat(row.querySelector('.click-x').value), y = parseFloat(row.querySelector('.click-y').value);
    action.click = (isNaN(x) || isNaN(y)) ? {} : { x: x / 100, y: y / 100 };
  }
  gameEditCategoriesEl.addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-remove-action')) {
      const row = e.target.closest('[data-action-key]');
      delete gameProfiles[currentGameKey].actions[row.dataset.actionKey];
      renderGameEditor();
    } else if (e.target.classList.contains('btn-capture-click')) {
      captureClickForRow(e.target);
    } else if (e.target.classList.contains('btn-add-action')) {
      const catEl = e.target.closest('[data-category]');
      gameProfiles[currentGameKey].actions['action_' + Date.now()] = { label: '', key: '', category: catEl.dataset.category };
      renderGameEditor();
    }
  });
  async function captureClickForRow(btn) {
    const row = btn.closest('[data-action-key]');
    const action = gameProfiles[currentGameKey].actions[row.dataset.actionKey];
    btn.disabled = true;
    gameProfilesStatusEl.textContent = 'Jetzt im Spiel an die richtige Stelle klicken … (15 s)';
    try {
      const res = await fetch('/capture-click', { method: 'POST' });
      const data = await res.json();
      if (data.error) {
        gameProfilesStatusEl.textContent = 'Fehler: ' + data.error;
      } else {
        row.querySelector('.click-x').value = Math.round(data.x * 100);
        row.querySelector('.click-y').value = Math.round(data.y * 100);
        updateClickFromRow(row, action);
        gameProfilesStatusEl.textContent = `Erfasst: ${Math.round(data.x * 100)} % / ${Math.round(data.y * 100)} % — nicht vergessen zu speichern.`;
      }
    } catch (err) {
      gameProfilesStatusEl.textContent = 'Fehler: ' + err.message;
    } finally {
      btn.disabled = false;
    }
  }
  document.getElementById('btnAddClick').addEventListener('click', () => {
    gameProfiles[currentGameKey].actions['klick_' + Date.now()] = { label: '', key: '', click: {}, category: 'Mausklicks' };
    forceOpenClicks = true;
    renderGameEditor();
  });
  document.getElementById('btnAddCategory').addEventListener('click', () => {
    const name = prompt('Name der neuen Kategorie, z.B. "Salvage":');
    if (!name || !name.trim()) return;
    gameProfiles[currentGameKey].actions['action_' + Date.now()] = { label: '', key: '', category: name.trim() };
    renderGameEditor();
  });
  document.getElementById('btnRemoveGame').addEventListener('click', () => {
    if (!currentGameKey || !confirm(`"${gameProfiles[currentGameKey].display_name || currentGameKey}" wirklich entfernen?`)) return;
    delete gameProfiles[currentGameKey];
    populateGameSelect();
    closeGameEditor();
  });
  document.getElementById('btnEditGame').addEventListener('click', () => {
    if (gameSelectEl.value === NEW_GAME_VALUE || !gameSelectEl.value) {
      const gKey = 'game_' + Date.now();
      gameProfiles[gKey] = { display_name: '', aliases: [], actions: {} };
      populateGameSelect();
      gameSelectEl.value = gKey;
      openGameEditor(gKey);
    } else {
      openGameEditor(gameSelectEl.value);
    }
  });
  document.getElementById('gameEditClose').addEventListener('click', closeGameEditor);
  gameEditOverlay.addEventListener('click', (e) => { if (e.target === gameEditOverlay) closeGameEditor(); });
  document.getElementById('btnSaveGameProfiles').addEventListener('click', async () => {
    gameProfilesStatusEl.textContent = 'Speichert …';
    try {
      const res = await fetch('/game-profiles', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(Object.entries(gameProfiles).filter(([k]) => k !== '__dev_test__'))),
      });
      const data = await res.json();
      gameProfilesStatusEl.textContent = data.error ? ('Fehler: ' + data.error) : 'Gespeichert.';
      if (!data.error) {
        populateGameSelect();
        gameSelectEl.value = currentGameKey;
        closeGameEditor();
      }
    } catch (e) {
      gameProfilesStatusEl.textContent = 'Fehler: ' + e.message;
    }
  });
ARI_MODS.on('status', d => {
    // --- Spielmodus (automatisch per Prozesserkennung, siehe hub.py) ---
  // Text zeigt zusaetzlich das erkannte Spiel an, wenn der Modus an ist —
  // die "on"/"off"-Klasse selbst kommt aus setGameModeUI() (siehe unten),
  // damit ein Klick sofort reagiert, ohne auf den naechsten Poll zu warten.
  if (devGameModePreview) {
    // Dev-Test-Vorschau aktiv: Anzeige nicht durch den echten Poll ueberschreiben
  } else if (d.active_game_mode) {
    // Ein konfiguriertes Spiel laeuft: Spielmodus automatisch aktiv (auch wenn der Schalter aus ist) - endet das Spiel, geht er von selbst wieder aus
    document.getElementById('gameModeBadgeText').textContent = 'SPIELMODUS: ' + d.active_game_mode.toUpperCase();
    gameModeBadgeEl.classList.remove('warn', 'off');
    btnGameModeEl.classList.add('on'); btnGameModeEl.classList.remove('off');
    gameAutoShown = true;
  } else {
    if (gameAutoShown) { gameAutoShown = false; setGameModeUI(gameModeEnabled); }   // Spiel beendet: Anzeige wieder wie der Schalter
    if (gameModeEnabled && d.game_scan === false) {
      // Automatische Erkennung aus, Spielmodus an, aber kein Spiel gewaehlt
      document.getElementById('gameModeBadgeText').textContent = 'SPIELMODUS: KEIN SPIEL GEWÄHLT';
      gameModeBadgeEl.classList.add('warn');
    } else if (gameModeEnabled) {
      // An, aber (noch) kein konfiguriertes Spiel laut Prozessliste erkannt - gelb, damit auffaellt, dass gerade nichts ueberwacht wird
      document.getElementById('gameModeBadgeText').textContent = 'SPIELMODUS: KEIN SPIEL';
      gameModeBadgeEl.classList.add('warn');
    }
  }
});
ARI_MODS.on('settings', () => { loadGameProfiles(); });
ARI_MODS.on('devReset', () => { loadGameModeToggleState(); });
Object.assign(devTestActions, {
    'gm-off': () => { devGameModePreview = true; setGameModeUI(false); },
    'gm-warn': () => { devGameModePreview = true; setGameModeUI(true); },
    'gm-on': () => {
      devGameModePreview = true; setGameModeUI(true);
      gameModeBadgeEl.classList.remove('warn');
      document.getElementById('gameModeBadgeText').textContent = 'SPIELMODUS: TESTSPIEL';
    },
    editor: () => {
      gameProfiles['__dev_test__'] = { display_name: 'Testspiel', process_name: '', actions: {
        'klick_a': { label: 'Beispiel-Klick', key: '', click: { x: 0.4, y: 0.6 }, category: 'Mausklicks' },
        'taste_a': { label: 'Beispiel-Taste', key: 'N', category: 'Allgemein' },
      } };
      populateGameSelect();
      openGameEditor('__dev_test__');
    },
});
