# Mod "Spiel-Integration": Spielmodus (automatische Spiel-Erkennung), Spiel-Tasten und Mausklicks per Sprache (game_action),
# Routenplanung (plan_route), Spiele-Editor. Dieser Code lief frueher fest im Hub; jetzt wird er als Mod geladen.
# Alle Namen des Hubs (psutil, app, _press_key_combo, _load_secrets ...) stehen hier schon zur Verfuegung (siehe _mods_load im Hub).

# ---------------------------------------------------------------------------
# Spielmodus: erkennt automatisch anhand der laufenden Windows-Prozesse,
# welches konfigurierte Spiel (falls ueberhaupt eins) gerade laeuft, statt
# einen manuellen Schalter zu brauchen. Aktiv/inaktiv folgt rein dem
# tatsaechlichen Prozess — startet der Nutzer das Spiel, wird der Modus
# automatisch aktiv, beendet er es, automatisch wieder inaktiv. game_action
# nutzt das als Sicherheitsgurt: Tastendruecke gehen nur raus, wenn das
# passende Spiel laut Prozessliste gerade wirklich laeuft (verhindert, dass
# Tasten versehentlich an ein falsches/kein Fenster gehen, wenn das Spiel gar
# nicht offen ist).
# ---------------------------------------------------------------------------
_active_game_key = None
_active_game_lock = threading.Lock()


def _game_scan_enabled():
    """Spiele automatisch erkennen (alle 10 s die Prozesse pruefen)? Standard AN. Aus = kein Scannen (spart Leistung) - dann den Spielmodus selbst einschalten."""
    return bool((_load_secrets().get("game_scan") or {}).get("enabled", True))


_GAME_EXTRA_PROCESSES = {"star citizen": ["starcitizen.exe"]}   # das eigentliche Spiel
_GAME_SKIP_RE = re.compile(r"launcher|crash|handler|setup|install|updater|helper|service|overlay|anticheat|easyanticheat|battleye|webhelper", re.I)
_game_scan_state = {"last": 0.0}


def _game_tokens(profile_key, profile):
    """Suchbegriffe fuer ein Spiel, aus seinem Namen: klein, ohne Leer-/Sonderzeichen ("Star Citizen" -> "starcitizen"). Mindestens 4 Zeichen."""
    toks = []
    for src in (profile.get("display_name"), profile_key):
        t = re.sub(r"[^a-z0-9]", "", str(src or "").lower())
        if len(t) >= 4 and t not in toks and not t.startswith("__"):
            toks.append(t)
    return toks


def _update_active_game_mode():
    """Das Spiel wird von A.R.I SELBST gefunden (nichts einzutragen): alle 10 Sekunden werden die laufenden Prozesse gepruft - ein Spiel gilt als
    gestartet, wenn sein Name (ohne Leerzeichen) im Programmnamen oder im Ordner des Programms steht (z. B. 'Star Citizen' -> StarCitizen.exe im
    Ordner ...\\StarCitizen\\...). Launcher, Updater und Hilfsprogramme zaehlen nicht. Das gilt auch bei ausgeschaltetem Spielmodus: startet ein Spiel,
    wird der Spielmodus im HUD automatisch aktiv, endet es, geht er wieder aus (der Schalter betrifft nur den Tastendruck-Schutz, siehe game_action)."""
    global _active_game_key
    now = time.time()
    if now - _game_scan_state["last"] < 10:
        return
    if not _game_scan_enabled():
        with _active_game_lock:
            _active_game_key = None
        _game_scan_state["last"] = now
        return
    _game_scan_state["last"] = now
    try:
        profiles = _load_game_profiles()
    except Exception:
        return
    tokens = {key: _game_tokens(key, p) for key, p in profiles.items()}
    exact = {}
    for key, p in profiles.items():
        for k, extra in _GAME_EXTRA_PROCESSES.items():
            if k in str(key).lower() or k in str(p.get("display_name", "")).lower():
                for n in extra:
                    exact[n] = key
    found_key = None
    for pr in psutil.process_iter(["name", "exe"]):
        try:
            name = (pr.info["name"] or "").lower()
            if not name:
                continue
            if name in exact:
                found_key = exact[name]
                break
            if _GAME_SKIP_RE.search(name):
                continue
            base = re.sub(r"[^a-z0-9]", "", os.path.splitext(name)[0])
            exe = re.sub(r"[^a-z0-9]", "", str(pr.info.get("exe") or "").lower())
            for key, toks in tokens.items():
                if any(t in base or (exe and t in exe) for t in toks):
                    found_key = key
                    break
            if found_key:
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    with _active_game_lock:
        if found_key != _active_game_key:
            old_name = profiles.get(_active_game_key, {}).get("display_name", _active_game_key)
            new_name = profiles.get(found_key, {}).get("display_name", found_key)
            print(f"[game-mode] {old_name or 'kein Spiel'} -> {new_name or 'kein Spiel'}")
        _active_game_key = found_key


def get_active_game_mode():
    """Gibt (game_key, display_name) des gerade per Prozess erkannten aktiven
    Spiels zurueck, oder (None, None) wenn keins laeuft."""
    with _active_game_lock:
        key = _active_game_key
    manual = _manual_game_key() if _load_game_mode_enabled() else None
    if manual:
        key = manual   # vom Nutzer per Klick auf "Spielmodus" gewaehltes Spiel gilt immer (auch bei eingeschalteter Erkennung)
    elif not _game_scan_enabled():
        return None, None   # Erkennung aus und nichts gewaehlt
    if key is None:
        return None, None
    try:
        profiles = _load_game_profiles()
        return key, profiles.get(key, {}).get("display_name", key)
    except Exception:
        return None, None


def _capture_next_click(timeout=15):
    """Wartet auf den naechsten echten Linksklick irgendwo auf dem
    Bildschirm (global, unabhaengig vom Fensterfokus — der Klick geht also
    ganz normal im Spiel an, waehrend wir nur zuschauen) und gibt seine
    Position als Bildschirmanteil (0.0-1.0) zurueck. Fuer die Klick-
    Kalibrierung in Einstellungen > Spiele: jeder Nutzer hat eine andere
    Monitor-Aufloesung, ein fester Pixel-Wert waere nicht uebertragbar —
    per Klick erfassen und in Prozent umrechnen loest das direkt. Einfaches
    Polling von GetAsyncKeyState statt eines systemweiten Hooks, reicht fuer
    einen einmaligen Klick voellig aus."""
    if not IS_WIN:
        return _lx.capture_next_click(timeout)
    was_down = bool(ctypes.windll.user32.GetAsyncKeyState(_VK_LBUTTON) & 0x8000)
    start = time.time()
    while time.time() - start < timeout:
        down = bool(ctypes.windll.user32.GetAsyncKeyState(_VK_LBUTTON) & 0x8000)
        if down and not was_down:
            pt = _Point()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
            screen_w = ctypes.windll.user32.GetSystemMetrics(0)
            screen_h = ctypes.windll.user32.GetSystemMetrics(1)
            return pt.x / screen_w, pt.y / screen_h
        was_down = down
        time.sleep(0.02)
    return None


def _resolve_game(game, profiles):
    """Gemeinsame Spiel-Aufloesung fuer game_action UND plan_route: Name/
    Alias/Teilstring-Abgleich gegen die konfigurierten Profile, faellt bei
    genau einem konfigurierten Spiel automatisch darauf zurueck. Gibt
    (matched_key, error) zurueck — error ist None bei Erfolg."""
    if not profiles:
        return None, "Es ist noch kein Spiel konfiguriert. Unter Einstellungen > Spiele ein Spiel und eine Aktion mit Taste hinzufuegen."
    game_needle = (game or "").strip().lower()
    if game_needle:
        if game_needle in profiles:
            return game_needle, None
        for key, p in profiles.items():
            aliases = [a.lower() for a in p.get("aliases", [])]
            if game_needle in aliases or game_needle in (p.get("display_name") or "").lower():
                return key, None
        available = ", ".join(p.get("display_name", k) for k, p in profiles.items())
        return None, f"Kein konfiguriertes Spiel gefunden fuer '{game}'. Konfiguriert sind: {available}."
    if len(profiles) == 1:
        return next(iter(profiles)), None
    available = ", ".join(p.get("display_name", k) for k, p in profiles.items())
    return None, f"Es sind mehrere Spiele konfiguriert ({available}) — bitte angeben, welches gemeint ist."



# Reine Richtungs-/Schaltwoerter — beim wortweisen Abgleich in
# _find_action_by_needle ignoriert, weil sie in vorkonfigurierten Labels oft
# nur EINE Richtung nennen (z.B. "Fahrwerk ausfahren" als Label fuer einen
# Umschalter, den man genauso gut per "Fahrwerk einfahren" ansprechen
# koennte) — das eigentliche Substantiv (Energie, Fahrwerk, Scanmodus, ...)
# soll fuer den Treffer reichen.
_TOGGLE_WORDS = {
    "an", "aus", "ein", "um", "auf", "zu",
    "umschalten", "einschalten", "ausschalten", "anschalten", "abschalten",
    "aktivieren", "deaktivieren", "ausfahren", "einfahren", "umlegen",
    "aktiviere", "deaktiviere", "schalte", "starte", "stoppe",
}

# Bekannte Spracherkennungs-Verhoerer fuer technische Begriffe, die die
# Browser-Spracherkennung phonetisch nicht sauber trifft (z.B. Abkuerzungen
# wie "VTOL") — wird VOR dem eigentlichen Abgleich auf den Needle angewandt,
# NICHT ins Aktions-Label geschrieben, damit die Erfolgsmeldung/gesprochene
# Bestaetigung sauber bleibt und nicht die Verhoerer mitvorliest. Bei neuen
# beobachteten Fehlhoerungen hier einfach ergaenzen.
_ASR_CORRECTIONS = {
    "vitos": "vtol", "wiedholz": "vtol", "wietholz": "vtol", "veto": "vtol",
}


def _apply_asr_corrections(needle):
    return " ".join(_ASR_CORRECTIONS.get(w, w) for w in needle.split())


def _find_action_by_needle(actions, needle):
    """Abgleich gegen Aktionsschluessel/-label, ohne dass der Nutzer sie
    exakt so benennen muss. Reihenfolge: (1) klassischer Teilstring-Treffer
    (wie _spotify_find_own_playlist), (2) wortweiser Abgleich — alle Woerter
    der Anfrage muessen im Aktionsnamen vorkommen, aber nicht zusammen-
    haengend (deckt z.B. 'Energie aus' gegen das Label 'Energie an/aus' ab),
    (3) derselbe wortweise Abgleich nochmal, aber mit ignorierten Richtungs-/
    Schaltwoertern (_TOGGLE_WORDS) — deckt z.B. 'Fahrwerk einfahren' gegen
    ein Label ab, das nur 'ausfahren' nennt, obwohl beides dieselbe
    Umschalt-Taste meint."""
    needle = (needle or "").lower().strip()
    if not needle:
        return None
    needle = _apply_asr_corrections(needle)
    if needle in actions:
        return actions[needle]
    for a_key, a in actions.items():
        if needle in a_key or needle in (a.get("label") or "").lower():
            return a
    needle_words = [w for w in re.split(r"[^\wäöüß]+", needle) if w]
    if not needle_words:
        return None
    match = _best_word_match(actions, needle_words)
    if match:
        return match
    core_words = [w for w in needle_words if w not in _TOGGLE_WORDS]
    if core_words and core_words != needle_words:
        return _best_word_match(actions, core_words)
    return None


def _best_word_match(actions, needle_words):
    best, best_score = None, 0
    for a_key, a in actions.items():
        haystack = (a_key + " " + (a.get("label") or "")).lower()
        score = sum(1 for w in needle_words if w in haystack)
        if score == len(needle_words) and score > best_score:
            best, best_score = a, score
    return best


def _find_click_position(actions, needle):
    """Sucht unter den Mausklick-Aktionen (Feld "click") eine, deren Name das
    Suchwort enthaelt, und gibt {"x", "y"} zurueck — None, wenn es keine gibt
    oder sie noch nicht kalibriert ist (leeres click-Feld)."""
    for a_key, a in actions.items():
        click = a.get("click")
        if not isinstance(click, dict):
            continue
        hay = (a_key + " " + (a.get("label") or "")).lower().replace(" ", "")   # "Such Ergebnis" und "Suchergebnis" gelten gleich
        if needle.replace(" ", "") in hay and "x" in click and "y" in click:
            return click
    return None


def _game_mode_block(matched_key, matched_profile):
    """Spieltasten/-klicks gibt es NUR im Spielmodus: ist er aus - oder laeuft/gilt dieses Spiel nicht - kommt eine Meldung statt eines Tastendrucks
    (sonst landen Tasten wie N oder F2 in jedem beliebigen Fenster)."""
    display_name = matched_profile.get("display_name", matched_key)
    if not _load_game_mode_enabled():
        return (f"Der Spielmodus ist aus - keine Taste gesendet. Schalte oben den Spielmodus ein (und wähle {display_name}), "
                f"dann funktionieren die Spielbefehle.")
    active_key, _ = get_active_game_mode()
    if active_key != matched_key:
        return f"{display_name} ist im Spielmodus gerade nicht aktiv - keine Taste gesendet. Spiel starten oder oben im Spielmodus auswählen."
    return None


def _tool_game_action(game, action):
    """Loest eine frei formulierte Spielaktion (z.B. 'Fahrwerk ausfahren')
    gegen die in Einstellungen > Spiele konfigurierten Profile auf und
    presst die zugehoerige Taste — rein textbasierter Abgleich (case-
    insensitive Teilstring, wie _spotify_find_own_playlist), erfindet nie
    einen Tastendruck: bei keinem Treffer kommt eine klare Fehlermeldung mit
    dem, was tatsaechlich konfiguriert ist."""
    profiles = _load_game_profiles()
    matched_key, error = _resolve_game(game, profiles)
    if error:
        return error

    matched_profile = profiles[matched_key]
    # Spielmodus-Sicherheitsgurt: standardmaessig AUS (siehe
    # _load_game_mode_enabled) — nur wenn der Nutzer ihn per Klick aktiviert
    # HAT und fuer dieses Spiel ein process_name konfiguriert ist, wird
    # geprueft, ob es laut Prozessliste gerade wirklich laeuft — sonst gehen
    # Tastendruecke ins Leere oder an ein falsches Fenster. Ist der Modus
    # aus oder kein process_name konfiguriert -> Gurt bleibt aus.
    blocked = _game_mode_block(matched_key, matched_profile)
    if blocked:
        return blocked
    actions = matched_profile.get("actions", {})
    matched_action = _find_action_by_needle(actions, (action or "").strip())
    if matched_action is None:
        available_actions = ", ".join(a.get("label", k) for k, a in actions.items()) or "keine"
        return (
            f"Fuer '{matched_profile.get('display_name', matched_key)}' ist keine Aktion '{action}' konfiguriert. "
            f"Vorhandene Aktionen: {available_actions}. Unter Einstellungen > Spiele hinzufuegen."
        )

    click = matched_action.get("click")
    if isinstance(click, dict):
        if "x" not in click or "y" not in click:
            return f"Mausklick '{matched_action.get('label', action)}' ist noch nicht kalibriert (Einstellungen > Spiele > Position erfassen)."
        _click_at_fraction(click["x"], click["y"])
        return f"Mausklick '{matched_action.get('label', action)}' ausgefuehrt."

    key_string = matched_action.get("key", "")
    if not _press_key_combo(key_string):
        return f"Taste '{key_string}' fuer '{matched_action.get('label', action)}' ist ungueltig konfiguriert."
    return f"'{matched_action.get('label', action)}' ausgefuehrt ({key_string})."


# Bekannte Star-Citizen-Standorte (aus einer vom Nutzer bereitgestellten
# Referenzliste, Stand 12.09.2026) — dient NUR dem unscharfen Abgleich in
# _tool_plan_route (Tippfehler/ASR-Verhoerer beim Zielnamen abfangen), kein
# vollstaendiger Reisefuehrer.
_SC_KNOWN_LOCATIONS = [
    "2930-CRU983",
    "ARC-L1 Wide Forest Station",
    "ARC-L2 Lively Pathway Station",
    "ARC-L3 Modern Express Station",
    "ARC-L4 Faint Glen Station",
    "ARC-L5 Yellow Core Station",
    "Aaron Halo",
    "Aberdeen",
    "Adir",
    "Akiro Cluster",
    "ArcCorp",
    "ArcCorp Mining Area 141",
    "Area18",
    "Area18 (ArcCorp)",
    "Arial",
    "Ashland",
    "Attritus OLP",
    "BGR-560",
    "Baijini Point",
    "Bloom",
    "Bueno Ravine",
    "CAJ-445",
    "CRU-L1 Ambitious Dream Station",
    "CRU-L4 Shallow Fields Station",
    "CRU-L5 Beautiful Glen Station",
    "Calliope",
    "Canard View",
    "Caplan Circuit",
    "Cellin",
    "Chawla’s Beach",
    "Checkmate Station",
    "Clio",
    "Comm Array ST1-02",
    "Comm Array ST1-13",
    "Comm Array ST1-48",
    "Comm Array ST1-61",
    "Comm Array ST1-92",
    "Comm Array ST2-28",
    "Comm Array ST2-47",
    "Comm Array ST2-55",
    "Comm Array ST2-76",
    "Comm Array ST3-18",
    "Comm Array ST3-35",
    "Comm Array ST3-90",
    "Comm Array ST4-22",
    "Comm Array ST4-31",
    "Comm Array ST4-59",
    "Comm Array ST4-64",
    "Covalex Hub Gundo",
    "Crusader",
    "Daymar",
    "Deakins Research Outpost",
    "Delamar",
    "Dudley & Daughters",
    "EMM-567",
    "Endgame",
    "Euterpe",
    "Everus Harbor",
    "FSN-704",
    "Fairo",
    "Fallow Field",
    "Fool’s Run",
    "Fuego",
    "GRP-839",
    "Gaslight",
    "Glaciem Ring",
    "GrimHEX",
    "GrimHEX (Yela)",
    "HDMS-Edmond",
    "HDMS-Hadley",
    "HDMS-Oparei",
    "HDMS-Pinewood",
    "HDMS-Stanhope",
    "HDMS-Thedus",
    "HDSF-Adlai",
    "HDSF-Barnabas",
    "HDSF-Breckinridge",
    "HDSF-Colfax",
    "HDSF-Damaris",
    "HDSF-Elbridge",
    "HDSF-Hendricks",
    "HDSF-Hiram",
    "HDSF-Hobart",
    "HDSF-Ishmael",
    "HDSF-Millerand",
    "HDSF-Rufus",
    "HDSF-Sherman",
    "HDSF-Tamar",
    "HDSF-Tompkins",
    "HDSF-Zacharias",
    "HJS-232",
    "HUR-L1 Green Glade Station",
    "HUR-L2 Faithful Dream Station",
    "HUR-L3 Thundering Express Station",
    "HUR-L4 Melodic Fields Station",
    "HUR-L5 High Course Station",
    "Hickes Research Outpost",
    "Hurston",
    "ICC ScanHub",
    "INS Jericho",
    "Ignis",
    "Ita",
    "JWY-925",
    "Jackson’s Swap",
    "KKE-717",
    "Keeger Belt",
    "LHB-976",
    "Lamina OLP",
    "Last Landings",
    "Levski",
    "Levski (Delamar)",
    "Levski / People’s Service Stations",
    "Lorville",
    "Lorville (Hurston)",
    "Lorville Outskirts",
    "Lyria",
    "MIC-L1 Shallow Frontier Station",
    "MIC-L2 Long Forest Station",
    "MIC-L3 Endless Odyssey Station",
    "MIC-L4 Red Crossroads Station",
    "MIC-L5 Modern Icarus Station",
    "MNK-833",
    "Magda",
    "Magnus Gateway",
    "Megumi Refueling",
    "Miner’s Lament",
    "Monox",
    "NDB-102",
    "New Babbage",
    "New Babbage (microTech)",
    "Nyx",
    "Nyx Gateway (Pyro)",
    "Nyx I",
    "Nyx II",
    "Nyx III",
    "Nyx – Bremen",
    "Nyx – Castra",
    "Nyx – Odin",
    "Nyx – Pyro",
    "Nyx – Stanton",
    "Nyx – Tohil",
    "Nyx – Virgil",
    "Orbituary",
    "Orison",
    "Orison (Crusader)",
    "PQE-291",
    "PYAM-EXHANG-0-1",
    "PYR1 L3 – PYAM-FARSTAT-1-3",
    "PYR3 L4 – PYAM-SUPVISR-3-4",
    "PYR3 L5 – PYAM-FARSTAT-3-5",
    "PYR5 L1 – PYAM-FARSTAT-5-1",
    "PYR5 L3 – PYAM-FARSTAT-5-3",
    "PYR6 L2 – PYAM-FARSTAT-6-2",
    "Patch City",
    "People’s Service Station Alpha",
    "People’s Service Station Delta",
    "People’s Service Station Lambda",
    "People’s Service Station Theta",
    "People’s Service Stations",
    "Port Olisar",
    "Port Tressler",
    "Pyro",
    "Pyro Gateway (Nyx)",
    "Pyro Gateway (Stanton)",
    "Pyro I",
    "Pyro IV",
    "Pyro V",
    "Pyro – Cano",
    "Pyro – Castra",
    "Pyro – Hadrian",
    "Pyro – Nyx",
    "Pyro – Oso",
    "Pyro – Stanton",
    "Pyro – Terra",
    "QV Services Stations",
    "RAB-Alpha",
    "RAB-Bravo",
    "RAB-Charlie",
    "RAB-Cook",
    "RAB-Delta",
    "RAB-Echo",
    "RAB-Foxtrot",
    "RAB-Gulf",
    "RAB-Helio",
    "RAB-Ignition",
    "RAB-Ion",
    "RAB-Jak",
    "RAB-Kilo",
    "RAB-Lamda",
    "RAB-Lynx",
    "RAB-Mat",
    "RAB-November",
    "RAB-Over",
    "RAB-Point",
    "RAB-Quagmire",
    "RAB-Roth",
    "RAB-Sierra",
    "RAB-Tung",
    "RAB-Ultra",
    "RAB-Victory",
    "RAB-Whiskey",
    "RAB-Xeno",
    "RAB-York",
    "RAB-Zeta",
    "RSC-340",
    "Rat’s Nest",
    "Rod’s Fuel ’N Supplies",
    "Ruin Station",
    "Ruptura OLP",
    "Rustville",
    "SGL-693",
    "SZA-178",
    "Sacren’s Plot",
    "Security Post Kareah",
    "Seer’s Canyon",
    "Seraphim Station",
    "Shepherd’s Rest",
    "Stanton",
    "Stanton Gateway (Pyro)",
    "Stanton – Magnus",
    "Stanton – Nyx",
    "Stanton – Pyro",
    "Stanton – Terra",
    "Starlight Service Station",
    "Sunset Mesa",
    "TYS-908",
    "Terminus",
    "Terra Gateway (Stanton)",
    "The Icebreaker",
    "The Sky Scraper",
    "VUP-613",
    "Vatra",
    "Vivere OLP",
    "Vuur",
    "WDH-387",
    "Wala",
    "Wikelo Emporium Dasi Station",
    "Wikelo Emporium Kinga Station",
    "Wikelo Emporium Selo Station",
    "YKA-011",
    "Yadar Valley",
    "Yela",
    "microTech",
]


def _tool_plan_route(game, destination):
    """Oeffnet die Sternenkarte/Navigationskarte des Spiels, klickt zuerst in
    das Suchfeld (Mausklick-Aktion "Suchfeld" — ohne diesen Klick landet die Eingabe
    nirgendwo, das Suchfeld ist nach dem Kartenoeffnen nicht automatisch
    fokussiert), tippt dann das Ziel ein und bestaetigt das oberste
    Suchergebnis per Mausklick (manche Spiele wie Star Citizen akzeptieren
    dafuer kein Enter, nur einen echten Klick) — beide Klickpositionen kommen
    aus dem Profil (jeweils als Bildschirm-Anteil 0.0-1.0, aufloesungs-
    unabhaengig) und muessen der Nutzer einmalig fuer sein eigenes UI-Layout
    kalibrieren. Ist keine Suchfeld-Klickposition konfiguriert, wird direkt
    (ohne vorherigen Klick) getippt — Ist keine Ergebnis-Klickposition
    konfiguriert, wird ersatzweise Enter versucht — bestmoegliche
    Automatisierung ohne Bildschirm-Rueckmeldung, kein garantierter Erfolg."""
    destination = (destination or "").strip()
    if not destination:
        return "Kein Ziel angegeben."
    profiles = _load_game_profiles()
    matched_key, error = _resolve_game(game, profiles)
    if error:
        return error
    matched_profile = profiles[matched_key]
    blocked = _game_mode_block(matched_key, matched_profile)
    if blocked:
        return blocked
    # Verhoerte/leicht falsch geschriebene Zielnamen (Sprach-ASR) auf die
    # bekannte Standortliste korrigieren, BEVOR getippt wird — nur fuer Star
    # Citizen (dafuer liegt die Liste vor) und nur bei einer wirklich engen
    # Uebereinstimmung (cutoff hoch), damit kein voellig falscher Ort
    # eingetippt wird, wenn der genannte Ort einfach nicht in der Liste ist.
    if matched_key == "star citizen":
        close = difflib.get_close_matches(
            destination.lower(), [loc.lower() for loc in _SC_KNOWN_LOCATIONS], n=1, cutoff=0.72
        )
        if close:
            canonical = next(loc for loc in _SC_KNOWN_LOCATIONS if loc.lower() == close[0])
            if canonical != destination:
                destination = canonical
    actions = matched_profile.get("actions", {})
    map_action = (
        _find_action_by_needle(actions, "sternenkarte")
        or _find_action_by_needle(actions, "starmap")
        or _find_action_by_needle(actions, "karte")
    )
    if map_action is None:
        return (
            f"Fuer '{matched_profile.get('display_name', matched_key)}' ist keine Sternenkarten-/"
            f"Navigationstaste konfiguriert. Unter Einstellungen > Spiele eine Aktion mit "
            f"'Sternenkarte' im Namen hinzufuegen."
        )
    if not _press_key_combo(map_action.get("key", "")):
        return f"Taste '{map_action.get('key', '')}' fuer die Sternenkarte ist ungueltig konfiguriert."
    # Wartezeiten: die Sternenkarte oeffnet sich mit Animation - klickt A.R.I zu frueh ins Suchfeld, ist es noch gar nicht da. Die Hauptzeit ist pro Spiel
    # einstellbar (Spiel bearbeiten > "Wartezeit nach dem Oeffnen der Karte", Standard 3 s); die uebrigen Pausen richten sich danach.
    try:
        wait_open = float(matched_profile.get("map_wait") or 3.0)
    except (TypeError, ValueError):
        wait_open = 3.0
    wait_open = max(0.5, min(15.0, wait_open))
    time.sleep(wait_open)  # Kartenoeffnungs-Animation abwarten, sonst kommen Klick und Zeichen zu frueh an
    search_click_pos = _find_click_position(actions, "suchfeld")
    if search_click_pos:
        _click_at_fraction(search_click_pos["x"], search_click_pos["y"])
        time.sleep(max(1.0, wait_open * 0.4))  # warten, bis das Suchfeld wirklich fokussiert/bereit ist, bevor getippt wird
    _type_text_scan(destination)
    time.sleep(max(0.8, wait_open * 0.3))  # Zeit fuer die Ergebnisliste, sich nach der Eingabe zu aktualisieren
    click_pos = _find_click_position(actions, "routenziel") or _find_click_position(actions, "suchergebnis")
    if click_pos:
        # Maus erst auf den Treffer fahren und kurz stehen lassen, dann laenger klicken - ein Blitz-Klick wird von der Sternenkarte ignoriert
        _click_at_fraction(click_pos["x"], click_pos["y"], hover=0.6, hold=0.12)
    else:
        _press_key_combo("Enter")
    # Optionaler Schritt: Klick "Ziel festlegen" (Einstellungen > Spiele > Mausklick) - erst nach einer Pause, weil der Knopf erst nach dem Treffer-Klick
    # eingeblendet wird; vorher ins Leere zu klicken war "zu schnell".
    set_pos = _find_click_position(actions, "zielfestlegen")
    if set_pos:
        time.sleep(max(1.8, wait_open * 0.6))
        _click_at_fraction(set_pos["x"], set_pos["y"], hover=0.7, hold=0.12)
        time.sleep(1.0)
    closed = False
    if matched_profile.get("close_map_after", True):
        # Route steht: die Sternenkarte wieder schliessen (dieselbe Taste noch einmal), damit man gleich weiterfliegen kann
        time.sleep(1.2)
        closed = _press_key_combo(map_action.get("key", ""))
    return (
        f"Route nach '{destination}' eingegeben und bestaetigt" + (" und die Sternenkarte wieder geschlossen" if closed else "") + f". Kurz im Spiel pruefen, ob die "
        f"Sternenkarte das Ziel korrekt uebernommen hat — ohne Bildschirmzugriff kann ich das "
        f"nicht selbst kontrollieren."
    )


def _load_game_mode_enabled():
    """Spielmodus (automatische Prozesserkennung + Tastendruck-Sicherheits-
    gurt in game_action) ist standardmaessig AUS — muss der Nutzer bewusst
    per Klick anschalten, statt dass ploetzlich Tastendruecke blockiert
    werden, ohne dass er das erwartet hat."""
    return bool((_load_secrets().get("game_mode") or {}).get("enabled", False))


def _save_game_mode_enabled(enabled, manual_game=None):
    """manual_game: bei ausgeschalteter Spielerkennung das vom Nutzer gewaehlte Spiel (None = unveraendert lassen, '' = keins)."""
    def _upd(old):
        d = dict(old or {})
        d["enabled"] = bool(enabled)
        if manual_game is not None:
            d["manual_game"] = str(manual_game)
        return d
    _update_secrets("game_mode", _upd)


def _manual_game_key():
    return str((_load_secrets().get("game_mode") or {}).get("manual_game") or "")


@app.route("/game-profiles", methods=["GET"])
def game_profiles_get():
    return jsonify(_load_game_profiles())


@app.route("/game-profiles", methods=["POST"])
def game_profiles_save():
    """Speichert das KOMPLETTE Profile-Dict (Ganz-Ersetzen) — das Frontend
    haelt den vollstaendigen Stand ohnehin im Speicher, solange das
    Einstellungen-Modal offen ist. Prueft jede Tastenkombo vorab gegen den
    _resolve_vk-Parser (ohne sie zu druecken), damit ungueltige Eingaben
    nicht erst beim naechsten game_action-Aufruf auffallen."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Ungueltige Daten."}), 400
    invalid = []
    for game_key, profile in data.items():
        if not isinstance(profile, dict) or not (profile.get("display_name") or "").strip():
            return jsonify({"error": f"Spiel '{game_key}' braucht einen Namen."}), 400
        actions = profile.get("actions")
        if not isinstance(actions, dict):
            return jsonify({"error": f"Spiel '{game_key}' hat ein ungueltiges Aktionsformat."}), 400
        for action_key, action in actions.items():
            key_string = (action or {}).get("key", "")
            if not key_string.strip():
                continue  # noch keine Taste hinterlegt (z.B. Maustaste im Original oder noch unbekannt) — kein Fehler, nur nicht ausfuehrbar bis der Nutzer eine Taste eintraegt
            parts = [p.strip() for p in key_string.split("+") if p.strip()]
            if not parts or any(_resolve_scancode(p) is None and _resolve_vk(p) is None for p in parts):
                invalid.append(f"{profile.get('display_name', game_key)} / {action.get('label', action_key)}")
    if invalid:
        return jsonify({"error": "Ungueltige Taste(n) bei: " + ", ".join(invalid)}), 400
    _save_game_profiles(data)
    return jsonify({"error": None})


@app.route("/game-mode", methods=["GET"])
def game_mode_get():
    key, name = get_active_game_mode()
    return jsonify({"enabled": _load_game_mode_enabled(), "active_game": name, "scan": _game_scan_enabled(), "manual_game": _manual_game_key()})


@app.route("/game-scan", methods=["POST"])
def game_scan_set():
    """Automatische Spielerkennung ein-/ausschalten (aus = keine Prozess-Pruefung, der Spielmodus wird von Hand geschaltet)."""
    if not _is_local_request() or not request.is_json:
        return jsonify({"error": "verboten"}), 403
    enabled = bool((request.get_json(silent=True) or {}).get("enabled"))
    _update_secrets("game_scan", lambda _old: {"enabled": enabled})
    if not enabled:
        with _active_game_lock:
            global _active_game_key
            _active_game_key = None
    else:
        _game_scan_state["last"] = 0.0   # sofort einmal pruefen
    return jsonify({"error": None, "enabled": enabled})


@app.route("/game-mode", methods=["POST"])
def game_mode_set():
    """Ein-Klick-Umschalter fuer den Spielmodus (Prozesserkennung + game_action-
    Sicherheitsgurt) — standardmaessig aus, siehe _load_game_mode_enabled."""
    data = request.get_json(silent=True) or {}
    enabled = bool(data.get("enabled"))
    game = data.get("game")   # nur bei ausgeschalteter Erkennung: das vom Nutzer gewaehlte Spiel
    if game is not None:
        game = str(game)
        if game and game not in _load_game_profiles():
            return jsonify({"error": "Dieses Spiel gibt es nicht.", "enabled": _load_game_mode_enabled()})
    _save_game_mode_enabled(enabled, game)
    if not enabled:
        with _active_game_lock:
            global _active_game_key
            _active_game_key = None
    return jsonify({"error": None, "enabled": enabled})


@app.route("/capture-click", methods=["POST"])
def capture_click():
    """Fuer die Klick-Kalibrierung im Spiele-Editor: wartet auf den naechsten
    echten Linksklick irgendwo auf dem Bildschirm und gibt seine Position
    als Bildschirmanteil zurueck — funktioniert unabhaengig von der eigenen
    Monitor-Aufloesung des Nutzers, siehe _capture_next_click()."""
    result = _capture_next_click()
    if result is None:
        return jsonify({"error": "Kein Klick erkannt (15 Sekunden Zeitueberschreitung)."})
    x, y = result
    return jsonify({"error": None, "x": x, "y": y})


@app.route("/pick-exe", methods=["POST"])
def pick_exe():
    """Oeffnet den nativen Windows-Datei-Dialog, damit der Nutzer die .exe
    seines Spiels per Ordner-Browser auswaehlen kann, statt den
    Prozessnamen selbst abtippen zu muessen — gibt nur den Dateinamen
    zurueck (z.B. 'StarCitizen.exe'), nicht den vollen Pfad (der volle Pfad
    ist fuer die Prozesserkennung per Namensabgleich nicht noetig und koennte
    unnoetig den Speicherort preisgeben)."""
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(
            title="Spiel-Programm (.exe) auswaehlen" if IS_WIN else "Spiel-Programm auswaehlen",
            filetypes=[("Programme", "*.exe"), ("Alle Dateien", "*.*")] if IS_WIN else [("Alle Dateien", "*")],
        )
        root.destroy()
    except Exception as e:
        return jsonify({"error": f"Datei-Dialog konnte nicht geoeffnet werden: {e}"})
    if not path:
        return jsonify({"error": "Keine Datei ausgewaehlt."})
    return jsonify({"error": None, "filename": os.path.basename(path)})


GAME_PROFILES_FILE = os.path.join(DATA_DIR, "game_profiles.json")
# Vorbefuellter Startzustand fuer das game_action-Tool (siehe TOOLS/run_tool
# weiter unten) — echte Star-Citizen-Standardtasten, damit "fahr das
# Fahrwerk aus" sofort funktioniert, ohne dass der Nutzer erst selbst alles
# in Einstellungen > Spiele anlegen muss. Einzelne Bindungen aendern sich
# gelegentlich zwischen SC-Patches — das ist kein Problem, jede Zeile bleibt
# ueber die UI frei editierbar/loeschbar wie jeder selbst hinzugefuegte Eintrag.
_DEFAULT_GAME_PROFILES = {
    "star citizen": {
        "display_name": "Star Citizen",
        "aliases": ["sc"],
        "actions": {
            # Mausklicks (Position als Anteil 0.0-1.0 der Bildschirmgroesse,
            # aufloesungsunabhaengig) — noch unkalibriert, der Nutzer erfasst sie
            # einmal unter Einstellungen > Spiele. plan_route nutzt genau diese
            # beiden ("suchfeld" zuerst, "suchergebnis" nach dem Tippen).
            "klick suchfeld": {"label": "Suchfeld (Sternenkarte)", "key": "", "click": {}, "category": "Mausklicks"},
            "klick suchergebnis": {"label": "Suchergebnis (Sternenkarte)", "key": "", "click": {}, "category": "Mausklicks"},
            # Allgemein
            "pause menue": {"label": "Pause-/Optionsmenue", "key": "Escape", "category": "Allgemein"},
            "chat umschalten": {"label": "Chat-Fenster ein-/ausblenden", "key": "F12", "category": "Allgemein"},
            "screenshot": {"label": "Screenshot aufnehmen", "key": "Druck", "category": "Allgemein"},
            "konsole": {"label": "Konsole oeffnen", "key": "`", "category": "Allgemein"},
            "einladung annehmen": {"label": "Einladung annehmen", "key": "[", "category": "Allgemein"},
            "einladung ablehnen": {"label": "Einladung ablehnen/ignorieren (halten)", "key": "]", "category": "Allgemein"},
            "kontakte umschalten": {"label": "Kontakte/2D-UI-Cursor ein-/ausblenden", "key": "F11", "category": "Allgemein"},
            "mobiglas": {"label": "MobiGlas ein-/ausschalten", "key": "F1", "category": "Allgemein"},
            "sternenkarte": {"label": "Sternkarte ein-/ausblenden", "key": "F2", "category": "Allgemein"},
            # Zu Fuss
            "springen": {"label": "Springen", "key": "Leertaste", "category": "Zu Fuß"},
            "interagieren": {"label": "Interagieren", "key": "F", "category": "Zu Fuß"},
            "seitenwaffe ausruesten": {"label": "Seitenwaffe ausruesten", "key": "1", "category": "Zu Fuß"},
            "hauptwaffe ausruesten": {"label": "Hauptwaffe ausruesten", "key": "2", "category": "Zu Fuß"},
            "nebenwaffe ausruesten": {"label": "Nebenwaffe ausruesten", "key": "3", "category": "Zu Fuß"},
            "geraet ausruesten": {"label": "Geraet ausruesten", "key": "4", "category": "Zu Fuß"},
            "nahkampfwaffe ausruesten": {"label": "Nahkampfwaffe ausruesten", "key": "5", "category": "Zu Fuß"},
            "waffe nachladen": {"label": "Waffe nachladen", "key": "R", "category": "Zu Fuß"},
            "granate ausruesten": {"label": "Granate ausruesten", "key": "G", "category": "Zu Fuß"},
            "feuermodus umschalten fuss": {"label": "Feuermodus umschalten (zu Fuss)", "key": "B", "category": "Zu Fuß"},
            "medizinstift ausruesten": {"label": "Medizinstift ausruesten", "key": "C", "category": "Zu Fuß"},
            "anzuglicht umschalten": {"label": "Anzuglicht umschalten", "key": "T", "category": "Zu Fuß"},
            "rennen": {"label": "Rennen (Sprint)", "key": "Shift", "category": "Zu Fuß"},
            "links lehnen": {"label": "Nach links lehnen", "key": "Q", "category": "Zu Fuß"},
            "rechts lehnen": {"label": "Nach rechts lehnen", "key": "E", "category": "Zu Fuß"},
            "ducken": {"label": "Ducken", "key": "Strg", "category": "Zu Fuß"},
            "kriechen": {"label": "Kriechen", "key": "X", "category": "Zu Fuß"},
            "waffe anpassen": {"label": "Waffe anpassen", "key": "J", "category": "Zu Fuß"},
            "freilook": {"label": "Freilook (halten)", "key": "Z", "category": "Zu Fuß"},
            # Im Schiff
            "sitz verlassen": {"label": "Sitz/Fahrzeug verlassen (halten)", "key": "Y", "category": "Im Schiff"},
            "eject": {"label": "Eject (Sitz ausstossen)", "key": "Alt+Y", "category": "Im Schiff"},
            "notausstieg": {"label": "Notausstieg", "key": "Shift+U", "category": "Im Schiff"},
            "fracht abwerfen": {"label": "Fracht abwerfen (Cargo Jettison)", "key": "Alt+J", "category": "Im Schiff"},
            "fahrzeug betreten": {"label": "Fahrzeug betreten", "key": "F", "category": "Im Schiff"},
            "fahrwerk": {"label": "Fahrwerk ein-/ausfahren (Landemodus umschalten, halten)", "key": "N", "category": "Im Schiff"},
            "landeerlaubnis": {"label": "Start-/Landeerlaubnis einholen", "key": "Alt+N", "category": "Im Schiff"},
            "tempomat umschalten": {"label": "Tempomat umschalten", "key": "Alt+C", "category": "Im Schiff"},
            "quantenantrieb umschalten": {"label": "Quantenantrieb umschalten", "key": "B", "category": "Im Schiff"},
            "quantensprung starten": {"label": "Quantensprung starten (halten)", "key": "B", "category": "Im Schiff"},
            "flugbereit": {"label": "Flugbereit (Startsequenz)", "key": "RAlt+R", "category": "Im Schiff"},
            "entkoppelten modus umschalten": {"label": "Entkoppelten Modus umschalten", "key": "C", "category": "Im Schiff"},
            "motoren umschalten": {"label": "Triebwerke/Motoren an/aus", "key": "I", "category": "Im Schiff"},
            "schilde umschalten": {"label": "Schilde an/aus", "key": "O", "category": "Im Schiff"},
            "booster": {"label": "Booster/Afterburner (Schub-Verstaerkung)", "key": "Shift", "category": "Im Schiff"},
            "fahrzeugleuchten": {"label": "Aussenbeleuchtung umschalten", "key": "L", "category": "Im Schiff"},
            "sitz aktiv modus": {"label": "Master-Modus durchschalten", "key": "B", "category": "Im Schiff"},
            "gimbal modus": {"label": "Gimbal-Modus umschalten", "key": "G", "category": "Im Schiff"},
            "vtol umschalten": {"label": "VTOL-Modus umschalten (M1: Neu konfigurieren)", "key": "K", "category": "Im Schiff"},
            "zuruecksehen": {"label": "Nach hinten schauen (halten)", "key": ",", "category": "Im Schiff"},
            "schiffsrotation sperren": {"label": "Schiffsrotation sperren", "key": ".", "category": "Im Schiff"},
            "weltraumbremse": {"label": "Weltraumbremse", "key": "X", "category": "Im Schiff"},
            "links rollen": {"label": "Nach links rollen", "key": "Q", "category": "Im Schiff"},
            "rechts rollen": {"label": "Nach rechts rollen", "key": "E", "category": "Im Schiff"},
            "nicken gieren sperre": {"label": "Nicken-/Gieren-Sperre umschalten", "key": "RShift", "category": "Im Schiff"},
            "interaktionsmodus": {"label": "Interaktionsmodus / Inner Thought", "key": "Tab", "category": "Allgemein"},
            "fahrzeug bremsen": {"label": "Bodenfahrzeug bremsen", "key": "X", "category": "Im Schiff"},
            "energie umschalten": {"label": "Energie an/aus", "key": "P", "category": "Im Schiff"},
            "scanmodus umschalten": {"label": "Scanmodus umschalten", "key": "V", "category": "Im Schiff"},
            "kamera ansicht wechseln": {"label": "Kamera-Ansicht durchschalten", "key": "F4", "category": "Im Schiff"},
            # Kampf
            "ziel aufschalten": {"label": "Ziel aufschalten/freigeben", "key": "F8", "category": "Kampf"},
            "ziel 1 aufschalten": {"label": "Ziel 1 aufschalten", "key": "1", "category": "Kampf"},
            "ziel 2 aufschalten": {"label": "Ziel 2 aufschalten", "key": "2", "category": "Kampf"},
            "ziel 3 aufschalten": {"label": "Ziel 3 aufschalten", "key": "3", "category": "Kampf"},
            "angreifer durchschalten": {"label": "Angreifer durchschalten", "key": "4", "category": "Kampf"},
            "feinde durchschalten": {"label": "Feinde durchschalten", "key": "5", "category": "Kampf"},
            "freunde durchschalten": {"label": "Freunde durchschalten", "key": "6", "category": "Kampf"},
            "gimbal unterstuetzung": {"label": "Gimbal-Unterstuetzung umschalten", "key": "G", "category": "Kampf"},
            "gegenmassnahmen": {"label": "Gegenmassnahmen ausstossen", "key": "J", "category": "Kampf"},
            "energie auf alles": {"label": "Energie gleichmaessig verteilen", "key": "U", "category": "Kampf"},
            "energie auf antrieb erhoehen": {"label": "Energie auf Antrieb erhoehen", "key": "F5", "category": "Kampf"},
            "energie auf schilde erhoehen": {"label": "Energie auf Schilde erhoehen", "key": "F6", "category": "Kampf"},
            "energie auf waffen erhoehen": {"label": "Energie auf Waffen erhoehen", "key": "F7", "category": "Kampf"},
            "energieverteilung standard": {"label": "Energieverteilung auf Standard", "key": "F8", "category": "Kampf"},
            "schild vorne": {"label": "Schildstaerke vorne erhoehen", "key": "Num8", "category": "Kampf"},
            "schild hinten": {"label": "Schildstaerke hinten erhoehen", "key": "Num2", "category": "Kampf"},
            "schild links": {"label": "Schildstaerke links erhoehen", "key": "Num4", "category": "Kampf"},
            "schild rechts": {"label": "Schildstaerke rechts erhoehen", "key": "Num6", "category": "Kampf"},
            "schild oben": {"label": "Schildstaerke oben erhoehen", "key": "Num7", "category": "Kampf"},
            "schild unten": {"label": "Schildstaerke unten erhoehen", "key": "Num1", "category": "Kampf"},
            "schild standard": {"label": "Schildstaerke auf Standard", "key": "Num5", "category": "Kampf"},
            # Mining
            "miningmodus": {"label": "Miningmodus umschalten", "key": "M", "category": "Mining"},
            "mining gimbal": {"label": "Mining-Gimbal umschalten", "key": "G", "category": "Mining"},
            "mining verbrauchsmaterial 1": {"label": "Verbrauchsmaterial 1 (z.B. Optimaler Mining-Modul)", "key": "Alt+1", "category": "Mining"},
            "mining verbrauchsmaterial 2": {"label": "Verbrauchsmaterial 2", "key": "Alt+2", "category": "Mining"},
            "mining verbrauchsmaterial 3": {"label": "Verbrauchsmaterial 3", "key": "Alt+3", "category": "Mining"},
            "gesteinsscan": {"label": "Gestein scannen (Rock Scan)", "key": "V", "category": "Mining"},
            "salvagemodus": {"label": "Salvagemodus umschalten", "key": "M", "category": "Salvage"},
            "salvage gimbal": {"label": "Salvage-Gimbal umschalten", "key": "G", "category": "Salvage"},
            "cm decoy": {"label": "Gegenmassnahmen-Koeder (Decoy)", "key": "H", "category": "Kampf"},
            "sub target cycle": {"label": "Untergeordnetes Ziel wechseln", "key": "R", "category": "Kampf"},
            "target in view": {"label": "Ziel in Sicht automatisch anvisieren (halten)", "key": "T", "category": "Kampf"},
            "lock pin 1": {"label": "Ziel auf Pin 1 sperren", "key": "1", "category": "Kampf"},
            "lock pin 2": {"label": "Ziel auf Pin 2 sperren", "key": "2", "category": "Kampf"},
            "lock pin 3": {"label": "Ziel auf Pin 3 sperren", "key": "3", "category": "Kampf"},
            "naechstes ziel angreifer": {"label": "Naechstes Ziel: Angreifer", "key": "4", "category": "Kampf"},
            "naechstes ziel feindlich": {"label": "Naechstes Ziel: Feindlich", "key": "5", "category": "Kampf"},
            "naechstes ziel freundlich": {"label": "Naechstes Ziel: Freundlich", "key": "6", "category": "Kampf"},
            "naechstes ziel alle": {"label": "Naechstes Ziel: Alle", "key": "7", "category": "Kampf"},
            "ziel anrufen": {"label": "Ziel anrufen (Hail)", "key": "9", "category": "Kampf"},
            "alle ziele entfernen": {"label": "Alle gepinnten Ziele entfernen", "key": "0", "category": "Kampf"},
            "selbstzerstoerung": {"label": "Selbstzerstoerung umschalten (halten)", "key": "Backspace", "category": "Kampf"},
            "bewegung springen eva hoch": {"label": "Springen / EVA hoch", "key": "Leertaste", "category": "Allgemein"},
            "bewegung ducken eva runter": {"label": "Ducken / EVA runter", "key": "Strg", "category": "Allgemein"},
            "bewegung sprint boost": {"label": "Sprint / Boost", "key": "Shift", "category": "Allgemein"},
            "interface inventar": {"label": "Inventar", "key": "I", "category": "Allgemein"},
            "interface chat": {"label": "Chat", "key": "Enter", "category": "Allgemein"},
            "kommunikation push to talk": {"label": "Push-to-Talk (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "kommunikation voice channel": {"label": "Voice Channel (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "fahrzeug fahrzeuglicht": {"label": "Fahrzeuglicht (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "fahrzeug hupe": {"label": "Hupe (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein emote men": {"label": "Emote-Menü (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein emote n chste": {"label": "Emote nächste (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein emote vorherige": {"label": "Emote vorherige (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item aufnehmen": {"label": "Item aufnehmen", "key": "F", "category": "Allgemein"},
            "allgemein item fallen lassen": {"label": "Item fallen lassen (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item untersuchen": {"label": "Item untersuchen (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item ausr sten": {"label": "Item ausrüsten (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein item ablegen": {"label": "Item ablegen (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "allgemein inventory search": {"label": "Inventory Search (in Referenz nicht fest belegt)", "key": "", "category": "Allgemein"},
            "flug roll links": {"label": "Roll links", "key": "Q", "category": "Im Schiff"},
            "flug roll rechts": {"label": "Roll rechts", "key": "E", "category": "Im Schiff"},
            "flug nav mode": {"label": "NAV Mode", "key": "B", "category": "Im Schiff"},
            "flug quantum travel": {"label": "Quantum Travel (halten)", "key": "B", "category": "Im Schiff"},
            "flug geschwindigkeitsbegrenzer": {"label": "Geschwindigkeitsbegrenzer + (Standard: Mausrad hoch — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "flug geschwindigkeitsbegrenzer 2": {"label": "Geschwindigkeitsbegrenzer - (Standard: Mausrad runter — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "flug esp": {"label": "ESP (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "flug g safe": {"label": "G-Safe (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme engines on": {"label": "Engines On", "key": "R", "category": "Im Schiff"},
            "systeme engines off": {"label": "Engines Off", "key": "U", "category": "Im Schiff"},
            "systeme power on": {"label": "Power On (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme power off": {"label": "Power Off (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme ship lights": {"label": "Ship Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme headlights": {"label": "Headlights", "key": "L", "category": "Im Schiff"},
            "systeme cockpit lights": {"label": "Cockpit Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme landing lights": {"label": "Landing Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme emergency lights": {"label": "Emergency Lights (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme alle t ren ffnen": {"label": "Alle Türen öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme alle t ren schlie en": {"label": "Alle Türen schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme cargo bay ffnen": {"label": "Cargo Bay öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "systeme cargo bay schlie en": {"label": "Cargo Bay schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation nav mode": {"label": "NAV Mode", "key": "B", "category": "Im Schiff"},
            "navigation quantum spool": {"label": "Quantum spool (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation quantum calibration": {"label": "Quantum calibration (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation quantum jump": {"label": "Quantum jump (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation quantum abbrechen": {"label": "Quantum abbrechen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation ziel ausw hlen": {"label": "Ziel auswählen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation route setzen": {"label": "Route setzen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation route l schen": {"label": "Route löschen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation n chstes nav ziel": {"label": "Nächstes NAV-Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "navigation vorheriges nav ziel": {"label": "Vorheriges NAV-Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing request landing": {"label": "Request Landing (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing request takeoff": {"label": "Request Takeoff (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing docking mode": {"label": "Docking Mode (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing request docking": {"label": "Request Docking (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing dock": {"label": "Dock (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "landing undock": {"label": "Undock (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo grid ffnen": {"label": "Cargo Grid öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo grid schlie en": {"label": "Cargo Grid schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo bewegen": {"label": "Cargo bewegen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo drehen": {"label": "Cargo drehen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo platzieren": {"label": "Cargo platzieren (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo entfernen": {"label": "Cargo entfernen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "cargo cargo scan": {"label": "Cargo Scan (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren t r ffnen": {"label": "Tür öffnen", "key": "F", "category": "Im Schiff"},
            "t ren t r schlie en": {"label": "Tür schließen", "key": "F", "category": "Im Schiff"},
            "t ren rampe ffnen": {"label": "Rampe öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren rampe schlie en": {"label": "Rampe schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren aufzug rufen": {"label": "Aufzug rufen", "key": "F", "category": "Im Schiff"},
            "t ren airlock ffnen": {"label": "Airlock öffnen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "t ren airlock schlie en": {"label": "Airlock schließen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd focus": {"label": "MFD Focus (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd n chste seite": {"label": "MFD nächste Seite (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd vorherige seite": {"label": "MFD vorherige Seite (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 1": {"label": "MFD Seite 1 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 2": {"label": "MFD Seite 2 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 3": {"label": "MFD Seite 3 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 4": {"label": "MFD Seite 4 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 5": {"label": "MFD Seite 5 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd seite 6": {"label": "MFD Seite 6 (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "mfd mfd reset": {"label": "MFD Reset (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar ping": {"label": "Radar Ping (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar reichweite": {"label": "Radar Reichweite + (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar reichweite 2": {"label": "Radar Reichweite - (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar ping winkel": {"label": "Ping Winkel + (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar ping winkel 2": {"label": "Ping Winkel - (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar focus": {"label": "Radar Focus (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar zoom": {"label": "Radar Zoom (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar contact ausw hlen": {"label": "Radar Contact auswählen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "radar radar contact l schen": {"label": "Radar Contact löschen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "scan scan mode": {"label": "Scan Mode", "key": "V", "category": "Im Schiff"},
            "scan scan starten": {"label": "Scan starten (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "scan scan angle": {"label": "Scan Angle + (Standard: Mausrad hoch — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "scan scan angle 2": {"label": "Scan Angle - (Standard: Mausrad runter — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "turret turret betreten": {"label": "Turret betreten", "key": "F", "category": "Im Schiff"},
            "turret turret verlassen": {"label": "Turret verlassen", "key": "Y", "category": "Im Schiff"},
            "turret turret feuer": {"label": "Turret Feuer (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "turret turret secondary": {"label": "Turret Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "turret turret lock": {"label": "Turret Lock (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "turret n chster turret": {"label": "Nächster Turret (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "turret vorheriger turret": {"label": "Vorheriger Turret (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "operator operator seat betreten": {"label": "Operator Seat betreten", "key": "F", "category": "Im Schiff"},
            "operator operator seat verlassen": {"label": "Operator Seat verlassen", "key": "Y", "category": "Im Schiff"},
            "operator operator mode wechseln": {"label": "Operator Mode wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "operator operator fire": {"label": "Operator Fire (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "operator operator secondary": {"label": "Operator Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "tractor tractor beam aktivieren": {"label": "Tractor Beam aktivieren (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "tractor tractor beam l sen": {"label": "Tractor Beam lösen (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Im Schiff"},
            "tractor objekt vor": {"label": "Objekt vor (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt zur ck": {"label": "Objekt zurück (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt links": {"label": "Objekt links (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt rechts": {"label": "Objekt rechts (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt hoch": {"label": "Objekt hoch (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt runter": {"label": "Objekt runter (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor distanz": {"label": "Distanz + (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor distanz 2": {"label": "Distanz - (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "tractor objekt drehen": {"label": "Objekt drehen (in Referenz nicht fest belegt)", "key": "", "category": "Im Schiff"},
            "waffen waffengruppe 1 feuern": {"label": "Waffengruppe 1 feuern (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Kampf"},
            "waffen waffengruppe 2 feuern": {"label": "Waffengruppe 2 feuern (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Kampf"},
            "waffen waffengruppe 1": {"label": "Waffengruppe 1", "key": "1", "category": "Kampf"},
            "waffen waffengruppe 2": {"label": "Waffengruppe 2", "key": "2", "category": "Kampf"},
            "waffen waffengruppe 3": {"label": "Waffengruppe 3", "key": "3", "category": "Kampf"},
            "waffen waffengruppe 4": {"label": "Waffengruppe 4", "key": "4", "category": "Kampf"},
            "waffen waffengruppe 5": {"label": "Waffengruppe 5", "key": "5", "category": "Kampf"},
            "waffen waffengruppe 6": {"label": "Waffengruppe 6", "key": "6", "category": "Kampf"},
            "waffen gimbal assist": {"label": "Gimbal Assist (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen fixed mode": {"label": "Fixed Mode (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen pip wechseln": {"label": "PIP wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen lead pip": {"label": "Lead PIP (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen lag pip": {"label": "Lag PIP (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "waffen waffenreichweite": {"label": "Waffenreichweite (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel aufschalten": {"label": "Ziel aufschalten (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel l sen": {"label": "Ziel lösen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chstes ziel": {"label": "Nächstes Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting vorheriges ziel": {"label": "Vorheriges Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chstes feindliches ziel": {"label": "Nächstes feindliches Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chstes freundliches ziel": {"label": "Nächstes freundliches Ziel (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting n chster angreifer": {"label": "Nächster Angreifer", "key": "4", "category": "Kampf"},
            "targeting n chster feind": {"label": "Nächster Feind", "key": "5", "category": "Kampf"},
            "targeting n chster freund": {"label": "Nächster Freund", "key": "6", "category": "Kampf"},
            "targeting n chste rakete": {"label": "Nächste Rakete (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel unter fadenkreuz": {"label": "Ziel unter Fadenkreuz (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting subsystem ausw hlen": {"label": "Subsystem auswählen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting ziel l schen": {"label": "Ziel löschen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "targeting pin target 1": {"label": "Pin Target 1", "key": "Alt+1", "category": "Kampf"},
            "targeting pin target 2": {"label": "Pin Target 2", "key": "Alt+2", "category": "Kampf"},
            "targeting pin target 3": {"label": "Pin Target 3", "key": "Alt+3", "category": "Kampf"},
            "targeting pin 1 ausw hlen": {"label": "Pin 1 auswählen", "key": "1", "category": "Kampf"},
            "targeting pin 2 ausw hlen": {"label": "Pin 2 auswählen", "key": "2", "category": "Kampf"},
            "targeting pin 3 ausw hlen": {"label": "Pin 3 auswählen", "key": "3", "category": "Kampf"},
            "missiles missile operator mode": {"label": "Missile Operator Mode", "key": "M", "category": "Kampf"},
            "missiles missile lock": {"label": "Missile Lock (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles missile launch": {"label": "Missile Launch (Standard: MMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Kampf"},
            "missiles rakete wechseln": {"label": "Rakete wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles raketenart n chste": {"label": "Raketenart nächste (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles raketenart vorherige": {"label": "Raketenart vorherige (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles lock abbrechen": {"label": "Lock abbrechen (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "missiles missile camera": {"label": "Missile Camera (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure": {"label": "Countermeasure", "key": "H", "category": "Kampf"},
            "countermeasures decoy": {"label": "Decoy (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures noise": {"label": "Noise (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures decoy burst": {"label": "Decoy Burst (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures noise burst": {"label": "Noise Burst (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure mode": {"label": "Countermeasure Mode (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure quantity": {"label": "Countermeasure Quantity + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "countermeasures countermeasure quantity 2": {"label": "Countermeasure Quantity - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power power to weapons": {"label": "Power to Weapons", "key": "F5", "category": "Kampf"},
            "power power to engines": {"label": "Power to Engines", "key": "F6", "category": "Kampf"},
            "power power to shields": {"label": "Power to Shields", "key": "F7", "category": "Kampf"},
            "power power reset": {"label": "Power Reset", "key": "F8", "category": "Kampf"},
            "power weapon power": {"label": "Weapon Power + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power weapon power 2": {"label": "Weapon Power - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power engine power": {"label": "Engine Power + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power engine power 2": {"label": "Engine Power - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power shield power": {"label": "Shield Power + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "power shield power 2": {"label": "Shield Power - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde schild vorne": {"label": "Schild vorne", "key": "Num8", "category": "Kampf"},
            "schilde schild hinten": {"label": "Schild hinten", "key": "Num2", "category": "Kampf"},
            "schilde schild links": {"label": "Schild links", "key": "Num4", "category": "Kampf"},
            "schilde schild rechts": {"label": "Schild rechts", "key": "Num6", "category": "Kampf"},
            "schilde schild balance": {"label": "Schild Balance", "key": "Num5", "category": "Kampf"},
            "schilde front": {"label": "Front + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde front 2": {"label": "Front - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde rear": {"label": "Rear + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde rear 2": {"label": "Rear - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde left": {"label": "Left + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde left 2": {"label": "Left - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde right": {"label": "Right + (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "schilde right 2": {"label": "Right - (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat combat mode": {"label": "Combat Mode (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat target focus": {"label": "Target Focus (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat fire group cycle": {"label": "Fire Group Cycle (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat weapon camera": {"label": "Weapon Camera (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "combat target info": {"label": "Target Info (in Referenz nicht fest belegt)", "key": "", "category": "Kampf"},
            "mining mining laser": {"label": "Mining Laser (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining mining laser secondary": {"label": "Mining Laser Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining laserleistung": {"label": "Laserleistung + (Standard: Alt+Mausrad hoch — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining laserleistung 2": {"label": "Laserleistung - (Standard: Alt+Mausrad runter — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining consumable 1": {"label": "Consumable 1", "key": "Alt+1", "category": "Mining"},
            "mining consumable 2": {"label": "Consumable 2", "key": "Alt+2", "category": "Mining"},
            "mining consumable 3": {"label": "Consumable 3", "key": "Alt+3", "category": "Mining"},
            "mining mining module 1": {"label": "Mining Module 1 (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining module 2": {"label": "Mining Module 2 (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining module 3": {"label": "Mining Module 3 (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining laser overcharge": {"label": "Laser Overcharge (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining scan starten": {"label": "Scan starten (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Mining"},
            "mining fracture": {"label": "Fracture (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining extract": {"label": "Extract (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining next mining head": {"label": "Next Mining Head (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining previous mining head": {"label": "Previous Mining Head (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining filter": {"label": "Mining Filter (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining mining focus": {"label": "Mining Focus (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining collect material": {"label": "Collect Material (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining stop laser": {"label": "Stop Laser (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "mining throttle while mining": {"label": "Throttle while mining (in Referenz nicht fest belegt)", "key": "", "category": "Mining"},
            "salvage salvage beam": {"label": "Salvage Beam (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "salvage salvage modifier": {"label": "Salvage Modifier (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "salvage beam spacing": {"label": "Beam Spacing + (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage beam spacing 2": {"label": "Beam Spacing - (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage beam axis": {"label": "Beam Axis (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage abrade": {"label": "Abrade (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage scrape": {"label": "Scrape (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage structural salvage": {"label": "Structural Salvage (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage material collect": {"label": "Material Collect (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage filter": {"label": "Salvage Filter (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage container": {"label": "Salvage Container (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage next salvage mode": {"label": "Next Salvage Mode (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage previous salvage mode": {"label": "Previous Salvage Mode (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage focus": {"label": "Salvage Focus (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage salvage target": {"label": "Salvage Target (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "salvage stop beam": {"label": "Stop Beam (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor tractor beam aktivieren 2": {"label": "Tractor Beam aktivieren (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "tractor tractor beam l sen 2": {"label": "Tractor Beam lösen (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Salvage"},
            "tractor objekt vor 2": {"label": "Objekt vor (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt zur ck 2": {"label": "Objekt zurück (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt links 2": {"label": "Objekt links (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt rechts 2": {"label": "Objekt rechts (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt hoch 2": {"label": "Objekt hoch (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt runter 2": {"label": "Objekt runter (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor distanz 3": {"label": "Distanz + (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor distanz 4": {"label": "Distanz - (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt drehen 2": {"label": "Objekt drehen (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor objekt locken": {"label": "Objekt locken (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "tractor n chstes objekt": {"label": "Nächstes Objekt (in Referenz nicht fest belegt)", "key": "", "category": "Salvage"},
            "bewegung sprinten": {"label": "Sprinten", "key": "Shift", "category": "Zu Fuß"},
            "bewegung ducken": {"label": "Ducken", "key": "Strg", "category": "Zu Fuß"},
            "bewegung springen": {"label": "Springen", "key": "Leertaste", "category": "Zu Fuß"},
            "bewegung prone": {"label": "Prone", "key": "X", "category": "Zu Fuß"},
            "bewegung lean left": {"label": "Lean Left", "key": "Q", "category": "Zu Fuß"},
            "bewegung lean right": {"label": "Lean Right", "key": "E", "category": "Zu Fuß"},
            "ausr stung inventar": {"label": "Inventar", "key": "I", "category": "Zu Fuß"},
            "ausr stung helm an aus": {"label": "Helm an/aus (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "ausr stung r stung an aus": {"label": "Rüstung an/aus (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "ausr stung backpack": {"label": "Backpack (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen waffe holstern": {"label": "Waffe holstern (halten)", "key": "R", "category": "Zu Fuß"},
            "waffen fire": {"label": "Fire (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "waffen aim zoom": {"label": "Aim / Zoom (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "waffen weapon inspect": {"label": "Weapon Inspect (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen scope zoom": {"label": "Scope Zoom (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen fire mode wechseln": {"label": "Fire Mode wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "waffen attachment wechseln": {"label": "Attachment wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "medizin medical tool": {"label": "Medical Tool (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "medizin heilen": {"label": "Heilen (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "medizin medical target": {"label": "Medical Target (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool multi tool aktivieren": {"label": "Multi-Tool aktivieren (Standard: LMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "multi tool multi tool secondary": {"label": "Multi-Tool Secondary (Standard: RMB — Maustaste/-rad, hier nicht automatisierbar)", "key": "", "category": "Zu Fuß"},
            "multi tool attachment wechseln": {"label": "Attachment wechseln (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool tractor beam": {"label": "Tractor Beam (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool medical mode": {"label": "Medical Mode (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "multi tool repair mode": {"label": "Repair Mode (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "eva roll links": {"label": "Roll links", "key": "Q", "category": "Zu Fuß"},
            "eva roll rechts": {"label": "Roll rechts", "key": "E", "category": "Zu Fuß"},
            "eva eva boost": {"label": "EVA Boost", "key": "Shift", "category": "Zu Fuß"},
            "eva eva stop": {"label": "EVA Stop", "key": "X", "category": "Zu Fuß"},
            "eva eva stabilize": {"label": "EVA Stabilize (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "kommunikation push to talk 2": {"label": "Push-to-Talk (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
            "kommunikation voice channel 2": {"label": "Voice Channel (in Referenz nicht fest belegt)", "key": "", "category": "Zu Fuß"},
        },
    },
}


def _migrate_route_clicks(profiles):
    """Frueher lagen die zwei Sternenkarten-Klickpositionen als feste Felder
    (route_search_click / route_result_click) im Profil; jetzt sind es ganz
    normale, erweiterbare Mausklick-Aktionen (Kategorie "Mausklicks", Feld
    "click"). Bestehende Werte werden einmalig uebernommen. Gibt True zurueck,
    wenn etwas geaendert wurde (dann wird neu gespeichert)."""
    changed = False
    for key, profile in profiles.items():
        if not isinstance(profile, dict) or not isinstance(profile.get("actions"), dict):
            continue
        actions = profile["actions"]
        for legacy, action_key, label in (
            ("route_search_click", "klick suchfeld", "Suchfeld (Sternenkarte)"),
            ("route_result_click", "klick routen ziel", "Routen Ziel"),
        ):
            if legacy in profile:
                value = profile.pop(legacy)
                changed = True
                if action_key not in actions and isinstance(value, dict) and "x" in value and "y" in value:
                    actions[action_key] = {"label": label, "key": "", "click": {"x": value["x"], "y": value["y"]}, "category": "Mausklicks"}
        if key == "star citizen":
            for action_key, label in (("klick suchfeld", "Suchfeld (Sternenkarte)"), ("klick routen ziel", "Routen Ziel")):
                if action_key not in actions:
                    actions[action_key] = {"label": label, "key": "", "click": {}, "category": "Mausklicks"}
                    changed = True
    return changed


def _load_game_profiles():
    if not os.path.exists(GAME_PROFILES_FILE):
        _save_game_profiles(_DEFAULT_GAME_PROFILES)
        return json.loads(json.dumps(_DEFAULT_GAME_PROFILES))
    try:
        with open(GAME_PROFILES_FILE, "r", encoding="utf-8") as f:
            profiles = json.load(f)
    except (OSError, ValueError):
        return {}
    if _migrate_route_clicks(profiles):
        _save_game_profiles(profiles)
    return profiles


def _save_game_profiles(data):
    with open(GAME_PROFILES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


GAME_TOOLS = [
    {
        "name": "game_action",
        "description": "Fuehrt eine konfigurierte spielspezifische Aktion per Tastendruck aus (z.B. Fahrwerk ausfahren, Waffe wechseln) — sendet die dafuer in Einstellungen > Spiele hinterlegte Taste an das gerade fokussierte Fenster. Das Tool macht den unscharfen Abgleich SELBST (Teilstring, Wort-fuer-Wort, bekannte Verhoerer der Spracherkennung) und liefert bei keinem Treffer eine Fehlermeldung mit der Liste der tatsaechlich vorhandenen Aktionen zurueck. DESHALB: bei jedem 'aktiviere X'/'schalte X um'/'mach X an/aus' waehrend eines konfigurierten Spiels dieses Tool DIREKT mit dem vom Nutzer genannten Wort aufrufen, OHNE vorher nachzufragen, was genau gemeint ist — auch wenn X mehrdeutig klingt (z.B. 'Triebwerk' koennte mehrere Aktionen treffen: das Tool waehlt selbst die beste Uebereinstimmung). Erst NACHDEM das Tool eine 'nicht konfiguriert'-Fehlermeldung zurueckgegeben hat, beim Nutzer nachfragen oder alternativ open_app in Betracht ziehen — niemals vorher raten oder nachfragen.",
        "input_schema": {
            "type": "object",
            "properties": {
                "game": {"type": "string", "description": "Name des Spiels, z.B. 'Star Citizen'. Weglassen, wenn nur ein Spiel konfiguriert ist oder aus dem Kontext eindeutig hervorgeht."},
                "action": {"type": "string", "description": "Die gewuenschte Aktion in natuerlicher Sprache, z.B. 'Fahrwerk ausfahren'."},
            },
            "required": ["action"],
        },
    },
    {
        "name": "plan_route",
        "description": "Oeffnet die Sternenkarte/Navigationskarte des Spiels, tippt ein Ziel ein und bestaetigt die Route per Klick auf das oberste Suchergebnis — fuer 'plane eine Route nach X' / 'flieg nach X'. Braucht eine Aktion mit 'Sternenkarte' im Namen und eine kalibrierte Mausklick-Aktion 'Suchergebnis' in Einstellungen > Spiele.",
        "input_schema": {
            "type": "object",
            "properties": {
                "game": {"type": "string", "description": "Name des Spiels, z.B. 'Star Citizen'. Weglassen, wenn nur ein Spiel konfiguriert ist."},
                "destination": {"type": "string", "description": "Zielort, z.B. 'Area18' oder 'Port Olisar'."},
            },
            "required": ["destination"],
        },
    },
]


def _game_handle(name, tool_input):
    if name == "game_action":
        return _tool_game_action(tool_input.get("game"), tool_input.get("action", ""))
    if name == "plan_route":
        return _tool_plan_route(tool_input.get("game"), tool_input.get("destination", ""))
    return "Unbekannt."


def register(ctx):
    ctx.add_tools(GAME_TOOLS, _game_handle,
                  keywords=r"spiel|game|star|citizen|schiff|fahrwerk|waffe|route|ziel|quantum|landen|sprung|mobi|scan|schild|energie|taste|cockpit",
                  labels={"game_action": "Spiel-Sprachbefehle", "plan_route": "die Routenplanung"})
    ctx.add_status(lambda: {"active_game_mode": get_active_game_mode()[1], "game_scan": _game_scan_enabled()})
    ctx.add_tick(_update_active_game_mode)   # drosselt sich selbst auf alle 10 Sekunden
