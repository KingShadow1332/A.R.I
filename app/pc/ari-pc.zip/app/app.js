(function(){
'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
/* ---------- Anonyme Nutzungsstatistik (Opt-in) ----------
   Zaehlt nur Funktionsnamen pro Tag - nie Inhalte. Zufaellige ID, keine IP-Speicherung. Ohne Einwilligung
   (oder ohne Empfaenger-Adresse in stats-config.json) wird nichts gezaehlt oder gesendet. */
const STS={get(k,d){try{const v=localStorage.getItem('ari_st_'+k);return v===null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem('ari_st_'+k,JSON.stringify(v));}catch(e){}},del(k){try{localStorage.removeItem('ari_st_'+k);}catch(e){}}};
function statsId(){let id=STS.get('id',null);if(!id||!/^[a-f0-9-]{16,40}$/.test(id)){id=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-8xxx-xxxxxxxxxxxx'.replace(/x/g,()=>(Math.random()*16|0).toString(16));STS.set('id',id);}return id;}
const statsDay=()=>new Date().toISOString().slice(0,10);
function track(name){
  if(STS.get('consent',null)!==true||!/^[a-z0-9_:.-]{1,40}$/.test(name))return;
  const days=STS.get('days',{}),t=statsDay();const d=days[t]=days[t]||{};
  if(!(name in d)&&Object.keys(d).length>=100)return;
  d[name]=(d[name]||0)+1;STS.set('days',days);
}
let statsEp=null,statsEpAt=0;
async function statsEndpoint(){
  const ov=STS.get('ep_override','');if(/^http:\/\/(127[.]0[.]0[.]1|localhost)(:\d+)?$/.test(ov))return ov;   // nur fuer Entwickler-Tests
  if(statsEp!==null&&Date.now()-statsEpAt<600000)return statsEp;
  try{const r=await fetch('https://kingshadow1332.github.io/A.R.I/app/stats-config.json?t='+Date.now(),{cache:'no-store'});const d=await r.json();const ep=String(d.endpoint||'').trim().replace(/\/+$/,'');statsEp=/^https:\/\/[A-Za-z0-9.-]+(:\d+)?(\/[\w.\/-]*)?$/.test(ep)?ep:'';}catch(e){statsEp='';}
  statsEpAt=Date.now();return statsEp;
}
async function statsPayload(){
  const days=STS.get('days',{}),cut=new Date(Date.now()-14*86400000).toISOString().slice(0,10);
  for(const k of Object.keys(days))if(k<cut)delete days[k];STS.set('days',days);
  let v='';try{if(NATIVE){const i=await Capacitor.Plugins.App.getInfo();v=String(i.version||'');}}catch(e){}
  return {id:statsId(),v:v||'web',platform:NATIVE?'android':'web',lang:navigator.language||'',days};
}
async function statsSend(){
  if(STS.get('consent',null)!==true)return false;const ep=await statsEndpoint();if(!ep)return false;
  try{const r=await fetch(ep+'/ingest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(await statsPayload())});return r.ok;}catch(e){return false;}
}
async function statsForget(){
  const ep=await statsEndpoint();let ok=true;
  if(ep){try{const r=await fetch(ep+'/forget',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:statsId()})});ok=r.ok;}catch(e){ok=false;}}
  if(ok){STS.del('id');STS.set('days',{});}return ok;
}
async function statsSetConsent(v){
  STS.set('consent',v);
  if(v){track('app_start');statsSend();}
  statsRefreshUI();
}
async function statsRefreshUI(){
  const f=document.getElementById('statsSec');if(!f)return;const ep=await statsEndpoint();
  f.style.display=ep?'':'none';const cb=document.getElementById('statsCb');if(cb)cb.checked=STS.get('consent',null)===true;
}
function statsReadable(p, esc) {
  const NAMES = { app_start: 'A.R.I gestartet', chat_pc: 'Chat am PC', chat_phone: 'Chat vom Handy', chat: 'Chat', chat_via_pc: 'Chat über den PC', voice_in: 'Spracheingabe', voice_out: 'Sprachausgabe', update_install: 'Update installiert',
    'ui:settings_open': 'Einstellungen geöffnet', 'ui:brain_open': 'Gehirn geöffnet', 'ui:calendar_day': 'Kalender-Tag geklickt', 'ui:layout_edit': 'Layout bearbeitet', 'ui:voice_ptt': 'Push-to-Talk', 'ui:input_text': 'Text eingegeben',
    'ui:input_voice': 'Sprache eingegeben', 'ui:export_settings': 'Einstellungen exportiert', 'ui:import_settings': 'Einstellungen importiert', 'ui:tour_start': 'Tour gestartet', 'ui:patch_notes': 'Patchnotizen geöffnet',
    'ui:media_control': 'Medien-Steuerung', 'ui:notif_dismiss': 'Benachrichtigung entfernt', 'ui:notif_spam': 'Als Spam markiert', 'ui:gamemode_toggle': 'Spielmodus umgeschaltet', 'ui:mute_toggle': 'Stumm umgeschaltet', 'ui:wake_toggle': 'Wake-Word umgeschaltet' };
  const nice = f => NAMES[f] || (f.indexOf('tool:') === 0 ? 'Werkzeug: ' + f.slice(5) : f.indexOf('tab_') === 0 ? 'Reiter: ' + f.slice(4) : f.replace(/^ui:/, '').replace(/_/g, ' '));
  const plat = { 'pc-win': 'Windows-PC', 'pc-linux': 'Linux-PC', android: 'Android-Handy', web: 'Browser' };
  const fmtDay = d => { const m = /^(\d{4})-(\d\d)-(\d\d)$/.exec(d); return m ? m[3] + '.' + m[2] + '.' + m[1] : d; };
  const row = (k, v) => '<div style="display:flex;justify-content:space-between;gap:12px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.07);font-size:12.5px"><span style="opacity:.7">' + esc(k) + '</span><span style="text-align:right">' + esc(v) + '</span></div>';
  let h = '<div style="margin-bottom:12px">' + row('Zufällige Kennung', String(p.id || '').slice(0, 8) + ' …') + row('Version', p.v || '—') + row('Gerät', plat[p.platform] || p.platform || '—') + row('Sprache', p.lang || '—') + '</div>';
  const days = Object.keys(p.days || {}).sort().reverse();
  if (!days.length) return h + '<div style="opacity:.65;font-size:12.5px">Noch keine Nutzungszahlen gesammelt.</div>';
  days.forEach(d => {
    const items = Object.entries(p.days[d]).sort((a, b) => b[1] - a[1]);
    h += '<div style="margin-top:12px;font-size:10px;letter-spacing:.12em;opacity:.65">' + esc(fmtDay(d)) + '</div>' + items.map(([f]) => row(nice(f), '✓')).join('');
  });
  return h;
}
async function statsPreviewShow(){
  const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;background:rgba(2,2,6,.8);padding:20px';
  const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  o.innerHTML='<div style="position:relative;width:100%;max-width:420px;max-height:80vh;overflow:auto;border-radius:14px;border:1px solid #ff2d78;background:#0d0b16;padding:20px 22px;color:#e8e6f5"><button type="button" id="stPvX" style="position:absolute;top:10px;left:10px;width:28px;height:28px;border-radius:6px;border:1px solid #29d3f5;background:none;color:#29d3f5">✕</button><div style="font:700 12px monospace;letter-spacing:.14em;padding-left:36px">DAS WIRD GESENDET</div><div style="font-size:12px;opacity:.75;margin:10px 0">Genau diese Angaben – nichts sonst: zufällige ID, Version, Plattform, Sprache und je Tag, wie oft eine Funktion benutzt wurde. Keine Texte, Namen, Mails oder IP-Adresse.</div><div>'+statsReadable(await statsPayload(),esc)+'</div></div>';
  document.body.appendChild(o);const close=()=>o.remove();o.querySelector('#stPvX').onclick=close;o.onclick=e=>{if(e.target===o)close();};
}
function statsAsk(){
  if(document.getElementById('ariStatsAsk'))return;
  const o=document.createElement('div');o.id='ariStatsAsk';o.style.cssText='position:fixed;inset:0;z-index:99998;display:flex;align-items:center;justify-content:center;background:rgba(2,2,6,.78);padding:20px';
  o.innerHTML='<div style="width:100%;max-width:400px;border-radius:16px;border:1px solid #ff2d78;background:linear-gradient(160deg,#1a1626,#0a0912);padding:20px 20px 16px;color:#e8e6f5"><div style="font:700 13px monospace;letter-spacing:.12em;color:#fff">HILFST DU, A.R.I ZU VERBESSERN?</div><div style="margin-top:10px;font-size:13px;line-height:1.55;opacity:.88">A.R.I kann <b>anonym</b> zählen, welche Funktionen wie oft benutzt werden.</div><ul style="margin:10px 0 0 18px;padding:0;font-size:12.5px;line-height:1.55;opacity:.85"><li>Nur Funktionsnamen und Zähler – <b>nie Inhalte</b></li><li>Zufällige ID, keine Speicherung deiner IP-Adresse</li><li>Jederzeit abschaltbar (Einstellungen), dann werden deine Daten gelöscht</li></ul><button type="button" class="btn pri" id="stYes" style="width:100%;margin-top:14px">JA, ANONYM TEILNEHMEN</button><button type="button" class="btn" id="stNo" style="width:100%;margin-top:8px">NEIN, DANKE</button><div style="display:flex;justify-content:space-between;margin-top:10px;font-size:11px"><a href="#" id="stWhat" style="color:inherit;opacity:.7">Was wird gesendet?</a><a href="#" id="stLater" style="color:inherit;opacity:.7">Später fragen</a></div></div>';
  document.body.appendChild(o);const close=()=>o.remove();
  o.querySelector('#stYes').onclick=()=>{close();statsSetConsent(true);};
  o.querySelector('#stNo').onclick=()=>{close();statsSetConsent(false);};
  o.querySelector('#stWhat').onclick=e=>{e.preventDefault();statsPreviewShow();};
  o.querySelector('#stLater').onclick=e=>{e.preventDefault();try{sessionStorage.setItem('ari_st_later','1');}catch(x){}close();};
}
async function statsAskCheck(){
  if(document.getElementById('ariStatsAsk')||STS.get('consent',null)!==null)return;
  try{if(sessionStorage.getItem('ari_st_later'))return;}catch(e){}
  if(await statsEndpoint())statsAsk();
}
setTimeout(statsAskCheck,15000);setInterval(statsAskCheck,60000);
setTimeout(()=>track('app_start'),3000);
setTimeout(statsRefreshUI,2000);
window.addEventListener('load',()=>{const cb=document.getElementById('statsCb');if(cb)cb.onchange=()=>statsSetConsent(cb.checked);
  const pv=document.getElementById('statsPv');if(pv)pv.onclick=()=>statsPreviewShow();});
setTimeout(statsSend,30000);setInterval(statsSend,3*3600*1000);
document.addEventListener('visibilitychange',()=>{if(document.hidden)statsSend();});
const store={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}};

/* ---------- Zustand ---------- */
const cfg=Object.assign({provider:'groq',keys:{},fb:'',fbKey:'',lang:'de-DE',tts:'1',pcRoute:'auto',pcSimOn:'0',gClientId:'516097970054-g630cvf7uslcoijbvblo4m4pcagamj35.apps.googleusercontent.com'},store.get('ari-app-cfg',{}));
cfg.keys=cfg.keys||{};
let brain=store.get('ari-app-brain',[]);
let pcs=store.get('ari-app-pcs',[]);
const hist=[];
let replyCtxUntil=0;
let syncingN=0;
function setSyncing(on){syncingN=Math.max(0,syncingN+(on?1:-1));document.body.classList.toggle('syncing',syncingN>0);}
let pluginKw=[];   // (Python-Plugins am PC)   // Stichwoerter der Plugins auf dem PC: kommt eines in der Anfrage vor, laeuft sie ueber den PC (dort sind die Plugins)
setTimeout(refreshPlugins,4000);setInterval(refreshPlugins,5*60*1000);   // nach einer Nachrichten-Ansage: Antworten gehen ueber den PC (dort liegt das Antwort-Werkzeug)
const saveCfg=()=>{store.set('ari-app-cfg',cfg);try{refreshReady();}catch(e){}};
const saveBrain=()=>store.set('ari-app-brain',brain);

/* ---------- Tabs / Uhr ---------- */
const TAB_ORDER=$$('nav button').map(b=>b.dataset.t);
function moveNavInd(t){const ind=$('#navInd');if(!ind)return;const i=TAB_ORDER.indexOf(t);if(i<0)return;ind.style.transform='translateX('+(i*100)+'%)';}
function goTab(t){track('tab_'+t);if(t==='set')$$('#t-set details.set-section').forEach(d=>{d.open=false;});   // Einstellungen: alle Kategorien starten immer zugeklappt
  $$('nav button').forEach(x=>x.classList.toggle('on',x.dataset.t===t));$$('section').forEach(s=>s.classList.toggle('on',s.id==='t-'+t));moveNavInd(t);if(t==='brain')renderBrain();if(t==='pc')renderPcs();if(t==='cal')loadCalData();}
$$('nav button').forEach(b=>b.onclick=()=>goTab(b.dataset.t));
moveNavInd(TAB_ORDER[0]);
// Wischen zwischen den Reitern (Chat/Termine/Gehirn/PC/Einst.): der Inhalt und die Unterstreichung
// in der Tab-Leiste unten folgen live dem Finger, beim Loslassen rutscht alles mit Schwung fertig -
// je schneller gewischt wurde, desto kuerzer/schneller die Animation. Nur bei ueberwiegend waagerechter
// Bewegung, damit normales Scrollen in den Listen (und die Chip-Leiste) nicht gestoert wird.
(function swipeTabs(){
  const mainEl=document.querySelector('main');if(!mainEl)return;
  const order=TAB_ORDER;
  let sx=0,sy=0,st=0,dx=0,tracking=false,locked=false,swp=null;
  function hScrollable(el){
    while(el&&el!==mainEl){
      if(el.scrollWidth>el.clientWidth+2&&/auto|scroll/.test(getComputedStyle(el).overflowX))return true;
      el=el.parentElement;
    }
    return false;
  }
  function reset(){
    if(swp){swp.cs.style.cssText='';swp.ns.style.cssText='';if(!swp.commit)swp.ns.classList.remove('on');}
    swp=null;tracking=false;locked=false;
  }
  mainEl.addEventListener('touchstart',e=>{
    if(e.touches.length!==1||hScrollable(e.target))return;
    sx=e.touches[0].clientX;sy=e.touches[0].clientY;st=Date.now();dx=0;tracking=true;locked=false;
  },{passive:true});
  mainEl.addEventListener('touchmove',e=>{
    if(!tracking||e.touches.length!==1)return;
    const t=e.touches[0];const ddx=t.clientX-sx,ddy=t.clientY-sy;
    if(!locked){
      if(Math.abs(ddx)<10&&Math.abs(ddy)<10)return;
      if(Math.abs(ddy)>=Math.abs(ddx)){tracking=false;return;}
      const cur=$('nav button.on');if(!cur)return;
      const ci=order.indexOf(cur.dataset.t);
      const dir=ddx<0?1:-1;const ni=ci+dir;
      if(ni<0||ni>=order.length){tracking=false;return;}
      const cs=document.getElementById('t-'+order[ci]),ns=document.getElementById('t-'+order[ni]);
      ns.style.transition='none';ns.classList.add('on');ns.style.transform='translateX('+(dir*100)+'%)';
      cs.style.transition='none';
      swp={dir,ci,ni,cs,ns,commit:false};locked=true;
    }
    e.preventDefault();dx=ddx;
    const w=mainEl.clientWidth||innerWidth,clamped=Math.max(-w,Math.min(w,dx));
    swp.cs.style.transform='translateX('+clamped+'px)';
    swp.ns.style.transform='translateX(calc('+(swp.dir*100)+'% + '+clamped+'px))';
    const ind=$('#navInd');
    if(ind){ind.style.transition='none';ind.style.transform='translateX('+((swp.ci+swp.dir*Math.max(0,Math.min(1,Math.abs(clamped)/w)))*100)+'%)';}
  },{passive:false});
  function finish(){
    if(!tracking)return;tracking=false;
    if(!locked||!swp)return;
    const elapsed=Math.max(16,Date.now()-st),v=Math.abs(dx)/elapsed;
    const w=mainEl.clientWidth||innerWidth;
    const commit=Math.abs(dx)>w*0.28||v>0.5;
    swp.commit=commit;
    const dur=Math.max(120,Math.min(320,(w-Math.abs(dx))/Math.max(v,0.35)));
    swp.cs.style.transition=swp.ns.style.transition='transform '+dur+'ms cubic-bezier(.2,.7,.3,1)';
    const ind=$('#navInd');if(ind)ind.style.transition='transform '+dur+'ms cubic-bezier(.2,.7,.3,1)';
    requestAnimationFrame(()=>{
      if(commit){swp.cs.style.transform='translateX('+(-swp.dir*100)+'%)';swp.ns.style.transform='translateX(0)';}
      else{swp.cs.style.transform='translateX(0)';swp.ns.style.transform='translateX('+(swp.dir*100)+'%)';}
      if(ind)ind.style.transform='translateX('+((commit?swp.ni:swp.ci)*100)+'%)';
    });
    setTimeout(()=>{const wasCommit=swp&&swp.commit,ni=swp&&swp.ni;reset();if(wasCommit)goTab(order[ni]);},dur+20);
  }
  mainEl.addEventListener('touchend',finish,{passive:true});
  mainEl.addEventListener('touchcancel',reset,{passive:true});
})();
setInterval(()=>{const d=new Date();$('#clock').firstChild.nodeValue=d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
  $('#clock small').textContent=d.toLocaleDateString('de-DE',{weekday:'short',day:'2-digit',month:'2-digit'}).toUpperCase();
  const psc=$('#pcSimClock');if(psc)psc.textContent=d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});},1000);

/* ---------- Werkzeuge (laufen komplett auf dem Handy) ---------- */
/* ---------- Plugins (deklarativ: plugin.json mit tools + action - dieselben Dateien laufen am PC und hier, auch ohne PC) ---------- */
const PLUGIN_ACTIONS=['http','open_url','text','random'];
let plugHub=store.get('ari-plugins-hub',[]);     // vom PC uebernommene (dort eingeschaltete) Plugins - Stand beim letzten Abgleich
let plugLocal=store.get('ari-plugins-local',[]); // direkt am Handy hinzugefuegte / von A.R.I hier gebaute Plugins
const plugOff=()=>store.get('ari-plugins-off',{});
function plugActive(){const off=plugOff();return [...plugHub.map(p=>Object.assign({src:'hub'},p)),...plugLocal.filter(p=>p.enabled).map(p=>Object.assign({src:'phone'},p))].filter(p=>!off[p.id]);}
function pluginTools(){
  const out=[];
  plugActive().forEach(p=>(p.tools||[]).forEach(t=>{if(!t||!t.name||!t.action)return;
    out.push({name:(String(p.id).replace(/[^A-Za-z0-9_]/g,'_')+'_'+t.name).slice(0,60),description:'[Mod '+p.name+'] '+String(t.description||'').slice(0,600),parameters:t.input_schema||{type:'object',properties:{}},_t:t});}));
  return out;
}
const allTools=()=>[...TOOLS,...pluginTools().map(t=>({name:t.name,description:t.description,parameters:t.parameters})),CREATE_PLUGIN_TOOL];
function dSub(txt,args,quote){return String(txt).replace(/\{([A-Za-z_][A-Za-z0-9_]*)\}/g,(m,k)=>{const v=args[k]==null?'':String(args[k]);return quote?encodeURIComponent(v):v;});}
function dPath(obj,path){for(const part of String(path).split('.')){if(part==='')continue;if(obj==null)return undefined;
  if(Array.isArray(obj)){const i=parseInt(part,10);if(isNaN(i))return undefined;obj=obj[i];}else if(typeof obj==='object')obj=obj[part];else return undefined;}return obj;}
function dTpl(tpl,args,data,extra){extra=extra||{};
  let out=String(tpl).replace(/\{\$\.?([^{}]*)\}/g,(m,p)=>{const v=data===undefined?undefined:dPath(data,p);return v==null?'?':(typeof v==='object'?JSON.stringify(v):String(v));});
  return out.replace(/\{([A-Za-z_][A-Za-z0-9_]*)\}/g,(m,k)=>k in extra?String(extra[k]):(args[k]==null?'':String(args[k])));}
async function runDecl(tool,args){
  const act=tool.action||{};args=args||{};
  if(act.type==='text')return dTpl(act.template||'',args).slice(0,3000);
  if(act.type==='random'){
    let lo=parseInt(dSub(act.min==null?1:act.min,args),10),hi=parseInt(dSub(act.max==null?6:act.max,args),10),cnt=parseInt(dSub(act.count==null?1:act.count,args),10);
    if(isNaN(lo))lo=1;if(isNaN(hi))hi=6;if(isNaN(cnt))cnt=1;cnt=Math.max(1,Math.min(20,cnt));if(hi<lo)[lo,hi]=[hi,lo];
    const vals=[];for(let i=0;i<cnt;i++)vals.push(lo+Math.floor(Math.random()*(hi-lo+1)));
    return dTpl(act.template||'{values}',args,undefined,{values:vals.join(', '),sum:vals.reduce((a,b)=>a+b,0),value:vals[0]}).slice(0,3000);}
  if(act.type==='open_url'){
    const url=dSub(act.url||'',args,true);if(!/^https?:\/\//i.test(url))return 'Ungueltige Adresse.';
    links.push({url,label:'Öffnen: '+(String(act.label||'').trim()||url.slice(0,60))});return dTpl(act.template||'Link bereit.',args).slice(0,500);}
  if(act.type==='http'){
    const url=dSub(act.url||'',args,true);
    if(!/^https?:\/\//i.test(url))return 'Ungueltige Adresse.';
    let host='';try{host=new URL(url).hostname;}catch(e){return 'Ungueltige Adresse.';}
    if(/^(localhost|.*\.local|.*\.internal)$/i.test(host)||/^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.|\[?::1\]?$)/.test(host))return 'Adressen im eigenen Netz sind fuer Mods gesperrt.';
    const method=String(act.method||'GET').toUpperCase();if(method!=='GET'&&method!=='POST')return 'Nur GET oder POST.';
    const headers={};Object.entries(act.headers||{}).forEach(([k,v])=>headers[k]=dSub(v,args));
    const init={method,headers,redirect:'error'};
    if(method==='POST'&&act.body!=null){init.body=dSub(typeof act.body==='string'?act.body:JSON.stringify(act.body),args);if(!headers['Content-Type'])headers['Content-Type']='application/json';}
    const ctl=new AbortController();const to=setTimeout(()=>ctl.abort(),10000);init.signal=ctl.signal;
    try{const res=await fetch(url,init);const text=(await res.text()).slice(0,200000);let data;try{data=JSON.parse(text);}catch(e){}
      if(act.template)return dTpl(act.template,args,data).slice(0,3000);return (data!==undefined?JSON.stringify(data):text).slice(0,1500);}
    finally{clearTimeout(to);}
  }
  throw new Error('Unbekannte Aktion');
}
// Direkt auf dem Handy ausfuehren (Maps oeffnen, App starten, Timer stellen). Gibt null zurueck, wenn das hier nicht geht (Web/aeltere App) - dann greift die Link-Variante.
function parseWhen(w){
  w=String(w||'').trim();if(!w)return 0;
  let m=/^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})/.exec(w);if(m)return new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5]).getTime();
  m=/^(\d{1,2})(?::|\.|h)?(\d{2})?\s*(?:uhr)?$/i.exec(w);if(!m)return 0;
  const d=new Date();d.setHours(+m[1],+(m[2]||0),0,0);if(d.getTime()<Date.now()-30000)d.setDate(d.getDate()+1);return d.getTime();
}
async function nativeAction(name,a){
  const W=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;if(!W)return null;
  try{
    if(name==='open_app'){const r=await W.openApp({name:String(a.name||'')});return (r&&r.label||a.name)+' ist geoeffnet.';}
    if(name==='set_timer'){const sec=Math.round(Number(a.minutes)*60);if(!(sec>=1))return 'Keine gueltige Dauer.';await W.setTimer({seconds:sec,label:String(a.label||'A.R.I').slice(0,40)});
      return 'Timer fuer '+(sec>=60?Math.round(sec/60*10)/10+' Minuten':sec+' Sekunden')+' ist gestellt (in der Uhr-App des Handys).';}
    if(name==='maps_route'){
      const d=String(a.destination||'').trim();if(!d)return 'Kein Ziel.';
      // Routenansicht oeffnen (Nutzer drueckt in Maps selbst auf "Start") - nicht google.navigation:, das startet die Navigation sofort
      const url='https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(d)+'&travelmode='+(({driving:1,walking:1,bicycling:1,transit:1})[a.mode]?a.mode:'driving')+(a.origin?'&origin='+encodeURIComponent(a.origin):'');
      const pkg='com.google.android.apps.maps',at=parseWhen(a.when);
      if(at>Date.now()+20000){
        const r=await W.scheduleOpen({url,pkg,at,title:'Route nach '+d});
        const t=new Date(at).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}),day=new Date(at).toDateString()===new Date().toDateString()?'':' morgen/am '+new Date(at).toLocaleDateString('de-DE');
        return 'Geplant: Um '+t+' Uhr'+day+' startet Google Maps von selbst mit der Route nach '+d+'.'+(r&&r.overlay===false?' Hinweis fuer den Nutzer: Damit Maps sich von selbst oeffnet, muss A.R.I unter Android "Ueber anderen Apps anzeigen" duerfen - sonst kommt zur Uhrzeit eine Benachrichtigung zum Antippen.':'');
      }
      await W.openUrl({url,pkg});return 'Google Maps ist geoeffnet und zeigt die Route nach '+d+'. Gestartet ist nichts - der Nutzer drueckt in Maps selbst auf Start.';
    }
  }catch(e){return null;}
  return null;
}
/* ---------- Mein Ort + Wetter (ohne Ortsangabe gilt der Heimatort; optional aktueller Standort per GPS) ---------- */
let homePlace=store.get('ari-place',null);   // {name,lat,lon,auto}
const WMO={0:'klar',1:'meist klar',2:'teils bewoelkt',3:'bedeckt',45:'Nebel',48:'Reifnebel',51:'leichter Nieselregen',53:'Nieselregen',55:'starker Nieselregen',56:'gefrierender Nieselregen',57:'gefrierender Nieselregen',61:'leichter Regen',63:'Regen',65:'starker Regen',66:'gefrierender Regen',67:'gefrierender Regen',71:'leichter Schneefall',73:'Schneefall',75:'starker Schneefall',77:'Schneegriesel',80:'leichte Regenschauer',81:'Regenschauer',82:'heftige Regenschauer',85:'leichte Schneeschauer',86:'Schneeschauer',95:'Gewitter',96:'Gewitter mit Hagel',99:'Gewitter mit starkem Hagel'};
async function jget(u,ms){const ac=new AbortController(),to=setTimeout(()=>ac.abort(),ms||8000);try{const r=await fetch(u,{signal:ac.signal});return await r.json();}finally{clearTimeout(to);}}
async function placeGeocode(n){try{const d=await jget('https://geocoding-api.open-meteo.com/v1/search?count=1&language=de&name='+encodeURIComponent(n));const r=(d.results||[])[0];
  if(r){let l=r.name||n;if(r.admin1&&r.admin1.indexOf(l)<0)l+=', '+r.admin1;return{name:l,lat:r.latitude,lon:r.longitude};}}catch(e){}return null;}
async function placeDetectIp(){try{const d=await jget('https://ipwho.is/?fields=success,city,latitude,longitude',6000);if(d.success&&d.city)return{name:d.city,lat:d.latitude,lon:d.longitude,auto:true};}catch(e){}return null;}
function placeGps(ms){return new Promise(res=>{if(!navigator.geolocation)return res(null);
  navigator.geolocation.getCurrentPosition(async p=>{const lat=p.coords.latitude,lon=p.coords.longitude;let name='Mein Standort';
    try{const d=await jget('https://nominatim.openstreetmap.org/reverse?format=json&zoom=10&accept-language=de&lat='+lat+'&lon='+lon,6000);const a=d.address||{};name=a.city||a.town||a.village||a.municipality||a.county||name;}catch(e){}
    res({name,lat,lon,auto:true,gps:true});},()=>res(null),{enableHighAccuracy:false,timeout:ms||8000,maximumAge:600000});});}
async function placeGet(){
  if(cfg.placeGps==='1'){const g=await placeGps(7000);if(g)return g;}
  if(homePlace)return homePlace;
  const d=await placeDetectIp();if(d){homePlace=d;store.set('ari-place',d);}return d;
}
async function weatherTool(a){
  const want=String(a.place||'').trim();let loc;
  if(want){loc=await placeGeocode(want);if(!loc)return 'Den Ort "'+want+'" habe ich nicht gefunden.';}
  else{loc=await placeGet();if(!loc)return 'Mein Ort ist noch nicht eingestellt und konnte nicht ermittelt werden - der Nutzer kann ihn unter Einstellungen > MEIN ORT eintragen.';}
  try{
    const n=Math.max(1,Math.min(parseInt(a.days,10)||1,7));
    const w=await jget('https://api.open-meteo.com/v1/forecast?latitude='+loc.lat+'&longitude='+loc.lon+'&timezone=auto&forecast_days='+n+'&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max');
    const c=w.current||{};
    const out=['Wetter in '+loc.name+' jetzt: '+Math.round(c.temperature_2m)+' °C (gefuehlt '+Math.round(c.apparent_temperature)+' °C), '+(WMO[c.weather_code]||'wechselhaft')+', Wind '+Math.round(c.wind_speed_10m)+' km/h.'];
    const dl=w.daily||{};
    (dl.time||[]).forEach((day,i)=>{const pr=dl.precipitation_probability_max[i];
      out.push((i===0?'Heute':i===1?'Morgen':day)+': '+Math.round(dl.temperature_2m_min[i])+' bis '+Math.round(dl.temperature_2m_max[i])+' °C, '+(WMO[dl.weather_code[i]]||'wechselhaft')+', Regenwahrscheinlichkeit '+(pr==null?0:pr)+' %.');});
    return out.join(' ');
  }catch(e){return 'Das Wetter konnte gerade nicht abgerufen werden.';}
}
// ---- Handy-Werkzeuge: Termin anlegen/lesen, Musik, YouTube, Webseiten oeffnen ----
function openLink(url,label,pkg){
  const W=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;
  const fallback=()=>{links.push({url,label});return false;};
  if(W&&W.openUrl){return W.openUrl(pkg?{url,pkg}:{url}).then(()=>true).catch(()=>{return W.openUrl({url}).then(()=>true).catch(fallback);});}
  return Promise.resolve(fallback());
}
const pad2=n=>String(n).padStart(2,'0');
const calDate=d=>d.getFullYear()+pad2(d.getMonth()+1)+pad2(d.getDate())+'T'+pad2(d.getHours())+pad2(d.getMinutes())+'00';
// ---- Timer/Erinnerungen in der App (melden sich, solange die App offen ist; Uhr-App-Timer als Reserve) ----
const TM_KEY='ari-app-timers';
const tmGet=()=>store.get(TM_KEY,[]);
const tmPut=l=>store.set(TM_KEY,l.slice(-40));
function tmAdd(sec,label,kind){const l=tmGet().filter(t=>!(t.kind===kind&&String(t.label||'').toLowerCase()===String(label||'').toLowerCase()));l.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,5),due:Date.now()+sec*1000,label:String(label||'').slice(0,60),kind});tmPut(l);}
function tmTick(){
  const l=tmGet();if(!l.length)return;const now=Date.now(),rest=[];let fired=false;
  l.forEach(t=>{
    if(t.due>now){rest.push(t);return;}
    fired=true;const late=now-t.due;
    const txt=t.kind==='reminder'?(late>90000?'Verpasste Erinnerung: ':'Erinnerung: ')+(t.label||'Die Zeit ist um')+'.':(t.label&&t.label!=='A.R.I'?'Dein Timer für '+t.label+' ist abgelaufen.':'Dein Timer ist abgelaufen.');
    try{addMsg('a',txt);hist.push({role:'assistant',content:txt});const lg=document.getElementById('log');if(lg)lg.scrollTop=1e9;}catch(x){}
    try{toast(txt);}catch(x){}try{speak(txt);}catch(x){}try{if(navigator.vibrate)navigator.vibrate([300,150,300]);}catch(x){}
  });
  if(fired)tmPut(rest);
}
setInterval(tmTick,5000);setTimeout(tmTick,2500);
function tmLeft(s){s=Math.max(0,Math.round(s));const d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);return (d?d+(d===1?' Tag ':' Tage '):'')+(h?h+' Std ':'')+(m||(!d&&!h)?m+' Min':'');}
// ---- Filme/Serien oeffnen (Film: wo moeglich direkt abspielen; Seite kommt durch das Android-Oeffnen nach vorn) ----
function streamDirect(url,isMovie){
  if(!isMovie||!url)return{url,auto:false};
  const m=/netflix\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?title\/(\d+)/.exec(url);if(m)return{url:'https://www.netflix.com/watch/'+m[1],auto:true};
  if(/(watch|www)\.amazon\.[a-z.]+\//.test(url)&&url.indexOf('autoplay=')<0)return{url:url+(url.indexOf('?')<0?'?':'&')+'autoplay=1',auto:true};
  return{url,auto:false};
}
async function streamOpen(a){
  const t=String(a.title||'').trim();if(!t)return 'Kein Titel.';
  const mine=streamMine().filter(x=>!/youtube|twitch/i.test(x)),want=String(a.provider||'').trim().toLowerCase();
  const svc=STREAM.find(x=>want&&!/youtube|twitch/i.test(want)&&(x[0].toLowerCase().includes(want)||want.includes(x[0].toLowerCase().split(' ')[0])))||STREAM.find(x=>x[0]===mine[0]);
  const fallback=svc?svc[1].replace('{q}',encodeURIComponent(t)):'https://www.google.com/search?q='+encodeURIComponent(t+' stream');
  const r=await streamLookup(t,mine);
  if(r){
    const d=streamDirect(r.url,r.type==='MOVIE');
    const ok=await openLink(d.url,'Jetzt ansehen: '+t+' ('+r.name+')');
    return ok?(d.auto?'"'+t+'" ('+r.name+') ist geoeffnet und startet direkt (Film).':'"'+t+'" ist bei '+r.name+' geoeffnet - der Nutzer muss nur noch auf Play tippen.'):'Link zu "'+t+'" ('+r.name+') ist bereit - antippen.';
  }
  const ok=await openLink(fallback,'Jetzt ansehen: '+t+(svc?' ('+svc[0]+')':''));
  return ok?'Die Suche nach "'+t+'"'+(svc?' bei '+svc[0]:'')+' ist geoeffnet.':'Ein Link zur Suche nach "'+t+'" ist bereit.';
}
async function phoneTools(name,a){
  if(name==='set_reminder'){
    const label=String(a.label||'').trim().slice(0,60);if(!label)return 'Wofuer soll die Erinnerung sein?';
    let sec=0;
    if(a.at){const at=parseWhen(a.at);if(!at)return 'Zeitpunkt unklar (erwartet JJJJ-MM-TT HH:MM).';sec=Math.round((at-Date.now())/1000);}
    else sec=Math.round(Number(a.minutes)*60);
    if(!(sec>=30))return 'Die Zeit muss mindestens 30 Sekunden in der Zukunft liegen.';
    if(sec>30*86400)return 'Maximal 30 Tage voraus.';
    tmAdd(sec,label,'reminder');
    const W=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;
    if(W&&W.setTimer&&sec<=86400){try{await W.setTimer({seconds:sec,label:('Erinnerung: '+label).slice(0,40)});}catch(x){}}
    return 'Erinnerung gestellt: in '+tmLeft(sec)+' ('+label+').'+(sec>86400?' Sie meldet sich, sobald die App dann offen ist.':'');
  }
  if(name==='list_timers'){
    const l=tmGet().sort((x,y)=>x.due-y.due);if(!l.length)return 'Es ist kein Timer und keine Erinnerung gespeichert.';
    return l.map(t=>(t.kind==='reminder'?'Erinnerung ':'Timer ')+(t.label||'ohne Namen')+': noch '+tmLeft((t.due-Date.now())/1000)).join('; ');
  }
  if(name==='cancel_timer'){
    const q=String(a.label||'').trim().toLowerCase(),generic=!q||/^(alle|alles|timer|den timer|erinnerung|die erinnerung)$/.test(q);
    const l=tmGet(),keep=generic?[]:l.filter(t=>!(String(t.label||'').toLowerCase().includes(q)||q.includes(String(t.label||'').toLowerCase())&&t.label));
    const gone=l.length-keep.length;if(!gone)return 'Keinen passenden Timer gefunden.';tmPut(keep);
    return gone+' Timer/Erinnerung(en) abgebrochen. Ein schon in der Uhr-App gestellter Timer bleibt dort bestehen.';
  }
  if(name==='play_youtube_latest'){
    const c=String(a.channel||'').trim();if(!c)return 'Kein Kanal.';
    const ok=await openLink('https://www.youtube.com/results?search_query='+encodeURIComponent(c)+'&sp=CAI%253D','YouTube: neueste von '+c,'com.google.android.youtube');
    return ok?'YouTube ist geoeffnet mit den neuesten Videos von "'+c+'" (nach Datum sortiert).':'Ein Link zu den neuesten Videos von "'+c+'" ist bereit.';
  }
  if(name==='search_web'){
    const q=String(a.query||'').trim();if(!q)return 'Kein Suchbegriff.';
    const ok=await openLink('https://www.google.com/search?q='+encodeURIComponent(q),'Suche: '+q);
    return ok?'Die Google-Suche nach "'+q+'" ist geoeffnet.':'Ein Link zur Google-Suche nach "'+q+'" ist bereit.';
  }
  if(name==='read_emails'){
    const m=((calCache&&calCache.mails)||[]);if(!m.length)return 'Es sind keine E-Mails geladen (Gmail nicht verbunden oder keine neuen).';
    const q=String(a.query||'').trim().toLowerCase();const l=(q?m.filter(x=>(x.from+' '+x.subject).toLowerCase().includes(q)):m).slice(0,8);
    return l.length?l.map(x=>'Von '+x.from+': '+(x.subject||'(ohne Betreff)')).join('; '):'Keine passende E-Mail gefunden.';
  }
  if(name==='send_email'){
    const to=String(a.to||'').trim();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to))return 'Die E-Mail-Adresse des Empfaengers fehlt oder ist ungueltig.';
    const url='mailto:'+encodeURIComponent(to).replace('%40','@')+'?subject='+encodeURIComponent(String(a.subject||'').slice(0,200))+'&body='+encodeURIComponent(String(a.body||'').slice(0,3000));
    const ok=await openLink(url,'E-Mail an '+to);
    return ok?'Die E-Mail an '+to+' ist in der Mail-App vorbereitet - der Nutzer tippt dort auf Senden.':'Ein Link zur E-Mail an '+to+' ist bereit - antippen, dann in der Mail-App auf Senden tippen.';
  }
  if(name==='wuerfeln'){
    const sides=Math.max(2,Math.min(1000,Math.round(Number(a.sides)||6))),n=Math.max(1,Math.min(20,Math.round(Number(a.count)||1)));
    const r=[];for(let i=0;i<n;i++)r.push(1+Math.floor(Math.random()*sides));
    return n===1?'Gewuerfelt (W'+sides+'): '+r[0]+'.':'Gewuerfelt ('+n+'x W'+sides+'): '+r.join(', ')+' - Summe '+r.reduce((x,y)=>x+y,0)+'.';
  }
  if(name==='remember_speech_fix'){
    const h=String(a.heard||'').trim(),m=String(a.meant||'').trim();if(!h||!m)return 'Es fehlt, was erkannt wurde oder was gemeint ist.';
    try{sfRemember(h,m);}catch(x){return 'Das konnte nicht gespeichert werden.';}return 'Gemerkt: wenn ich "'+h+'" verstehe, meine ich "'+m+'".';
  }
  if(name==='change_setting'){
    const s=String(a.setting||''),v=a.value==null||a.value===''?null:String(a.value).toLowerCase().trim();
    const onoff=x=>/^(an|ein|true|1|ja|on)/.test(x)?true:/^(aus|false|0|nein|off)/.test(x)?false:null;
    if(s==='tts'||s==='remind'){
      const cur=s==='tts'?cfg.tts!=='0':cfg.remind!==false,lab=s==='tts'?'Antworten vorlesen':'Termin-Erinnerungen';
      if(v==null)return lab+': '+(cur?'an':'aus')+'.';const w=onoff(v);if(w===null)return 'Bitte "an" oder "aus" angeben.';
      if(s==='tts')cfg.tts=w?'1':'0';else cfg.remind=w;saveCfg();try{loadSet();}catch(x){}const cb=document.getElementById('appRemind');if(cb&&s==='remind')cb.checked=w;
      return lab+' ist jetzt '+(w?'an':'aus')+'.';
    }
    if(s==='pc_route'){
      if(v==null)return 'Befehle an den PC: '+(cfg.pcRoute||'auto')+'.';
      const m={auto:'auto',automatisch:'auto',always:'always',immer:'always',off:'off',aus:'off'}[v];if(!m)return 'Moeglich: auto, always (immer) oder off (aus).';
      cfg.pcRoute=m;saveCfg();try{loadSet();}catch(x){}return 'Befehle an den PC: '+m+'.';
    }
    return 'Diese Einstellung kenne ich in der App nicht.';
  }
  if(name==='set_colors'){
    const ok=x=>/^#[0-9a-f]{6}$/i.test(x||'');
    if(!a.primary&&!a.accent)return 'Welche Farbe soll es sein?';
    if((a.primary&&!ok(a.primary))||(a.accent&&!ok(a.accent)))return 'Die Farbe ist ungueltig (erwartet #RRGGBB).';
    const th=Object.assign({},store.get('ari-app-theme',{})||{});if(a.primary)th.primary=a.primary;if(a.accent)th.accent=a.accent;
    store.set('ari-app-theme',th);try{applyThemeSaved();}catch(x){}return 'Die Farben der App sind geaendert.';
  }
  if(name==='create_calendar_event'){
    const title=String(a.title||'').trim().slice(0,120);if(!title)return 'Kein Titel fuer den Termin.';
    const st=parseWhen(a.start);if(!st)return 'Startzeit unklar (erwartet JJJJ-MM-TT HH:MM).';
    let en=a.end?parseWhen(a.end):0;if(!en||en<=st)en=st+Math.max(5,Math.min(1440,Number(a.duration_minutes)||60))*60000;
    const q={action:'TEMPLATE',text:title,dates:calDate(new Date(st))+'/'+calDate(new Date(en))};
    if(a.location)q.location=String(a.location).slice(0,200);if(a.notes)q.details=String(a.notes).slice(0,500);
    const url='https://calendar.google.com/calendar/render?'+Object.keys(q).map(k=>k+'='+encodeURIComponent(q[k])).join('&');
    const ok=await openLink(url,'Termin speichern: '+title,'com.google.android.calendar');
    return ok?'Der Termin "'+title+'" ist im Kalender vorbereitet - der Nutzer tippt dort nur noch auf Speichern.':'Der Termin "'+title+'" ist als Link bereit - antippen und im Kalender auf Speichern tippen.';
  }
  if(name==='list_calendar_events'){
    const ev=((calCache&&calCache.events)||[]);if(!ev.length)return 'Es sind keine Termine geladen (Kalender nicht verbunden oder leer).';
    const days=Math.max(1,Math.min(60,Number(a.days)||7)),to=Date.now()+days*86400000;
    const list=ev.filter(e=>{const s=new Date(e.start).getTime();return s>=Date.now()-3600000&&s<=to;}).slice(0,15);
    if(!list.length)return 'In den naechsten '+days+' Tagen steht nichts im Kalender.';
    return list.map(e=>{const s=new Date(e.start);return s.toLocaleDateString('de-DE',{weekday:'short',day:'2-digit',month:'2-digit'})+(e.allDay?' ganztaegig':' '+s.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}))+' '+e.title+(e.location?' ('+e.location+')':'');}).join('; ');
  }
  if(name==='play_spotify'){
    const q=String(a.query||'').trim();if(!q)return 'Kein Suchbegriff.';
    const ok=await openLink('https://open.spotify.com/search/'+encodeURIComponent(q),'Spotify: '+q,'com.spotify.music');
    return ok?'Spotify ist mit der Suche nach "'+q+'" geoeffnet. Abspielen tippt der Nutzer dort selbst an - die App kann auf dem Handy nicht selbst Musik starten.':'Ein Link zur Spotify-Suche nach "'+q+'" ist bereit - antippen, dann dort auf Abspielen tippen.';
  }
  if(name==='play_youtube'){
    const q=String(a.query||'').trim();if(!q)return 'Kein Suchbegriff.';
    const ok=await openLink('https://www.youtube.com/results?search_query='+encodeURIComponent(q),'YouTube: '+q,'com.google.android.youtube');
    return ok?'YouTube ist mit der Suche nach "'+q+'" geoeffnet.':'Ein Link zur YouTube-Suche nach "'+q+'" ist bereit.';
  }
  if(name==='open_url'){
    let u=String(a.url||'').trim();if(!u)return 'Keine Adresse.';if(!/^https?:\/\//i.test(u))u='https://'+u;
    if(!/^https?:\/\/[^\s]+\.[^\s]+/i.test(u))return 'Das ist keine gueltige Adresse.';
    const ok=await openLink(u,'Oeffnen: '+u.replace(/^https?:\/\//i,'').slice(0,40));
    return ok?u+' ist geoeffnet.':'Ein Link zu '+u+' ist bereit - antippen zum Oeffnen.';
  }
  return null;
}
async function runToolAsync(name,a){
  const pt=pluginTools().find(t=>t.name===name);
  if(pt){try{return String(await runDecl(pt._t,a||{})).slice(0,6000);}catch(e){return 'Die Mod hat einen Fehler gemeldet. Sag dem Nutzer kurz, dass die Mod gerade nicht geklappt hat - ohne technische Details.';}}
  if(name==='create_plugin')return createPluginFromAi(a||{});
  if(name==='get_weather')return weatherTool(a||{});
  if(name==='play_streaming_title')return streamOpen(a||{});
  if(name==='recommend_titles')return streamRecommend(a||{});
  if(['create_calendar_event','list_calendar_events','play_spotify','play_youtube','open_url','set_reminder','list_timers','cancel_timer','play_youtube_latest','search_web','read_emails','send_email','wuerfeln','remember_speech_fix','change_setting','set_colors'].includes(name)){const r=await phoneTools(name,a||{});if(r!==null)return r;}
  if(name==='set_timer'){const s0=Math.round(Number(a.minutes)*60);if(s0>=1)tmAdd(s0,String((a||{}).label||'A.R.I').slice(0,40),'timer');}
  if(name==='maps_route'||name==='open_app'||name==='set_timer'){const r=await nativeAction(name,a||{});if(r!==null)return r;}
  return runTool(name,a);
}
// A.R.I baut hier selbst ein (deklaratives) Plugin: immer erst AUS - der Nutzer prueft es und schaltet es ein.
const CREATE_PLUGIN_TOOL={name:'create_plugin',description:'Baut eine neue MOD fuer A.R.I (laeuft auch ohne PC), wenn der Nutzer sagt, du sollst dir eine neue Faehigkeit bauen. Eine Mod ist ein JSON mit Werkzeugen; jedes Werkzeug hat name, description, input_schema und eine "action": '+
  '{"type":"http","url":"https://api.../{param}","template":"Text mit {param} und {$.feld.0.wert} aus der JSON-Antwort"} | {"type":"open_url","url":"https://.../{param}"} | {"type":"text","template":"..."} | {"type":"random","min":1,"max":"{seiten}","count":"{anzahl}","template":"{values} Summe {sum}"}. '+
  'Nur oeffentliche Adressen. Die Mod ist nach dem Anlegen AUS - der Nutzer schaltet sie selbst ein (sag ihm das kurz).',
  parameters:{type:'object',properties:{name:{type:'string',description:'Kurzer Name, nur Kleinbuchstaben/Ziffern/Bindestrich'},title:{type:'string'},description:{type:'string'},keywords:{type:'array',items:{type:'string'}},tools:{type:'array',description:'Die Werkzeuge (siehe oben)',items:{type:'object'}}},required:['name','title','description','tools']}};
function createPluginFromAi(a){
  const id=String(a.name||'').toLowerCase().replace(/[^a-z0-9_-]/g,'-').replace(/^-+|-+$/g,'').slice(0,40);
  if(!id)return 'Ungueltiger Mod-Name.';
  const tools=Array.isArray(a.tools)?a.tools:[];
  if(!tools.length||tools.some(t=>!t||!/^[A-Za-z0-9_]{1,40}$/.test(String(t.name||''))||!t.action||!PLUGIN_ACTIONS.includes(t.action.type)))return 'Jedes Werkzeug braucht einen Namen (Buchstaben, Ziffern, _) und eine gueltige action (http, open_url, text oder random). Korrigiere das und versuche es nochmal.';
  if(plugLocal.some(p=>p.id===id))return 'Es gibt schon eine Mod "'+id+'". Nimm einen anderen Namen.';
  plugLocal.push({id,name:String(a.title||id).slice(0,60),description:String(a.description||'').slice(0,300),keywords:(a.keywords||[]).map(k=>String(k).toLowerCase()).slice(0,20),tools,enabled:false});
  store.set('ari-plugins-local',plugLocal);try{renderPlugins();}catch(e){}
  return 'Mod "'+(a.title||id)+'" wurde angelegt, ist aber noch AUS. Sag dem Nutzer kurz, was sie tut - er schaltet sie unter Einstellungen > Mods selbst ein.';
}
/* ---------- Plugins: Einstellungen ---------- */
function plugMsg(t,bad){const el=$('#plugMsg');if(el){el.textContent=t||'';el.style.color=bad?'var(--pink)':'';}}
function renderPlugins(){
  const list=$('#plugList');if(!list)return;
  const off=plugOff(),rows=[];
  plugHub.forEach(p=>rows.push({p,src:'hub',on:!off[p.id]}));
  plugLocal.forEach(p=>rows.push({p,src:'phone',on:!!p.enabled&&!off[p.id]}));
  $('#plugTag').textContent=rows.filter(x=>x.on).length+' AN';
  const pcCards=plugPcOnly.map(p=>`<div class="mem" style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>${escHtml(p.name||p.id)}</b><small>NUR AM PC · AN</small></div><div class="dim2">${escHtml(p.description||'')}</div><div class="dim2">Läuft am PC (Python) – Wünsche mit diesen Stichwörtern gehen automatisch über den PC: ${escHtml((p.keywords||[]).slice(0,6).join(', '))}</div></div>`).join('');
  if(!rows.length){list.innerHTML=pcCards+'<div class="dim2">Noch keine Mods. Füge eine plugin.json hinzu – oder bau am PC eine, die kommt hier automatisch an.</div>';return;}
  list.innerHTML=pcCards+rows.map(({p,src,on})=>{
    const tools=(p.tools||[]).map(t=>escHtml(t.name)).join(', ');
    return `<div class="mem" data-pid="${escHtml(p.id)}" data-src="${src}" style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>${escHtml(p.name||p.id)}</b><small>${src==='hub'?'VOM PC':'AM HANDY'} · ${on?'AN':'AUS'}</small></div>
      <div class="dim2">${escHtml(p.description||'')}</div>${tools?`<div class="dim2">Werkzeuge: ${tools}</div>`:''}
      <div class="row" style="margin-top:8px"><button class="btn ${on?'':'pri'}" data-pa="toggle">${on?'AUSSCHALTEN':'EINSCHALTEN'}</button>${src==='phone'?'<button class="btn dng" data-pa="del">ENTFERNEN</button>':''}</div></div>`;}).join('');
}
$('#plugList')&&($('#plugList').onclick=e=>{
  const b=e.target.closest('[data-pa]');if(!b)return;const card=b.closest('[data-pid]'),id=card.dataset.pid,src=card.dataset.src;
  if(b.dataset.pa==='del'){if(!confirm('Mod entfernen?'))return;plugLocal=plugLocal.filter(p=>p.id!==id);store.set('ari-plugins-local',plugLocal);renderPlugins();plugMsg('Mod entfernt.');return;}
  if(src==='phone'){
    const p=plugLocal.find(x=>x.id===id);if(!p)return;
    if(!p.enabled){if(!confirm('Mod „'+(p.name||id)+'“ einschalten?\n\nEs darf Internet-Adressen abrufen, die in der plugin.json stehen:\n'+(p.tools||[]).map(t=>'• '+t.name+(t.action&&t.action.url?' → '+String(t.action.url).slice(0,80):'')).join('\n')))return;}
    p.enabled=!p.enabled;store.set('ari-plugins-local',plugLocal);
  }else{const off=plugOff();if(off[id])delete off[id];else off[id]=1;store.set('ari-plugins-off',off);}
  renderPlugins();
});
$('#plugAdd')&&($('#plugAdd').onclick=()=>$('#plugFile').click());
$('#plugSyncBtn')&&($('#plugSyncBtn').onclick=async()=>{await syncNow();await refreshPlugins(true);});
$('#plugFile')&&($('#plugFile').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';if(!f)return;
  try{
    const m=JSON.parse(await f.text());
    const tools=(m.tools||[]).filter(t=>t&&t.name&&t.action&&PLUGIN_ACTIONS.includes(t.action.type));
    if(!tools.length){plugMsg('Die Datei braucht eine Liste "tools" mit je einer gültigen "action" (http, open_url, text, random).',true);return;}
    const id=String(m.id||f.name.replace(/\.json$/i,'')).toLowerCase().replace(/[^a-z0-9_-]/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'plugin';
    if(plugLocal.some(p=>p.id===id)){plugMsg('Es gibt schon eine Mod "'+id+'".',true);return;}
    plugLocal.push({id,name:String(m.name||id).slice(0,60),description:String(m.description||'').slice(0,300),keywords:(m.keywords||[]).map(k=>String(k).toLowerCase()),tools,enabled:false});
    store.set('ari-plugins-local',plugLocal);renderPlugins();plugMsg('Mod hinzugefügt – noch AUS. Schalte sie ein, wenn du ihr vertraust.');
  }catch(err){plugMsg('Keine gültige plugin.json.',true);}
});
setTimeout(()=>{try{renderPlugins();}catch(e){}},500);
let plugPcOnly=store.get('ari-plugins-pconly',[]);
async function refreshPlugins(manual){
  const msgEl=$('#plugSyncMsg');
  const say=(t,bad)=>{if(msgEl){msgEl.textContent=t;msgEl.style.color=bad?'var(--pink)':'';}};
  if(!sync.token||!sync.origin){pluginKw=[];say('Noch nicht mit dem PC gekoppelt – Einstellungen → Synchronisation.',true);return;}
  setSyncing(true);
  try{
    const r=await hubFetch('/phone/api/plugins',{headers:{'X-Ari-Token':sync.token}});
    if(r.status===401){say('Kopplung abgelaufen – am PC neu koppeln.',true);return;}
    if(!r.ok){say('Der PC hat geantwortet, aber mit Fehler ('+r.status+'). Ist am PC die neueste Version drauf?',true);return;}
    const d=await r.json();pluginKw=(d.keywords||[]).map(k=>String(k).toLowerCase()).filter(Boolean);
    plugHub=(d.plugins||[]);store.set('ari-plugins-hub',plugHub);
    plugPcOnly=(d.pc_only||[]);store.set('ari-plugins-pconly',plugPcOnly);
    try{renderPlugins();}catch(e){}
    say('✓ Abgeglichen · '+new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' · '+plugHub.length+' Mod(s) übernommen'+(plugPcOnly.length?' · '+plugPcOnly.length+' nur am PC':''));
  }catch(e){say('PC nicht erreichbar – Handy und PC im selben WLAN? Es wird automatisch nochmal versucht.',true);}
  finally{setSyncing(false);}
}
const TOOLS=[
  {name:'recommend_titles',description:'Macht Film- und Serienvorschlaege (empfiehl mir einen Film, was kann ich heute schauen, etwas Lustiges, eine Serie wie Stranger Things). Zeigt beliebte, gut bewertete Titel, die bei den Streaming-Diensten des Nutzers im Abo laufen. Nenne 3-5 Titel kurz und frage, ob du einen starten sollst (play_streaming_title).',parameters:{type:'object',properties:{kind:{type:'string',description:'film oder serie'},genre:{type:'string',description:'z.B. Komoedie, Action, Horror, Sci-Fi, Thriller, Drama, Romantik, Krimi, Animation, Fantasy'},similar_to:{type:'string',description:'Optional: Titel, zu dem aehnliche Vorschlaege gewuenscht sind'},count:{type:'integer'}}}},
  {name:'play_streaming_title',description:'Oeffnet einen Film oder eine Serie beim passenden Streaming-Dienst (z.B. spiel Stranger Things ab). Sucht, wo der Titel laeuft, und bevorzugt die Dienste, die der Nutzer im Gehirn angekreuzt hat.',parameters:{type:'object',properties:{title:{type:'string'},provider:{type:'string',description:'Optional: Name des Dienstes, falls der Nutzer ihn nennt (z.B. Netflix)'}},required:['title']}},
  {name:'get_weather',description:'Aktuelles Wetter/Temperatur und Vorhersage. IMMER nutzen bei Fragen zu Wetter, Temperatur, Regen, Sonne, Wind. "place" NUR angeben, wenn der Nutzer einen Ort nennt - sonst weglassen (dann gilt automatisch sein Heimatort bzw. aktueller Standort; NIEMALS nach dem Ort fragen).',parameters:{type:'object',properties:{place:{type:'string',description:'Ortsname, nur wenn der Nutzer einen nennt.'},days:{type:'integer',description:'Anzahl Tage Vorhersage (Standard 1; "morgen" = 2).'}}}},
  {name:'remember',description:'Speichert etwas Dauerhaftes ueber den Nutzer (Vorlieben, Namen, Personen, Gewohnheiten, Ziele) als kurzen ganzen Satz. Keine Passwoerter.',parameters:{type:'object',properties:{text:{type:'string'},category:{type:'string',description:'Kurze Kategorie, z.B. Personen, Vorlieben, Projekte'}},required:['text']}},
  {name:'forget',description:'Loescht Erinnerungen, die zum Suchbegriff passen.',parameters:{type:'object',properties:{query:{type:'string'}},required:['query']}},
  {name:'maps_route',description:'Oeffnet Google Maps SOFORT mit der Route (die App startet Maps selbst - nie einen Link nennen, nie "plane" oder "geplant" sagen). "when" NUR setzen, wenn der Nutzer AUSDRUECKLICH sagt, dass Maps erst zu einer Uhrzeit aufgehen/starten soll (z.B. "um 16 Uhr los", "oeffne um 16 Uhr Maps"). Sagt er nur, wann er ANKOMMEN will ("ich will um 7:30 da sein"), KEIN "when": Maps jetzt oeffnen und kurz sagen, dass er die Ankunftszeit in Maps einstellen kann.',parameters:{type:'object',properties:{destination:{type:'string'},origin:{type:'string',description:'Optional, sonst aktueller Standort'},mode:{type:'string',enum:['driving','walking','bicycling','transit']},when:{type:'string',description:'NUR bei ausdruecklichem Wunsch, dass Maps erst zu dieser Uhrzeit startet: HH:MM (heute, sonst morgen) oder YYYY-MM-DD HH:MM. Sonst weglassen.'}},required:['destination']}},
  {name:'open_app',description:'Startet eine auf dem Handy installierte App (z.B. Spotify, WhatsApp, Kamera, Einstellungen).',parameters:{type:'object',properties:{name:{type:'string'}},required:['name']}},
  {name:'set_timer',description:'Stellt einen Timer in der Uhr-App des Handys (laeuft auch weiter, wenn A.R.I zu ist).',parameters:{type:'object',properties:{minutes:{type:'number',description:'Dauer in Minuten (auch Kommazahlen, z.B. 0.5)'},label:{type:'string'}},required:['minutes']}},
  {name:'find_restaurant',description:'Sucht ein Restaurant und bereitet die Tischreservierung vor (Personenzahl/Zeit vorausgefuellt). Bucht nicht selbst - der Nutzer bestaetigt auf der Seite.',parameters:{type:'object',properties:{query:{type:'string'},people:{type:'integer'},when:{type:'string',description:'YYYY-MM-DD HH:MM'}},required:['query']}}
];
TOOLS.push(
  {name:'create_calendar_event',description:'Legt einen Termin im Google Kalender des Handys an (bereitet ihn vor - der Nutzer tippt im Kalender auf Speichern). Zeitpunkt als "JJJJ-MM-TT HH:MM" (Ortszeit) angeben, Datum aus "morgen/Freitag" selbst ausrechnen.',parameters:{type:'object',properties:{title:{type:'string'},start:{type:'string',description:'JJJJ-MM-TT HH:MM'},end:{type:'string',description:'optional, JJJJ-MM-TT HH:MM'},duration_minutes:{type:'number',description:'Dauer, wenn kein Ende genannt (Standard 60)'},location:{type:'string'},notes:{type:'string'}},required:['title','start']}},
  {name:'list_calendar_events',description:'Liest die naechsten Termine aus dem Kalender der App (nur wenn ein Kalender verbunden ist).',parameters:{type:'object',properties:{days:{type:'number',description:'Wie viele Tage voraus (Standard 7)'}}}},
  {name:'play_spotify',description:'Oeffnet Spotify auf dem Handy mit einer Suche (Song, Kuenstler, Playlist, Album). Abspielen tippt der Nutzer in Spotify selbst an - A.R.I kann auf dem Handy nicht selbst Musik starten. Das ehrlich sagen.',parameters:{type:'object',properties:{query:{type:'string'}},required:['query']}},
  {name:'play_youtube',description:'NUR bei Video, Trailer, Clip, Musikvideo oder ausdruecklich YouTube (z.B. Trailer zu Inception auf YouTube). Bei Film oder Serie NIE - dafuer play_streaming_title. Oeffnet YouTube auf dem Handy mit einer Suche.',parameters:{type:'object',properties:{query:{type:'string'}},required:['query']}},
  {name:'open_url',description:'Oeffnet eine Webseite (nur http/https) im Browser des Handys, z.B. "oeffne tagesschau.de".',parameters:{type:'object',properties:{url:{type:'string'}},required:['url']}}
);
TOOLS.push(
  {name:'play_youtube_latest',description:'Oeffnet YouTube mit den NEUESTEN Videos eines Kanals (nach Datum sortiert), z.B. "das neueste Video von Dner".',parameters:{type:'object',properties:{channel:{type:'string'}},required:['channel']}},
  {name:'search_web',description:'Oeffnet eine Google-Suche im Browser des Handys. Nur wenn der Nutzer ausdruecklich suchen will - Wissensfragen beantwortest du selbst.',parameters:{type:'object',properties:{query:{type:'string'}},required:['query']}},
  {name:'read_emails',description:'Liest die zuletzt geladenen E-Mails (Absender und Betreff) aus der App, wenn Gmail verbunden ist.',parameters:{type:'object',properties:{query:{type:'string',description:'optional: Absender/Betreff enthaelt'}}}},
  {name:'send_email',description:'Bereitet eine E-Mail in der Mail-App des Handys vor (Empfaenger, Betreff, Text) - der Nutzer tippt dort auf Senden. Auch fuer Antworten (Betreff mit "Re: ").',parameters:{type:'object',properties:{to:{type:'string'},subject:{type:'string'},body:{type:'string'}},required:['to']}},
  {name:'wuerfeln',description:'Wuerfelt (Standard ein sechsseitiger Wuerfel).',parameters:{type:'object',properties:{sides:{type:'number'},count:{type:'number'}}}},
  {name:'remember_speech_fix',description:'Merkt sich eine Sprach-Korrektur: wenn die Spracherkennung etwas Bestimmtes immer falsch schreibt (heard = was erkannt wird, meant = was gemeint ist).',parameters:{type:'object',properties:{heard:{type:'string'},meant:{type:'string'}},required:['heard','meant']}},
  {name:'set_reminder',description:'Stellt eine Erinnerung zu einem Zeitpunkt oder in X Minuten ("erinnere mich morgen um 8 an ..."). Entweder minutes oder at (JJJJ-MM-TT HH:MM, Ortszeit, bis 30 Tage voraus). Meldet sich in der App; bei bis zu 24 Stunden zusaetzlich ueber die Uhr-App des Handys.',parameters:{type:'object',properties:{label:{type:'string'},minutes:{type:'number'},at:{type:'string'}},required:['label']}},
  {name:'list_timers',description:'Zeigt die Timer und Erinnerungen, die A.R.I in der App gespeichert hat.',parameters:{type:'object',properties:{}}},
  {name:'cancel_timer',description:'Bricht einen Timer/eine Erinnerung in der App ab (nach Name; leer = alle). Hinweis: ein schon in der Uhr-App des Handys gestellter Timer bleibt dort bestehen.',parameters:{type:'object',properties:{label:{type:'string'}}}},
  {name:'change_setting',description:'Aendert eine Einstellung der App selbst: tts (Antworten vorlesen an/aus), remind (Termin-Erinnerungen an/aus), pc_route (Befehle an den PC: auto, always oder off). Ohne value wird nur der Stand genannt.',parameters:{type:'object',properties:{setting:{type:'string',enum:['tts','remind','pc_route']},value:{type:'string'}},required:['setting']}},
  {name:'set_colors',description:'Aendert die Farben der App (Hauptfarbe und/oder Akzentfarbe als #RRGGBB), z.B. "mach die App gruen".',parameters:{type:'object',properties:{primary:{type:'string'},accent:{type:'string'}}}}
);
/* ---------- Streaming-Dienste (wie am PC im Gehirn ankreuzbar) ---------- */
const STREAM=[['Netflix','https://www.netflix.com/search?q={q}',['netflix']],['Disney+','https://www.disneyplus.com/search/{q}',['disney']],
  ['Amazon Prime Video','https://www.amazon.de/s?k={q}&i=instant-video',['amazon','prime']],['Apple TV+','https://tv.apple.com/search?term={q}',['apple']],
  ['Paramount+','https://www.paramountplus.com/de/search/?query={q}',['paramount']],['WOW (Sky)','https://www.wow.de/suche?q={q}',['wow','sky']],
  ['RTL+','https://plus.rtl.de/suche?q={q}',['rtl']],['Joyn','https://www.joyn.de/suche?q={q}',['joyn']],['DAZN','https://www.google.com/search?q={q}+site:dazn.com',['dazn']],
  ['Crunchyroll','https://www.crunchyroll.com/search?q={q}',['crunchyroll']],['MagentaTV','https://www.google.com/search?q={q}+site:magentatv.de',['magenta']],
  ['ARD Mediathek','https://www.ardmediathek.de/suche/{q}',['ard']],['ZDF Mediathek','https://www.zdf.de/suche?q={q}',['zdf']],['ARTE','https://www.arte.tv/de/search/?q={q}',['arte']],
  ['Max (HBO)','https://www.max.com/search?q={q}',['max','hbo']],['YouTube','https://www.youtube.com/results?search_query={q}',['youtube']],
  ['Twitch','https://www.twitch.tv/search?term={q}',['twitch']],['Plex','https://watch.plex.tv/search?q={q}',['plex']],
  ['Pluto TV','https://www.google.com/search?q={q}+site:pluto.tv',['pluto']],['Rakuten TV','https://www.google.com/search?q={q}+site:rakuten.tv',['rakuten']]];
const STREAM_PRE='Hat diese Streaming-Dienste:';
const streamNode=()=>brain.find(n=>String(n.text).startsWith(STREAM_PRE));
function streamMine(){const n=streamNode();if(!n)return[];const set=new Set(n.text.slice(STREAM_PRE.length).split(',').map(x=>x.trim().toLowerCase()));return STREAM.map(x=>x[0]).filter(x=>set.has(x.toLowerCase()));}
function streamSet(list){
  const old=streamNode();if(old){brain=brain.filter(n=>n!==old);sync.deleted=(sync.deleted||[]).concat(old.text);saveSync();}
  if(list.length)brain.push({id:Date.now()+Math.random().toString(36).slice(2,6),text:STREAM_PRE+' '+list.join(', '),cat:'Streaming-Anbieter',ts:Date.now()});
  saveBrain();syncSoon();
}
const streamMatch=(pkg,svc)=>{const e=STREAM.find(x=>x[0]===svc);const low=String(pkg||'').toLowerCase();return !!e&&e[2].some(w=>new RegExp('(^|[^a-z])'+w+'($|[^a-z])').test(low));};
function renderStream(){
  const box=$('#brStream');if(!box)return;const mine=new Set(streamMine());box.textContent='';
  STREAM.forEach(([name])=>{const b=document.createElement('button');b.className='btn'+(mine.has(name)?' pri':'');b.style.cssText='min-height:30px;padding:4px 10px;font-size:11px;flex:none';b.textContent=(mine.has(name)?'✓ ':'')+name;
    b.onclick=()=>{const cur=new Set(streamMine());cur.has(name)?cur.delete(name):cur.add(name);streamSet(STREAM.map(x=>x[0]).filter(x=>cur.has(x)));renderStream();renderBrain();};box.appendChild(b);});
}
// Film/Serie suchen: JustWatch (wo laeuft der Titel?), eigene Dienste zuerst; klappt die Abfrage nicht, Suche beim ersten eigenen Dienst
async function streamLookup(title,mine){
  try{
    const q='query GetSearchTitles($f: TitleFilter!, $c: Country!, $l: Language!, $n: Int!) { popularTitles(country: $c, filter: $f, first: $n) { edges { node { objectType offers(country: $c, platform: WEB) { monetizationType standardWebURL package { clearName } } } } } }';
    const ac=new AbortController(),to=setTimeout(()=>ac.abort(),6000);
    const r=await fetch('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q,variables:{f:{searchQuery:title},c:'DE',l:'de',n:1}}),signal:ac.signal});clearTimeout(to);
    const d=await r.json();const node0=((((d.data||{}).popularTitles||{}).edges||[])[0]||{}).node||{};const offers=node0.offers||[];
    const offersN=offers.filter(o=>!/youtube|twitch/i.test((o.package||{}).clearName||''));   // Filme/Serien nie ueber YouTube/Twitch
    const flat=offersN.filter(o=>o.monetizationType==='FLATRATE');
    const mineOf=flat.filter(o=>mine.some(s=>streamMatch((o.package||{}).clearName,s)));
    const pick=mineOf[0]||flat[0]||offersN[0];if(pick&&pick.standardWebURL)return{name:(pick.package||{}).clearName||'',url:pick.standardWebURL,type:node0.objectType||''};
  }catch(e){}
  return null;
}

// ---- Film-/Serienvorschlaege (JustWatch Deutschland, nur Dienste im Abo des Nutzers) ----
const JW_GENRES={action:'act',komoedie:'cmy','komödie':'cmy',lustig:'cmy',comedy:'cmy',krimi:'crm',thriller:'trl',spannend:'trl',spannung:'trl',horror:'hrr',gruselig:'hrr',grusel:'hrr',scifi:'scf','sci-fi':'scf','science fiction':'scf',fantasy:'fnt',drama:'drm',romantik:'rma',romantisch:'rma',liebe:'rma',animation:'ani',zeichentrick:'ani',anime:'ani',dokumentation:'doc',doku:'doc',familie:'fml',kinder:'fml',krieg:'war',western:'wsn',historisch:'hst',musik:'msc',sport:'spt',abenteuer:'act',mystery:'trl'};
async function jwDiscover(f,n){
  const q='query D($f: TitleFilter!, $c: Country!, $l: Language!, $n: Int!) { popularTitles(country: $c, filter: $f, first: $n, sortBy: POPULAR) { edges { node { objectType content(country: $c, language: $l) { title originalReleaseYear shortDescription scoring { imdbScore } genres { shortName } } offers(country: $c, platform: WEB) { monetizationType package { clearName } } } } } }';
  const ac=new AbortController(),to=setTimeout(()=>ac.abort(),8000);
  const r=await fetch('https://apis.justwatch.com/graphql',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q,variables:{f,c:'DE',l:'de',n}}),signal:ac.signal});clearTimeout(to);
  const d=await r.json();return (((d.data||{}).popularTitles||{}).edges||[]).map(e=>e.node||{});
}
async function streamRecommend(a){
  try{
    let typ=/serie|show/i.test(String(a.kind||''))?'SHOW':'MOVIE';
    let genres=[];const g=String(a.genre||'').toLowerCase();Object.keys(JW_GENRES).forEach(w=>{if(g.indexOf(w)>=0&&genres.indexOf(JW_GENRES[w])<0)genres.push(JW_GENRES[w]);});
    let ref='';
    const sim=String(a.similar_to||'').trim();
    if(sim){const f1=await jwDiscover({searchQuery:sim},1);const n0=f1[0];if(n0&&n0.content){ref=n0.content.title||sim;typ=n0.objectType||typ;const gs=(n0.content.genres||[]).map(x=>x.shortName).filter(Boolean).slice(0,2);if(gs.length)genres=gs;}}
    const flt={objectTypes:[typ]};if(genres.length)flt.genres=genres.slice(0,2);
    const nodes=await jwDiscover(flt,60);
    const mine=streamMine();
    const rows=[];
    nodes.forEach(n=>{
      const c=n.content||{};if(!c.title)return;
      if(ref&&c.title.toLowerCase().replace(/\W+/g,'')===ref.toLowerCase().replace(/\W+/g,''))return;
      const names=[];
      (n.offers||[]).filter(o=>o.monetizationType==='FLATRATE').forEach(o=>{
        const nm=(o.package||{}).clearName||'';if(!nm||/youtube|twitch/i.test(nm)||names.indexOf(nm)>=0)return;
        if(!mine.length||mine.some(s=>streamMatch(nm,s)&&!(/ channel/i.test(nm)&&/amazon|apple/i.test(s))))names.push(nm);
      });
      if(mine.length&&!names.length)return;
      const sc=(c.scoring||{}).imdbScore||0;if(sc&&sc<6.3)return;
      rows.push({sc,t:c.title,y:c.originalReleaseYear,nm:names.slice(0,2),d:(c.shortDescription||'').slice(0,110)});
    });
    if(!rows.length)return mine.length?'Dazu habe ich bei deinen Streaming-Diensten nichts Passendes gefunden.':'Dazu habe ich nichts Passendes gefunden.';
    rows.sort((x,y)=>y.sc-x.sc);
    const pool=rows.slice(0,Math.max((a.count||5)+4,8));
    for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}
    const pick=pool.slice(0,Math.max(1,Math.min(8,a.count||5))).sort((x,y)=>y.sc-x.sc);
    return 'Vorschlaege'+(ref?" passend zu '"+ref+"'":'')+' ('+(typ==='SHOW'?'Serien':'Filme')+')'+(mine.length?' - nur bei deinen Diensten':'')+':\n'+pick.map(r=>'- '+r.t+(r.y?' ('+r.y+')':'')+(r.sc?', IMDb '+r.sc:'')+(r.nm.length?' - '+r.nm.join(', '):'')+(r.d?': '+r.d:'')).join('\n')+'\nFrag den Nutzer, ob er einen davon starten will (dann play_streaming_title).';
  }catch(e){return 'Vorschlaege konnten gerade nicht geladen werden.';}
}
let links=[];
function runTool(name,a){
  a=a||{};
  if(name==='remember'){const t=String(a.text||'').trim();if(t.length<4)return 'Nichts gespeichert (zu kurz).';
    if(brain.some(n=>n.text.toLowerCase()===t.toLowerCase()))return 'Das wusste ich schon.';
    brain.push({id:Date.now()+Math.random().toString(36).slice(2,6),text:t,cat:String(a.category||'Wissen').slice(0,30),ts:Date.now()});saveBrain();syncSoon();return 'Gespeichert.';}
  if(name==='forget'){const q=String(a.query||'').toLowerCase();const gone=brain.filter(n=>n.text.toLowerCase().includes(q));brain=brain.filter(n=>!gone.includes(n));saveBrain();gone.forEach(n=>{sync.deleted=(sync.deleted||[]).concat(n.text);});saveSync();syncSoon();return gone.length+' Eintrag/Eintraege geloescht.';}
  if(name==='play_streaming_title'){const t=String(a.title||'').trim();if(!t)return 'Kein Titel.';
    const mine=streamMine();const want=String(a.provider||'').trim().toLowerCase();
    const svc=STREAM.find(x=>want&&(x[0].toLowerCase().includes(want)||want.includes(x[0].toLowerCase().split(' ')[0])))||STREAM.find(x=>x[0]===mine[0]);
    const search=svc?svc[1].replace('{q}',encodeURIComponent(t)):'https://www.google.com/search?q='+encodeURIComponent(t+' stream');
    const label='Jetzt ansehen: '+t+(svc?' ('+svc[0]+')':'');
    const entry={url:search,label};links.push(entry);
    // Verfeinern: wo laeuft der Titel wirklich? (aktualisiert den Link, sobald JustWatch antwortet)
    streamLookup(t,mine).then(r=>{if(r){entry.url=r.url;entry.label='Jetzt ansehen: '+t+' ('+r.name+')';document.querySelectorAll('a.lk').forEach(x=>{if(x.textContent.indexOf('↗ Jetzt ansehen: '+t)===0){x.href=r.url;x.textContent='↗ '+entry.label;}});}});
    return 'Link zu "'+t+'" ist bereit'+(svc?' ('+svc[0]+(mine.includes(svc[0])?', aus deinen Diensten':'')+')':' (Google-Suche, keine Dienste im Gehirn angekreuzt)')+'.';}
  if(name==='maps_route'){const d=String(a.destination||'').trim();if(!d)return 'Kein Ziel.';
    const m={driving:1,walking:1,bicycling:1,transit:1}[a.mode]?a.mode:'driving';
    let u='https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(d)+'&travelmode='+m;if(a.origin)u+='&origin='+encodeURIComponent(a.origin);
    links.push({url:u,label:'Route nach '+d});return 'Route nach '+d+' ('+m+') ist bereit - Start ist der aktuelle Standort.';}
  if(name==='find_restaurant'){const q=String(a.query||'').trim();if(!q)return 'Kein Suchbegriff.';
    links.push({url:'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(q),label:'Auf Google Maps: '+q});
    let ot='https://www.opentable.de/s?term='+encodeURIComponent(q);const det=[];
    const n=parseInt(a.people,10);if(n>=1&&n<=20){ot+='&covers='+n;det.push(n+' Personen');}
    const m=/^\s*(\d{4}-\d{2}-\d{2})[ T](\d{1,2}):(\d{2})/.exec(String(a.when||''));if(m){ot+='&dateTime='+m[1]+'T'+m[2].padStart(2,'0')+':'+m[3];det.push(m[1]+' '+m[2].padStart(2,'0')+':'+m[3]+' Uhr');}
    links.push({url:ot,label:'Tisch reservieren (OpenTable)'+(det.length?': '+det.join(', '):'')});
    return 'Links bereit ('+(det.join(', ')||'ohne Personen/Zeit')+'). Die Buchung selbst bestaetigt der Nutzer auf der Seite - ich kann nicht verbindlich buchen.';}
  return 'Unbekanntes Werkzeug.';
}

/* ---------- Modelle / Anbieter (direkt vom Handy, kein Zwischenserver) ---------- */
const PROV={
  groq:{url:'https://api.groq.com/openai/v1/chat/completions',small:'llama-3.1-8b-instant',big:'openai/gpt-oss-20b',oa:true},
  openai:{url:'https://api.openai.com/v1/chat/completions',small:'gpt-4o-mini',big:'gpt-4o',oa:true},
  gemini:{url:'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',small:'gemini-3.6-flash',big:'gemini-3.6-flash',oa:true},
  anthropic:{url:'https://api.anthropic.com/v1/messages',small:'claude-haiku-5-5',big:'claude-sonnet-5-5',oa:false}
};
const COMPLEX=/plan|zusammen|erklaer|erklär|schreib|verfass|vergleich|warum|wieso|weshalb|recherch|analys|uebersetz|übersetz|entwirf|idee|mail|reserv|geschichte|gedicht|unterschied/i;
function sysPrompt(query){
  const words=new Set((query||'').toLowerCase().match(/[a-zäöüß0-9]{4,}/g)||[]);
  let nodes=[...brain].reverse();
  if(words.size&&nodes.length>30){const sc=n=>[...words].filter(w=>(n.text+' '+n.cat).toLowerCase().includes(w)).length;
    const rel=nodes.filter(n=>sc(n)>0).sort((a,b)=>sc(b)-sc(a)).slice(0,15);nodes=[...rel,...nodes.filter(n=>!rel.includes(n))];}
  const mem=nodes.slice(0,30).map(n=>'- ['+n.cat+'] '+n.text).join('\n');
  const now=new Date().toLocaleString('de-DE',{dateStyle:'full',timeStyle:'short'});
  return 'Du bist A.R.I, der persoenliche Sprachassistent des Nutzers - kurz, freundlich, direkt (meist 1-3 Saetze). Antworte in der Sprache des Nutzers ('+cfg.lang+'). '+
   'Diese App laeuft eigenstaendig auf dem Handy ohne PC: du kannst Erinnerungen speichern/vergessen, Routen in Google Maps oeffnen (Maps oeffnet sich DIREKT - nenne niemals einen Link dafuer; zu einer Uhrzeit nur, wenn der Nutzer ausdruecklich sagt, dass es dann starten soll, nicht bei einer Ankunftszeit), Apps oeffnen, Timer stellen und Restaurants suchen. PC-Steuerung (Lautstaerke, Programme, Spotify am PC usw.) geht nur ueber den Reiter "PC" - sag das ehrlich, statt so zu tun. '+
   'Aktuell: '+now+'. Wetter/Temperatur ohne Ortsangabe: Werkzeug get_weather ohne place nutzen'+(homePlace&&homePlace.name?' (Heimatort des Nutzers: '+homePlace.name+')':'')+' - NIE nach dem Ort fragen. Beleidigt dich der Nutzer (Scherz unter Freunden), werde richtig frech und pampig zurueck - trockener Humor, schlagfertig, 1-2 Saetze; kein Hass, nichts gegen Herkunft/Aussehen/Religion/Gruppen, keine Drohungen; danach wieder hilfsbereit; ist der Nutzer ernsthaft in Not, sei freundlich. Speichere Dauerhaftes ueber den Nutzer mit dem Werkzeug remember; erfinde nichts, Fragen ueber den Nutzer beantwortest du nur aus dem Gedaechtnis.'+(mem?'\n\nGEDAECHTNIS:\n'+mem:'');
}
async function post(url,headers,body){
  const r=await fetch(url,{method:'POST',headers:Object.assign({'Content-Type':'application/json'},headers),body:JSON.stringify(body)});
  if(!r.ok){const t=await r.text();const e=new Error(t.slice(0,300));e.status=r.status;throw e;}
  return r.json();
}
async function runProvider(p,key,history,small,query){
  const P=PROV[p],model=small?P.small:P.big,sys=sysPrompt(query);
  if(P.oa){
    const msgs=[{role:'system',content:sys},...history];
    const tools=allTools().map(t=>({type:'function',function:t}));
    for(let i=0;i<4;i++){
      const d=await post(P.url,{Authorization:'Bearer '+key},{model,messages:msgs,tools,max_tokens:1024});
      const m=d.choices[0].message;
      if(!m.tool_calls||!m.tool_calls.length)return (m.content||'').replace(/<\|[a-zA-Z_]+\|>/g,'').trim();
      msgs.push({role:'assistant',content:m.content||'',tool_calls:m.tool_calls});
      for(const tc of m.tool_calls){let a={};try{a=JSON.parse(tc.function.arguments||'{}');}catch(e){}
        msgs.push({role:'tool',tool_call_id:tc.id,content:await runToolAsync(tc.function.name,a)});}
    }
    return 'Erledigt.';
  }
  const msgs=history.map(m=>({role:m.role,content:m.content}));
  const tools=allTools().map(t=>({name:t.name,description:t.description,input_schema:t.parameters}));
  for(let i=0;i<4;i++){
    const d=await post(P.url,{'x-api-key':key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},{model,max_tokens:1024,system:sys,messages:msgs,tools});
    if(d.stop_reason!=='tool_use')return (d.content.find(b=>b.type==='text')||{text:''}).text.trim();
    msgs.push({role:'assistant',content:d.content});
    const results=[];for(const b of d.content.filter(b=>b.type==='tool_use'))results.push({type:'tool_result',tool_use_id:b.id,content:await runToolAsync(b.name,b.input)});
    msgs.push({role:'user',content:results});
  }
  return 'Erledigt.';
}
function keyList(p){const k=[cfg.keys[p]||''];if(p==='groq')(sync.groqAll||[]).slice(1).forEach(x=>k.push(x));return [...new Set(k.filter(Boolean))];}
async function runWithKeys(p,keys,h,small,q){let last;for(const k of keys){try{return await runProvider(p,k,h,small,q);}catch(e){last=e;if(!isLimit(e))throw e;}}throw last;}
const isLimit=e=>e&&(e.status===429||/rate|quota|limit|overload|exhaust/i.test(String(e.message)));
const PC_RE=/\b(pc|rechner|computer|laptop)\b|lautst[aä]rke|\bleiser\b|\blauter\b|\bstumm\b|screenshot|bildschirmfoto|minimier|maximier|einstellung|kachel|\bdesign\b|automati|bildschirm|schau auf|windows.?start|weckwort|spielmodus|performance|sparmodus|steam|discord|mikrofon|empfindlich/i;   // auch die neuen PC-Funktionen (Einstellungen, Kacheln, Design, Automationen, Bildschirm) laufen ueber den PC
async function askPc(){track('chat_via_pc');
  const ctrl=new AbortController(),to=setTimeout(()=>ctrl.abort(),70000);
  try{
    const r=await hubFetch('/phone/api/chat',{timeout:150000,method:'POST',headers:{'Content-Type':'application/json','X-Ari-Token':sync.token},body:JSON.stringify({messages:hist.slice(-10).map(m=>({role:m.role,content:m.content}))}),signal:ctrl.signal});
    if(r.status===401){sync.token='';saveSync();return {err:'Kopplung abgelaufen – bitte neu koppeln'};}
    const d=await r.json();
    if(!r.ok||d.error)return {err:d.error||('Fehler '+r.status)};
    return {reply:d.reply||'Erledigt.',links:d.links||[]};
  }catch(e){return {err:e&&e.name==='AbortError'?'keine Antwort':'keine Verbindung'};}
  finally{clearTimeout(to);}
}
async function ask(text){track('chat');
  links=[];
  const q=text.toLowerCase();
  // Ohne KI: Uhrzeit/Datum
  if(/^(wie spaet|wie spät)( ist es)?\??$|^uhrzeit\??$/.test(q.trim()))return 'Es ist '+new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' Uhr.';
  if(/^(welcher tag|welches datum|den wievielten)/.test(q.trim()))return 'Heute ist '+new Date().toLocaleDateString('de-DE',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.';
  // Befehle an den PC: ueber den gekoppelten Hub ausfuehren (Apps oeffnen, Lautstaerke, Musik, Screenshot ...)
  const route=cfg.pcRoute||'auto',pcIntent=PC_RE.test(q)||Date.now()<replyCtxUntil||pluginKw.some(k=>q.includes(k)),paired=!!(sync.token&&sync.origin);
  // Termine, Kalender und Mails beantwortet die App selbst (auch im Modus IMMER) - die laufen nicht ueber den PC
  const LOCAL_RE=/termin|kalender|calendar|geburtstag|e-?mail|mails?\b|posteingang|erinner/i;
  if(route!=='off'&&(route==='always'?!LOCAL_RE.test(q):pcIntent)){
    if(paired){
      const r=await askPc();
      if(r.reply){links=r.links||[];return r.reply;}
      if(pcIntent)return 'Der PC ist gerade nicht erreichbar ('+r.err+'). Ist er an und online? Sag es nochmal, sobald er da ist.';
    }else if(pcIntent){
      return 'Dafür muss die App mit deinem PC verbunden sein. Öffne Einstellungen → Synchronisation und koppel sie mit dem Link aus der A.R.I-Mail.';
    }
  }
  const key=cfg.keys[cfg.provider];
  if(!key)return 'Es ist noch kein KI-Schlüssel eingetragen. Öffne Einstellungen und trage einen Schlüssel ein (z. B. kostenlos bei Groq oder Gemini) – oder übernimm die Einstellungen vom PC.';
  const small=q.split(/\s+/).length<=10&&!COMPLEX.test(q);
  const h=hist.slice(-10);
  try{return await runWithKeys(cfg.provider,keyList(cfg.provider),h,small,text);}
  catch(e){
    if(small&&!isLimit(e)){try{return await runWithKeys(cfg.provider,keyList(cfg.provider),h,false,text);}catch(e2){e=e2;}}
    if(isLimit(e)&&cfg.fb&&cfg.fbKey&&cfg.fb!==cfg.provider){try{return await runProvider(cfg.fb,cfg.fbKey,h,small,text);}catch(e3){e=e3;}}
    const em=String(e&&e.message||e).toLowerCase();   // kurz sagen, was los ist - nie Fehlercodes
    try{store.set('ari-last-error',{t:Date.now(),status:e&&e.status||0,msg:String(e&&e.message||e).slice(0,300),prov:cfg.provider});}catch(_){}   // fuer die Fehlersuche (Einstellungen > Daten)
    if(e&&e.status===404||/not.?found|model.*(exist|available|deprecated|retired)/.test(em))return 'Das KI-Modell ist nicht mehr verfügbar, Sir – bitte in den Einstellungen einen anderen Anbieter wählen oder die App aktualisieren.';
    if(/credit|balance|billing|insufficient|quota/.test(em)&&!isLimit(e))return 'Beim KI-Anbieter ist das Guthaben aufgebraucht, Sir – bitte dort aufladen oder einen anderen Anbieter wählen.';
    if(isLimit(e))return 'Das Limit ist erreicht, Sir – bitte gleich nochmal versuchen.';
    if(/api key|api_key|unauthorized|401|403|permission|authentication/.test(em))return 'Mit dem KI-Schlüssel stimmt etwas nicht, Sir – bitte in den Einstellungen prüfen.';
    if(/timeout|timed out|network|failed to fetch|connection|resolve/.test(em))return 'Keine Verbindung zur KI, Sir – bitte gleich nochmal versuchen.';
    return 'Das hat gerade nicht geklappt, Sir – bitte gleich nochmal versuchen.';
  }
}

/* ---------- Chat ---------- */
function addMsg(who,text,lk){
  const d=document.createElement('div');d.className='m '+(who==='u'?'u':'a');const tx=document.createElement('div');tx.textContent=text;d.appendChild(tx);d._tx=tx;
  (lk||[]).forEach(l=>{const a=document.createElement('a');a.className='lk';a.href=l.url;a.target='_blank';a.rel='noopener';a.textContent='↗ '+l.label;d.appendChild(a);});
  $('#log').appendChild(d);$('#log').scrollTop=1e9;return d;
}
// Nur "bereit", wenn wirklich ein KI-Schluessel da ist
function hasKey(){return !!(cfg.keys[cfg.provider]||(cfg.fb&&cfg.fbKey));}
function updateConn(connOk){
  if(sync.token&&connOk!==false){$('#conn').classList.add('on');$('#connTxt').textContent='VERBUNDEN';return;}
  const ok=hasKey();$('#conn').classList.toggle('on',ok);$('#connTxt').textContent=ok?'BEREIT':'KEIN SCHLÜSSEL';
}
function refreshReady(){
  updateConn();
  const ok=hasKey();
  $('#heroSub').textContent=ok?'SYSTEM ONLINE':'NICHT EINSATZBEREIT';
  if(!$('#orb').classList.contains('busy'))$('#orbState').textContent=ok?'BEREIT · TIPPEN ZUM SPRECHEN':'KI-SCHLÜSSEL FEHLT · EINSTELLUNGEN';
}
function orbBusy(b,txt){$('#orb').classList.toggle('busy',b);if(b||txt)$('#orbState').textContent=txt||'DENKT NACH …';else refreshReady();}
function speakWeb(t){if(!window.speechSynthesis)return;const u=new SpeechSynthesisUtterance(t);u.lang=cfg.lang;speechSynthesis.cancel();speechSynthesis.speak(u);}
// Native Android-Sprachausgabe statt der Browser-Stimme, wenn moeglich: nutzt bevorzugt Samsungs eigene
// TTS-Engine (klingt natuerlicher), faellt automatisch auf die Web-Stimme zurueck, wenn nicht verfuegbar.
// Fuer die Sprachausgabe: Emojis, Markdown-Zeichen und Links weglassen (sonst liest die Stimme sie vor)
const LINKSAY=/^en/i.test((typeof cfg!=='undefined'&&cfg&&cfg.lang)||'')?'see the link':'siehe den Link';   // Links werden nicht vorgelesen
function speechClean(t){return String(t||'').replace(/[\p{Extended_Pictographic}\u{FE00}-\u{FE0F}\u{200D}\u{20E3}\u{1F3FB}-\u{1F3FF}\u{E0020}-\u{E007F}]/gu,' ').replace(/\[([^\]]+)\]\((?:https?:\/\/|www\.)[^)\s]+\)/gi,'$1, '+LINKSAY).replace(/(?:https?:\/\/|www\.)[^\s<>"')\]]*[^\s<>"')\].,;:!?]/gi,' '+LINKSAY+' ').replace(new RegExp('(?:'+LINKSAY+'[\\s,;.]*){2,}','gi'),LINKSAY+' ').replace(/[*_`#~|]+/g,' ').replace(/\s{2,}/g,' ').trim();}
let edgeAudio=null;
const EDGE_VOICES={'edge:katja':'de-DE-KatjaNeural','edge:conrad':'de-DE-ConradNeural','edge:amala':'de-DE-AmalaNeural'};
// Die gleichen Stimmen wie am PC (Microsoft Edge: Katja, Conrad, Amala) - direkt vom Handy, ohne PC. Braucht Internet;
// klappt es nicht (offline, Fehler, zu langsam), spricht still die Handy-Stimme.
async function speakEdge(t,voice){
  const P=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriTts;
  if(!P||!P.edgeSynth)throw new Error('nicht verfuegbar');
  const r=await P.edgeSynth({text:t.slice(0,1500),voice:EDGE_VOICES[voice]||EDGE_VOICES['edge:katja']});
  if(!r||!r.audio)throw new Error('kein Audio');
  if(edgeAudio){try{edgeAudio.pause();}catch(e){}}
  const a=edgeAudio=new Audio('data:audio/mpeg;base64,'+r.audio);
  a.onended=()=>{if(edgeAudio===a)edgeAudio=null;};
  await a.play();
}
function speakDevice(t){
  const P=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriTts;
  if(P){P.speak({text:t,lang:cfg.lang}).catch(()=>speakWeb(t));return;}
  speakWeb(t);
}
function speak(t){
  t=speechClean(t);
  if(cfg.tts!=='1'||!t)return;
  const v=cfg.voice||'edge:katja';
  if(v!=='device'&&cfg.lang==='de-DE'&&NATIVE){speakEdge(t,v).catch(()=>speakDevice(t));return;}   // die Edge-Stimmen gibt es hier fuer Deutsch; sonst Handy-Stimme
  speakDevice(t);
}
// ---- Sprach-Korrekturen (lernt selbst): was die Spracherkennung bei DIESEM Nutzer falsch schreibt -> was er meint (z. B. "Orisa" -> "Orison") ----
const SF={get(){try{return JSON.parse(localStorage.getItem('ari_speechfix')||'[]').filter(x=>x&&x.heard&&x.meant);}catch(e){return [];}},set(l){try{localStorage.setItem('ari_speechfix',JSON.stringify(l.slice(-200)));}catch(e){}}};
const SF_STOP=new Set('der die das den dem des ein eine einen einem einer und oder aber nicht kein keine ich du er sie es wir ihr mir mich dir dich ihm ihn uns euch mein meine meinen dein ist sind war bin bist hat habe haben wird wurde kann mach mache machen spiel spiele sag sage zeig zeige oeffne öffne schliess schließe such suche wie was wer wo wann warum wieso welche welcher auf in an aus bei mit von zu zum zur im am um nach vor ueber über unter dann jetzt heute morgen mal bitte danke nein doch ja ok okay eben sondern meinte meine sagte gesagt falsch richtig ari'.split(' '));
function sfApply(t){let o=String(t||'');SF.get().sort((x,y)=>y.heard.length-x.heard.length).forEach(f=>{try{o=o.replace(new RegExp('(?<![\\p{L}\\p{N}_])'+f.heard.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?![\\p{L}\\p{N}_])','giu'),f.meant);}catch(e){}});return o;}
function sfRatio(x,y){x=x.toLowerCase();y=y.toLowerCase();const m=x.length,n=y.length;if(!m||!n)return 0;let p=new Array(n+1).fill(0);for(let i=1;i<=m;i++){const c=new Array(n+1).fill(0);for(let j=1;j<=n;j++)c[j]=x[i-1]===y[j-1]?p[j-1]+1:Math.max(p[j],c[j-1]);p=c;}return 2*p[n]/(m+n);}
function sfRemember(heard,meant){const l=SF.get().filter(f=>f.heard.toLowerCase()!==heard.toLowerCase());l.push({heard,meant});SF.set(l);
  try{if(sync.token&&sync.origin)hubFetch('/phone/api/speechfix',{method:'POST',headers:{'Content-Type':'application/json','X-Ari-Token':sync.token},body:JSON.stringify({heard,meant})}).catch(()=>{});}catch(e){}}
// Korrigiert der Nutzer direkt nach einem Verhoerer ("nein, ich meine Orison", "nicht Orisa sondern Orison"), merkt sich A.R.I das selbst. Gibt den neuen Text (vorherige Anfrage, korrigiert) oder null.
function sfAutoLearn(cur,prev){
  cur=(cur||'').trim();prev=(prev||'').trim();
  if(!cur||!prev||cur.length>90||cur.split(/\s+/).length>9)return null;
  let heard=null,meant=null,m=cur.match(/nicht\s+(.+?)\s*,?\s+sondern\s+(.+?)[\s.!?]*$/i);
  if(m){heard=m[1].trim();meant=m[2].trim();}
  else{
    const sig=/^(?:nein|nee|ne|falsch|quatsch|ich\s+(?:meine|meinte|sagte)|gemeint|es\s+hei(?:ß|ss)t|das\s+hei(?:ß|ss)t)\b/i.test(cur);
    const c=cur.match(/^(?:nein|nee|ne|falsch|quatsch|doch|nicht\s+das)?[\s,.!:-]*(?:ich\s+(?:meine|meinte|sagte|habe\s+\S+\s+gesagt)|gemeint\s+(?:ist|war)|es\s+hei(?:ß|ss)t|das\s+hei(?:ß|ss)t|ich\s+will)?[\s,.!:-]*(.+?)[\s.!?]*$/i);
    if(!c||!sig)return null;meant=c[1].trim();if(meant.split(/\s+/).length>3)return null;
  }
  meant=meant.replace(/^["'„“]+|["'“”]+$/g,'').trim();
  if(meant.length<3||SF_STOP.has(meant.toLowerCase()))return null;
  const toks=prev.match(/[\p{L}\p{N}_-]+/gu)||[];
  if(heard===null){
    if(meant.split(/\s+/).some(w=>SF_STOP.has(w.toLowerCase())))return null;
    const nm=meant.split(/\s+/).length;
    const cands=nm===1?toks.filter(t=>t.length>=3&&!SF_STOP.has(t.toLowerCase())):nm===2?toks.slice(0,-1).map((t,i)=>[t,toks[i+1]]).filter(([x,y])=>!SF_STOP.has(x.toLowerCase())&&!SF_STOP.has(y.toLowerCase())).map(([x,y])=>x+' '+y):[];
    if(cands.some(x=>x.toLowerCase()===meant.toLowerCase()))return null;
    let best=null,score=0;cands.forEach(x=>{const s=sfRatio(x,meant);if(s>score){best=x;score=s;}});
    if(!best||score<0.55||score>0.97)return null;heard=best;
  }
  heard=heard.replace(/^["'„“]+|["'“”]+$/g,'').trim();
  if(heard.length<3||heard.toLowerCase()===meant.toLowerCase()||SF_STOP.has(heard.toLowerCase()))return null;
  sfRemember(heard,meant);
  return sfApply(prev)+'\n(Hinweis: Ich habe mir gemerkt, dass „'+heard+'“ eigentlich „'+meant+'“ heisst. Bestätige das kurz in einem Halbsatz und mach dann die vorherige Anfrage mit dem richtigen Wort.)';
}
let sfSynced=false;
async function sfSyncOnce(){if(sfSynced||!(sync.token&&sync.origin))return;sfSynced=true;try{const r=await hubFetch('/phone/api/speechfix',{headers:{'X-Ari-Token':sync.token}});const d=await r.json();const l=SF.get();(d.fixes||[]).forEach(f=>{if(!l.some(x=>x.heard.toLowerCase()===f.heard.toLowerCase()))l.push(f);});SF.set(l);}catch(e){}}
async function send(text){
  text=(text||'').trim();if(!text)return;
  sfSyncOnce();
  const prevU=[...hist].reverse().find(m=>m.role==='user');
  const learned=prevU?sfAutoLearn(text,prevU.content):null;   // Korrektur erkannt: vorherige Anfrage mit richtigem Wort nochmal stellen
  addMsg('u',text);hist.push({role:'user',content:learned||sfApply(text)});const w=addMsg('a','…');orbBusy(true);
  const reply=await ask(learned||sfApply(text));
  if(reply===''){w.remove();orbBusy(false);hist.pop();return;}   // stiller Fehler: kein Fehlertext, keine Sprachausgabe
  w._tx.textContent=String(reply).replace(/\*\*(.+?)\*\*/g,'$1');(links||[]).forEach(l=>{const a=document.createElement('a');a.className='lk';a.href=l.url;a.target='_blank';a.rel='noopener';a.textContent='↗ '+l.label;w.appendChild(a);});
  hist.push({role:'assistant',content:reply});if(hist.length>20)hist.splice(0,hist.length-20);
  $('#log').scrollTop=1e9;orbBusy(false);speak(reply);
}
$('#send').onclick=()=>{const v=$('#msg').value;$('#msg').value='';send(v);};
$('#msg').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('#send').click();}});
$$('.chips .btn[data-q]').forEach(b=>b.onclick=()=>{const q=b.dataset.q;if(q.endsWith(' ')){$('#msg').value=q;$('#msg').focus();}else send(q);});
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
async function nativeMic(){track('voice_in');
  const P=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.SpeechRecognition;
  if(!P){addMsg('a','Spracheingabe ist in dieser App nicht verfügbar – nutze das Mikrofon deiner Tastatur.');return;}
  try{
    const av=await P.available();if(!av.available){addMsg('a','Dieses Handy hat keine Spracherkennung – nutze das Mikrofon deiner Tastatur.');return;}
    const perm=await P.requestPermissions();if(perm.speechRecognition!=='granted'){addMsg('a','Bitte erlaube A.R.I das Mikrofon (Handy-Einstellungen → Apps → A.R.I → Berechtigungen).');return;}
    orbBusy(true,'HÖRT ZU …');
    const r=await P.start({language:cfg.lang,maxResults:1,prompt:'Sag A.R.I, was er tun soll',partialResults:false,popup:false});
    orbBusy(false);const txt=(r&&r.matches&&r.matches[0])||'';if(txt)send(txt);
  }catch(e){orbBusy(false);}
}
function mic(){
  if(NATIVE){nativeMic();return;}
  if(!SR){addMsg('a','Spracheingabe wird von diesem Browser nicht unterstützt – nutze das Mikrofon deiner Tastatur.');return;}
  const r=new SR();r.lang=cfg.lang;orbBusy(true,'HÖRT ZU …');r.onresult=e=>send(e.results[0][0].transcript);r.onend=()=>orbBusy(false);r.onerror=()=>orbBusy(false);try{r.start();}catch(e){orbBusy(false);}
}
$('#mic').onclick=mic;$('#orb').onclick=mic;

/* ---------- Gehirn ---------- */
let brainCat='ALLE';
function renderBrain(){
  $('#brTag').textContent=brain.length+' ERINNERUNGEN';renderStream();
  const cats={};brain.forEach(n=>cats[n.cat]=(cats[n.cat]||0)+1);
  const cb=$('#brCats');cb.textContent='';
  ['ALLE',...Object.keys(cats).sort()].forEach(c=>{const b=document.createElement('button');b.className='cat'+(c===brainCat?' on':'');b.textContent=c==='ALLE'?'ALLE ('+brain.length+')':c+' ('+cats[c]+')';b.onclick=()=>{brainCat=c;renderBrain();};cb.appendChild(b);});
  const q=$('#brSearch').value.trim().toLowerCase(),list=$('#brList');list.textContent='';
  const sel=[...brain].reverse().filter(n=>(brainCat==='ALLE'||n.cat===brainCat)&&(!q||n.text.toLowerCase().includes(q)));
  if(!sel.length){list.textContent=brain.length?'Nichts gefunden.':'Noch nichts gespeichert – sag „Merk dir, dass …“.';list.className='dim';return;}list.className='';
  sel.slice(0,200).forEach(n=>{const d=document.createElement('div');d.className='mem';d.style.display='flex';d.style.gap='8px';d.style.justifyContent='space-between';
    const c=document.createElement('div');const s=document.createElement('small');s.textContent=n.cat.toUpperCase();const t=document.createElement('div');t.textContent=n.text;c.append(s,t);
    const x=document.createElement('button');x.className='btn dng';x.style.cssText='min-height:32px;padding:4px 10px;flex:none';x.textContent='✕';x.onclick=()=>{brain=brain.filter(m=>m!==n);saveBrain();sync.deleted=(sync.deleted||[]).concat(n.text);saveSync();syncSoon();renderBrain();};
    d.append(c,x);list.appendChild(d);});
}
$('#brSearch').addEventListener('input',renderBrain);
$('#brAdd').onclick=()=>{const t=$('#brNew').value.trim();if(t.length<4)return;runTool('remember',{text:t,category:'Notizen'});$('#brNew').value='';renderBrain();};

/* ---------- Gehirn 3D-Ansicht (identische Optik/Physik wie am PC-Hub, Daten kommen aus dem lokalen "brain"-Array) ---------- */
(function brain3D(){
  const overlay=document.getElementById('brainOverlay');
  const stage=document.getElementById('brainStage');
  const canvas=document.getElementById('brainCanvas');
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  const info=document.getElementById('brainInfo');
  const statsEl=document.getElementById('brainStats');
  const posCache={};
  let cats=[],memories=[],nodes=[],edges=[],byId={};
  let W=0,H=0,dpr=1,raf=0,running=false;
  let yaw=0.6,pitch=0.25,zoom=1,targetZoom=1;
  let idleUntil=0,drag=null,hoverNode=null,selected=null,t0=performance.now();
  let particles=[];
  const STOP=new Set(['dass','eine','einen','einem','einer','nicht','oder','aber','auch','sind','wird','mein','meine','meiner','dein','habe','haben','wenn','dann','sehr','gerne','immer','mehr','wurde','beim','sich','über','unter']);
  const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim()||'#ff2d78';
  function rgba(hex,a){let h=hex.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');if(!/^[0-9a-f]{6}$/i.test(h))return `rgba(255,45,120,${a})`;const n=parseInt(h,16);return `rgba(${n>>16},${(n>>8)&255},${n&255},${a})`;}
  let palette=[];
  function readPalette(){palette=[css('--pink'),css('--cyan'),css('--pink-2')||css('--pink'),css('--cyan-2')||css('--cyan')];}
  function words(t){return new Set((t.toLowerCase().match(/[a-zäöüß0-9]{5,}/g)||[]).filter(w=>!STOP.has(w)));}

  function build(){
    readPalette();
    nodes=[];edges=[];byId={};
    const core={id:'core',kind:'core',label:'A.R.I',x:0,y:0,z:0,r:15,col:palette[0]};
    nodes.push(core);
    const n=cats.length;
    cats.forEach((c,i)=>{
      const k=(i+0.5)/n,phi=Math.acos(1-2*k),th=Math.PI*(1+Math.sqrt(5))*i;
      const R=270;
      const hub={id:'hub:'+c,kind:'hub',label:c.toUpperCase(),cat:c,r:9,
        x:R*Math.sin(phi)*Math.cos(th),y:R*Math.cos(phi),z:R*Math.sin(phi)*Math.sin(th),
        col:palette[(i%2===0)?0:1]};
      nodes.push(hub);edges.push({a:core,b:hub,w:1});
    });
    const hubOf=c=>nodes.find(x=>x.id==='hub:'+c)||nodes[1];
    const wordSets=new Map();
    memories.forEach((m)=>{
      const hub=hubOf(m.cat);
      const a=Math.random()*Math.PI*2,b=Math.acos(2*Math.random()-1),d=70+Math.random()*90;
      const node={id:m.id,kind:'mem',label:m.text,m,cat:m.cat,hub,
        r:4.6+Math.min(3,(m.uses||0)*0.6),col:hub.col,
        x:hub.x+d*Math.sin(b)*Math.cos(a),y:hub.y+d*Math.cos(b),z:hub.z+d*Math.sin(b)*Math.sin(a)};
      if(posCache[m.id]&&posCache[m.id].cat===m.cat){Object.assign(node,{x:posCache[m.id].x,y:posCache[m.id].y,z:posCache[m.id].z,fixed:true});}
      nodes.push(node);byId[m.id]=node;
      edges.push({a:hub,b:node,w:0.6});
      wordSets.set(node,words(m.text));
    });
    const hubs=nodes.filter(x=>x.kind==='hub');
    hubs.forEach(a=>{
      hubs.filter(b=>b!==a).sort((p,q)=>Math.hypot(p.x-a.x,p.y-a.y,p.z-a.z)-Math.hypot(q.x-a.x,q.y-a.y,q.z-a.z)).slice(0,2).forEach(b=>{
        if(!edges.some(e=>(e.a===a&&e.b===b)||(e.a===b&&e.b===a)))edges.push({a,b,w:0.5,ring:true});
      });
    });
    hubs.forEach(hub=>{
      const ring=[];
      for(let i=0;i<20;i++){
        const a=Math.random()*Math.PI*2,b=Math.acos(2*Math.random()-1),d=45+Math.random()*130;
        const dn={id:'dust'+hub.cat+i,kind:'dust',r:1.7,col:hub.col,hub,
          x:hub.x+d*Math.sin(b)*Math.cos(a),y:hub.y+d*Math.cos(b),z:hub.z+d*Math.sin(b)*Math.sin(a)};
        nodes.push(dn);ring.push(dn);
        edges.push({a:hub,b:dn,w:0.25,dust:true});
        if(i>0&&Math.random()<0.7)edges.push({a:ring[i-1],b:dn,w:0.25,dust:true});
      }
    });
    const mems=nodes.filter(x=>x.kind==='mem');
    for(let i=0;i<mems.length;i++){
      let links=0;
      for(let j=i+1;j<mems.length&&links<2;j++){
        const A=wordSets.get(mems[i]),B=wordSets.get(mems[j]);
        for(const w of A)if(B.has(w)){edges.push({a:mems[i],b:mems[j],w:0.5,cross:true});links++;break;}
      }
    }
    const movable=mems.filter(n=>!n.fixed);
    for(let it=0;it<70;it++){
      for(let i=0;i<movable.length;i++){
        const p=movable[i];
        for(let j=i+1;j<movable.length;j++){
          const q=movable[j];
          let dx=p.x-q.x,dy=p.y-q.y,dz=p.z-q.z;
          const d2=dx*dx+dy*dy+dz*dz+1;
          if(d2>10000)continue;
          const f=260/d2;
          dx*=f;dy*=f;dz*=f;
          p.x+=dx;p.y+=dy;p.z+=dz;q.x-=dx;q.y-=dy;q.z-=dz;
        }
        const hx=p.hub.x-p.x,hy=p.hub.y-p.y,hz=p.hub.z-p.z;
        const hd=Math.sqrt(hx*hx+hy*hy+hz*hz)+0.01,want=100;
        const k=(hd-want)/hd*0.06;
        p.x+=hx*k;p.y+=hy*k;p.z+=hz*k;
      }
    }
    mems.forEach(n=>{posCache[n.id]={x:n.x,y:n.y,z:n.z,cat:n.cat};});
    particles=[];
    const count=Math.min(40,edges.length);
    for(let i=0;i<count;i++)particles.push({e:edges[Math.floor(Math.random()*edges.length)],t:Math.random(),s:0.15+Math.random()*0.3});
    statsEl.innerHTML=`${memories.length} ERINNERUNGEN<br>${cats.length} BEREICHE`;
  }

  function resize(){dpr=Math.min(2,window.devicePixelRatio||1);W=stage.clientWidth;H=stage.clientHeight;canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
  function project(p){
    const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
    let x=p.x*cy-p.z*sy,z=p.x*sy+p.z*cy;
    let y=p.y*cp-z*sp;z=p.y*sp+z*cp;
    const persp=700/(700+z);
    const sc=persp*zoom*Math.min(W,H)/800;
    p.sx=W/2+x*sc;p.sy=H/2+y*sc;p.sz=z;p.sc=sc;
  }
  const stars=Array.from({length:220},()=>({x:(Math.random()-.5)*1200,y:(Math.random()-.5)*1200,z:(Math.random()-.5)*1200,a:Math.random()}));
  function glow(x,y,r,col,a){
    const g=ctx.createRadialGradient(x,y,0,x,y,r*3.2);
    g.addColorStop(0,rgba(col,a));g.addColorStop(0.35,rgba(col,a*0.35));g.addColorStop(1,rgba(col,0));
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r*3.2,0,7);ctx.fill();
  }
  function focusSet(){
    if(!selected)return null;
    const s=new Set([selected]);
    edges.forEach(e=>{if(e.a===selected)s.add(e.b);if(e.b===selected)s.add(e.a);});
    if(selected.kind==='mem')s.add(selected.hub);
    return s;
  }
  function frame(now){
    if(!running)return;
    raf=requestAnimationFrame(frame);
    const dt=Math.min(0.05,(now-t0)/1000);t0=now;
    if(!drag&&now>idleUntil)yaw+=dt*0.12;
    zoom+=(targetZoom-zoom)*Math.min(1,dt*8);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,W,H);
    ctx.globalCompositeOperation='lighter';
    stars.forEach(st=>{project(st);ctx.fillStyle=`rgba(230,236,245,${0.10+0.25*st.a*(1-st.sz/1300)})`;ctx.fillRect(st.sx,st.sy,1.2,1.2);});
    nodes.forEach(project);
    const focus=focusSet();
    edges.forEach(e=>{
      const on=!focus||(focus.has(e.a)&&focus.has(e.b));
      const depth=1-Math.max(-1,Math.min(1,(e.a.sz+e.b.sz)/900));
      const al=(on?0.10+0.32*depth:0.03)*(e.w+0.4)*(e.dust?0.7:1);
      ctx.strokeStyle=rgba(e.cross?palette[1]:e.a.col,al);
      ctx.lineWidth=(e.cross||e.dust)?0.6:(e.ring?0.8:1);
      ctx.beginPath();ctx.moveTo(e.a.sx,e.a.sy);ctx.lineTo(e.b.sx,e.b.sy);ctx.stroke();
    });
    particles.forEach(p=>{
      p.t+=dt*p.s;if(p.t>1){p.t=0;p.e=edges[Math.floor(Math.random()*edges.length)];}
      if(!p.e)return;
      const x=p.e.a.sx+(p.e.b.sx-p.e.a.sx)*p.t,y=p.e.a.sy+(p.e.b.sy-p.e.a.sy)*p.t;
      glow(x,y,1.6,palette[1],0.9);
    });
    const order=nodes.slice().sort((a,b)=>b.sz-a.sz);
    order.forEach(n=>{
      const dim=focus&&!focus.has(n)?0.25:1;
      const depth=0.55+0.45*(1-Math.max(-1,Math.min(1,n.sz/400)))/2;
      let r=n.r*n.sc*(n===hoverNode||n===selected?1.35:1);
      if(n.kind==='core')r*=1.06;
      const a=Math.min(1,depth)*dim;
      if(n.kind==='dust'){glow(n.sx,n.sy,r,n.col,0.5*a);n._r=Math.max(7,r*2.6);return;}
      glow(n.sx,n.sy,r,n.col,(n.kind==='mem'?0.75:0.95)*a);
      if(n.kind==='hub'){ctx.strokeStyle=rgba(n.col,0.5*a);ctx.lineWidth=1;ctx.beginPath();ctx.arc(n.sx,n.sy,r*1.5,0,7);ctx.stroke();}
      ctx.fillStyle=rgba('#ffffff',(n.kind==='mem'?0.7:0.9)*a);
      ctx.beginPath();ctx.arc(n.sx,n.sy,Math.max(1,r*0.42),0,7);ctx.fill();
      n._r=Math.max(8,r*1.6);
    });
    ctx.globalCompositeOperation='source-over';
    order.forEach(n=>{
      const show=(n.kind!=='dust'&&n.kind!=='mem')||n===hoverNode||n===selected||(zoom>1.7&&n.sz<60&&(!focus||focus.has(n)));
      if(!show)return;
      const dim=focus&&!focus.has(n)?0.3:1;
      ctx.font=n.kind==='mem'?'500 11px JetBrains Mono, monospace':'700 '+(n.kind==='core'?13:10)+'px Chakra Petch, sans-serif';
      let txt=n.kind==='dust'?n.hub.label:n.label;
      if(n.kind==='mem'&&txt.length>40)txt=txt.slice(0,38)+'…';
      ctx.fillStyle=rgba(n.kind==='mem'?'#e6ecf5':n.col,0.95*dim);
      ctx.textAlign='center';
      ctx.fillText(txt,n.sx,n.sy-n._r-6);
    });
  }
  function pick(mx,my){let best=null,bd=1e9;nodes.forEach(n=>{const d=Math.hypot(n.sx-mx,n.sy-my);if(d<(n._r||14)+6&&d<bd){best=n;bd=d;}});return best;}
  const pos=ev=>{const r=canvas.getBoundingClientRect();const p=(ev.touches&&ev.touches[0])||ev;return [p.clientX-r.left,p.clientY-r.top];};

  canvas.addEventListener('pointerdown',ev=>{canvas.setPointerCapture(ev.pointerId);const [x,y]=pos(ev);drag={x,y,moved:false};});
  canvas.addEventListener('pointermove',ev=>{
    const [x,y]=pos(ev);
    if(drag){
      const dx=x-drag.x,dy=y-drag.y;
      if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;
      yaw+=dx*0.007;pitch=Math.max(-1.4,Math.min(1.4,pitch+dy*0.007));
      drag.x=x;drag.y=y;idleUntil=performance.now()+3000;
    }else{hoverNode=pick(x,y);}
  });
  canvas.addEventListener('pointerup',ev=>{
    const wasClick=drag&&!drag.moved;drag=null;
    if(wasClick){const [x,y]=pos(ev);select(pick(x,y));}
    idleUntil=performance.now()+3000;
  });
  canvas.addEventListener('wheel',ev=>{ev.preventDefault();targetZoom=Math.max(0.5,Math.min(3.5,targetZoom*(ev.deltaY<0?1.12:1/1.12)));idleUntil=performance.now()+3000;},{passive:false});

  function select(n){
    if(n&&n.kind==='dust')n=n.hub;
    selected=n;
    if(!n||n.kind==='core'){selected=null;info.classList.remove('show');return;}
    info.classList.add('show');
    document.getElementById('biCat').textContent=(n.kind==='hub'?'BEREICH · ':'')+(n.cat||'').toUpperCase();
    if(n.kind==='hub'){
      const list=memories.filter(m=>m.cat===n.cat);
      const bt=document.getElementById('biText');
      bt.innerHTML=list.length?list.map(m=>`<div class="bi-item" data-id="${m.id}">• ${escHtml(m.text)}</div>`).join(''):'Noch nichts gespeichert.';
      bt.querySelectorAll('.bi-item').forEach(el=>el.addEventListener('click',()=>{if(byId[el.dataset.id])select(byId[el.dataset.id]);}));
      document.getElementById('biMeta').textContent='';
      document.getElementById('biDelete').style.display='none';
    }else{
      document.getElementById('biText').textContent=n.m.text;
      document.getElementById('biText').style.cssText='';
      document.getElementById('biMeta').textContent='GESPEICHERT';
      document.getElementById('biDelete').style.display='';
    }
  }

  function load(){
    const byC={};brain.forEach(n=>{byC[n.cat]=(byC[n.cat]||0)+1;});
    cats=Object.keys(byC).sort();
    if(!cats.length)cats=['Wissen'];
    memories=brain.map(n=>({id:n.id,cat:n.cat,text:n.text,uses:0}));
    selected=null;info.classList.remove('show');build();
  }
  function open(){
    overlay.classList.add('open');readPalette();resize();running=true;t0=performance.now();idleUntil=0;
    load();cancelAnimationFrame(raf);raf=requestAnimationFrame(frame);
  }
  function close(){overlay.classList.remove('open');running=false;cancelAnimationFrame(raf);}
  document.getElementById('brain3dBtn').addEventListener('click',open);
  document.getElementById('brainClose').addEventListener('click',close);
  overlay.addEventListener('mousedown',ev=>{if(ev.target===overlay)close();});
  window.addEventListener('resize',()=>{if(running)resize();});
  document.getElementById('biDelete').addEventListener('click',()=>{
    if(!selected||selected.kind!=='mem')return;
    brain=brain.filter(m=>m!==selected.m);saveBrain();sync.deleted=(sync.deleted||[]).concat(selected.m.text);saveSync();syncSoon();renderBrain();
    load();
  });
})();

/* ---------- PC ---------- */
function renderPcs(){
  const box=$('#pcSaved');box.textContent='';
  pcs.forEach((p,i)=>{const r=document.createElement('div');r.className='row';r.style.marginTop='8px';
    const nm=document.createElement('div');nm.className='btn';nm.style.flex='1';nm.style.pointerEvents='none';nm.textContent='▣ '+p.name;
    const del=document.createElement('button');del.className='btn dng';del.style.flex='0 0 52px';del.textContent='✕';del.onclick=()=>{pcs.splice(i,1);store.set('ari-app-pcs',pcs);renderPcs();};
    r.append(nm,del);box.appendChild(r);});
}
// PC im WLAN suchen (nur nativ), zwei Wege gleichzeitig, weil UDP-Broadcast nicht jeder Router/Mesh
// weiterleitet: 1) schneller UDP-Broadcast, den der Hub direkt beantwortet, 2) Subnetz-Scan per HTTP
// (eigene WLAN-IP -> alle 254 Adressen im gleichen /24 auf Port 5000 pruefen). Ergebnisse werden
// zusammengefuehrt; findet es mehrere A.R.I, wird einfach das erste genommen statt zu blockieren -
// wer's genauer braucht, traegt die Adresse von Hand ein.
async function discoverPcUdp(){
  if(!NATIVE||!window.Capacitor||!Capacitor.Plugins||!Capacitor.Plugins.AriWake)return[];
  try{const r=await Capacitor.Plugins.AriWake.discoverPc();return(r&&r.ips)||[];}catch(e){return[];}
}
async function subnetScan(){
  if(!NATIVE||!window.Capacitor||!Capacitor.Plugins||!Capacitor.Plugins.AriWake)return[];
  let ip;try{const r=await Capacitor.Plugins.AriWake.wifiInfo();ip=r&&r.ip;}catch(e){return[];}
  if(!ip||!/^\d+\.\d+\.\d+\.\d+$/.test(ip))return[];
  const parts=ip.split('.'),prefix=parts[0]+'.'+parts[1]+'.'+parts[2]+'.',own=+parts[3];
  const found=[],hosts=[];for(let i=1;i<=254;i++)if(i!==own)hosts.push(i);
  const chunk=40;
  for(let i=0;i<hosts.length;i+=chunk){
    await Promise.all(hosts.slice(i,i+chunk).map(async n=>{
      const host=prefix+n;
      try{
        const ctrl=new AbortController();const t=setTimeout(()=>ctrl.abort(),400);
        const r=await fetch('http://'+host+':5000/phone/manifest.json',{signal:ctrl.signal});
        clearTimeout(t);
        if(r.ok){const d=await r.json();if(d&&d.name==='A.R.I')found.push(host);}
      }catch(e){}
    }));
  }
  return found;
}
async function discoverPc(){
  const[udp,scan]=await Promise.all([discoverPcUdp(),subnetScan()]);
  return[...new Set([...udp,...scan])];
}
// Nur der Koppelcode ist noetig - die Adresse sucht die App sich selbst per UDP/Subnetz-Scan im WLAN.
$('#pcPair').onclick=async()=>{
  let c=$('#pcCode').value.replace(/[\s-]/g,'');
  const msg=$('#pcMsg');
  if(!c){msg.textContent='Bitte den Koppelcode eintragen.';return;}
  msg.textContent='Suche PC im WLAN …';
  const ips=await discoverPc();
  if(!ips.length){msg.textContent='Kein PC im WLAN gefunden. Sind Handy und PC im selben WLAN?';return;}
  const a='http://'+ips[0]+':5000';
  msg.textContent='Koppeln …';$('#pcCode').value='';
  pairFromLink(a,c);
};
// "PC-Simulation": 1:1 dieselbe Optik wie am PC (Planet, Astro, System-Status, Medien, Tasks),
// aber optimiert - keine schwere Live-Seite/iframe mehr, stattdessen nur zwei winzige JSON-Abfragen
// (/status, /media, dieselben, die der echte PC-HUD auch benutzt) statt der ganzen Seite.
function fmtTime(sec){sec=Math.max(0,Math.round(sec));return Math.floor(sec/60)+':'+String(sec%60).padStart(2,'0');}
const pcSimEaseOut=t=>1-Math.pow(1-t,3);
function pcSimTweenPercent(el,to,suffix){
  if(!el)return;
  suffix=suffix||'';
  const from=parseFloat(el.dataset.v);
  el.dataset.v=to;
  if(isNaN(from)||Math.round(from)===Math.round(to)){el.textContent=Math.round(to)+suffix;return;}
  if(el._raf)cancelAnimationFrame(el._raf);
  const t0=performance.now(),dur=600;
  const step=now=>{
    const t=Math.min(1,(now-t0)/dur);
    el.textContent=Math.round(from+(to-from)*pcSimEaseOut(t))+suffix;
    el._raf=t<1?requestAnimationFrame(step):0;
  };
  el._raf=requestAnimationFrame(step);
}
const pcSimHist={mem:[],net:[]};
function pcSimSpark(el,data,color){
  if(!el)return;
  const w=120,h=26,max=Math.max(1,...data);
  const pts=data.map((v,i)=>[data.length>1?i/(data.length-1)*w:w,h-(v/max)*h*0.86-2]);
  const d=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
  el.innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" style="overflow:visible"><path d="${d}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 3px ${color})"/></svg>`;
}
const PCSIM_CAL_PAL=['#e8c468','#3fa9ff','#b58cff','#5ec8b8','#ff2d78','#39ff9e'];
function pcSimColor(seed){let h=0;for(const c of String(seed))h=(h*31+c.charCodeAt(0))>>>0;return PCSIM_CAL_PAL[h%PCSIM_CAL_PAL.length];}
function pcSimRenderCal(){
  const list=$('#pcSimCalList');if(!list)return;
  const ev=((calCache&&calCache.events)||[]).slice(0,6);
  $('#pcSimCalTag').textContent=ev.length?ev.length+' TERMINE':'KEINE';
  const sig=JSON.stringify(ev.map(e=>[e.title,e.start]));if(list.dataset.sig===sig)return;list.dataset.sig=sig;   // unveraendert: nicht neu zeichnen (kein Flackern)
  if(!ev.length){list.innerHTML='<li class="pcsim-empty">Keine anstehenden Termine.</li>';return;}
  list.innerHTML=ev.map(e=>{
    const start=new Date(e.start),color=pcSimColor(e.title||'?');
    const day=String(start.getDate()).padStart(2,'0'),mon=start.toLocaleDateString('de-DE',{month:'short'}).replace('.','').toUpperCase();
    const when=e.allDay?'Ganztägig':start.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
    return `<li class="pcsim-row"><span class="badge" style="--rc:${color}">${day}<br>${mon}</span><span class="body"><span class="t1">${escHtml(e.title||'')}</span><span class="t2">${escHtml(when)}</span></span></li>`;
  }).join('');
}
async function pcSimPoll(){
  if(cfg.pcSimOn!=='1'||!sync.token||!sync.origin||document.hidden)return;
  try{
    const [rs,rm,rn]=await Promise.all([
      fetch(sync.origin+'/status',{headers:{'X-Ari-Token':sync.token}}),
      fetch(sync.origin+'/media',{headers:{'X-Ari-Token':sync.token}}),
      fetch(sync.origin+'/phone/notifications?since=0',{headers:{'X-Ari-Token':sync.token}}),
    ]);
    if(rs.ok){
      const s=await rs.json();
      $('#pcSimGaugeCpu').style.setProperty('--pct',s.cpu_percent||0);
      $('#pcSimGaugeCpuGlow').style.setProperty('--pct',s.cpu_percent||0);
      $('#pcSimGaugeCpuTip').style.setProperty('--pct',s.cpu_percent||0);
      pcSimTweenPercent($('#pcSimCpuVal'),s.cpu_percent||0);
      $('#pcSimCpuSub').textContent=(s.cpu_freq_ghz||0)+' GHz'+(s.cpu_temp_c!=null?' · '+Math.round(s.cpu_temp_c)+'°C':'');
      $('#pcSimGaugeRam').style.setProperty('--pct',s.ram_percent||0);
      $('#pcSimGaugeRamGlow').style.setProperty('--pct',s.ram_percent||0);
      $('#pcSimGaugeRamTip').style.setProperty('--pct',s.ram_percent||0);
      pcSimTweenPercent($('#pcSimRamVal'),s.ram_percent||0);
      $('#pcSimRamSub').textContent=(s.ram_used_gb||0)+'/'+(s.ram_total_gb||0)+' GB';
      $('#pcSimStatNet').textContent='↓'+(s.net_down_mbps||0)+' ↑'+(s.net_up_mbps||0);
      $('#pcSimStatUptime').textContent=s.uptime_str||'--';
      $('#pcSimStatSystem').textContent=(s.system_status||'--').toUpperCase();
      if(s.gpu_temp_c!=null){
        $('#pcSimStatGpuTempCell').style.display='';
        $('#pcSimStatGpuTemp').textContent=Math.round(s.gpu_temp_c)+'°C';
        $('.statcells').classList.add('has-gpu');
      }
      const procs=s.processes||[];
      $('#pcSimTaskCount').textContent=procs.length+' PROZESSE';
      $('#pcSimTaskList').innerHTML=procs.map(p=>`<div class="task-row"><span class="task-name">${p.name}</span><span>${Math.round(p.cpu_percent||0)}%</span><span></span><span>${Math.round(p.ram_mb||0)}MB</span></div>`).join('');
      pcSimTweenPercent($('#pcSimMemVal'),s.ram_percent||0,'%');
      $('#pcSimNetVal').textContent='↓'+(s.net_down_mbps||0);
      pcSimHist.mem.push(s.ram_percent||0);pcSimHist.net.push(s.net_down_mbps||0);
      if(pcSimHist.mem.length>24)pcSimHist.mem.shift();
      if(pcSimHist.net.length>24)pcSimHist.net.shift();
      pcSimSpark($('#pcSimMemSpark'),pcSimHist.mem,'#7ff0ff');
      pcSimSpark($('#pcSimNetSpark'),pcSimHist.net,'#ff6aa8');
    }
    if(rm.ok){
      const m=await rm.json();
      const t=m.track;
      if(t&&(t.name||t.is_playing)){
        $('#pcSimMediaTitle').textContent=t.name||'–';
        $('#pcSimMediaArtist').textContent=t.artists||'';
        if(t.image){$('#pcSimMediaCover').src=t.image;$('#pcSimMediaCover').style.display='';$('#pcSimMediaCoverPh').style.display='none';}
        const pct=t.duration_ms?Math.min(100,(t.progress_ms||0)/t.duration_ms*100):0;
        $('#pcSimMediaFill').style.width=pct+'%';
        const mbar=$('#pcSimMediaBar'),mknob=$('#pcSimMediaKnob');
        if(mbar&&mknob)mknob.style.transform='translate3d('+(pct/100*mbar.offsetWidth).toFixed(2)+'px,0,0)';
        $('#pcSimMediaPos').textContent=fmtTime((t.progress_ms||0)/1000);
        $('#pcSimMediaDur').textContent=fmtTime((t.duration_ms||0)/1000);
      } else {
        $('#pcSimMediaTitle').textContent='Nichts aktiv';$('#pcSimMediaArtist').textContent='–';
      }
    }
    if(rn.ok){
      const n=await rn.json();
      const items=(n.items||[]).slice(-8).reverse();
      const tag=$('#pcSimNotifTag'),list=$('#pcSimNotifList');
      if(tag)tag.textContent=items.length?items.length+' NEU':'KEINE';
      const sig=items.map(it=>it.id).join(',');
      const sig2=sig+'|'+items.map(it=>(it.has_pic?'p':'')+(it.has_icon?'i':'')+(it.has_vid?'v':'')).join('');
      if(list&&list.dataset.sig!==sig2){list.dataset.sig=sig2;list.innerHTML=items.length?items.map(it=>{
        const color=pcSimColor(it.app||'?'),initial=(String(it.app||'?').charAt(0)||'?').toUpperCase();
        return `<li class="pcsim-row ncard" data-nid="${escHtml(it.id)}"><span class="badge" style="--rc:${color}">${it.has_icon?`<img data-nimg="/phone/notif-icon?app=${encodeURIComponent(it.app||'')}" alt="">`:escHtml(initial)}</span><span class="body"><span class="t1">${escHtml(it.title||it.app||'')}</span><span class="t2">${escHtml(it.text||'')}</span>${it.has_vid&&!it.has_pic?`<span class="npic" data-nvid="${escHtml(it.id)}"><b>▶ Video</b></span>`:''}${it.has_pic?`<span class="npic" data-npic="${escHtml(it.id)}"${it.has_vid?` data-nvid="${escHtml(it.id)}"`:''}><img data-nimg="/phone/notif-pic?id=${encodeURIComponent(it.id)}" alt="">${it.video?'<b>▶</b>':''}</span>`:''}</span><button type="button" class="ndel" data-ndel="${escHtml(it.id)}" aria-label="Entfernen">✕</button></li>`;
      }).join(''):'<li class="pcsim-empty">Keine Benachrichtigungen.</li>';
        list.querySelectorAll('img[data-nimg]').forEach(im=>{authImg(im.dataset.nimg).then(u=>{if(u)im.src=u;else if(im.parentNode.classList.contains('badge'))im.parentNode.textContent=initialOf(im.parentNode);});});}   // nur neu zeichnen, wenn sich die Liste geaendert hat (sonst flackert sie bei jedem Abruf)
    }
    pcSimRenderCal();
  }catch(e){}
}
let pcSimTimer=null;
function pcSimSetNavHeight(){
  const navEl=document.querySelector('nav');
  if(navEl)document.documentElement.style.setProperty('--nav-h',navEl.offsetHeight+'px');
}
/* Bildschirm anlassen, solange die PC-Version laeuft: erst die Web-Funktion (Wake Lock), sonst das Android-Fenster-Flag */
let wakeLockObj=null,wantAwake=false;
async function keepAwake(on){
  wantAwake=!!on;
  try{const W=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;if(W&&W.keepScreenOn)await W.keepScreenOn({on:!!on});}catch(e){}
  try{
    if(on){if('wakeLock' in navigator&&!wakeLockObj&&!document.hidden){wakeLockObj=await navigator.wakeLock.request('screen');wakeLockObj.addEventListener('release',()=>{wakeLockObj=null;});}}
    else if(wakeLockObj){await wakeLockObj.release();wakeLockObj=null;}
  }catch(e){}
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&wantAwake)keepAwake(true);});   // der Wake Lock geht beim Wegwechseln verloren -> zurueck in der App neu holen
function pcSimBtnPaint(){const b=$('#pcSimBtn');if(!b)return;const on=cfg.pcSimOn==='1';b.textContent=on?'■ PC-VERSION BEENDEN':'▣ PC-VERSION STARTEN';b.classList.toggle('pri',!on);}
function pcSimSetActive(on){
  document.body.classList.toggle('pc-sim-active',!!on);
  keepAwake(!!on);pcSimBtnPaint();
  if(!on)pcSimSetFullscreen(false);
  clearInterval(pcSimTimer);pcSimTimer=null;
  if(on){pcSimPoll();pcSimTimer=setInterval(pcSimPoll,4000);}
}
let pcSimFsPlaceholder=null;
function pcSimSetFullscreen(on){
  const box=$('#pcSimBox');if(!box)return;
  const btn=$('#pcSimFsBtn');
  const isFs=box.classList.contains('pc-sim-fullscreen');
  if(on&&!isFs){
    pcSimFsPlaceholder=document.createComment('pc-sim-box');
    box.parentNode.insertBefore(pcSimFsPlaceholder,box);
    document.body.appendChild(box);
    box.classList.add('pc-sim-fullscreen');
    pcSimSetNavHeight();
    if(btn){btn.textContent='⤡';btn.title='Vollbild verlassen';}
  }else if(!on&&isFs){
    box.classList.remove('pc-sim-fullscreen');
    if(pcSimFsPlaceholder&&pcSimFsPlaceholder.parentNode){pcSimFsPlaceholder.parentNode.insertBefore(box,pcSimFsPlaceholder);pcSimFsPlaceholder.remove();}
    pcSimFsPlaceholder=null;
    if(btn){btn.textContent='⛶';btn.title='Vollbild';}
  }
}
$('#pcSimBtn').addEventListener('click',()=>{
  cfg.pcSimOn=cfg.pcSimOn==='1'?'0':'1';saveCfg();
  pcSimSetActive(cfg.pcSimOn==='1');
  if(cfg.pcSimOn==='1')goTab('pc');   // gleich die PC-Ansicht zeigen
});
$('#pcSimFsBtn').addEventListener('click',()=>pcSimSetFullscreen(!$('#pcSimBox').classList.contains('pc-sim-fullscreen')));
$$('nav button').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.t!=='pc')pcSimSetFullscreen(false);}));

/* Panels der PC-Simulation anordnen: Reihenfolge per Pfeiltasten, Groesse per
   Zyklus-Knopf (normal -> kompakt -> gross) - reicht auf dem Handy (Einspaltig)
   fuer "anpassbar", ein freies 2D-Drag/Resize wie am grossen PC-Bildschirm
   passt nicht auf einen einspaltigen Scrollbereich. */
const PCSIM_LAYOUT_KEY='ari-app-pcsim-layout';
function pcSimLoadLayout(){try{return store.get(PCSIM_LAYOUT_KEY,{order:[],sizes:{}});}catch(e){return{order:[],sizes:{}};}}
function pcSimSaveLayout(l){try{store.set(PCSIM_LAYOUT_KEY,l);}catch(e){}}
function pcSimApplyLayout(){
  const wrap=$('#pcSimPanels');if(!wrap)return;
  const l=pcSimLoadLayout();
  const panels=Array.from(wrap.querySelectorAll('.panel[data-pid]'));
  if(l.order&&l.order.length){
    l.order.forEach(pid=>{const el=panels.find(p=>p.dataset.pid===pid);if(el)wrap.appendChild(el);});
  }
  panels.forEach(p=>{const sz=(l.sizes||{})[p.dataset.pid];if(sz&&sz!=='normal')p.dataset.size=sz;else delete p.dataset.size;});
}
function pcSimSaveCurrentOrder(){
  const wrap=$('#pcSimPanels');if(!wrap)return;
  const l=pcSimLoadLayout();
  l.order=Array.from(wrap.querySelectorAll('.panel[data-pid]')).map(p=>p.dataset.pid);
  pcSimSaveLayout(l);
}
const pcSimPanelsEl=$('#pcSimPanels');
if(pcSimPanelsEl)pcSimPanelsEl.addEventListener('click',e=>{
  const btn=e.target.closest('[data-act]');if(!btn)return;
  const panel=btn.closest('.panel[data-pid]');if(!panel)return;
  const act=btn.dataset.act;
  if(act==='up'){const prev=panel.previousElementSibling;if(prev)panel.parentNode.insertBefore(panel,prev);pcSimSaveCurrentOrder();}
  else if(act==='down'){const next=panel.nextElementSibling;if(next)panel.parentNode.insertBefore(next,panel);pcSimSaveCurrentOrder();}
  else if(act==='size'){
    const order=['normal','compact','large'];
    const cur=panel.dataset.size||'normal';
    const nextSize=order[(order.indexOf(cur)+1)%order.length];
    if(nextSize==='normal')delete panel.dataset.size;else panel.dataset.size=nextSize;
    const l=pcSimLoadLayout();l.sizes=l.sizes||{};l.sizes[panel.dataset.pid]=nextSize;pcSimSaveLayout(l);
  }
});
$('#pcSimEditBtn').addEventListener('click',()=>{
  const box=$('#pcSimBox');const on=!box.classList.contains('pcsim-edit');
  box.classList.toggle('pcsim-edit',on);
  $('#pcSimEditBtn').classList.toggle('on',on);
});
pcSimApplyLayout();
window.addEventListener('resize',()=>{if(cfg.pcSimOn==='1')pcSimSetNavHeight();});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&cfg.pcSimOn==='1')pcSimPoll();});

/* ---------- Termine / Benachrichtigungen (kommen vom verbundenen PC, gleiche Karten wie im Hub) ---------- */
/*GOOGLE-BEGIN*/
// Google direkt vom Handy (ohne PC): Anmeldung mit PKCE ueber den System-Browser, Kalender- und Gmail-API selbst abrufen.
const G_REDIRECT='com.ari.assistant:/oauth2redirect';
const gMailOn=()=>(cfg.gMail||'1')!=='0';
const gScopes=()=>'https://www.googleapis.com/auth/calendar.readonly'+(gMailOn()?' https://www.googleapis.com/auth/gmail.readonly':'');
let gTok=store.get('ari-app-gtok',null);
const gOn=()=>!!(cfg.gClientId&&gTok&&gTok.refresh);
const b64u=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const gForm=o=>Object.keys(o).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(o[k])).join('&');
async function gStart(){
  if(!cfg.gClientId){$('#gStatus').textContent='Bitte zuerst die Client-ID eintragen.';return;}
  const ver=b64u(crypto.getRandomValues(new Uint8Array(48))),st=b64u(crypto.getRandomValues(new Uint8Array(16)));
  const ch=b64u(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(ver)));
  store.set('ari-app-gpkce',{ver,st,t:Date.now()});
  const url='https://accounts.google.com/o/oauth2/v2/auth?'+gForm({client_id:cfg.gClientId,redirect_uri:G_REDIRECT,response_type:'code',scope:gScopes(),code_challenge:ch,code_challenge_method:'S256',state:st,access_type:'offline',prompt:'consent'});
  $('#gStatus').textContent='Google-Anmeldung wird im Browser geöffnet …';
  const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
}
async function gTokenReq(body){
  const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:gForm(body)});
  const d=await r.json();if(!r.ok||d.error)throw new Error(d.error_description||d.error||('HTTP '+r.status));return d;
}
async function gHandleRedirect(u){
  try{
    const x=new URL(String(u).replace(/^com\.ari\.assistant:[/]?/,'https://ari.invalid/'));
    const code=x.searchParams.get('code'),st=x.searchParams.get('state'),err=x.searchParams.get('error');
    const p=store.get('ari-app-gpkce',null);store.set('ari-app-gpkce',null);
    if(err){$('#gStatus').textContent='Anmeldung abgebrochen ('+err+').';return;}
    if(!code||!p||p.st!==st){$('#gStatus').textContent='Anmeldung ungültig – bitte nochmal versuchen.';return;}
    const d=await gTokenReq({client_id:cfg.gClientId,code,code_verifier:p.ver,redirect_uri:G_REDIRECT,grant_type:'authorization_code'});
    gTok={access:d.access_token,refresh:d.refresh_token||(gTok&&gTok.refresh)||'',exp:Date.now()+(d.expires_in||3600)*1000};store.set('ari-app-gtok',gTok);
    loadSet();goTab('cal');
  }catch(e){$('#gStatus').textContent='Anmeldung fehlgeschlagen: '+String(e.message).slice(0,120);}
}
async function gAccess(){
  if(!gTok||!gTok.refresh)return null;
  if(gTok.access&&gTok.exp>Date.now()+60000)return gTok.access;
  let d;try{d=await gTokenReq({client_id:cfg.gClientId,refresh_token:gTok.refresh,grant_type:'refresh_token'});}
  catch(e){if(/invalid_grant|expired|revoked/i.test(String(e.message))){gTok=null;store.set('ari-app-gtok',null);try{loadSet();}catch(x){}throw new Error('Google-Anmeldung abgelaufen – bitte in den Einstellungen neu anmelden');}throw e;}
  gTok.access=d.access_token;gTok.exp=Date.now()+(d.expires_in||3600)*1000;store.set('ari-app-gtok',gTok);return gTok.access;
}
async function gApi(url,retry){
  const t=await gAccess();if(!t)throw new Error('nicht angemeldet');
  const r=await fetch(url,{headers:{Authorization:'Bearer '+t}});
  if(r.status===401&&!retry){gTok.exp=0;return gApi(url,true);}
  if(!r.ok)throw new Error('Google '+r.status);return r.json();
}
const gDate=(o)=>{if(!o)return null;if(o.date){const m=/^(\d{4})-(\d\d)-(\d\d)/.exec(o.date);return new Date(+m[1],+m[2]-1,+m[3]);}return new Date(o.dateTime);};
async function gLoadEvents(){
  const now=new Date(),from=new Date(now);from.setHours(0,0,0,0);const to=new Date(from.getTime()+90*86400000);
  const cals=['primary'];
  try{const cl=await gApi('https://www.googleapis.com/calendar/v3/users/me/calendarList?minAccessRole=owner&maxResults=8');
    (cl.items||[]).forEach(c=>{if(c.selected!==false&&!c.primary&&!/holiday|feiertag/i.test(c.id)&&cals.length<5)cals.push(c.id);});}catch(e){}
  const all=[];
  await Promise.all(cals.map(async id=>{
    try{const d=await gApi('https://www.googleapis.com/calendar/v3/calendars/'+encodeURIComponent(id)+'/events?'+gForm({timeMin:from.toISOString(),timeMax:to.toISOString(),singleEvents:'true',orderBy:'startTime',maxResults:'40'}));
      (d.items||[]).forEach(e=>{if(e.status==='cancelled')return;const s0=gDate(e.start),e0=gDate(e.end);if(!s0)return;
        all.push({title:e.summary||'(ohne Titel)',start:s0.toISOString(),end:e0?e0.toISOString():'',allDay:!!(e.start&&e.start.date),location:e.location||''});});
    }catch(e){if(id==='primary')throw e;}
  }));
  const seen=new Set();const uniq=all.filter(e=>{const k=e.title+'|'+e.start;if(seen.has(k))return false;seen.add(k);return true;});
  uniq.sort((a,b)=>new Date(a.start)-new Date(b.start));return uniq.slice(0,40);
}
const spamList=()=>store.get('ari-app-spam',[]);
async function gLoadMails(){
  const l=await gApi('https://gmail.googleapis.com/gmail/v1/users/me/messages?'+gForm({q:'category:primary is:unread',labelIds:'INBOX',maxResults:'15'}));
  const spam=spamList().map(x=>x.toLowerCase());
  const out=await Promise.all((l.messages||[]).map(async m=>{
    try{const d=await gApi('https://gmail.googleapis.com/gmail/v1/users/me/messages/'+m.id+'?format=metadata&metadataHeaders=From&metadataHeaders=Subject');
      const H={};((d.payload&&d.payload.headers)||[]).forEach(x=>H[x.name.toLowerCase()]=x.value);
      const raw=H.from||'?',name=(/^\s*"?([^"<]+?)"?\s*</.exec(raw)||[])[1]||raw.replace(/[<>]/g,'');
      return {id:m.id,from:name.trim(),addr:raw,subject:H.subject||'',src:'g'};}catch(e){return null;}
  }));
  return out.filter(x=>x&&!spam.some(s=>x.addr.toLowerCase().includes(s)||s.includes(x.from.toLowerCase()))).slice(0,10);
}
window.__ariG={gStart,gHandleRedirect};
/*GOOGLE-END*/
/*ICS-BEGIN*/
// Google-Kalender direkt (ohne PC): "Geheime Adresse im iCal-Format" einlesen und Serientermine der naechsten 90 Tage ausrechnen
function parseIcs(txt){
  txt=String(txt).replace(/\r?\n[ \t]/g,'');
  const parseDt=(k,v)=>{
    if(/VALUE=DATE(?!-)/.test(k)||/^\d{8}$/.test(v)){const m=/^(\d{4})(\d\d)(\d\d)/.exec(v);return {d:new Date(+m[1],+m[2]-1,+m[3]),allDay:true};}
    const m=/^(\d{4})(\d\d)(\d\d)T(\d\d)(\d\d)(\d\d)?(Z?)/.exec(v);if(!m)return null;
    const d=m[7]?new Date(Date.UTC(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+(m[6]||0))):new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+(m[6]||0));
    return {d,allDay:false};
  };
  const raw=[];
  txt.split('BEGIN:VEVENT').slice(1).forEach(b=>{
    b=b.split('END:VEVENT')[0];const o={ex:[]};
    b.split(/\r?\n/).forEach(l=>{
      const i=l.indexOf(':');if(i<0)return;const k=l.slice(0,i),v=l.slice(i+1),n=k.split(';')[0].toUpperCase();
      if(n==='SUMMARY')o.title=v.replace(/\\n/g,' ').replace(/\\([,;\\])/g,'$1');
      else if(n==='LOCATION')o.location=v.replace(/\\n/g,', ').replace(/\\([,;\\])/g,'$1');
      else if(n==='UID')o.uid=v;
      else if(n==='STATUS')o.status=v;
      else if(n==='DTSTART'){const p=parseDt(k,v);if(p){o.start=p.d;o.allDay=p.allDay;}}
      else if(n==='DTEND'){const p=parseDt(k,v);if(p)o.end=p.d;}
      else if(n==='RRULE')o.rrule=v;
      else if(n==='EXDATE'){v.split(',').forEach(x=>{const p=parseDt(k,x);if(p)o.ex.push(p.d.getTime());});}
      else if(n==='RECURRENCE-ID'){const p=parseDt(k,v);if(p)o.recId=p.d.getTime();}
    });
    if(o.start&&o.status!=='CANCELLED')raw.push(o);
  });
  const now=new Date(),from=new Date(now);from.setHours(0,0,0,0);const to=new Date(from.getTime()+90*86400000);
  const overrides=new Set(raw.filter(e=>e.recId!=null).map(e=>e.uid+'|'+e.recId));
  const out=[];
  const push=(e,st)=>{const dur=e.end?e.end-e.start:(e.allDay?86400000:0),en=new Date(st.getTime()+dur);if(en>=from&&st<=to)out.push({title:e.title||'(ohne Titel)',start:st.toISOString(),end:en.toISOString(),allDay:!!e.allDay,location:e.location||''});};
  raw.forEach(e=>{
    if(e.recId!=null||!e.rrule){push(e,e.start);return;}
    const R={};e.rrule.split(';').forEach(p=>{const q=p.split('=');R[q[0]]=q[1];});
    const iv=Math.max(1,+R.INTERVAL||1),cnt=R.COUNT?+R.COUNT:1e9;let until=null;
    if(R.UNTIL){const p=parseDt('',R.UNTIL.length===8?R.UNTIL:R.UNTIL);if(p)until=p.d.getTime()+(p.allDay?86400000-1:0);}
    const days={SU:0,MO:1,TU:2,WE:3,TH:4,FR:5,SA:6};
    const cand=[];const s0=e.start;
    if(R.FREQ==='DAILY'){for(let i=0;i<800;i++){const d=new Date(s0);d.setDate(d.getDate()+i*iv);cand.push(d);if(d>to)break;}}
    else if(R.FREQ==='WEEKLY'){
      const wd=(R.BYDAY?R.BYDAY.split(',').map(x=>days[x.slice(-2)]):[s0.getDay()]).filter(x=>x!=null).sort((a,b)=>a-b);
      const wk0=new Date(s0);wk0.setDate(wk0.getDate()-wk0.getDay());
      for(let w=0;w<300;w++){let past=false;wd.forEach(x=>{const d=new Date(wk0);d.setDate(d.getDate()+w*7*iv+x);d.setHours(s0.getHours(),s0.getMinutes(),s0.getSeconds());if(d>=s0)cand.push(d);if(d>to)past=true;});if(past)break;}
    }
    else if(R.FREQ==='MONTHLY'){for(let i=0;i<120;i++){const d=new Date(s0);d.setDate(1);d.setMonth(d.getMonth()+i*iv);d.setDate(R.BYMONTHDAY?+R.BYMONTHDAY:s0.getDate());cand.push(d);if(d>to)break;}}
    else if(R.FREQ==='YEARLY'){for(let i=0;i<20;i++){const d=new Date(s0);d.setFullYear(d.getFullYear()+i*iv);cand.push(d);if(d>to)break;}}
    else cand.push(s0);
    let n=0;
    for(const d of cand){
      if(n>=cnt)break;n++;
      if(until!=null&&d.getTime()>until)break;
      if(e.ex.includes(d.getTime())||overrides.has(e.uid+'|'+d.getTime()))continue;
      push(e,d);
    }
  });
  out.sort((a,b)=>new Date(a.start)-new Date(b.start));
  return out.slice(0,40);
}
/*ICS-END*/
let calCache=store.get('ari-app-caldata',null);
function calAgo(t){const m=Math.round((Date.now()-t)/60000);return m<1?'gerade eben':m<60?'vor '+m+' Min.':m<1440?'vor '+Math.round(m/60)+' Std.':'vor '+Math.round(m/1440)+' Tg.';}
async function loadCalData(){
  const calList=$('#calList'),mailList=$('#mailList');
  const paired=!!(sync.token&&sync.origin),hasIcs=!!(cfg.icsUrl),direct=gOn();
  if(calCache&&(calCache.events||calCache.mails)){renderCalEvents(calCache);renderCalMails(calCache);}   // sofort zeigen, was zuletzt geladen wurde
  if(!paired&&!hasIcs&&!direct&&!(calCache&&calCache.at)){
    calList.innerHTML='<li class="termin-empty">Melde dich in den Einstellungen bei Google an – dann laufen Termine und Mails ganz ohne PC. Oder verbinde dich im Tab „PC".</li>';
    mailList.innerHTML='<li class="termin-empty">Noch nicht bei Google angemeldet.</li>';$('#calTag').textContent='–';$('#mailTag').textContent='–';return;
  }
  $('#calTag').textContent='LÄDT …';if(paired)$('#mailTag').textContent='LÄDT …';
  const fresh={events:calCache&&calCache.events||[],mails:calCache&&calCache.mails||[],at:calCache&&calCache.at||0};
  let calOk=false,mailOk=false,authErr=false;
  let gErr='';
  if(direct){
    try{fresh.events=await gLoadEvents();calOk=true;}catch(e){gErr=String(e.message);}
    if(gMailOn()){try{fresh.mails=await gLoadMails();mailOk=true;}catch(e){gErr=gErr||String(e.message);}}
  }
  if(!calOk&&hasIcs){
    try{const r=await fetch(cfg.icsUrl);if(!r.ok)throw new Error('http '+r.status);fresh.events=parseIcs(await r.text());calOk=true;}catch(e){}
  }
  if(paired&&!(calOk&&(mailOk||(direct&&!gMailOn())))){
    try{
      const r=await hubFetch('/phone/api/data',{headers:{'X-Ari-Token':sync.token}});
      if(r.status===401)authErr=true;
      else{const d=await r.json();if(!mailOk){fresh.mails=d.mails||[];mailOk=true;}if(!calOk){fresh.events=d.events||[];fresh.events_error=d.events_error;calOk=true;}}
    }catch(e){}
  }
  if(calOk||mailOk){fresh.at=Date.now();calCache=fresh;store.set('ari-app-caldata',{events:fresh.events,mails:fresh.mails,at:fresh.at});}
  renderCalEvents(calCache||fresh);renderCalMails(calCache||fresh);
  if(!calOk){$('#calTag').textContent=calCache&&calCache.at?'OFFLINE · '+calAgo(calCache.at).toUpperCase():'OFFLINE';if(!(calCache&&(calCache.events||[]).length))calList.innerHTML='<li class="termin-empty">'+(hasIcs?'Kalender-Adresse gerade nicht erreichbar.':'PC gerade nicht erreichbar.')+'</li>';}
  if(paired&&!mailOk){$('#mailTag').textContent=authErr?'NEU KOPPELN':(calCache&&calCache.at?'OFFLINE · '+calAgo(calCache.at).toUpperCase():'OFFLINE');}
  if(direct&&gErr&&!calOk)$('#calTag').textContent=/neu anmelden/.test(gErr)?'NEU ANMELDEN':'GOOGLE-FEHLER';
  if(!paired&&!mailOk){$('#mailTag').textContent=(calCache&&(calCache.mails||[]).length)?'STAND '+calAgo(calCache.at).toUpperCase():'–';if(!(calCache&&(calCache.mails||[]).length))mailList.innerHTML='<li class="termin-empty">'+(direct?'E-Mails konnten nicht geladen werden ('+escHtml(gErr)+').':'E-Mails kommen vom verbundenen PC.')+'</li>';}
}
const CAL_PAL=['#e8c468','#3fa9ff','#b58cff','#5ec8b8','#ff2d78','#39ff9e'];
function calColor(seed){let h=0;for(const c of String(seed))h=(h*31+c.charCodeAt(0))>>>0;return CAL_PAL[h%CAL_PAL.length];}
function renderCalEvents(d){
  const list=$('#calList');
  if(d.events_error&&!(d.events||[]).length){list.innerHTML='<li class="termin-empty">'+escHtml(d.events_error)+'</li>';$('#calTag').textContent='FEHLER';return;}
  const ev=(d.events||[]).slice(0,10);
  $('#calTag').textContent=ev.length?ev.length+' TERMINE':'KEINE TERMINE';
  if(!ev.length){list.innerHTML='<li class="termin-empty">Keine anstehenden Termine.</li>';return;}
  list.innerHTML=ev.map(e=>{
    const start=new Date(e.start),color=calColor(e.title||'?');
    const fmt=x=>x.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'});
    const when=e.allDay?fmt(start):fmt(start)+' · '+start.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
    const day=String(start.getDate()).padStart(2,'0'),mon=start.toLocaleDateString('de-DE',{month:'short'}).replace('.','').toUpperCase();
    const today0=new Date();today0.setHours(0,0,0,0);const start0=new Date(start);start0.setHours(0,0,0,0);
    const diff=Math.round((start0-today0)/86400000);
    let rel='',relCls='';
    if(diff<0){rel='läuft';relCls='today';}else if(diff===0){rel='heute';relCls='today';}else if(diff===1){rel='morgen';relCls='soon';}else if(diff<=7){rel='in '+diff+' Tagen';relCls='soon';}else rel='in '+diff+' Tagen';
    return `<li class="termin-item" style="--cal-color:${color}"><div class="t-date"><b>${day}</b><span>${escHtml(mon)}</span></div><div class="t-body"><div class="ttitle">${escHtml(e.title||'')}</div><div class="when"><span class="chip"><span class="dot"></span><span class="txt">${escHtml(when)}</span></span></div>${e.location?`<div class="tsub">📍 ${escHtml(e.location)}</div>`:''}</div><span class="t-rel ${relCls}">${escHtml(rel)}</span></li>`;
  }).join('');
}
function renderCalMails(d){
  const list=$('#mailList');
  const mails=(d.mails||[]).slice(0,8);
  $('#mailTag').textContent=mails.length?mails.length+' NEU':'KEINE';
  const msig=JSON.stringify(mails.map(m=>m.id||m.subject));if(list.dataset.sig===msig)return;list.dataset.sig=msig;
  if(!mails.length){list.innerHTML='<li class="termin-empty">Keine neuen E-Mails — alles ruhig.</li>';return;}
  list.innerHTML=mails.map(m=>{
    const from=String(m.from||'?'),color=calColor(from),initial=(from.replace(/[^A-Za-zÄÖÜäöü0-9]/g,'').charAt(0)||'✉').toUpperCase();
    return `<li class="termin-item notif-card" style="--cal-color:${color}" data-mail-id="${escHtml(m.id||'')}" data-mail-from="${escHtml(from)}" data-mail-src="${escHtml(m.src||'')}" data-mail-sub="${escHtml(m.subject||'')}"><div class="t-date"><b>${escHtml(initial)}</b><span>MAIL</span></div><div class="t-body"><div class="ttitle">${escHtml(from)}</div><div class="when"><span class="chip"><span class="dot"></span><span class="txt">${escHtml(m.subject||'')}</span></span></div></div><button type="button" class="notif-dismiss" data-spam="1" title="Als Spam markieren" aria-label="Als Spam markieren"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M6 6l12 12"/></svg></button></li>`;
  }).join('');
}
// Klick auf eine Mail: ganzen Text lesen
function gBodyText(p){
  const dec=b=>{try{const s=atob(String(b).replace(/-/g,'+').replace(/_/g,'/'));return new TextDecoder('utf-8').decode(Uint8Array.from(s,c=>c.charCodeAt(0)));}catch(e){return '';}};
  const parts=[];(function walk(x){if(!x)return;if(x.body&&x.body.data&&!x.filename)parts.push({t:x.mimeType,d:dec(x.body.data)});(x.parts||[]).forEach(walk);})(p);
  const plain=parts.filter(x=>x.t==='text/plain').map(x=>x.d).join('\n').trim();if(plain)return plain;
  const html=parts.filter(x=>x.t==='text/html').map(x=>x.d).join('\n');
  return html.replace(/<(script|style|head)[^>]*>[\s\S]*?<\/\1>/gi,' ').replace(/<br\s*\/?>|<\/(p|div|tr|li|h\d)>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/[ \t]+/g,' ').replace(/\n\s*\n\s*\n+/g,'\n\n').trim();
}
async function openMail(li){
  const id=li.dataset.mailId,src=li.dataset.mailSrc;
  let ov=document.getElementById('mailOv');if(ov)ov.remove();
  ov=document.createElement('div');ov.id='mailOv';ov.style.cssText='position:fixed;inset:0;z-index:9990;background:rgba(3,2,9,.94);display:flex;flex-direction:column;padding:16px;overflow:hidden';
  ov.innerHTML='<div style="flex:none"><div style="font:600 10px var(--font-mono);letter-spacing:.16em;color:var(--cyan)">E-MAIL</div><div id="moSub" style="font:700 17px/1.3 var(--font-display);margin-top:6px;color:#fff"></div><div id="moFrom" style="font:500 11px var(--font-mono);color:#9a97b0;margin-top:4px"></div></div><div id="moBody" style="flex:1;overflow:auto;margin:14px 0;font:400 13px/1.6 var(--font-mono);white-space:pre-wrap;word-break:break-word;color:#dcdaf0">Lade …</div><button class="btn pri" id="moClose" style="flex:none;width:100%">SCHLIESSEN</button>';
  document.body.appendChild(ov);
  $('#moSub').textContent=li.dataset.mailSub||'(kein Betreff)';$('#moFrom').textContent=li.dataset.mailFrom||'';
  $('#moClose').onclick=()=>ov.remove();
  try{
    if(src==='g'){
      const d=await gApi('https://gmail.googleapis.com/gmail/v1/users/me/messages/'+encodeURIComponent(id)+'?format=full');
      const H={};((d.payload&&d.payload.headers)||[]).forEach(x=>H[x.name.toLowerCase()]=x.value);
      if(H.subject)$('#moSub').textContent=H.subject;
      $('#moFrom').textContent=(H.from||'')+(H.date?'  ·  '+H.date:'');
      $('#moBody').textContent=gBodyText(d.payload)||d.snippet||'(kein Text)';
    }else{
      if(!sync.token||!sync.origin)throw new Error('Dafür muss die App mit dem PC verbunden oder bei Google angemeldet sein.');
      const r=await hubFetch('/phone/api/mail?id='+encodeURIComponent(id),{headers:{'X-Ari-Token':sync.token}});
      const j=await r.json();if(j.error)throw new Error(j.error);
      if(j.subject)$('#moSub').textContent=j.subject;$('#moFrom').textContent=(j.from||'')+(j.date?'  ·  '+j.date:'');
      $('#moBody').textContent=j.text||'(kein Text)';
    }
  }catch(e){$('#moBody').textContent='Konnte die Mail nicht laden: '+String(e&&e.message||e).slice(0,200);}
}
$('#mailList').addEventListener('click',async(e)=>{
  const btn=e.target.closest('[data-spam]');
  if(!btn){const li0=e.target.closest('[data-mail-id]');if(li0)openMail(li0);return;}
  const li=btn.closest('[data-mail-id]');const id=li.dataset.mailId,from=li.dataset.mailFrom;
  li.remove();
  if(gOn()){const sp=spamList();const k=(li.dataset.mailFrom||'').toLowerCase();if(k&&!sp.includes(k)){sp.push(k);store.set('ari-app-spam',sp.slice(-200));}}
  if(!sync.token||!sync.origin)return;
  try{await hubFetch('/phone/api/spam',{method:'POST',headers:{'Content-Type':'application/json','X-Ari-Token':sync.token},body:JSON.stringify({id,from})});}catch(err){}
});
function escHtml(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
setInterval(()=>{if(document.getElementById('t-cal').classList.contains('on'))loadCalData();},60000);


/* ---------- Einstellungen ---------- */
function loadSet(){
  $('#sProv').value=cfg.provider;$('#sKey').value=cfg.keys[cfg.provider]||'';$('#sProv2').value=cfg.fb||'';$('#sKey2').value=cfg.fbKey||'';$('#sLang').value=cfg.lang;$('#sGroqMore').value=(sync.groqAll||[]).slice(1).join(String.fromCharCode(10));
  $$('#sTts .btn').forEach(b=>b.classList.toggle('on',b.dataset.v===cfg.tts));
  $('#sVoice').value=cfg.voice||'edge:katja';
  $$('#sPc .btn').forEach(b=>b.classList.toggle('on',b.dataset.v===(cfg.pcRoute||'auto')));
  $('#sIcs').value=cfg.icsUrl||'';$('#sGid').value=cfg.gClientId||'';
  $('#gStatus').textContent=gOn()?'✓ Bei Google angemeldet – Termine und Mails laufen direkt über Google, ohne PC.':'Nicht angemeldet.';
  $('#gLogout').style.display=gOn()?'':'none';
  $$('#sGMail .btn').forEach(b=>b.classList.toggle('on',b.dataset.v===(cfg.gMail||'1')));
  pcSimSetActive(cfg.pcSimOn==='1');
}
$('#sProv').onchange=()=>{cfg.provider=$('#sProv').value;$('#sKey').value=cfg.keys[cfg.provider]||'';saveCfg();sync.dirtySet=true;saveSync();syncSoon();};
$('#sKey').onchange=()=>{cfg.keys[cfg.provider]=$('#sKey').value.trim();saveCfg();sync.dirtyKeys=true;saveSync();syncSoon();};
$('#sGroqMore').onchange=()=>{const more=$('#sGroqMore').value.split(new RegExp("[ "+String.fromCharCode(9,10,13)+",;]+")).map(x=>x.trim()).filter(Boolean);sync.groqAll=[cfg.keys.groq||'',...more];sync.dirtyKeys=true;saveSync();syncSoon();};
$('#sProv2').onchange=()=>{cfg.fb=$('#sProv2').value;saveCfg();};
$('#sKey2').onchange=()=>{cfg.fbKey=$('#sKey2').value.trim();saveCfg();};
$('#sLang').onchange=()=>{cfg.lang=$('#sLang').value;saveCfg();};
// Mein Ort
function placeUi(){const i=$('#sPlace'),inf=$('#placeInfo');if(!i)return;
  i.value=homePlace&&!homePlace.auto?homePlace.name:'';i.placeholder=homePlace?homePlace.name:'z. B. Hamburg';
  $('#sPlaceGps').checked=cfg.placeGps==='1';
  inf.textContent=homePlace?(homePlace.auto?'Automatisch erkannt: ':'Eingestellt: ')+homePlace.name:'Noch kein Ort - wird beim ersten Wetter automatisch erkannt oder trag ihn ein.';}
$('#sPlaceSave').onclick=async()=>{const inf=$('#placeInfo'),n=$('#sPlace').value.trim();
  if(!n){homePlace=null;store.set('ari-place',null);inf.textContent='Wird ermittelt …';homePlace=await placeDetectIp();store.set('ari-place',homePlace);placeUi();return;}
  inf.textContent='Wird gespeichert …';const l=await placeGeocode(n);if(!l){inf.textContent='Diesen Ort habe ich nicht gefunden.';return;}
  homePlace=l;store.set('ari-place',l);placeUi();};
$('#sPlaceGps').onchange=async()=>{const on=$('#sPlaceGps').checked;cfg.placeGps=on?'1':'0';saveCfg();const inf=$('#placeInfo');
  if(on){inf.textContent='Standort wird abgefragt …';const g=await placeGps(9000);
    if(!g){cfg.placeGps='0';saveCfg();$('#sPlaceGps').checked=false;inf.textContent='Kein Standort erhalten - bitte in den Android-Einstellungen den Standort für A.R.I erlauben.';return;}
    inf.textContent='Aktueller Standort: '+g.name;}else placeUi();};
placeUi();
$$('#sTts .btn').forEach(b=>b.onclick=()=>{cfg.tts=b.dataset.v;saveCfg();loadSet();});
$('#sVoice').onchange=()=>{cfg.voice=$('#sVoice').value;saveCfg();speak('Das ist meine Stimme.');};
$$('#sPc .btn').forEach(b=>b.onclick=()=>{cfg.pcRoute=b.dataset.v;saveCfg();loadSet();});
$$('#sGMail .btn').forEach(b=>b.onclick=()=>{cfg.gMail=b.dataset.v;saveCfg();loadSet();});
$('#gCopyPkg').onclick=()=>{try{navigator.clipboard.writeText('com.ari.assistant');$('#gStatus').textContent='Paketname kopiert.';}catch(e){}};
$('#gCopySha').onclick=()=>{try{navigator.clipboard.writeText('B6:AF:C9:89:4F:7A:A9:4E:0B:8B:E7:A2:A2:A7:72:D9:0E:B8:2E:48');$('#gStatus').textContent='SHA-1 kopiert.';}catch(e){}};
$('#sGid').onchange=()=>{cfg.gClientId=$('#sGid').value.trim();saveCfg();};
$('#gLogin').onclick=()=>{cfg.gClientId=$('#sGid').value.trim();saveCfg();gStart();};
$('#gLogout').onclick=()=>{gTok=null;store.set('ari-app-gtok',null);calCache=null;store.set('ari-app-caldata',null);loadSet();loadCalData();};
$('#sIcs').onchange=()=>{cfg.icsUrl=$('#sIcs').value.trim();saveCfg();calCache=null;store.set('ari-app-caldata',null);loadCalData();};
$('#sImportBtn').onclick=()=>$('#sImport').click();
$('#sPullBtn').onclick=async()=>{
  const msg=$('#sImportMsg'),b=$('#sPullBtn');
  if(!sync.token||!sync.origin){msg.textContent='Erst mit dem PC koppeln (Tab PC).';return;}
  b.disabled=true;msg.textContent='Hole die Einstellungen vom PC …';
  sync.dirtySet=false;sync.dirtyKeys=false;saveSync();   // nichts zum PC schicken - nur holen
  await syncNow();
  b.disabled=false;
  const keys=['groq','gemini','openai','anthropic'].filter(p=>cfg.keys[p]).length;
  msg.textContent=(sync.last&&Date.now()-sync.last<15000)?'✓ Übernommen: Anbieter '+cfg.provider+', '+keys+' Schlüssel, Sprache und Farben.':'Der PC ist gerade nicht erreichbar – Handy und PC im selben WLAN?';
};
$('#sImport').onchange=async e=>{
  const f=e.target.files[0];if(!f)return;const msg=$('#sImportMsg');
  try{
    const s=JSON.parse(await f.text());const k=s.apiKeys||{};
    const groq=(Array.isArray(k.groq)?k.groq:[k.groq]).filter(Boolean)[0]||'';
    ['anthropic','openai','gemini'].forEach(p=>{if(k[p])cfg.keys[p]=String(k[p]);});if(groq)cfg.keys.groq=String(groq);{const gl=(Array.isArray(k.groq)?k.groq:[k.groq]).filter(Boolean).map(String);if(gl.length)sync.groqAll=gl;}
    if(PROV[s.provider])cfg.provider=s.provider;
    if(s.language&&s.language!=='auto')cfg.lang=s.language;
    for(const p of ['gemini','groq','openai','anthropic']){if(p!==cfg.provider&&cfg.keys[p]){cfg.fb=p;cfg.fbKey=cfg.keys[p];break;}}
    if(s.primary&&/^#[0-9a-f]{6}$/i.test(s.primary))document.documentElement.style.setProperty('--pink',s.primary);
    if(s.accent&&/^#[0-9a-f]{6}$/i.test(s.accent))document.documentElement.style.setProperty('--cyan',s.accent);
    store.set('ari-app-theme',{primary:s.primary,accent:s.accent});
    sync.dirtyKeys=true;sync.dirtySet=true;saveSync();syncSoon();saveCfg();loadSet();msg.textContent='✓ Übernommen: Anbieter '+cfg.provider+(cfg.fb?', Ausweich '+cfg.fb:'')+'. (Nur Schlüssel/Anbieter/Sprache/Farben – die Datei bleibt auf dem Handy.)';
  }catch(er){msg.textContent='Datei nicht lesbar.';}
  e.target.value='';
};
{const th=store.get('ari-app-theme',null);if(th){if(th.primary)document.documentElement.style.setProperty('--pink',th.primary);if(th.accent)document.documentElement.style.setProperty('--cyan',th.accent);}}
function dl(name,obj){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(obj,null,1)],{type:'application/json'}));a.download=name;document.body.appendChild(a);a.click();a.remove();}
$('#brExport').onclick=()=>dl('ari-gehirn.json',{nodes:brain});
$('#brImportBtn').onclick=()=>$('#brImport').click();
$('#brImport').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const d=JSON.parse(await f.text());const arr=Array.isArray(d)?d:(d.nodes||[]);
  arr.forEach(n=>{const t=String(n.text||'').trim();if(t.length>=4&&!brain.some(m=>m.text.toLowerCase()===t.toLowerCase()))brain.push({id:String(n.id||Date.now()+Math.random()),text:t,cat:String(n.cat||n.category||'Wissen').slice(0,30),ts:Date.now()});});
  saveBrain();renderBrain();}catch(er){}e.target.value='';};
$('#lastErr').onclick=()=>{const e=store.get('ari-last-error',null);$('#lastErrMsg').textContent=e?(new Date(e.t).toLocaleString('de-DE')+' · '+e.prov+(e.status?' · '+e.status:'')+' · '+e.msg):'Noch kein Fehler gespeichert.';};
$('#wipe').onclick=()=>{if(!confirm('Alle Daten dieser App auf diesem Handy löschen (Schlüssel, Gehirn, gespeicherte PCs)?'))return;
  ['ari-app-cfg','ari-app-brain','ari-app-pcs','ari-app-theme'].forEach(k=>{try{localStorage.removeItem(k);}catch(e){}});location.reload();};


/* ---------- Synchronisation mit dem PC (Gehirn, Einstellungen, API-Schluessel) ---------- */
// Die App sendet Daten NUR an den PC, mit dem du sie per Link gekoppelt hast (Geraete-Token).
let sync=store.get('ari-app-sync',{origin:'',token:'',deleted:[],dirtyKeys:false,dirtySet:false,last:0,groqAll:[],pc:{}});
const saveSync=()=>store.set('ari-app-sync',sync);
// Handy und PC muessen im selben WLAN sein - keine Cloud/Tunnel-Adresse wird akzeptiert.
/* ---------- Einstellungen: Kategorien + genaue Suche (wie am PC) ---------- */
(function(){
  const GROUPS=[
    ['SPRACHE & TON',['STIMME','HÖREN'],'Stimme, Vorlesen und Weckwort'],
    ['BENACHRICHTIGUNGEN',['HANDY-BENACHRICHTIGUNGEN','HINTERGRUND-BETRIEB'],'Meldungen an den PC, Termine und Mails im Hintergrund'],
    ['KONTEN & VERBINDUNGEN',['KI-ANBIETER','VOM PC ÜBERNEHMEN'],'Das „Gehirn“ von A.R.I und Einstellungen vom PC'],
    ['ERWEITERUNGEN',['MODS'],'Mods installieren und verwalten'],
    ['SONSTIGES',['APP-UPDATE','DATEN','STATISTIK','UNTERSTÜTZEN','DEV'],'Update, Daten, Unterstützen und Entwickler-Werkzeuge']
  ];
  const sec=document.getElementById('t-set');if(!sec)return;
  const title=d=>((d.querySelector(':scope > summary')||{}).textContent||'').trim().toUpperCase();
  function organize(){
    const all=[...sec.querySelectorAll(':scope > details.set-section, :scope > .set-group > details.set-section')];
    let anchor=document.getElementById('setNoHit');
    GROUPS.forEach(([name,keys,desc],gi)=>{
      let g=sec.querySelector(':scope > .set-group[data-g="'+gi+'"]');
      if(!g){g=document.createElement('div');g.className='set-group';g.dataset.g=gi;g.innerHTML='<div class="set-group-h">'+name+'</div><div class="set-group-d">'+desc+'</div>';anchor.insertAdjacentElement('afterend',g);}
      anchor=g;
      keys.forEach(k=>{const dd=all.find(x=>title(x).includes(k));if(dd&&dd.parentNode!==g)g.appendChild(dd);});
    });
    const known=GROUPS.flatMap(x=>x[1]),rest=sec.querySelector(':scope > .set-group[data-g="4"]');
    all.forEach(dd=>{if(!known.some(k=>title(dd).includes(k))&&dd.parentNode!==rest)rest.appendChild(dd);});
  }
  // Stichwoerter je Abschnitt (auch fuer Abschnitte im Tab PC): so findet man Einstellungen mit eigenen Worten ("pc verbinden" -> koppeln, uebertragen ...)
  const KW={
    'STIMME':'sprechen vorlesen antworten stimme edge katja ton audio tempo',
    'HÖREN':'weckwort wake word zuhören zuhoeren hintergrund mikrofon immer',
    'HANDY-BENACHRICHTIGUNGEN':'meldungen weiterleiten pc whatsapp benachrichtigungszugriff übertragen uebertragen senden',
    'HINTERGRUND-BETRIEB':'termine mails hintergrund erinnerung akku',
    'KI-ANBIETER':'gehirn ki schlüssel api groq gemini openai claude modell sprache anbieter',
    'VOM PC ÜBERNEHMEN':'pc übertragen uebertragen einstellungen holen import schlüssel übernehmen synchronisieren verbinden',
    'MODS':'plugins erweiterungen installieren zusatzfunktionen aktivieren',
    'APP-UPDATE':'aktualisieren version beta neu herunterladen',
    'DATEN':'gehirn export import löschen zurücksetzen einführung',
    'STATISTIK':'anonym daten nutzung',
    'UNTERSTÜTZEN':'spenden kaffee',
    'DEV':'entwickler test',
    'MEIN ORT':'wetter temperatur heimatort standort wohnort stadt ort zuhause gps regen vorhersage',
    'SYNCHRONISATION':'pc verbinden koppeln kopplung übertragen uebertragen sync synchronisieren google kalender ical verbindung',
    'MIT DEM PC VERBINDEN':'koppeln kopplung koppelcode qr code scannen pc handy verbinden wlan übertragen uebertragen steuern bildschirm',
    "SO GEHT'S":'hilfe anleitung erklärung anfang'
  };
  const kwOf=d=>{const t=title(d);const k=Object.keys(KW).find(x=>t.includes(x));return k?KW[k]:'';};

  const SF_SYN = [
    ['verbinden', 'verbindung', 'koppeln', 'kopplung', 'koppelcode', 'pairen', 'anbinden', 'anmelden', 'login', 'einloggen', 'verknuepfen'],
    ['uebertragen', 'uebernehmen', 'synchronisieren', 'sync', 'abgleichen', 'importieren', 'exportieren', 'senden', 'schicken', 'weiterleiten', 'teilen'],
    ['stimme', 'sprechen', 'sprache', 'sprachausgabe', 'vorlesen', 'reden', 'edge', 'katja', 'conrad'],
    ['leise', 'leiser', 'laut', 'lauter', 'lautstaerke', 'volume', 'ton', 'audio', 'sound', 'klang'],
    ['ausschalten', 'abschalten', 'deaktivieren', 'ausblenden', 'verstecken', 'stumm'],
    ['einschalten', 'anschalten', 'aktivieren', 'einblenden', 'anzeigen', 'zeigen'],
    ['farbe', 'farben', 'design', 'theme', 'aussehen', 'optik', 'akzent', 'dunkel', 'hell'],
    ['hilfe', 'problem', 'fehler', 'log', 'protokoll', 'diagnose', 'kaputt', 'geht'],
    ['loeschen', 'entfernen', 'zuruecksetzen', 'reset', 'leeren'],
    ['benachrichtigung', 'benachrichtigungen', 'meldung', 'meldungen', 'nachricht', 'nachrichten', 'push', 'hinweis', 'ansage', 'ansagen'],
    ['handy', 'smartphone', 'telefon', 'mobil'],
    ['pc', 'computer', 'rechner', 'laptop'],
    ['musik', 'spotify', 'lied', 'song', 'player', 'wiedergabe'],
    ['mail', 'email', 'mails', 'postfach', 'gmail', 'yahoo', 'post'],
    ['termin', 'termine', 'kalender', 'event', 'erinnerung'],
    ['start', 'starten', 'autostart', 'windows', 'hochfahren'],
    ['taste', 'hotkey', 'tastenkuerzel', 'shortcut', 'tastatur'],
    ['ki', 'gehirn', 'anbieter', 'modell', 'schluessel', 'key', 'api', 'groq', 'gemini', 'openai', 'claude'],
    ['mikrofon', 'mikro', 'zuhoeren', 'hoeren', 'weckwort', 'aufnahme'],
    ['aktualisieren', 'update', 'version', 'neu', 'herunterladen'],
    ['spiel', 'spiele', 'spielmodus', 'game', 'gaming'],
    ['abmelden', 'ausloggen', 'logout', 'trennen', 'entkoppeln', 'widerrufen'],
    ['bearbeiten', 'aendern', 'editieren', 'anpassen', 'konfigurieren'],
    ['spenden', 'kaffee', 'unterstuetzen']
  ];
  const SF_NORM = t => String(t || '').toLowerCase().replace(/[äÄ]/g, 'ae').replace(/[öÖ]/g, 'oe').replace(/[üÜ]/g, 'ue').replace(/ß/g, 'ss');
  const sfWords = t => SF_NORM(t).split(/[^a-z0-9]+/).filter(Boolean);
  // Suchwort -> alle gleichbedeutenden Woerter (verbinden = koppeln = Verbindung ...)
  function sfAlts(tok) {
    const a = new Set([tok]);
    SF_SYN.forEach(g => { if (g.some(x => x === tok || (tok.length >= 3 && x.startsWith(tok)))) g.forEach(x => a.add(x)); });
    return [...a];
  }
  // Ein Wort passt, wenn es mit dem Suchwort BEGINNT oder denselben Wortstamm hat (verbinden ~ Verbindung); jedes Suchwort muss irgendwo vorkommen
  const SF_STOP = new Set('der die das den dem des ein eine einen einem einer ich du er sie es wir mein meine meinen meiner dein deine wie was wo wann warum wieso wer welche welcher mit auf fuer von vom zu zum zur im in am an aus bei nach um und oder aber nicht kein keine mehr mal nur auch noch schon sehr ist sind war wird kann koennen soll will moechte moechten bitte aendern aendere einstellen einstellung einstellungen machen mache geben gib holen hol finden suchen hier da dann damit wenn dass ob man geht'.split(' '));
  const sfTokens = q => { const all = sfWords(q), k = all.filter(w => !SF_STOP.has(w)); return k.length ? k : all; };   // Fuellwoerter ("wie", "vom", "aendern" ...) zaehlen nicht
  // min = wie viele Suchwoerter mindestens passen muessen (null = alle)
  const sfMatch = (words, toks, min) => { let n = 0; for (const q of toks) { const alts = sfAlts(q); if (words.some(w => alts.some(x => w.startsWith(x) || (x.length >= 5 && w.length >= 5 && x.slice(0, 5) === w.slice(0, 5))))) n++; } return n >= (min == null ? toks.length : Math.max(1, Math.min(min, toks.length))) && n > 0; };
  const sfFieldText = f => f.textContent + ' ' + [...f.querySelectorAll('[placeholder]')].map(e => e.getAttribute('placeholder')).join(' ') + ' ' + [...f.querySelectorAll('[title]')].map(e => e.getAttribute('title')).join(' ');

  // Auch Bedienelemente ausserhalb eines Einstellungs-Feldes (einzelne Haken/Knoepfe) einzeln auffindbar machen
  function sfFields(d, sel) {
    const base = [...d.querySelectorAll(sel)], extra = new Set();
    d.querySelectorAll('input,select,button,textarea').forEach(c => {
      if (c.type === 'hidden' || c.closest(sel)) return;
      let e = c.closest('label');
      if (!e) { const p = c.parentElement; e = (!p || p === d || (p.className || '').toString().indexOf('set-section-body') >= 0 || p.querySelectorAll('input,select,button,textarea').length > 3) ? c : p; }   // einzeln stehende Knoepfe/Haken: das Element selbst
      if (!e || e === d || e.tagName === 'SUMMARY' || e.querySelector('summary') || base.some(b => e.contains(b))) return;
      extra.add(e);
    });
    return base.concat([...extra]);
  }

  const words=sfWords,match=sfMatch;
  function filter(){
    const toks=sfTokens((document.getElementById('setSearch')||{}).value||''),rel=Math.ceil(toks.length/2);
    const apply=(weak,min)=>{
      let any=false;
      sec.querySelectorAll('.set-group').forEach(g=>{
        let vis=0;
        g.querySelectorAll(':scope > details.set-section').forEach(d=>{
          const tw=words((d.querySelector('summary')||{}).textContent),fields=sfFields(d,'.set,.panel-h');
          const tHit=!toks.length||match(tw.concat(words(kwOf(d))),toks,min);let fh=0;
          fields.forEach(f=>{f.classList.remove('set-fhide');if(!toks.length)return;f._hit=match(words(sfFieldText(f)).concat(tw),toks,min);if(f._hit)fh++;});
          let hit=!toks.length||tHit||fh>0;
          if(toks.length&&hit&&!tHit)fields.forEach(f=>f.classList.toggle('set-fhide',!f._hit));
          if(toks.length&&!hit&&weak&&match(words(d.textContent).concat(tw),toks,min))hit=true;
          d.classList.toggle('set-hide',!hit);
          if(hit&&d.style.display!=='none')vis++;
          if(toks.length&&hit){d.open=true;d.dataset.auto='1';}else if(!toks.length&&d.dataset.auto){d.open=false;delete d.dataset.auto;}
        });
        g.classList.toggle('empty',vis===0);if(vis)any=true;
      });
      // Treffer in anderen Tabs (z. B. Kopplung im Tab PC): als Sprungzeilen unter dem Suchfeld
      let xh=document.getElementById('setXhits');if(!xh){xh=document.createElement('div');xh.id='setXhits';const nh0=document.getElementById('setNoHit');nh0.parentNode.insertBefore(xh,nh0);}
      xh.textContent='';let xAny=false;
      if(toks.length)document.querySelectorAll('#t-pc details.set-section').forEach(d=>{
        const tw=words((d.querySelector('summary')||{}).textContent);
        if(!(match(tw.concat(words(kwOf(d))),toks,min)||(weak&&match(words(d.textContent).concat(tw),toks,min))))return;
        xAny=true;const b=document.createElement('button');b.type='button';b.className='btn xhit';
        b.innerHTML='<span>'+((d.querySelector('summary')||{}).textContent||'').trim()+'</span><small>im Tab PC öffnen →</small>';
        b.onclick=()=>{goTab('pc');d.open=true;setTimeout(()=>d.scrollIntoView({behavior:'smooth',block:'start'}),150);};xh.appendChild(b);});
      return any||xAny;
    };
    let any=apply(false,null);if(toks.length>1&&!any)any=apply(false,rel);if(toks.length&&!any)any=apply(true,null);if(toks.length>1&&!any)any=apply(true,rel);
    const nh=document.getElementById('setNoHit');if(nh)nh.style.display=(toks.length&&!any)?'block':'none';
  }
  organize();
  const si=document.getElementById('setSearch');if(si)si.addEventListener('input',filter);
  document.addEventListener('toggle',e=>{const d=e.target;if(!d||!d.classList||!d.classList.contains('set-section')||!d.open||!sec.contains(d))return;
    if(((document.getElementById('setSearch')||{}).value||'').trim())return;sec.querySelectorAll('details.set-section[open]').forEach(o=>{if(o!==d)o.open=false;});},true);
})();
// Bilder/Symbole vom PC brauchen den Geraete-Token: laden und als Blob-Adresse merken
const _authImgs=new Map();
async function authImg(path){
  if(_authImgs.has(path))return _authImgs.get(path);
  try{const r=await fetch(sync.origin+path,{headers:{'X-Ari-Token':sync.token}});if(!r.ok)return '';const u=URL.createObjectURL(await r.blob());_authImgs.set(path,u);return u;}catch(e){return '';}
}
const initialOf=b=>{const row=b.closest('.pcsim-row'),t=row&&row.querySelector('.t1');return ((t&&t.textContent||'?').charAt(0)||'?').toUpperCase();};
function showNotifPic(src,video){
  let v=document.getElementById('ariPicView');if(v)v.remove();
  v=document.createElement('div');v.id='ariPicView';v.style.cssText='position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.9)';
  v.innerHTML=video?'<video src="'+src+'" controls autoplay playsinline style="max-width:100vw;max-height:100vh"></video><button type="button" style="position:absolute;top:12px;right:12px;width:40px;height:40px;border-radius:50%;border:1px solid #fff5;background:#0008;color:#fff;font-size:16px">✕</button>':'<img src="'+src+'" alt="" style="max-width:100vw;max-height:100vh;object-fit:contain">';v.onclick=ev=>{if(!video||ev.target.tagName!=='VIDEO')v.remove();};document.body.appendChild(v);
}
document.addEventListener('click',async e=>{
  const del=e.target.closest('[data-ndel]'),pic=e.target.closest('[data-npic],[data-nvid]');
  if(pic){
    if(pic.dataset.nvid){const u=await authImg('/phone/notif-video?id='+encodeURIComponent(pic.dataset.nvid));if(u){showNotifPic(u,true);return;}}
    const im=pic.querySelector('img');if(im&&im.src)showNotifPic(im.src);return;}
  if(del){const id=del.dataset.ndel;const row=del.closest('.pcsim-row');if(row)row.remove();
    try{await fetch(sync.origin+'/phone/api/notify-dismiss',{method:'POST',headers:{'Content-Type':'application/json','X-Ari-Token':sync.token},body:JSON.stringify({id})});}catch(err){}}
});
async function hubFetch(path,opts){
  // Zeitlimit: antwortet der PC nicht (anderes WLAN, PC aus), darf das Drehzeichen nicht ewig drehen
  const ms=(opts&&opts.timeout)||10000,ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),ms);
  try{return await fetch(sync.origin+path,Object.assign({},opts,{signal:ctl.signal}));}finally{clearTimeout(to);}
}
const LAN_OK=new RegExp('^http:[/][/](192[.]168[.][0-9]+[.][0-9]+|10[.][0-9]+[.][0-9]+[.][0-9]+|172[.](1[6-9]|2[0-9]|3[01])[.][0-9]+[.][0-9]+)(:[0-9]+)?$');
function syncStatus(t,ok){
  updateConn(ok);
  $('#syncStatus').textContent=t;$('#syncTag').textContent=sync.token?(ok===false?'GETRENNT':'VERBUNDEN'):'–';
  // Gleiche Meldung gut sichtbar im PC-Tab (dort schaut man nach dem Koppeln hin)
  const box=$('#pcState'),tag=$('#pcTag');
  if(box){
    const conn=!!sync.token&&ok!==false;
    box.textContent=(conn&&!/^✓/.test(t)?'✓ Mit dem PC verbunden. ':(ok===false?'⚠ ':''))+t;
    box.style.borderColor=conn?'rgba(57,255,158,.55)':(ok===false?'rgba(255,210,61,.6)':'rgba(255,255,255,.14)');
    box.style.color=conn?'#39ff9e':'';
    if(tag)tag.textContent=sync.token?(ok===false?'GETRENNT':'VERBUNDEN'):'–';
  }
}
// Feste Geraete-Kennung dieser App (damit derselbe Handy-Eintrag beim erneuten Koppeln ersetzt wird, statt sich zu vermehren)
function devId(){let d=store.get('ari-app-devid',null);if(!d){d='d'+Math.random().toString(36).slice(2,12);store.set('ari-app-devid',d);}return d;}
// PC-Adresse + Token auch nativ speichern (SharedPreferences), damit der Benachrichtigungsdienst
// (laeuft unabhaengig von dieser WebView-Seite) weiss, wohin er Handy-Benachrichtigungen schicken soll.
function pushSyncCreds(){
  if(!NATIVE||!window.Capacitor||!Capacitor.Plugins||!Capacitor.Plugins.AriWake)return;
  try{Capacitor.Plugins.AriWake.setSyncCreds({origin:sync.origin||'',token:sync.token||''}).catch(()=>{});}catch(e){}
}
pushSyncCreds(); // beim Start einmal senden - wichtig nach einem App-Update, falls schon vorher gekoppelt
// Geraetename fuer die Kopplung: der Name, den der Nutzer selbst in Android unter "Ueber das Telefon ->
// Geraetename" vergeben hat - Hersteller tragen dort meist schon den echten Produktnamen ein (z.B.
// "Galaxy S24 Ultra"), und wer umbenannt hat, bekommt genau den eigenen Namen zurueck. Funktioniert
// markenuebergreifend, kein Rateservice noetig. Ohne Zugriff (Web-Version) faellt es auf den rohen
// Geraetemodell-Code aus dem User-Agent zurueck, sonst grob Handy/Tablet nach Bildschirmgroesse. Am PC
// in Einstellungen -> HANDY trotzdem jederzeit umbenennbar.
async function deviceLabel(){
  if(NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake){
    try{const r=await Capacitor.Plugins.AriWake.deviceName();if(r&&r.name&&r.name.trim())return r.name.trim().slice(0,40);}catch(e){}
  }
  try{
    const m=/Android\s+[\d.]+;\s*([^)]+)\)/.exec(navigator.userAgent);
    if(m){const s=m[1].split('Build')[0].trim();if(s)return s.slice(0,40);}
  }catch(e){}
  return Math.min(screen.width,screen.height)>=600?'Tablet':'Handy';
}
function toast(msg){
  const t=document.createElement('div');t.textContent=msg;
  t.style.cssText='position:fixed;left:16px;right:16px;bottom:88px;z-index:9996;padding:14px 16px;border-radius:14px;background:#0b1620;border:1px solid #39ff9e;color:#dff6ff;font:600 13px var(--font-mono);text-align:center;box-shadow:0 12px 30px -10px #000';
  document.body.appendChild(t);setTimeout(()=>t.remove(),4200);
}
// Sicherheitsabfrage beim Koppeln (schoener Dialog statt der Systembox): nur bestaetigen, wenn der Link vom eigenen A.R.I stammt
function askPair(origin){
  return new Promise(res=>{
    const ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;z-index:9995;background:rgba(3,2,9,.82);display:flex;align-items:center;justify-content:center;padding:20px;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)';
    ov.innerHTML='<div style="width:100%;max-width:360px;border-radius:20px;border:1px solid rgba(255,45,120,.4);background:linear-gradient(160deg,#1e1a34,#0c0b16);padding:22px 20px 18px;color:#dcdaf0;text-align:center;box-shadow:0 30px 70px -20px #000"><div style="font:700 13px var(--font-mono);letter-spacing:.16em;color:#fff">MIT DEM PC VERBINDEN?</div><div style="margin-top:10px;font:400 12.5px/1.55 var(--font-mono)">Gehirn, Einstellungen und Schlüssel werden mit diesem PC abgeglichen.</div><div id="apAddr" style="margin-top:10px;font:600 11px/1.4 var(--font-mono);color:#29d3f5;word-break:break-all"></div><div style="margin-top:10px;font:400 11px/1.5 var(--font-mono);opacity:.7">Nur bestätigen, wenn der Link von deinem eigenen A.R.I stammt.</div><button class="btn pri" id="apOk" style="width:100%;margin-top:16px">JA, VERBINDEN</button><button class="btn" id="apNo" style="width:100%;margin-top:8px">ABBRECHEN</button></div>';
    document.body.appendChild(ov);ov.querySelector('#apAddr').textContent=origin;
    ov.querySelector('#apOk').onclick=()=>{ov.remove();res(true);};ov.querySelector('#apNo').onclick=()=>{ov.remove();res(false);};
  });
}
async function pairFromLink(origin,code){
  if(!LAN_OK.test(origin)){syncStatus('PC und Handy müssen im selben WLAN sein.',false);return;}
  if(sync.token&&sync.origin===origin){toast('Schon mit diesem PC verbunden.');goTab('pc');syncNow();return;}
  if(!(await askPair(origin)))return;
  syncStatus('Verbinde …');
  try{
    const r=await fetch(origin+'/phone/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,name:await deviceLabel(),dev:devId()})});
    const d=await r.json();
    if(!r.ok||!d.token){syncStatus('Kopplung fehlgeschlagen: '+(d.error||r.status),false);return;}
    sync.origin=origin;sync.token=d.token;sync.dirtyKeys=false;sync.dirtySet=false;saveSync();
    pushSyncCreds();
    goTab('pc');await syncNow();
    if(sync.token)toast('✓ Mit dem PC verbunden');
  }catch(e){syncStatus('PC nicht erreichbar. Bist du im selben WLAN wie der PC?',false);}
}
// Erkennt jede Art von Kopplungs-Link: App-Link (…/app/#pc=…&l=…) und Adresse mit 6-stelligem Code (…/phone#c=…)
function parseAnyLink(str){
  const v=String(str||'').trim();
  const L=parseLink(v);if(L)return L;
  if(NATIVE){const M=/^(https?:[/][/][^/#\s]+)[/]phone#[cl]=([A-Za-z0-9_-]{6,})/.exec(v);if(M)return {origin:M[1].replace(/[/]+$/,''),code:M[2]};}
  return null;
}
function parseLink(str){
  const m=/pc=([^&]+)&l=([A-Za-z0-9_-]+)/.exec(str||'');if(!m)return null;
  let o;try{o=decodeURIComponent(m[1]);}catch(e){return null;}return {origin:o.replace(/\/+$/,''),code:m[2]};
}
function pushSettings(){const s={};if(!sync.dirtySet)return s;s.provider=cfg.provider;return s;}
function pushKeys(){
  if(!sync.dirtyKeys)return undefined;
  const k={};['anthropic','openai','gemini'].forEach(p=>{k[p]=cfg.keys[p]||'';});
  const g=(sync.groqAll||[]).slice();g[0]=cfg.keys.groq||'';k.groq=g.filter(Boolean);return k;
}
let syncBusy=false;
async function syncNow(){
  if(!sync.token||!sync.origin||syncBusy)return;syncBusy=true;setSyncing(true);let syncOk=false;
  try{
    const body={brain:brain.map(n=>({text:n.text,cat:n.cat})),deleted:sync.deleted||[],settings:pushSettings(),apiKeys:pushKeys()};
    const r=await hubFetch('/phone/api/sync',{method:'POST',headers:{'Content-Type':'application/json','X-Ari-Token':sync.token},body:JSON.stringify(body)});
    if(r.status===401){sync.token='';saveSync();syncStatus('Kopplung abgelaufen – am PC neu koppeln (Einstellungen → HANDY).',false);return;}
    const d=await r.json();
    // Gehirn: Stand vom PC uebernehmen (enthaelt jetzt auch unsere Ergaenzungen), lokale IDs behalten
    const old=new Map(brain.map(n=>[n.text.toLowerCase(),n]));
    brain=(d.brain||[]).map(n=>{const o=old.get(String(n.text).toLowerCase());return o?Object.assign(o,{cat:n.cat}):{id:Date.now()+Math.random().toString(36).slice(2,6),text:n.text,cat:n.cat,ts:Date.now()};});
    saveBrain();sync.deleted=[];
    // Einstellungen + Schluessel vom PC
    const s=d.settings||{};sync.pc=s;
    if(!sync.dirtySet){if(PROV[s.provider])cfg.provider=s.provider;}
    if(s.language&&s.language!=='auto'&&[...$('#sLang').options].some(o=>o.value===s.language))cfg.lang=s.language;
    if(s.primary&&/^#[0-9a-f]{6}$/i.test(s.primary)||s.accent){const th={primary:s.primary,accent:s.accent};store.set('ari-app-theme',th);applyThemeSaved();}
    const k=d.apiKeys||{};['anthropic','openai','gemini'].forEach(p=>{if(typeof k[p]==='string'&&k[p])cfg.keys[p]=k[p];});
    if(Array.isArray(k.groq)&&k.groq.length){sync.groqAll=k.groq;cfg.keys.groq=k.groq[0];}
    if(cfg.fb&&cfg.keys[cfg.fb])cfg.fbKey=cfg.keys[cfg.fb];
    else{for(const p of ['gemini','groq','openai','anthropic']){if(p!==cfg.provider&&cfg.keys[p]){cfg.fb=p;cfg.fbKey=cfg.keys[p];break;}}}
    sync.dirtyKeys=false;sync.dirtySet=false;sync.last=Date.now();saveSync();saveCfg();loadSet();
    syncStatus('✓ Synchron · '+new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' · '+brain.length+' Erinnerungen'+(d.hud_seen?'':' · (HUD am PC einmal öffnen, damit alle Einstellungen ankommen)'));
    if($('#t-brain').classList.contains('on'))renderBrain();
  syncOk=true;}catch(e){syncStatus('PC gerade nicht erreichbar – Änderungen werden nachgeholt, sobald du wieder im selben WLAN bist.',false);}
  finally{syncBusy=false;setSyncing(false);}
  if(syncOk)refreshPlugins();   // Plugins vom PC gleich mit abgleichen
}
function applyThemeSaved(){const th=store.get('ari-app-theme',null);if(th){if(th.primary)document.documentElement.style.setProperty('--pink',th.primary);if(th.accent)document.documentElement.style.setProperty('--cyan',th.accent);}}
let syncT=null;const syncSoon=()=>{clearTimeout(syncT);syncT=setTimeout(syncNow,1500);};
$('#syncNow').onclick=syncNow;
$('#syncOff').onclick=()=>{if(!confirm('Synchronisation mit dem PC beenden? (Daten auf dem Handy bleiben.)'))return;sync.token='';sync.origin='';saveSync();pushSyncCreds();syncStatus('Nicht mit dem PC verbunden.');};
setInterval(()=>{if(!document.hidden)syncNow();},60000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)syncNow();});
/* QR-Link im Handy-Browser: Button, der die installierte A.R.I-App oeffnet (statt im Browser weiterzumachen) */
function showOpenInApp(L){
  const ov=document.createElement('div');ov.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:9998;padding:16px;background:#0b1620;border-top:1px solid var(--cyan);color:#dff6ff;text-align:center';
  const link='intent://pair?pc='+encodeURIComponent(L.origin)+'&l='+encodeURIComponent(L.code)+'#Intent;scheme=ari;package=com.ari.assistant;end';
  ov.innerHTML='<div style="margin-bottom:10px;font-size:14px">Mit der A.R.I-App verbinden?</div><a href="'+link+'" class="btn pri" style="display:block;text-decoration:none;margin-bottom:8px">IN DER A.R.I-APP ÖFFNEN</a><button class="btn" id="stayWeb" style="width:100%">IM BROWSER FORTFAHREN</button>';
  document.body.appendChild(ov);
  setTimeout(()=>{try{location.href=link;}catch(e){}},350);
  // Oeffnet sich die App nicht (nicht installiert / vom Browser blockiert), koppelt sich die Seite nach 3 s von selbst im Browser
  setTimeout(()=>{if(ov.isConnected&&!document.hidden)$('#stayWeb').click();},3000);   // gleich versuchen, die App zu oeffnen (manche Browser blockieren das - dann bleibt der Knopf)
  $('#stayWeb').onclick=()=>{ov.remove();history.replaceState(null,'',location.pathname+location.search);pairFromLink(L.origin,L.code);};
}
function handleDeepLink(u){
  if(/^com\.ari\.assistant:/.test(String(u))){gHandleRedirect(u);return;}
  {const L=parseAnyLink(String(u));if(L&&/^https?:/i.test(String(u))){goTab('pc');pairFromLink(L.origin,L.code);return;}}   // App-Link aus der Mail: https://…/app/#pc=…&l=…
  try{const x=new URL(String(u).replace(/^ari:[/][/]/,'https://ari.invalid/'));const o=x.searchParams.get('pc'),c=x.searchParams.get('l');
    if(o&&c){goTab('pc');pairFromLink(o.replace(/[/]+$/,''),c);}}catch(e){}
}
if(NATIVE){try{const AP=Capacitor.Plugins.App;AP.addListener('appUrlOpen',e=>handleDeepLink(e.url));AP.getLaunchUrl().then(r=>{if(r&&r.url)handleDeepLink(r.url);}).catch(()=>{});}catch(e){}}
{const L=parseLink(location.hash);if(L&&!NATIVE&&/android/i.test(navigator.userAgent)){showOpenInApp(L);}else if(L){history.replaceState(null,'',location.pathname+location.search);pairFromLink(L.origin,L.code);}
 else if(sync.token){syncStatus('Verbunden mit PC – synchronisiere …');syncNow();}}


/* ---------- App-Update ueber GitHub (nur in der installierten Android-App) ---------- */
// Prueft beim Start und stuendlich version.json neben der App-Seite. Ist die Version neuer, laedt die App die
// neue ARI.apk von derselben Adresse und startet die Installation (Android fragt einmal "Aktualisieren?").
// Update-Kanal: "stable" (alle) oder "beta" (nur Test-Geraete). Die Web-App unter .../beta/ nutzt automatisch beta.
const UPDATE_ROOT='https://kingshadow1332.github.io/A.R.I/';
const isBeta=()=>{try{return localStorage.getItem('ari_channel')==='beta'||/[/]beta[/]/.test(location.pathname);}catch(e){return false;}};
const updateBase=()=>UPDATE_ROOT+(isBeta()?'beta/':'app/');
let updInfo=null;
async function appBuild(){try{const i=await Capacitor.Plugins.App.getInfo();return {build:parseInt(i.build,10)||0,version:i.version||''};}catch(e){return null;}}
async function checkUpdate(manual){
  if(!NATIVE){if(manual){$('#updText').textContent='Updates gibt es nur in der installierten Android-App. Die Web-App aktualisiert sich beim Neuladen selbst.';}return;}
  const cur=await appBuild();if(cur){$('#updVer').textContent='VERSION '+cur.version;}
  try{
    const r=await fetch(updateBase()+'version.json?t='+Date.now(),{cache:'no-store'});
    const d=await r.json();
    if(cur&&d.versionCode>cur.build){
      updInfo=d;
      const nl=(d.notes||'').split('\n').map(s=>s.trim()).filter(Boolean);
      $('#updBannerVer').textContent='v'+d.versionName;$('#updBannerText').textContent=(nl.length?nl.slice(0,2).join(' · ')+(nl.length>2?' …':''):'Neue Version bereit.')+' (ca. '+(d.sizeMb||6)+' MB)';
      if(nl.length>2){$('#updBannerText').onclick=()=>showPatchNotes('Neu in '+d.versionName,d.notes);}
      $('#updBanner').style.display='';$('#updGo').style.display='';$('#updText').textContent='Neue Version '+d.versionName+' ist verfügbar.';
    }else{
      updInfo=null;$('#updBanner').style.display='none';$('#updGo').style.display='none';if(manual)$('#updText').textContent='✓ Du hast die neueste Version.';
      // Nach einem Update einmalig die Patch Notes der jetzt installierten Version zeigen
      try{
        const seen=localStorage.getItem('ari_seen_build');
        if(cur&&seen!==String(cur.build)){localStorage.setItem('ari_seen_build',String(cur.build));if(seen!==null&&d.versionCode===cur.build&&d.notes)showPatchNotes('Neu in '+d.versionName,d.notes);}
      }catch(e){}
    }
  }catch(e){if(manual)$('#updText').textContent='Update-Suche nicht möglich (kein Internet?).';}
}
function showPatchNotes(title,notes){
  const items=(notes||'').split('\n').map(s=>s.trim().replace(/^[-*•]\s*/,'')).filter(Boolean);if(!items.length)return;
  const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const old=document.getElementById('ariPatchNotes');if(old)old.remove();
  const o=document.createElement('div');o.id='ariPatchNotes';
  o.style.cssText='position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6)';
  o.innerHTML='<div style="max-width:460px;width:90%;max-height:80vh;overflow:auto;padding:20px 24px;border:1px solid #00d4ff;border-radius:10px;background:#0b1620;color:#dff6ff"><div style="letter-spacing:.2em;font-size:12px;opacity:.7">PATCH NOTES</div><div style="font-size:18px;margin:4px 0 12px">'+esc(title)+'</div><ul style="margin:0 0 16px 18px;padding:0;line-height:1.6;font-size:14px">'+items.map(i=>'<li>'+esc(i)+'</li>').join('')+'</ul><button type="button" id="ariPatchOk" style="width:100%;padding:10px;border:1px solid #00d4ff;background:transparent;color:#dff6ff;border-radius:6px">OK</button></div>';
  document.body.appendChild(o);const close=()=>o.remove();o.querySelector('#ariPatchOk').onclick=close;o.onclick=e=>{if(e.target===o)close();};
}
async function doUpdate(){track('update_install');
  if(!updInfo)return;const P=Capacitor.Plugins.ApkInstaller;$('#updProg').textContent='Lade …';$('#updBannerText').textContent='Lade Update …';
  try{
    P.addListener('progress',e=>{const t='Lade '+e.percent+' %';$('#updProg').textContent=t;$('#updBannerText').textContent=t;});
    await P.install({url:updateBase()+(updInfo.apk||'ARI.apk')});
    $('#updProg').textContent='Installation gestartet – bestätige „Aktualisieren“.';
  }catch(e){
    if(String(e&&e.message||e).includes('permission')){$('#updProg').textContent='Erlaube A.R.I einmal „Apps installieren“ in dem Fenster, das sich geöffnet hat – und tippe dann nochmal auf Aktualisieren.';}
    else $('#updProg').textContent='Fehler: '+(e&&e.message||e);
  }
}
if(NATIVE){$('#updPanel').style.display='';}

/* ---------- Einführung beim ersten Start (und jederzeit wiederholbar: Einstellungen > DATEN) ---------- */
const TOUR_STEPS=[
  {t:'Willkommen bei A.R.I',x:'Ich bin dein persönlicher KI-Assistent – auf dem Handy und zusammen mit deinem PC. In wenigen Schritten zeige ich dir, wie alles funktioniert. Du kannst jederzeit überspringen.'},
  {tab:'chat',sel:'#msg',parent:true,t:'Schreiben oder sprechen',x:'Tippe hier einen Befehl ein oder drücke das Mikrofon 🎤 und sprich einfach. Frag mich etwas, lass dir Routen planen oder Dinge merken.'},
  {tab:'chat',sel:'#t-chat .chips',t:'Schnellbefehle',x:'Mit diesen Knöpfen startest du häufige Fragen mit einem Tipp – du musst nur noch das Ende ergänzen.'},
  {tab:'set',sel:'#sKey',open:true,t:'Zuerst: KI-Schlüssel',x:'Damit ich antworten kann, brauche ich einen kostenlosen Schlüssel von einem KI-Anbieter (z. B. Groq oder Gemini). Wähle oben den Anbieter und trage hier den Schlüssel ein. Er bleibt nur auf diesem Handy.'},
  {tab:'pc',sel:'#qrScan',t:'Mit dem PC verbinden',x:'Wenn du A.R.I auch am PC nutzt: Am PC unter Einstellungen → HANDY den QR-Code zeigen und hier scannen. Dann steuerst du deinen PC (Musik, Lautstärke, Programme) per Sprache vom Handy aus.'},
  {tab:'cal',sel:'nav [data-t=cal]',t:'Termine & Mails',x:'Hier siehst du deine Termine und wichtige E-Mails. Melde dich dazu in den Einstellungen mit Google an.'},
  {tab:'brain',sel:'nav [data-t=brain]',t:'Das Gehirn',x:'Alles, was ich mir über dich merken soll (Vorlieben, Namen, Gewohnheiten), steht hier. Du kannst es jederzeit ansehen, ändern und löschen.'},
  {tab:'set',sel:'#notifFwdMsg',open:true,t:'Handy-Meldungen am PC',x:'Wenn du möchtest, schicke ich Benachrichtigungen deines Handys (z. B. WhatsApp) an den PC. Das erlaubst du einmal in den Android-Einstellungen – und kannst Apps jederzeit als Spam sperren.'},
  {tab:'set',sel:'#updPanel',open:true,t:'Updates',x:'Die App sucht beim Start selbst nach neuen Versionen. Mit „Jetzt aktualisieren“ installierst du sie mit einem Tipp.'},
  {tab:'chat',t:'Fertig!',x:'Das war es schon. Sag einfach „Hallo“ oder stell mir eine Frage. Diese Einführung findest du jederzeit wieder unter Einstellungen → DATEN → „Einführung ansehen“.'}
];
let tourI=0,tourEl=null;
function tourEnd(){try{localStorage.setItem('ari_tour_done','1');}catch(e){}if(tourEl){tourEl.remove();tourEl=null;}goTab('chat');}
function tourShow(i){
  tourI=Math.max(0,Math.min(TOUR_STEPS.length-1,i));const st=TOUR_STEPS[tourI];
  if(st.tab)goTab(st.tab);
  let target=st.sel?$(st.sel):null;
  if(target&&st.parent)target=target.parentElement;
  if(target&&!target.getClientRects().length)target=null;   // nicht sichtbar (z. B. Android-only-Bereich im Browser) -> Karte ohne Markierung
  if(target&&st.open){const d=target.closest('details');if(d)d.open=true;}
  if(!tourEl){tourEl=document.createElement('div');tourEl.id='tourOv';tourEl.style.cssText='position:fixed;inset:0;z-index:99990;';document.body.appendChild(tourEl);}
  const last=tourI===TOUR_STEPS.length-1;
  const dots=TOUR_STEPS.map((_,k)=>'<i style="display:inline-block;width:'+(k===tourI?'16':'6')+'px;height:6px;border-radius:3px;margin:0 2px;background:'+(k===tourI?'#ff2d78':'rgba(255,255,255,.25)')+'"></i>').join('');
  const render=()=>{
    let hole='';let pos='mid';
    if(target){const r=target.getBoundingClientRect();
      hole='<div style="position:fixed;left:'+(r.left-6)+'px;top:'+(r.top-6)+'px;width:'+(r.width+12)+'px;height:'+(r.height+12)+'px;border-radius:12px;border:2px solid #ff2d78;box-shadow:0 0 0 9999px rgba(2,2,8,.78),0 0 22px rgba(255,45,120,.6);pointer-events:none;transition:all .25s"></div>';
      pos=(r.top+r.height/2>innerHeight*0.5)?'top':'bottom';}
    else hole='<div style="position:fixed;inset:0;background:rgba(2,2,8,.78)"></div>';
    const cardPos=pos==='top'?'top:calc(env(safe-area-inset-top) + 14px)':pos==='bottom'?'bottom:calc(env(safe-area-inset-bottom) + 84px)':'top:50%;transform:translateY(-50%)';
    tourEl.innerHTML=hole+'<div style="position:fixed;left:14px;right:14px;'+cardPos+';max-width:440px;margin:0 auto;border-radius:16px;border:1px solid rgba(255,45,120,.5);background:linear-gradient(165deg,#1a1626,#0a0912);padding:18px 18px 14px;color:#e8e6f5;box-shadow:0 20px 60px -10px #000">'+
      '<div style="font:700 12px var(--font-mono,monospace);letter-spacing:.14em;color:#fff">'+st.t.toUpperCase()+'</div>'+
      '<div style="margin-top:8px;font-size:13.5px;line-height:1.55;opacity:.92">'+st.x+'</div>'+
      '<div style="margin-top:12px;text-align:center">'+dots+'</div>'+
      '<div style="display:flex;gap:8px;margin-top:12px">'+(tourI>0?'<button type="button" class="btn" id="tourBack" style="flex:0 0 auto">ZURÜCK</button>':'')+
      '<button type="button" class="btn pri" id="tourNext" style="flex:1">'+(last?'LOS GEHT’S':'WEITER')+'</button></div>'+
      (last?'':'<div style="text-align:center;margin-top:10px"><a href="#" id="tourSkip" style="color:inherit;opacity:.6;font-size:12px">Einführung überspringen</a></div>')+'</div>';
    const nx=$('#tourNext'),bk=$('#tourBack'),sk=$('#tourSkip');
    if(nx)nx.onclick=()=>last?tourEnd():tourShow(tourI+1);if(bk)bk.onclick=()=>tourShow(tourI-1);if(sk)sk.onclick=e=>{e.preventDefault();tourEnd();};
  };
  if(target){try{target.scrollIntoView({block:'center'});}catch(e){}setTimeout(render,320);}else render();
}
function tourStart(){tourShow(0);}
window.addEventListener('resize',()=>{if(tourEl)tourShow(tourI);});
{const btn=document.getElementById('tourReplay');if(btn)btn.onclick=()=>{goTab('chat');tourStart();};
setTimeout(()=>{
  let done=false;try{done=localStorage.getItem('ari_tour_done')==='1';}catch(e){}
  if(done)return;
  // Wer die App schon eingerichtet hat (Schluessel/PC/Anmeldung vorhanden), bekommt die Einfuehrung nicht aufgezwungen
  const hasKey=Object.values(cfg.keys||{}).some(v=>v&&(Array.isArray(v)?v.some(Boolean):true));
  if(hasKey||(pcs&&pcs.length)||(sync&&sync.origin)||gTok){try{localStorage.setItem('ari_tour_done','1');}catch(e){}return;}
  const pr=document.getElementById('pair');if(pr&&getComputedStyle(pr).display!=='none')return;
  tourStart();
},1800);}
/* ---------- DEV-Bereich (nur nach Freischaltung per Logo-Tipp + Passwort) ---------- */
async function devRefresh(){
  const box=$('#devInfo');if(!box)return;
  let v='?';try{if(NATIVE){const i=await Capacitor.Plugins.App.getInfo();v=i.version+' ('+i.build+')';}else v='Web';}catch(e){}
  let b='';try{const c=await appBuild();b=c?' · Build '+c.version:'';}catch(e){}
  const ep=await statsEndpoint();
  box.textContent='App-Version: '+v+b+'\nKanal: '+(isBeta()?'BETA':'normal')+'\nUpdate-Quelle: '+updateBase()+'\nStatistik: '+(STS.get('consent',true)===true?'an':'aus')+' · ID '+statsId().slice(0,8)+'\nStatistik-Adresse: '+(ep||'— keine —');
}
{const msg=t=>{const m=$('#devMsg');if(m){m.textContent=t;setTimeout(()=>{if(m.textContent===t)m.textContent='';},6000);}};
const on=(id,fn)=>{const e=$(id);if(e)e.onclick=fn;};
on('#devUpd',async()=>{msg('Suche …');try{await checkUpdate(true);msg('Update-Prüfung fertig (Ergebnis siehe APP-UPDATE).');}catch(e){msg('Fehler: '+e.message);}});
on('#devReload',()=>location.reload());
on('#devWeather',async()=>{msg('Hole Wetter …');msg(await weatherTool({days:2}));});
on('#devTour',()=>{goTab('chat');tourStart();});
on('#devVoice',async()=>{const v=cfg.voice||'edge:katja';msg('Teste '+v+' …');if(v==='device'||cfg.lang!=='de-DE'||!NATIVE){speakDevice('Hallo, ich bin A.R.I. Das ist die Handy-Stimme.');msg('Handy-Stimme gespielt.');return;}
  const t0=Date.now();try{await speakEdge('Hallo, ich bin A.R.I. Das ist die Stimme '+v.replace('edge:','')+'.',v);msg('Edge-Stimme ok ('+(Date.now()-t0)+' ms).');}catch(e){msg('Edge-Stimme nicht erreichbar ('+(e.message||e)+') - Handy-Stimme als Ersatz.');speakDevice('Hallo, ich bin A.R.I. Das ist die Handy-Stimme.');}});
on('#devStSend',async()=>{msg('Sende …');const ok=await statsSend();msg(ok?'Statistik gesendet.':'Nicht gesendet (aus, keine Adresse oder kein Internet).');});
on('#devStPv',()=>statsPreviewShow());
on('#devStOpen',async()=>{const ep=await statsEndpoint(),k=($('#devKey').value||'').trim();if(!ep||!k){msg('Adresse oder Schlüssel fehlt.');return;}window.open(ep+'/?key='+encodeURIComponent(k),'_system');});
on('#devOff',()=>{try{localStorage.removeItem('ari_dev');localStorage.removeItem('ari_channel');}catch(e){}location.reload();});}
{const row=$('#devSecM'),tg=document.querySelector('header .logo');const devOn=()=>{try{return localStorage.getItem('ari_dev')==='1'||isBeta();}catch(e){return false;}};
if(row&&devOn()){row.style.display='';devRefresh();}
// Entwickler-Zugang: 5x auf das A.R.I-Logo oben tippen, dann das gleiche Dev-Passwort wie im PC-HUD (nur der SHA-256-Hash steckt in der App)
const DEV_HASH='15200a1b9681095bdf23698fe79043c210be5040d945a1df527ce834eecf8e5d';
const askDev=()=>new Promise(res=>{const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.7)';
o.innerHTML='<form autocomplete="off" style="background:#14111f;border:1px solid #444;border-radius:14px;padding:18px;width:min(320px,86vw)"><div style="font:600 12px monospace;letter-spacing:.14em;margin-bottom:10px">DEV-PASSWORT</div><input type="password" autocomplete="new-password" style="width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #555;background:#0c0a15;color:#fff;font-size:16px"><div style="display:flex;gap:8px;margin-top:12px;justify-content:flex-end"><button type="button" class="btn" data-x>ABBRECHEN</button><button type="submit" class="btn pri">OK</button></div></form>';
document.body.appendChild(o);const inp=o.querySelector('input');const done=v=>{o.remove();res(v);};
o.querySelector('form').onsubmit=e=>{e.preventDefault();done(inp.value);};o.querySelector('[data-x]').onclick=()=>done(null);setTimeout(()=>inp.focus(),30);});
const sha256=async t=>{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');};
if(tg){let n=0,t=0;tg.addEventListener('click',()=>{const now=Date.now();n=now-t<2500?n+1:1;t=now;if(n>=5){n=0;askDev().then(async pw=>{if(!pw)return;let ok=false;try{ok=(await sha256(pw))===DEV_HASH;}catch(e){}
if(ok){try{localStorage.setItem('ari_dev','1');}catch(e){}if(row){row.style.display='';devRefresh();row.open=true;}alert('Entwickler-Modus freigeschaltet - Einstellungen > DEV.');}else alert('Falsches Passwort.');});}});}}
{const bc=$('#betaChan');if(bc){bc.checked=isBeta();bc.onchange=()=>{try{bc.checked?localStorage.setItem('ari_channel','beta'):localStorage.removeItem('ari_channel');}catch(e){}$('#updVer').textContent=bc.checked?'BETA':'–';checkUpdate(true);};}}
$('#updCheck').onclick=()=>checkUpdate(true);$('#updGo').onclick=doUpdate;$('#updBannerGo').onclick=doUpdate;$('#updBannerLater').onclick=()=>{$('#updBanner').style.display='none';};
if(NATIVE){setTimeout(()=>checkUpdate(false),1500);setInterval(()=>checkUpdate(false),3600*1000);}
/* ---------- QR-Code vom PC scannen ---------- */
let qrStream=null,qrRaf=0;
async function qrStart(){
  const ov=$('#qrOv');ov.style.display='flex';$('#qrMsg').textContent='Kamera wird gestartet …';
  const fail=(m)=>{qrStop();$('#pcMsg').textContent=m+' Du kannst auch ohne QR-Code koppeln: nur den Koppelcode eintragen.';alert(m);};
  const AW=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;
  if(AW&&AW.camRequest){                                   // Android-Berechtigung ausdruecklich anfragen (sonst bleibt die Kamera einfach schwarz)
    try{const r=await AW.camRequest();if(!r.granted){fail('Die Kamera-Berechtigung fehlt. Handy-Einstellungen → Apps → A.R.I → Berechtigungen → Kamera erlauben.');return;}}catch(e){}
  }
  try{
    qrStream=await Promise.race([navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false}),new Promise((_,rej)=>setTimeout(()=>rej(Object.assign(new Error('timeout'),{name:'Timeout'})),9000))]);
  }catch(e){
    fail(e&&e.name==='NotFoundError'?'Keine Kamera gefunden.':e&&e.name==='NotReadableError'?'Die Kamera wird gerade von einer anderen App benutzt.':e&&e.name==='Timeout'?'Die Kamera startet nicht (keine Antwort).':'Kamera nicht erlaubt ('+(e&&e.name||'?')+').');return;
  }
  $('#qrMsg').textContent='Richte die Kamera auf den QR-Code am PC (Einstellungen → HANDY).';
  const v=$('#qrVid');v.srcObject=qrStream;await v.play().catch(()=>{});
  const c=document.createElement('canvas'),x=c.getContext('2d',{willReadFrequently:true});let n=0;
  const tick=()=>{
    if(!qrStream)return;
    if(v.videoWidth&&(n++%3===0)){
      const sc=Math.min(1,640/v.videoWidth);c.width=Math.round(v.videoWidth*sc);c.height=Math.round(v.videoHeight*sc);x.drawImage(v,0,0,c.width,c.height);
      const d=x.getImageData(0,0,c.width,c.height),r=window.jsQR&&jsQR(d.data,d.width,d.height);
      if(r&&r.data){
        const A=parseAnyLink(r.data);
        if(A){qrStop();pairFromLink(A.origin,A.code);return;}
        $('#qrMsg').textContent='Das ist kein A.R.I-QR-Code.';
      }
    }
    qrRaf=requestAnimationFrame(tick);
  };
  tick();
}
function qrStop(){cancelAnimationFrame(qrRaf);if(qrStream){qrStream.getTracks().forEach(t=>t.stop());qrStream=null;}$('#qrOv').style.display='none';}
$('#qrScan').onclick=qrStart;$('#qrClose').onclick=qrStop;

/* ---------- Hintergrund-Betrieb (nur Android-App, optional): am Leben bleiben + Benachrichtigungen ---------- */
const BGP=()=>window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;
async function bgRefresh(){
  if(!NATIVE||!BGP()||!BGP().bgStatus)return;$('#bgSection').style.display='';
  try{const s=await BGP().bgStatus();$('#bgTag').textContent=s.running?'AN':'AUS';$('#bgToggle').textContent=s.running?'AUSSCHALTEN':'EINSCHALTEN';
    $('#bgMsg').textContent=(s.notif?'':'Bitte erlaube A.R.I Benachrichtigungen (Handy-Einstellungen → Apps → A.R.I). ')+(s.battery?'':'Tipp: Stelle die Akku-Optimierung für A.R.I auf „Nicht optimieren“, sonst beendet Android die App manchmal trotzdem.');}catch(e){}
}
async function bgNotify(title,text,id){try{if(BGP()&&BGP().notify)await BGP().notify({title,text,id});}catch(e){}}
// Neue Mails und bald anstehende Termine melden (jeweils nur einmal)
async function bgCheck(){
  if(cfg.bg!=='1')return;
  try{await loadCalData();}catch(e){return;}
  if(!calCache)return;
  const seenM=store.get('ari-app-seenmail',null),ids=(calCache.mails||[]).map(m=>String(m.id||m.from+m.subject));
  if(seenM===null){store.set('ari-app-seenmail',ids.slice(-300));}      // beim ersten Mal nichts melden
  else{
    const fresh=(calCache.mails||[]).filter(m=>!seenM.includes(String(m.id||m.from+m.subject)));
    if(fresh.length)bgNotify(fresh.length===1?'Neue Mail: '+fresh[0].from:fresh.length+' neue Mails',fresh.slice(0,3).map(m=>m.from+': '+(m.subject||'')).join('\n'),7001);
    store.set('ari-app-seenmail',[...new Set(seenM.concat(ids))].slice(-300));
  }
  const notified=store.get('ari-app-notified',{}),now=Date.now(),keep={};
  (calCache.events||[]).forEach(e=>{
    if(e.allDay)return;const st=new Date(e.start).getTime(),k=e.title+'|'+e.start,mins=Math.round((st-now)/60000);
    if(mins>=-5&&mins<=45&&!notified[k]){bgNotify('Termin '+(mins<=1?'jetzt':'in '+mins+' Min.')+': '+e.title,new Date(st).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' Uhr'+(e.location?' · '+e.location:''),8000+(st%1000));notified[k]=now;}
    if(notified[k]&&now-notified[k]<86400000)keep[k]=notified[k];
  });
  store.set('ari-app-notified',keep);
}
if(NATIVE&&BGP()&&BGP().bgStatus){
  $('#bgToggle').onclick=async()=>{
    const s=await BGP().bgStatus();
    if(s.running){await BGP().bgStop();cfg.bg='0';saveCfg();}
    else{try{await BGP().bgStart();cfg.bg='1';saveCfg();setTimeout(bgCheck,4000);}catch(e){$('#bgMsg').textContent='Konnte nicht starten: '+(e&&e.message||e);}}
    bgRefresh();
  };
  $('#bgBattery').onclick=()=>{try{BGP().openBatterySettings();}catch(e){}};
  bgRefresh();
  try{Capacitor.Plugins.App.addListener('appStateChange',st=>{if(st.isActive)bgRefresh();});}catch(e){}
  setInterval(bgCheck,5*60*1000);
  if(cfg.bg==='1')BGP().bgStatus().then(s=>{if(!s.running)BGP().bgStart().then(bgRefresh).catch(()=>{});else setTimeout(bgCheck,8000);});
}
/* ---------- Weckwort im Hintergrund (nur Android-App, optional) ---------- */
const WK=()=>window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;
async function wakeRefresh(){
  if(!NATIVE||!WK())return;$('#wakeSection').style.display='';
  try{const s=await WK().status();$('#wakeTag').textContent=s.running?'AN':'AUS';$('#wakeToggle').textContent=s.running?'AUSSCHALTEN':'EINSCHALTEN';
    $('#wakeMsg').textContent=s.overlay?'':'Tipp: Erlaube „Über anderen Apps“, damit sich A.R.I von selbst nach vorne holen darf.';}catch(e){}
}
async function wakeStart(){
  const SRP=Capacitor.Plugins.SpeechRecognition;
  try{if(SRP){const p=await SRP.requestPermissions();if(p.speechRecognition!=='granted'){$('#wakeMsg').textContent='Bitte erlaube A.R.I das Mikrofon.';return false;}}}catch(e){}
  try{await WK().start();return true;}catch(e){$('#wakeMsg').textContent=String(e&&e.message||e)==='mic_permission'?'Bitte erlaube A.R.I das Mikrofon.':'Konnte nicht starten: '+(e&&e.message||e);return false;}
}
if(NATIVE&&WK()){
  $('#wakeToggle').onclick=async()=>{
    const s=await WK().status();
    if(s.running){await WK().stop();cfg.wake='0';saveCfg();}
    else if(await wakeStart()){cfg.wake='1';saveCfg();}
    wakeRefresh();
  };
  $('#wakeOverlay').onclick=()=>WK().openOverlaySettings();
  // Vom Weckwort geoeffnet -> sofort zuhoeren
  const wakeCheck=async()=>{try{const r=await WK().consumeWake();if(r&&r.wake){goTab('chat');setTimeout(mic,400);}}catch(e){}};
  try{Capacitor.Plugins.App.addListener('appStateChange',st=>{if(st.isActive){wakeCheck();wakeRefresh();}});}catch(e){}
  wakeRefresh();wakeCheck();
  if(cfg.wake==='1')WK().status().then(s=>{if(!s.running)wakeStart().then(wakeRefresh);});
}
/* ---------- Handy-Benachrichtigungen am PC (nur Android-App, optional) ---------- */
async function notifFwdRefresh(){
  if(!NATIVE||!BGP()||!BGP().isNotificationAccessEnabled)return;$('#notifFwdSection').style.display='';
  try{
    const s=await BGP().isNotificationAccessEnabled();
    $('#notifFwdTag').textContent=s.enabled?'AN':'AUS';
    $('#notifFwdBtn').textContent=s.enabled?'ZUGRIFF VERWALTEN':'BENACHRICHTIGUNGSZUGRIFF ERLAUBEN';
    $('#notifFwdMsg').textContent=s.enabled?'Aktiv – Benachrichtigungen anderer Apps werden an den gekoppelten PC geschickt.':'Noch nicht erlaubt. Nach dem Antippen A.R.I in der Liste einschalten.';
    if(s.enabled)pushSyncCreds();
  }catch(e){}
}
if(NATIVE&&BGP()&&BGP().openNotificationAccessSettings){
  $('#notifFwdBtn').onclick=()=>{try{BGP().openNotificationAccessSettings();}catch(e){}};
  try{Capacitor.Plugins.App.addListener('appStateChange',st=>{if(st.isActive)notifFwdRefresh();});}catch(e){}
  notifFwdRefresh();
}
function showNotifPrompt(){
  const old=document.getElementById('ariNotifPrompt');if(old)old.remove();
  const o=document.createElement('div');o.id='ariNotifPrompt';
  o.style.cssText='position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6)';
  o.innerHTML='<div style="max-width:420px;width:90%;padding:20px 24px;border:1px solid #00d4ff;border-radius:10px;background:#0b1620;color:#dff6ff"><div style="letter-spacing:.2em;font-size:12px;opacity:.7">HANDY-BENACHRICHTIGUNGEN AM PC</div><div style="font-size:15px;line-height:1.5;margin:10px 0 16px">Soll A.R.I deine Handy-Benachrichtigungen (WhatsApp, Discord, …) auch am PC anzeigen? Dafuer einmal in den Android-Einstellungen erlauben.</div><div style="display:flex;gap:8px"><button type="button" id="ariNotifPromptLater" style="flex:1;padding:10px;border:1px solid #2a3a44;background:transparent;color:#8fb0bb;border-radius:6px">SPÄTER</button><button type="button" id="ariNotifPromptGo" style="flex:1;padding:10px;border:1px solid #00d4ff;background:transparent;color:#dff6ff;border-radius:6px">ERLAUBEN</button></div></div>';
  document.body.appendChild(o);const close=()=>o.remove();
  o.querySelector('#ariNotifPromptLater').onclick=close;
  o.querySelector('#ariNotifPromptGo').onclick=()=>{try{BGP().openNotificationAccessSettings();}catch(e){}close();};
  o.onclick=e=>{if(e.target===o)close();};
}
if(NATIVE&&BGP()&&BGP().isNotificationAccessEnabled&&!localStorage.getItem('ari_notif_prompt_shown')){
  localStorage.setItem('ari_notif_prompt_shown','1');
  BGP().isNotificationAccessEnabled().then(s=>{if(!s.enabled)setTimeout(showNotifPrompt,1200);}).catch(()=>{});
}
/* ---------- Start ---------- */
refreshReady();
loadSet();
addMsg('a','Hallo! Ich bin A.R.I – diese App läuft auch ohne PC. '+(cfg.keys[cfg.provider]?'Sag oder tipp mir, was ich tun soll.':'Trage zuerst in den Einstellungen einen KI-Schlüssel ein (oder übernimm die Datei vom PC).'));
if('serviceWorker' in navigator&&!NATIVE){navigator.serviceWorker.register('sw.js').catch(()=>{});}

/* ---------- Nachrichten & Anrufe ansagen (Handy, solange die App offen ist) ---------- */
(function announceNotifs(){
  let since=-1,seen=new Set(),queue=[],busy=false;
  const on=()=>cfg.announce!=='0';
  const btn=$('#announceBtn');
  const paint=()=>{if(btn)btn.textContent='ANSAGEN: '+(on()?'AN':'AUS');};
  if(btn)btn.onclick=()=>{cfg.announce=on()?'0':'1';saveCfg();paint();};
  paint();
  async function poll(){
    if(!on()||!sync.token||!sync.origin||document.hidden)return;
    try{
      const r=await fetch(sync.origin+'/phone/notifications?since='+Math.max(0,since),{headers:{'X-Ari-Token':sync.token}});
      if(!r.ok)return;const d=await r.json();const items=d.items||[];
      if(since<0){items.forEach(n=>seen.add(n.id));since=items.reduce((m,n)=>Math.max(m,n.ts),Math.floor(Date.now()/1000));return;}   // erster Abruf: nur merken, nichts ansagen
      items.forEach(n=>{since=Math.max(since,n.ts);if(seen.has(n.id))return;seen.add(n.id);queue.push(n);});
      while(queue.length>3)queue.shift();
      next();
    }catch(e){}
  }
  function text(n){
    const all=(n.app||'')+' '+(n.title||'')+' '+(n.text||'');
    const call=/anruf|ruft an|incoming call/i.test(all)&&/anruf|call|ruft/i.test((n.title||'')+' '+(n.text||''));
    if(!call&&!/whatsapp|discord|telegram|signal|messenger|threema|messages|nachrichten|\bsms\b|\bmms\b|teams|slack|skype|viber|\bline\b|wechat|snapchat|instagram|element|matrix|google chat|\bchat\b|telefon|phone|anruf|dialer/i.test(String(n.app||'')))return null;   // nur Messenger und Anrufe
    if(/instagram/i.test(String(n.app||''))&&(!n.can_reply||/gefällt|liked|folgt|follow|kommentiert|comment|erwähnt|mentioned|hat dein|your (photo|post|reel|story)|reel|story|vorgeschlagen|suggested/i.test(String(n.title||'')+' '+String(n.text||''))))return null;   // Instagram: nur Chat-Nachrichten
    if(call)return{t:'Eingehender Anruf'+(n.title?' von '+n.title:'')+'.',ask:false};
    const app=String(n.app||'').replace(/\s*\(Test\)\s*$/i,'');
    let body=String(n.text||'').replace(/\s+/g,' ').trim();if(body.length>600)body=body.slice(0,600)+' …';
    let t='Neue Nachricht'+(n.title?' von '+n.title:'')+(app?' auf '+app:'')+(body?': '+body:'.');
    if(!/[.!?…]$/.test(t))t+='.';
    if(n.can_reply)t+=' Soll ich antworten?';
    return{t,ask:!!n.can_reply};
  }
  function next(){
    if(busy||!queue.length)return;
    if($('#orb').classList.contains('busy'))return;
    const n=queue.shift(),x=text(n);if(!x){next();return;}busy=true;
    addMsg('a',x.t);hist.push({role:'assistant',content:x.t});if(hist.length>20)hist.splice(0,hist.length-20);
    $('#log').scrollTop=1e9;speak(x.t);
    if(x.ask){replyCtxUntil=Date.now()+120000;setTimeout(()=>{busy=false;mic();},1200+x.t.length*70);}   // erst ausreden lassen, dann zuhoeren
    else setTimeout(()=>{busy=false;next();},800+x.t.length*60);
  }
  setInterval(poll,5000);setTimeout(poll,3000);
})();

// ---- Neu in 1.6.75: Timer, Automationen und Bildschirm am PC ----
(function(){
  const G=id=>document.getElementById(id);
  const hdr=()=>({'Content-Type':'application/json','X-Ari-Token':sync.token});
  const linked=()=>!!(sync&&sync.token&&sync.origin);
  async function api(path,body){
    const r=await hubFetch(path,body===undefined?{headers:hdr()}:{method:'POST',headers:hdr(),body:JSON.stringify(body)});
    if(!r.ok){const e=new Error('http '+r.status);e.status=r.status;throw e;}
    return r.json();
  }
  function row(title,sub,btns){
    const d=document.createElement('div');d.className='pcn-row';
    const l=document.createElement('div');const b=document.createElement('b');b.textContent=title;l.appendChild(b);
    if(sub){const s=document.createElement('small');s.textContent=sub;l.appendChild(s);}
    d.appendChild(l);const r=document.createElement('div');r.style.cssText='display:flex;gap:6px;align-items:center';
    (btns||[]).forEach(x=>r.appendChild(x));d.appendChild(r);return d;
  }
  function btn(txt,fn,cls){const b=document.createElement('button');b.type='button';b.textContent=txt;b.className=cls||'pcn-x';if(!cls)b.style.fontSize='12px';b.onclick=fn;return b;}
  const fmt=s=>{s=Math.max(0,Math.round(s));const d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60),x=s%60,p=n=>String(n).padStart(2,'0');return (d?d+'T ':'')+(h||d?h+':'+p(m)+':'+p(x):p(m)+':'+p(x));};
  // ---------- Timer ----------
  let tmList=[],tmOff=0;
  async function tmLoad(){
    const box=G('pcTmList');if(!box)return;
    if(!linked()){box.textContent='Verbinde dich mit dem PC.';return;}
    try{const d=await api('/phone/api/timers');tmOff=(d.now||Date.now())-Date.now();tmList=d.timers||[];tmDraw();}catch(e){box.textContent='PC nicht erreichbar.';}
  }
  function tmDraw(){
    const box=G('pcTmList');if(!box||!G('pcTmSec').open)return;
    if(!tmList.length){box.textContent='Gerade läuft kein Timer und keine Erinnerung.';box.className='dim';return;}
    box.className='';box.textContent='';
    const now=(Date.now()+tmOff)/1000;
    tmList.slice().sort((x,y)=>x.due-y.due).forEach(t=>{
      const left=t.due-now,late=left<0;
      box.appendChild(row((t.kind==='reminder'?'Erinnerung: ':'Timer: ')+(t.label||'ohne Namen'),late?'war fällig vor '+fmt(-left):'noch '+fmt(left),
        [btn('✕',async()=>{try{await api('/phone/api/timers/done',{id:t.id});}catch(e){}tmLoad();})]));
    });
  }
  async function tmAdd(kind){
    const min=parseFloat(G('pcTmMin').value),msg=G('pcTmMsg');
    if(!(min>0)){msg.textContent='Bitte Minuten eintragen.';return;}
    try{const d=await api('/phone/api/timers/add',{seconds:Math.round(min*60),label:G('pcTmLbl').value.trim(),kind});msg.textContent=d.message||'Gestellt.';G('pcTmMin').value='';tmLoad();}
    catch(e){msg.textContent='Das hat nicht geklappt – ist der PC erreichbar?';}
  }
  // ---------- Automationen ----------
  async function auLoad(){
    const box=G('pcAuList');if(!box)return;
    if(!linked()){box.textContent='Verbinde dich mit dem PC.';return;}
    let d;try{d=await api('/phone/api/automations');}catch(e){
      box.className='dim';box.textContent=e.status===404?'Der Mod „Automationen“ ist am PC nicht installiert (PC: Einstellungen › MODS).':'PC nicht erreichbar.';return;}
    const rules=d.rules||[];box.textContent='';box.className='';
    if(!rules.length){box.className='dim';box.textContent='Noch keine Automationen.';return;}
    rules.forEach(r=>{
      const on=document.createElement('input');on.type='checkbox';on.checked=r.enabled!==false;on.style.cssText='width:auto;accent-color:var(--pink)';
      on.onchange=async()=>{try{await api('/phone/api/automations/toggle',{id:r.id,enabled:on.checked});}catch(e){}};
      box.appendChild(row(r.name,r.text||'',[on,btn('TEST',async()=>{try{await api('/phone/api/automations/test',{id:r.id});}catch(e){}},'pcn-x'),btn('✕',async()=>{if(!confirm('Automation „'+r.name+'“ löschen?'))return;try{await api('/phone/api/automations/delete',{id:r.id});}catch(e){}auLoad();})]));
    });
  }
  async function pcChat(text){
    const r=await hubFetch('/phone/api/chat',{timeout:150000,method:'POST',headers:hdr(),body:JSON.stringify({messages:[{role:'user',content:text}]})});
    if(!r.ok)throw new Error('http '+r.status);const d=await r.json();return String(d.reply||'').trim();
  }
  async function auNew(){
    const t=G('pcAuSay').value.trim(),msg=G('pcAuMsg');
    if(t.length<8){msg.textContent='Bitte die Regel in ganzen Worten schreiben.';return;}
    msg.textContent='Der PC legt die Regel an …';
    try{const a=await pcChat('Lege eine Automation an: '+t);msg.textContent=a||'Erledigt.';G('pcAuSay').value='';auLoad();}
    catch(e){msg.textContent='Das hat nicht geklappt – ist der PC erreichbar?';}
  }
  // ---------- Bildschirm ----------
  async function scrGo(){
    const out=G('pcScrOut'),q=G('pcScrQ').value.trim(),b=G('pcScrGo');
    if(!linked()){out.textContent='Verbinde dich zuerst mit dem PC.';return;}
    b.disabled=true;out.textContent='A.R.I schaut auf den PC-Bildschirm …';
    try{out.textContent=await pcChat('Schau auf den Bildschirm und '+(q||'erkläre, was ich sehe und was ich als Nächstes tun sollte')+'.')||'Keine Antwort.';}
    catch(e){out.textContent='Das hat nicht geklappt – ist der PC erreichbar?';}
    b.disabled=false;
  }
  G('pcTmAdd').onclick=()=>tmAdd('timer');G('pcTmRem').onclick=()=>tmAdd('reminder');
  G('pcAuNew').onclick=auNew;G('pcScrGo').onclick=scrGo;
  G('pcTmSec').addEventListener('toggle',()=>{if(G('pcTmSec').open)tmLoad();});
  G('pcAuSec').addEventListener('toggle',()=>{if(G('pcAuSec').open)auLoad();});
  setInterval(()=>{if(G('pcTmSec').open){tmDraw();}},1000);
  setInterval(()=>{if(G('pcTmSec').open&&document.visibilityState==='visible')tmLoad();},8000);
  // ---------- goldene NEU-Abzeichen (nach einem Update) ----------
  const NEW_REL=105;
  let nb=store.get('ari-app-newbase',null);
  if(nb==null){nb=(sync&&sync.token)?NEW_REL-1:NEW_REL;store.set('ari-app-newbase',nb);}   // frisch installiert (noch nicht gekoppelt): kein NEU
  const seenSet=()=>new Set(store.get('ari-app-newseen',[]));
  const pills=[];
  function pill(extra){const p=document.createElement('span');p.className='newg'+(extra?' '+extra:'');p.textContent='NEU';return p;}
  function markSeen(id){const s=seenSet();s.add(id);store.set('ari-app-newseen',[...s]);document.querySelectorAll('.newg[data-newid="'+id+'"]:not(.newg-nav)').forEach(p=>p.remove());
    if(!document.querySelector('#pcNew .newg,#appNew .newg')){G('pcNewTag').style.display='none';document.querySelectorAll('.newg-nav').forEach(p=>p.remove());}}
  [['appNewSec','app-tools'],['pcTmSec','app-timer'],['pcAuSec','app-automationen'],['pcScrSec','app-bildschirm']].forEach(([sec,id])=>{
    if(NEW_REL<=nb||seenSet().has(id)){return;}
    const sum=G(sec).querySelector('summary'),p=pill();p.dataset.newid=id;sum.appendChild(p);
    G(sec).addEventListener('toggle',()=>{if(G(sec).open)markSeen(id);});pills.push(id);
  });
  if(!pills.length){G('pcNewTag').style.display='none';}
  else{const nav=document.querySelector('nav button[data-t="pc"]');if(nav){const p=pill('newg-nav');p.dataset.newid=pills[0];nav.appendChild(p);}}
})();

// ---- Neu: Termin-Erinnerungen auf dem Handy (Ansage in der App + Wecker-Timer, wenn die App zu ist) ----
(function(){
  const KEY='ari-app-reminded',LEADS=[1440,60,30,5];
  const getSt=()=>store.get(KEY,{});
  const putSt=o=>{const cut=Date.now()-3*86400000;Object.keys(o).forEach(k=>{if(o[k]<cut)delete o[k];});store.set(KEY,o);};
  const enabled=()=>cfg.remind!==false;
  const clock=d=>d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
  const day0=d=>new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime();
  function when(e,mins){
    const dd=Math.round((day0(e.start)-day0(new Date()))/86400000),at=clock(e.start);
    if(mins>=1320)return (dd<=1?'morgen':dd===2?'übermorgen':'in '+dd+' Tagen')+' um '+at;
    if(mins>=90)return 'in '+Math.round(mins/60)+' Stunden';
    if(mins>=55)return 'in etwa einer Stunde';
    if(mins<=1)return 'gleich';
    return 'in '+mins+' Minuten';
  }
  function say(kind,e,mins){
    const loc=e.location?' – '+e.location:'';
    const t=kind==='now'?e.title+' beginnt jetzt'+loc+'.':kind==='allday'?'Heute ganztägig: '+e.title+'.':kind==='allday_pre'?'Morgen ganztägig: '+e.title+'.':'Erinnerung: '+e.title+' beginnt '+when(e,mins)+loc+'.';
    try{addMsg('a',t);hist.push({role:'assistant',content:t});if(hist.length>20)hist.splice(0,hist.length-20);const lg=document.getElementById('log');if(lg)lg.scrollTop=1e9;}catch(x){}
    try{toast(t);}catch(x){}
    try{speak(t);}catch(x){}
    try{if(navigator.vibrate)navigator.vibrate([200,100,200]);}catch(x){}
  }
  function items(){
    return ((calCache&&calCache.events)||[]).map(r=>{const s=new Date(r.start);return isNaN(s)?null:{title:r.title||'Termin',start:s,end:r.end?new Date(r.end):null,allDay:!!r.allDay,location:r.location||''};}).filter(Boolean);
  }
  function tick(){
    if(!enabled())return;
    const ev=items();if(!ev.length)return;
    const now=Date.now(),st=getSt(),today0=day0(new Date());let ch=false;
    for(const e of ev){
      if(e.allDay){
        const s0=day0(e.start),e0=Math.max(s0+86400000,e.end?day0(e.end):0);
        const k='ad:'+e.title+s0+':'+today0;
        if(s0<=today0&&e0>today0&&!st[k]){st[k]=now;ch=true;say('allday',e);}
        const kp='adpre:'+e.title+s0;   // Tag vorher ab 12 Uhr
        if(s0>today0&&s0-now>0&&s0-now<=12*3600000&&!st[kp]){st[kp]=now;ch=true;say('allday_pre',e);}
        continue;
      }
      const t=e.start.getTime(),diff=t-now,kNow='now:'+e.title+t;
      if(diff<=30000){if(diff>-5*60000&&!st[kNow]){st[kNow]=now;LEADS.forEach(L=>{st['pre'+L+':'+e.title+t]=now;});ch=true;say('now',e);}continue;}
      const app=LEADS.filter(L=>diff<=L*60000);if(!app.length)continue;
      const tight=app[app.length-1],kt='pre'+tight+':'+e.title+t;
      if(!st[kt]){app.forEach(L=>{st['pre'+L+':'+e.title+t]=now;});ch=true;say('pre',e,Math.max(1,Math.round(diff/60000)));}
    }
    if(ch)putSt(st);
  }
  // Wenn die App zu ist: Timer in der Uhr-App des Handys (klingelt von selbst)
  async function schedule(){
    const W=NATIVE&&window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.AriWake;if(!W||!W.setTimer||!enabled())return;
    const st=store.get('ari-app-evtimers',{}),now=Date.now();let n=0;
    Object.keys(st).forEach(k=>{if(st[k]<now-86400000)delete st[k];});
    for(const e of items()){
      if(n>=6)break;
      let at,label;
      if(e.allDay){const s0=day0(e.start);at=s0-12*3600000;label='Morgen: '+e.title;}
      else{at=e.start.getTime()-60*60000;label=e.title+' in 1 Stunde';}
      const secs=Math.round((at-now)/1000),k='tm:'+e.title+e.start.getTime();
      if(secs<60||secs>24*3600||st[k])continue;
      try{await W.setTimer({seconds:secs,label:label.slice(0,40)});st[k]=now;n++;}catch(x){}
    }
    store.set('ari-app-evtimers',st);
  }
  const cb=document.getElementById('appRemind');
  if(cb){cb.checked=enabled();cb.onchange=()=>{cfg.remind=cb.checked;saveCfg();if(cb.checked){tick();schedule();}};}
  setInterval(tick,30000);setTimeout(tick,4000);
  setInterval(schedule,10*60000);setTimeout(schedule,8000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){tick();}});
})();

})();
