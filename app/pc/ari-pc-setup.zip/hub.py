"""
A.R.I Hub — lokaler Backend-Server fuer das A.R.I Command Center.

Liefert das Dashboard aus und bedient den in "A.R.I HUD.html" dokumentierten
Vertrag:
    GET  /status -> echte Systemdaten via psutil (siehe unten, welche
                    Felder echt / geschaetzt / demo sind)
    POST /chat   -> body: { messages: [{role, content}, ...] }
                    resp: { reply, tools_used?: [...], error? }

/chat ruft die echte Anthropic-API mit Tool-Use auf, damit A.R.I den PC
tatsaechlich steuern kann (Lautstaerke/Medien, Apps oeffnen/schliessen,
Screenshot, Fenster) — siehe TOOLS/run_tool() unten. Ohne gesetzten
ANTHROPIC_API_KEY antwortet /chat mit einer klaren Hinweismeldung statt
einem Fehler, damit das Frontend trotzdem testbar bleibt.

Sprachausgabe laeuft komplett ueber die Browser-Stimmen des Frontends,
nicht ueber diesen Hub.

Start:
    pip install -r requirements.txt
    setx ANTHROPIC_API_KEY "dein-key"   (neues Terminal danach oeffnen)
    python hub.py
Dann im Browser http://127.0.0.1:5000 oeffnen (nicht die HTML-Datei direkt
per Doppelklick — nur ueber den Server sind /status und /chat erreichbar).
"""
import base64
import collections
import concurrent.futures
import datetime
import hashlib
import hmac
import imaplib
import json
import logging
import difflib
import os
import shlex
import shutil
import socket
import re
import smtplib
import subprocess
import sys
import threading
import time

# Wenn stdout nicht an eine echte Konsole angehaengt ist (z.B. gestartet aus
# einer Verknuepfung, per Start-Process ohne Konsolenfenster, oder umgeleitet),
# puffert Python print()-Ausgaben blockweise statt pro Zeile — die [timing]-/
# [chat]-Logs erscheinen dann stark verzoegert oder scheinbar gar nicht,
# obwohl der Request laengst verarbeitet wurde. Erzwingt sofortiges Anzeigen
# unabhaengig davon, wie hub.py gestartet wurde.
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass
import urllib.error

import tempfile
import uuid

import psutil
from flask import Flask, Response, jsonify, request, send_from_directory

# Plattform: Windows nutzt ctypes/PowerShell direkt in dieser Datei, Linux (X11) das Modul platform_linux.py.
IS_WIN = sys.platform == "win32"
_NOWIN = 0x08000000 if IS_WIN else 0   # CREATE_NO_WINDOW - unter Linux gibt es das Argument nicht
if IS_WIN:
    import winreg
else:
    winreg = None
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "linux"))
    import platform_linux as _lx

# Der Hub laeuft unsichtbar (ohne Konsole). Jedes Hilfsprogramm, das er startet (PowerShell, taskkill,
# piper.exe ...), wuerde sonst kurz ein CMD-/PowerShell-Fenster aufblitzen lassen. Deshalb starten ALLE
# Unterprozesse standardmaessig ohne eigenes Fenster. (Nur die Dev-Konsole setzt bewusst eigene Flags.)
if sys.platform == "win32":
    _orig_popen_init = subprocess.Popen.__init__

    def _popen_init_quiet(self, *args, **kwargs):
        if not kwargs.get("creationflags"):
            kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
        _orig_popen_init(self, *args, **kwargs)

    subprocess.Popen.__init__ = _popen_init_quiet

try:
    import anthropic
except ImportError:
    anthropic = None
try:
    from openai import OpenAI as _OpenAIClient
except ImportError:
    _OpenAIClient = None
try:
    from groq import Groq as _GroqClient
except ImportError:
    _GroqClient = None
try:
    from google.auth.transport.requests import Request as _GoogleAuthRequest
    from google.oauth2.credentials import Credentials as _GoogleCredentials
    from google_auth_oauthlib.flow import InstalledAppFlow as _GoogleInstalledAppFlow
    from googleapiclient.discovery import build as _google_api_build
    # Die Bibliothek schickt ihre Erfolgsseite nach dem Google-Login fest als text/plain -
    # damit unser eigenes, huebsch gestaltetes HTML (siehe _oauth_success_html) auch wirklich
    # als Seite gerendert wird statt als Rohtext, hier einmalig auf text/html umstellen.
    from google_auth_oauthlib import flow as _google_flow_mod
    def _redirect_wsgi_call_html(self, environ, start_response):
        import wsgiref.util as _wsgiref_util
        start_response("200 OK", [("Content-type", "text/html; charset=utf-8")])
        self.last_request_uri = _wsgiref_util.request_uri(environ)
        return [self._success_message.encode("utf-8")]
    _google_flow_mod._RedirectWSGIApp.__call__ = _redirect_wsgi_call_html
except ImportError:
    _GoogleAuthRequest = _GoogleCredentials = _GoogleInstalledAppFlow = _google_api_build = None

app = Flask(__name__)


def _oauth_success_html(title, subtitle):
    """Kleine, huebsch gestaltete Bestaetigungsseite (statt der nackten Standard-Textzeile),
    die nach einem erfolgreichen Google-/Spotify-Login im Browserfenster erscheint."""
    return f"""<!DOCTYPE html>
<html lang="de"><head><meta charset="UTF-8"><title>A.R.I</title>
<style>
  @keyframes ariFade{{from{{opacity:0;transform:translateY(10px)}}to{{opacity:1;transform:none}}}}
  @keyframes ariGlow{{0%,100%{{box-shadow:0 0 24px -4px color-mix(in srgb,#29d3f5 65%,transparent)}}50%{{box-shadow:0 0 40px 2px color-mix(in srgb,#ff2d78 55%,transparent)}}}}
  @keyframes ariPulse{{0%,100%{{transform:scale(1)}}50%{{transform:scale(1.06)}}}}
  body{{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
    background:radial-gradient(circle at 30% 20%,#181226 0%,#0a0710 60%,#050308 100%);
    font-family:'Segoe UI',system-ui,sans-serif;color:#eaf7ff}}
  .card{{text-align:center;padding:48px 56px;border-radius:18px;
    background:linear-gradient(160deg,rgba(255,45,120,.10),rgba(41,211,245,.06));
    border:1px solid rgba(120,220,255,.25);animation:ariFade .5s ease both,ariGlow 3.2s ease-in-out infinite}}
  .tick{{width:64px;height:64px;margin:0 auto 18px;border-radius:50%;display:flex;align-items:center;justify-content:center;
    background:linear-gradient(135deg,#29d3f5,#ff2d78);animation:ariPulse 2.4s ease-in-out infinite}}
  .tick svg{{width:32px;height:32px}}
  h1{{margin:0 0 8px;font-size:22px;letter-spacing:.04em;
    background:linear-gradient(90deg,#3fd9ff,#ff4d85);-webkit-background-clip:text;background-clip:text;color:transparent}}
  p{{margin:0;font-size:13px;letter-spacing:.03em;color:#9fb4c2}}
  .brand{{margin-top:22px;font:600 10px/1 'Consolas',monospace;letter-spacing:.3em;color:#3fd9ff;opacity:.6}}
</style></head>
<body><div class="card">
  <div class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="#05070a" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12l5 5L20 6"/></svg></div>
  <h1>{title}</h1>
  <p>{subtitle}</p>
  <div class="brand">A · R · I</div>
</div></body></html>"""

# Das Frontend fragt /status alle 1-2s ab — das flutet das Terminal sonst mit
# einer Zeile pro Poll und begraebt die eigentlich interessanten Logs (Fehler,
# Tool-Aufrufe). Nur diese eine Route aus dem Werkzeug-Zugriffslog filtern,
# alles andere (POST /chat, /calendar/configure usw.) bleibt sichtbar.
class _HideStatusPolling(logging.Filter):
    def filter(self, record):
        msg = record.getMessage()
        return "GET /status " not in msg and "/groq-status" not in msg and "GET /brain " not in msg and "POST /heartbeat " not in msg and "GET /media " not in msg and "GET /timers " not in msg and "/phone/admin/hud-patch" not in msg and "/phone/api/state" not in msg and "/phone/api/data" not in msg and "/phone/api/stream" not in msg


logging.getLogger("werkzeug").addFilter(_HideStatusPolling())

DASHBOARD_DIR = os.path.dirname(os.path.abspath(__file__))
DASHBOARD_FILE = "A.R.I HUD.html"
_HUB_START_TIME = time.time()

# Alle Speicher-/Zustandsdateien (Zugangsdaten, Spiele-Profile, gesehene
# E-Mails, ...) leben zusammen in diesem einen Unterordner statt lose neben
# hub.py verstreut — einfacher zu finden, zu sichern oder komplett zu
# loeschen. Bereits vorhandene Dateien aus der alten, flachen Struktur
# werden beim Start automatisch hierher verschoben (siehe _migrate_data_dir).
DATA_DIR = os.path.join(DASHBOARD_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Ohne Konsolenfenster (Start ueber pythonw/START-ARI.bat) gibt es kein
# stdout/stderr: alles Geschriebene geht in data/hub.log. Im Dev-Modus des HUD
# oeffnet sich ein Fenster, das diese Datei live mitliest (siehe /dev/console).
HUB_LOG_FILE = os.path.join(DATA_DIR, "hub.log")
_HEADLESS = sys.stdout is None or os.path.basename(sys.executable).lower().startswith("pythonw")
if _HEADLESS:
    try:
        _hub_log_handle = open(HUB_LOG_FILE, "w", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = _hub_log_handle
    except OSError:
        pass


def _migrate_data_dir():
    """Einmalige Migration: JSON-Speicherdateien, die noch direkt neben
    hub.py liegen (alte, flache Struktur), in DATA_DIR verschieben."""
    for name in ("secrets.json", "game_profiles.json", "seen_emails.json"):
        old_path = os.path.join(DASHBOARD_DIR, name)
        new_path = os.path.join(DATA_DIR, name)
        if os.path.exists(old_path) and not os.path.exists(new_path):
            try:
                shutil.move(old_path, new_path)
                print(f"[data] {name} nach data/ verschoben.")
            except OSError as e:
                print(f"[data] Konnte {name} nicht nach data/ verschieben: {e}")


_migrate_data_dir()

# ---------------------------------------------------------------------------
# Versteckter Dev-Bereich im Frontend (Einstellungen -> mehrfach auf die
# Versionsnummer klicken) — nur fuer den Entwickler selbst, nicht Teil der
# normalen Bedienung. Das Passwort steht bewusst NICHT im Klartext im Code,
# nur sein SHA-256-Hash; der Vergleich passiert zeitkonstant (hmac.compare_
# digest) statt mit == , damit die Antwortzeit nicht verraet, wie viele
# Zeichen schon stimmen. Kein Session-Token: das Frontend haelt das Passwort
# nur im Arbeitsspeicher des Tabs (nicht localStorage) und schickt es bei
# jeder Dev-Aktion erneut mit — nach einem Reload ist man wieder ausgeloggt.
DEV_PASSWORD_HASH = "15200a1b9681095bdf23698fe79043c210be5040d945a1df527ce834eecf8e5d"


def _check_dev_password(password):
    if not isinstance(password, str) or not password:
        return False
    return hmac.compare_digest(hashlib.sha256(password.encode("utf-8")).hexdigest(), DEV_PASSWORD_HASH)

# ---------------------------------------------------------------------------
# Piper TTS: laeuft komplett lokal auf der CPU (kein Internet, kein Kontingent)
# — piper.exe + die beiden Stimmmodelle liegen im Projektordner, siehe piper/
# und piper/voices/. Alternative zur bisherigen Browser-Sprachausgabe
# (window.speechSynthesis), die weiterhin als Rueckfalloption existiert.
# ---------------------------------------------------------------------------
PIPER_DIR = os.path.join(DASHBOARD_DIR, "piper")
PIPER_EXE = os.path.join(PIPER_DIR, "piper.exe" if IS_WIN else "piper")
PIPER_VOICES_DIR = os.path.join(PIPER_DIR, "voices")
PIPER_VOICE_MODELS = {
    "thorsten": "de_DE-thorsten-high.onnx",
}

# ---------------------------------------------------------------------------
# Microsoft Edge Online-Stimmen ("edge-tts"): dieselben natuerlich klingenden
# Neural-Stimmen wie beim "Vorlesen" in Microsoft Edge, kostenlos und ohne
# eigenen API-Schluessel nutzbar (das Paket spricht denselben oeffentlichen
# Dienst an, den Edge selbst nutzt) — braucht aber Internet, anders als Piper.
# ---------------------------------------------------------------------------
EDGE_VOICES = {
    "de-DE": [("katja", "de-DE-KatjaNeural", "Katja"), ("conrad", "de-DE-ConradNeural", "Conrad"), ("amala", "de-DE-AmalaNeural", "Amala")],
    "en-US": [("aria", "en-US-AriaNeural", "Aria"), ("guy", "en-US-GuyNeural", "Guy")],
    "fr-FR": [("denise", "fr-FR-DeniseNeural", "Denise")],
    "es-ES": [("elvira", "es-ES-ElviraNeural", "Elvira")],
    "it-IT": [("elsa", "it-IT-ElsaNeural", "Elsa")],
}
_EDGE_VOICE_IDS = {f"edge:{key}": vid for voices in EDGE_VOICES.values() for key, vid, _ in voices}


def _edge_tts_synthesize(text, voice_id):
    import asyncio
    import edge_tts

    async def _run():
        chunks = bytearray()
        async for chunk in edge_tts.Communicate(text, voice_id).stream():
            if chunk.get("type") == "audio":
                chunks.extend(chunk["data"])
        return bytes(chunks)

    return asyncio.run(_run())
# Piper/espeak versucht sonst, Emojis phonetisch zu "buchstabieren" — reine
# Kauderwelsch-Aussprache. Frontend entfernt sie schon vor dem Request, das
# hier ist nur die zweite Absicherung direkt vor der eigentlichen Synthese.
EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF☀-➿←-⇿⬀-⯿️‍]"
)

# ---------------------------------------------------------------------------
# Mehrere KI-Anbieter: /chat bekommt vom Frontend mit, welcher Anbieter fuer
# diese Anfrage genutzt werden soll ("anthropic" | "openai" | "groq") — so
# kann man in den Einstellungen zwischen Claude, ChatGPT und Groq wechseln,
# ohne den Hub neu zu starten. Jeder Anbieter braucht seinen eigenen API-Key
# als Umgebungsvariable; fehlt einer, bleibt nur dieser Anbieter deaktiviert
# (klare Hinweismeldung statt Absturz), die anderen funktionieren weiter.
# Modellnamen sind per Umgebungsvariable ueberschreibbar, falls sich die
# Anbieter-Modellpalette aendert.
# ---------------------------------------------------------------------------
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-opus-5")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o")
GROQ_MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-20b")
# Google bietet fuer Gemini einen OpenAI-kompatiblen Endpunkt an — daher
# reicht der bestehende _run_openai_compatible()-Pfad (wie bei OpenAI/Groq),
# es braucht kein eigenes google-generativeai-Paket.
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

# Kurzes Timeout statt der SDK-Standardwerte (teils 10 Minuten) — schlaegt ein
# API-Aufruf fehl (kein Netz, falscher Key, Firewall/Proxy blockiert), soll
# das Frontend zuegig eine Fehlermeldung zeigen statt endlos "DENKT..." zu
# haengen.
_API_TIMEOUT_SECONDS = 45

# Zusaetzlich zum SDK-eigenen Timeout oben: eine ERZWUNGENE harte Zeitgrenze
# fuer den kompletten /chat-Ablauf. Beobachtet wurden Faelle, in denen ein
# einzelner Groq-Aufruf trotz timeout=45 mehrere Minuten haengen blieb (der
# SDK-Timeout greift offenbar nicht zuverlaessig bei jeder Art von Haenger,
# z.B. bei einer Verbindung, die minimal Daten trickelt aber nie fertig wird).
# Ohne diese harte Grenze bleibt "state" im Frontend auf DENKEN stehen und
# JEDE weitere Eingabe wird bis dahin stillschweigend ignoriert. Ein Thread
# mit .result(timeout=...) erzwingt einen Abbruch unabhaengig davon, was die
# Bibliothek/Verbindung darunter gerade macht.
CHAT_HARD_TIMEOUT_SECONDS = 20
# Eigener, kleinerer Pool nur fuer /status — get_top_processes()/psutil kann
# gelegentlich an einem einzelnen Systemaufruf haengen bleiben (beobachtet:
# viele parallele "status"-Anfragen blieben im Browser fuer immer "pending",
# haben dabei alle 6 gleichzeitigen Verbindungen des Browsers blockiert und
# so JEDE andere Anfrage inkl. /chat in die Warteschlange gezwungen). Eigener
# Pool statt _chat_executor mitzunutzen, damit sich beide Warteschlangen
# nicht gegenseitig verstopfen koennen.
STATUS_HARD_TIMEOUT_SECONDS = 3
_chat_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
_status_executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)


def _run_with_hard_timeout(fn, *args, timeout=CHAT_HARD_TIMEOUT_SECONDS, executor=None, **kwargs):
    future = (executor or _chat_executor).submit(fn, *args, **kwargs)
    try:
        return future.result(timeout=timeout)
    except concurrent.futures.TimeoutError:
        raise TimeoutError(
            f"Anfrage hat laenger als {timeout}s gedauert und wurde erzwungen abgebrochen "
            "(haengender Aufruf, evtl. Anbieter-/System-Stoerung)."
        )


def _groq_clients_for(keys):
    """Baut fuer jeden vom Frontend mitgeschickten, nicht-leeren Groq-
    Schluessel (bis zu 5, siehe Einstellungen) einen eigenen Client — so
    kann bei einem Rate-Limit auf den naechsten Schluessel gewechselt
    werden. Gibt (key, client)-Paare zurueck statt nur Clients: der Key-
    String selbst ist der Schluessel fuer das Cooldown-Tracking (siehe
    _groq_key_cooldowns) — Client-Objekte werden pro Anfrage neu gebaut,
    der Key bleibt aber ueber Anfragen hinweg gleich. Ohne mitgeschickte
    Schluessel wird auf den Env-Var-Client zurueckgefallen (bisheriges
    Verhalten); der hat keinen eigenen Key-String, also auch kein Cooldown-
    Tracking (nur ein einzelner Key ohnehin, Rotation ergibt da keinen Sinn)."""
    pairs = []
    for key in keys or []:
        key = (key or "").strip()
        if key and _GroqClient:
            pairs.append((key, _GroqClient(api_key=key, timeout=_API_TIMEOUT_SECONDS, max_retries=0)))
    if not pairs and _groq_client:
        pairs.append((None, _groq_client))
    return pairs


def _is_rate_limit_error(e):
    text = str(e).lower()
    return "rate_limit" in text or "429" in text or "resource_exhausted" in text


def _parse_retry_after_seconds(e):
    """Extrahiert die vom Anbieter genannte Wartezeit aus einer Rate-Limit-
    Fehlermeldung. Kennt zusammengesetzte Angaben wie Groqs 'try again in
    7m12.5s' oder '2h3m1s' (Tages-/Minutenlimits!), '850ms', sowie Geminis
    'retryDelay: "5s"'. None, wenn nichts gefunden wird."""
    text = str(e)
    match = re.search(r"try again in\s+((?:\d+(?:\.\d+)?(?:ms|h|m|s))+)", text, re.IGNORECASE)
    if not match:
        match = re.search(r"retry(?:Delay)?['\"]?\s*[:=]?\s*['\"]?((?:\d+(?:\.\d+)?(?:ms|h|m|s))+)", text, re.IGNORECASE)
    if not match:
        return None
    total = 0.0
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)(ms|h|m|s)", match.group(1).lower()):
        total += float(num) * {"h": 3600, "m": 60, "s": 1, "ms": 0.001}[unit]
    return total or None


# Merkt sich pro Groq-API-Key (Key-String, nicht Client-Objekt — Clients
# werden pro Anfrage neu gebaut), bis wann er laut letztem Rate-Limit-Fehler
# gesperrt ist (Unix-Zeitstempel). Ueberlebt ueber mehrere /chat-Anfragen
# hinweg (Modul-globaler Zustand), damit ein bereits als limitiert bekannter
# Key beim naechsten Versuch gar nicht erst angefragt wird, statt jedes Mal
# erneut auf den Fehler zu warten.
_groq_key_cooldowns = {}
_groq_cooldown_lock = threading.Lock()
_GROQ_DEFAULT_COOLDOWN_SECONDS = 5.0


def _mark_groq_key_limited(key, wait_seconds):
    if key is None:
        return
    with _groq_cooldown_lock:
        _groq_key_cooldowns[key] = time.time() + max(0.1, wait_seconds or _GROQ_DEFAULT_COOLDOWN_SECONDS)


def _groq_key_locked_seconds_left(key):
    if key is None:
        return 0.0
    with _groq_cooldown_lock:
        until = _groq_key_cooldowns.get(key, 0.0)
    return max(0.0, until - time.time())


class GroqAllKeysLimitedError(Exception):
    """Alle konfigurierten Groq-Schluessel sind laut Cooldown-Tracking
    gerade gesperrt — kein API-Aufruf wurde versucht, retry_after_seconds
    sagt, wann der erste wieder frei wird."""

    def __init__(self, retry_after_seconds):
        self.retry_after_seconds = retry_after_seconds
        super().__init__(f"Alle Groq-Schluessel sind gerade limitiert (frei in {retry_after_seconds:.1f}s).")


def groq_status_snapshot(keys):
    """Fuer /groq-status und den Chat-Vorab-Check: sind ALLE uebergebenen
    Groq-Schluessel (Key-Strings) laut Cooldown-Tracking gerade gesperrt?
    Meldet dann die Wartezeit bis zum fruehesten freien Key. Ohne Keys (z.B.
    nur der Env-Var-Fallback) gibt es kein Tracking -> nie limitiert."""
    waits = [_groq_key_locked_seconds_left(k) for k in (keys or []) if k]
    if not waits or any(w <= 0 for w in waits):
        return {"rate_limited": False, "retry_after_seconds": 0}
    return {"rate_limited": True, "retry_after_seconds": round(min(waits), 1)}


def _call_with_key_rotation(keys_and_clients, call_fn):
    """Fuehrt EINEN einzelnen API-Aufruf aus (call_fn(client)), mit Rotation
    ueber mehrere Groq-Schluessel bei Rate-Limits — anders als die frühere
    _run_groq_with_fallback wird hier NUR dieser eine Aufruf wiederholt,
    nicht ein kompletter Tool-Use-Ablauf (der Aufrufer haelt den Gespraechs-
    zustand selbst und ruft diese Funktion pro einzelner API-Anfrage auf).
    Bereits gesperrte Keys werden anhand von _groq_key_cooldowns komplett
    uebersprungen, statt sie erneut anzufragen und auf denselben Fehler zu
    warten. Sind ALLE Keys gesperrt, wird kein einziger API-Aufruf gemacht —
    stattdessen sofort GroqAllKeysLimitedError."""
    if not keys_and_clients:
        raise Exception("Kein Client konfiguriert.")
    last_error = None
    soonest_wait = None
    attempted = False
    for key, client in keys_and_clients:
        locked_left = _groq_key_locked_seconds_left(key)
        if locked_left > 0:
            soonest_wait = locked_left if soonest_wait is None else min(soonest_wait, locked_left)
            continue
        attempted = True
        try:
            return call_fn(client)
        except Exception as e:
            last_error = e
            if key is not None and _is_rate_limit_error(e):
                wait = _parse_retry_after_seconds(e) or _GROQ_DEFAULT_COOLDOWN_SECONDS
                _mark_groq_key_limited(key, wait)
                soonest_wait = wait if soonest_wait is None else min(soonest_wait, wait)
                continue
            raise
    if not attempted:
        raise GroqAllKeysLimitedError(soonest_wait or _GROQ_DEFAULT_COOLDOWN_SECONDS)
    raise last_error


_anthropic_client = anthropic.Anthropic(timeout=_API_TIMEOUT_SECONDS, max_retries=0) if (anthropic and os.environ.get("ANTHROPIC_API_KEY")) else None
_openai_client = _OpenAIClient(timeout=_API_TIMEOUT_SECONDS, max_retries=0) if (_OpenAIClient and os.environ.get("OPENAI_API_KEY")) else None
_groq_client = _GroqClient(timeout=_API_TIMEOUT_SECONDS, max_retries=0) if (_GroqClient and os.environ.get("GROQ_API_KEY")) else None
_gemini_client = (
    _OpenAIClient(api_key=os.environ.get("GEMINI_API_KEY"), base_url=GEMINI_BASE_URL, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
    if (_OpenAIClient and os.environ.get("GEMINI_API_KEY")) else None
)

# Persoenlichkeit fuer die API-Anbindung in /chat (anbieteruebergreifend).
SYSTEM_PROMPT = (
    "Du bist A.R.I, ein KI-System mit warmer, lockerer, hochkompetenter Art - "
    "weniger steif als ein britischer Butler, eher zugewandt und direkt, mit "
    "trockenem Witz. Du sprichst den Nutzer abwechselnd mit wechselnden Anreden "
    "an - z.B. 'Sir', 'Master', 'Boss', 'Chief', 'Captain', 'Commander' oder "
    "'Champ' -, je nach Tonfall der Situation passend gewaehlt, nie zweimal "
    "hintereinander dieselbe, damit es lebendig bleibt. Du passt deinen Sprachstil im Gespraechsverlauf "
    "an den des Nutzers an - Wortwahl, Tonfall, Foermlichkeit, typische "
    "Ausdruecke -, ohne deine eigene Persoenlichkeit zu verlieren. Antworte "
    "auf Deutsch (die Anreden bleiben bewusst englisch), in 1-3 kurzen, "
    "druckreifen Saetzen, geeignet zum Vorlesen. Bleib auch bei Fehlern oder "
    "Rueckfragen gelassen und locker. Erfinde niemals Fakten, IDs, Zahlen, "
    "Links oder Codes, die du nicht sicher weisst oder aus einem Tool-Ergebnis "
    "hast - klingt das plausibel, ist aber trotzdem geraten, ist es schlimmer "
    "als ehrlich zu sagen, dass du es nicht weisst. Ist eine Anfrage "
    "mehrdeutig, frag im Zweifel kurz nach, statt zu raten - ausser bei "
    "'guid'/'guide' im Zusammenhang mit einem Spiel: das ist immer als "
    "'Anleitung/Guide' gemeint (nicht als technische ID), dazu direkt "
    "antworten statt nachzufragen. Fuer aktuelle/live Infos, die sich staendig "
    "aendern (Krypto-/Aktienkurse, Wechselkurse, Wetter, News, Sportergebnisse "
    "o.ae.), hast du ein Such-Tool - nutze es aktiv, um eine echte Antwort zu "
    "liefern, statt zu sagen, du haettest keine Live-Daten oder der Nutzer "
    "solle selbst nachschauen. Wichtig: Hast du das Such-Tool bereits benutzt "
    "und stehen Ergebnisse (Zahlen, Preise, Fakten) im Tool-Ergebnis, MUSST du "
    "diese in deiner finalen Antwort auch tatsaechlich nennen/zitieren - sag "
    "in diesem Fall niemals, du haettest keine aktuellen/Live-Daten, das waere "
    "widerspruechlich, wenn das Suchergebnis welche enthaelt. Nur wenn die "
    "Suche wirklich nichts Brauchbares liefert, ehrlich sagen, dass du nichts "
    "gefunden hast. Bei E-Mails: sende oder beantworte niemals eine E-Mail von "
    "dir aus, ohne dass der Nutzer das verlangt hat. Aber wenn der Nutzer in "
    "seiner Nachricht klar sagt 'schreibe/sende/beantworte eine E-Mail an X "
    "mit Inhalt Y' (oder aehnlich eindeutig), ist das bereits die direkte "
    "Aufforderung - dann sofort das Tool aufrufen und verschicken, OHNE vorher "
    "nochmal nachzufragen ob du wirklich senden sollst. Nachfragen nur, wenn "
    "Empfaenger oder Inhalt der E-Mail wirklich fehlen/unklar sind. read_emails "
    "zeigt ALLE ungelesenen E-Mails, ohne Filter - der Nutzer entscheidet selbst, "
    "was wichtig ist. Nur wenn er ausdruecklich nur die wichtigen will, "
    "important_only=true setzen. Genauso "
    "bei Kalender-Terminen: loesche/bearbeite niemals von dir aus einen Termin, "
    "aber wenn der Nutzer klar sagt einen bestimmten Termin zu loeschen oder zu "
    "aendern, direkt mit list_calendar_events die id suchen und dann sofort "
    "delete_calendar_event bzw. update_calendar_event aufrufen, ohne nochmal "
    "nachzufragen. Bei allem, was mit Lautstaerke oder Musik zu tun hat "
    "(lauter/leiser, Titel wechseln, Play/Pause): standardmaessig set_spotify_volume "
    "bzw. control_media nutzen (wirkt auf Spotify), NICHT control_volume (Windows-"
    "Systemlautstaerke) - nur wenn der Nutzer ausdruecklich 'Windows' oder "
    "'Systemlautstaerke' sagt, control_volume nehmen. control_media bei 'naechster "
    "Titel'/'skip'/'zurueck' GENAU EINMAL aufrufen, niemals zweimal hintereinander "
    "im selben Zug - ein einzelner Tastendruck reicht, ein zweiter Aufruf wuerde "
    "einen Titel zu viel ueberspringen. Fragt der Nutzer, welcher Titel gerade "
    "laeuft/kommt, get_current_spotify_track nutzen statt zu raten. Du darfst "
    "passende Emojis "
    "einstreuen, um Antworten lebendiger wirken zu lassen - sparsam, hoechstens "
    "ein bis zwei pro Antwort, nicht in jedem Satz. Sie werden vor der "
    "Sprachausgabe automatisch entfernt, du musst also nicht auf sie eingehen "
    "oder sie im Text erklaeren. Nach take_screenshot antworte NUR mit "
    "'Screenshot gespeichert.' - keine Anrede, kein Kommentar, kein Dateiname, "
    "nichts weiter."
)

# ---------------------------------------------------------------------------
# Netzwerk-Durchsatz: psutil liefert nur kumulative Byte-Zaehler, daher wird
# die Differenz seit dem letzten /status-Aufruf in MB/s umgerechnet.
# ---------------------------------------------------------------------------
_last_net = psutil.net_io_counters()
_last_net_time = time.time()


def get_network_rates():
    global _last_net, _last_net_time
    now = time.time()
    current = psutil.net_io_counters()
    elapsed = max(now - _last_net_time, 0.001)
    down_mbps = (current.bytes_recv - _last_net.bytes_recv) / elapsed / 1024 / 1024
    up_mbps = (current.bytes_sent - _last_net.bytes_sent) / elapsed / 1024 / 1024
    _last_net, _last_net_time = current, now
    return round(max(down_mbps, 0), 2), round(max(up_mbps, 0), 2)


def format_uptime():
    seconds = int(time.time() - psutil.boot_time())
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    return f"{hours}h {minutes}m"


# ---------------------------------------------------------------------------
# Prozessliste: psutil.Process.cpu_percent() braucht zwei Messpunkte, um eine
# sinnvolle Prozentzahl zu liefern (der erste Aufruf pro Prozess ist immer
# 0.0). Deshalb werden die Process-Objekte ueber Aufrufe hinweg zwischen-
# gespeichert; ein Prozess taucht also erst ab dem zweiten /status-Poll
# (~1.2s nach dem ersten Sehen) mit echtem CPU-Wert in der Liste auf.
# ---------------------------------------------------------------------------
_proc_cache = {}
_cpu_count = psutil.cpu_count() or 1


# PIDs/Namen, die psutil unter Windows fuer Kernel-Sammelprozesse liefert
# ("System Idle Process" summiert Leerlaufzeit ueber alle Kerne und meldet
# dabei absurd hohe/verzerrte cpu_percent-Werte) — fuer eine Nutzer-Taskliste
# nicht relevant, daher ausgefiltert.
_IGNORED_PROCESS_NAMES = {"system idle process"}


# Windows: EIN Systemaufruf (NtQuerySystemInformation) liefert Name, Arbeitsspeicher und CPU-Zeit ALLER Prozesse
# in ~8 ms. Die psutil-Variante unten fragt jeden Prozess einzeln ab und liest dabei jedes Mal die komplette
# Prozesstabelle neu ein (bei ~400 Prozessen ca. 3,3 s reine CPU-Zeit pro Durchlauf = dauerhaft ~50 % eines
# Kerns, auch wenn gar kein Fenster offen ist).
_nt_size = [1 << 20]
_nt_prev = {"t": 0.0, "cpu": {}}


def _win_process_snapshot():
    """{pid: (name, working_set_bytes, cpu_100ns)} - oder {} bei Fehler (dann greift der psutil-Weg)."""
    import ctypes
    import struct
    ntdll = ctypes.WinDLL("ntdll")
    nt_query = ntdll.NtQuerySystemInformation
    nt_query.argtypes = [ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
    nt_query.restype = ctypes.c_long
    for _ in range(4):
        buf = ctypes.create_string_buffer(_nt_size[0])
        ret = ctypes.c_ulong(0)
        st = nt_query(5, buf, _nt_size[0], ctypes.byref(ret)) & 0xFFFFFFFF   # 5 = SystemProcessInformation
        if st == 0:
            break
        if st == 0xC0000004:   # Puffer zu klein
            _nt_size[0] = max(_nt_size[0] * 2, ret.value + 65536)
            continue
        return {}
    else:
        return {}
    base = ctypes.addressof(buf)
    raw = buf.raw
    out = {}
    off = 0
    while True:
        nxt = struct.unpack_from("<I", raw, off)[0]
        user, kern = struct.unpack_from("<qq", raw, off + 40)
        nlen = struct.unpack_from("<H", raw, off + 56)[0]
        nptr = struct.unpack_from("<Q", raw, off + 64)[0]
        pid = struct.unpack_from("<Q", raw, off + 80)[0]
        ws = struct.unpack_from("<Q", raw, off + 144)[0]
        name = raw[nptr - base: nptr - base + nlen].decode("utf-16-le", "replace") if nlen and nptr else ""
        out[int(pid)] = (name, int(ws), int(user + kern))
        if not nxt:
            break
        off += nxt
    return out


def _get_top_processes_win(limit):
    snap = _win_process_snapshot()
    if not snap:
        return None
    now = time.time()
    prev_t, prev_cpu = _nt_prev["t"], _nt_prev["cpu"]
    dt = now - prev_t
    grouped = {}
    cpu_now = {}
    for pid, (raw_name, ws, cpu100) in snap.items():
        cpu_now[pid] = cpu100
        if pid == 0 or not raw_name or raw_name.lower() in _IGNORED_PROCESS_NAMES:
            continue
        if pid not in prev_cpu or dt <= 0:
            continue   # wie bisher: neue Prozesse zaehlen erst ab dem zweiten Durchlauf
        cpu = max(0.0, (cpu100 - prev_cpu[pid]) / 1e7 / dt * 100.0) / _cpu_count
        group_name = raw_name[:-4] if raw_name.lower().endswith(".exe") else raw_name
        group_name = group_name[:1].upper() + group_name[1:] if group_name else group_name
        entry = grouped.setdefault(group_name, {"name": group_name, "status": "LÄUFT", "cpu_percent": 0.0, "ram_mb": 0.0})
        entry["cpu_percent"] += cpu
        entry["ram_mb"] += ws / 1024 / 1024
    _nt_prev["t"], _nt_prev["cpu"] = now, cpu_now
    procs = list(grouped.values())
    for entry in procs:
        entry["cpu_percent"] = round(entry["cpu_percent"], 1)
        entry["ram_mb"] = round(entry["ram_mb"], 1)
    procs.sort(key=lambda x: (x["ram_mb"], x["cpu_percent"]), reverse=True)
    return procs[:limit]


def get_top_processes(limit=6):
    """
    Wie der Task-Manager gruppiert nach App (z.B. "Chrome" statt 16 einzelne
    chrome.exe-Eintraege) — sonst dominieren Mehrprozess-Apps (Chrome, Claude,
    Discord, ...) die Liste mit lauter Eintraegen desselben Programms.
    """
    if IS_WIN:
        try:
            fast = _get_top_processes_win(limit)
            if fast is not None:
                return fast
        except Exception as e:
            print(f"[status] Schneller Prozess-Snapshot fehlgeschlagen, nutze psutil: {e}")
    grouped = {}
    seen_pids = set()
    for p in psutil.process_iter(["pid", "name", "memory_info"]):
        try:
            pid = p.info["pid"]
            seen_pids.add(pid)
            raw_name = p.info["name"] or "unbekannt"
            if pid == 0 or raw_name.lower() in _IGNORED_PROCESS_NAMES:
                continue
            if pid not in _proc_cache:
                _proc_cache[pid] = p
                p.cpu_percent(None)  # Baseline setzen, dieser Poll zaehlt noch nicht
                continue
            cached = _proc_cache[pid]
            # psutil normiert Prozess-CPU% auf einen einzelnen Kern (kann bei
            # Mehrkern-Prozessen z.B. 278% ergeben) — durch die Kernanzahl
            # geteilt, damit es zur systemweiten 0-100%-Anzeige oben passt.
            cpu = cached.cpu_percent(None) / _cpu_count
            mem = p.info["memory_info"]
            ram_mb = mem.rss / 1024 / 1024 if mem else 0.0

            group_name = raw_name[:-4] if raw_name.lower().endswith(".exe") else raw_name
            group_name = group_name[:1].upper() + group_name[1:] if group_name else group_name
            entry = grouped.setdefault(group_name, {"name": group_name, "status": "LÄUFT", "cpu_percent": 0.0, "ram_mb": 0.0})
            entry["cpu_percent"] += cpu
            entry["ram_mb"] += ram_mb
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    for pid in list(_proc_cache.keys()):
        if pid not in seen_pids:
            del _proc_cache[pid]

    procs = list(grouped.values())
    for entry in procs:
        entry["cpu_percent"] = round(entry["cpu_percent"], 1)
        entry["ram_mb"] = round(entry["ram_mb"], 1)
    # Nach RAM statt CPU sortieren — sonst zeigt die Liste z.B. einen
    # Leerlauf-Prozess mit 2% CPU statt eines RAM-Fressers mit 0% CPU, und
    # die angezeigten Werte passen nicht zur RAM-Gesamtanzeige daneben.
    procs.sort(key=lambda x: (x["ram_mb"], x["cpu_percent"]), reverse=True)
    return procs[:limit]


# get_top_processes() ist auf diesem Rechner zu teuer, um sie bei jedem
# /status-Poll live zu berechnen (viele laufende Prozesse -> psutil braucht
# mehrere Sekunden) — das fuehrte dazu, dass sich Anfragen aufstauten und
# alle Browser-Verbindungsplaetze blockierten (siehe Netzwerk-Tab-Befund).
# Ein eigener Hintergrund-Thread aktualisiert die Liste alle paar Sekunden;
# /status liest nur noch den letzten fertigen Stand und ist dadurch fast
# augenblicklich, egal wie lange die eigentliche Berechnung dauert.
_latest_processes = []
_processes_lock = threading.Lock()

def _process_updater_loop():
    global _latest_processes
    while True:
        try:
            result = get_top_processes()
            with _processes_lock:
                _latest_processes = result
        except Exception as e:
            print(f"[status] Prozessliste konnte nicht aktualisiert werden: {e}")
        try:
            _mod_tick()
        except NameError:
            pass   # der Mod-Teil weiter unten ist beim allerersten Durchlauf eventuell noch nicht fertig geladen
        time.sleep(3)


threading.Thread(target=_process_updater_loop, daemon=True).start()


def get_cached_processes():
    with _processes_lock:
        return _latest_processes


def estimate_memory_breakdown():
    """
    psutil liefert unter Windows keine System/Anwendungen/Cache-Aufteilung,
    nur used/available/total — daher grobe Schaetzung (klar als estimated
    markiert, siehe Vertrag oben).
    """
    vm = psutil.virtual_memory()
    total_gb = vm.total / 1024 ** 3
    used_gb = vm.used / 1024 ** 3
    free_gb = vm.available / 1024 ** 3
    cache_gb = getattr(vm, "cached", 0) / 1024 ** 3  # nur auf Linux vorhanden
    system_gb = used_gb * 0.28
    apps_gb = max(used_gb - system_gb - cache_gb, 0)
    return {
        "system_gb": round(system_gb, 1),
        "apps_gb": round(apps_gb, 1),
        "cache_gb": round(cache_gb, 1),
        "free_gb": round(free_gb, 1),
        "total_gb": round(total_gb, 1),
        "estimated": True,
    }


def get_system_status_label(cpu_percent, ram_percent):
    if cpu_percent > 90 or ram_percent > 92:
        return "critical"
    if cpu_percent > 75 or ram_percent > 80:
        return "warning"
    return "optimal"


# ---------------------------------------------------------------------------
# PC-Steuerung: bewusst nur ctypes (user32-Tastatursimulation) + Pillow +
# subprocess/os.startfile — keine COM/WMI-Abhaengigkeit, siehe die
# Instabilitaet, die dazu fuehrte, die GPU-Ueberwachung wieder zu entfernen
# (unten dokumentiert). Apps werden per Namenssuche aufgeloest: zuerst
# APP_REGISTRY (schnelle, exakte Treffer fuer die haeufigsten Programme),
# sonst eine Suche unter den echten Desktop-/Startmenue-Verknuepfungen des
# Nutzers (_find_app_shortcut) — das Modell bekommt also nie einen rohen
# Pfad/Befehl zum Ausfuehren, sondern kann immer nur etwas oeffnen, das
# tatsaechlich schon als installierte Verknuepfung existiert.
# ---------------------------------------------------------------------------
import ctypes

_VK_VOLUME_MUTE = 0xAD
_VK_VOLUME_DOWN = 0xAE
_VK_VOLUME_UP = 0xAF
_VK_MEDIA_NEXT_TRACK = 0xB0
_VK_MEDIA_PREV_TRACK = 0xB1
_VK_MEDIA_PLAY_PAUSE = 0xB3
_VK_LWIN = 0x5B
_VK_D = 0x44
_KEYEVENTF_EXTENDEDKEY = 0x1
_KEYEVENTF_KEYUP = 0x2
_KEYEVENTF_SCANCODE = 0x8


_VK_TO_MEDIA_NAME = {0xAD: "mute", 0xAE: "down", 0xAF: "up", 0xB0: "next", 0xB1: "previous", 0xB3: "play_pause"}


def _press_key(vk, extended=True):
    if not IS_WIN:
        name = _VK_TO_MEDIA_NAME.get(vk)
        if name:
            _lx.press_media_key(name)
        elif vk == _VK_LWIN:
            _lx.press_combo("super")
        return
    flags = _KEYEVENTF_EXTENDEDKEY if extended else 0
    ctypes.windll.user32.keybd_event(vk, 0, flags, 0)
    ctypes.windll.user32.keybd_event(vk, 0, flags | _KEYEVENTF_KEYUP, 0)


# ---------------------------------------------------------------------------
# Spiel-Aktionen (game_action-Tool weiter unten): beliebige Einzeltasten +
# Modifikator-Kombos (z.B. "Strg+G") fuer konfigurierbare In-Game-Befehle wie
# "Fahrwerk ausfahren". Baut bewusst nur auf dem bereits vorhandenen ctypes/
# keybd_event-Mechanismus auf, keine neue Abhaengigkeit.
# ---------------------------------------------------------------------------
_VK_NAMED_KEYS = {
    "space": 0x20, "leertaste": 0x20,
    "enter": 0x0D, "return": 0x0D, "eingabe": 0x0D,
    "tab": 0x09,
    "escape": 0x1B, "esc": 0x1B,
    "backspace": 0x08, "ruecktaste": 0x08,
    "shift": 0x10, "umschalt": 0x10,
    "ctrl": 0x11, "strg": 0x11, "control": 0x11,
    "alt": 0x12,
    "up": 0x26, "hoch": 0x26, "down": 0x28, "runter": 0x28,
    "left": 0x25, "links": 0x25, "right": 0x27, "rechts": 0x27,
    "pageup": 0x21, "bildhoch": 0x21, "pagedown": 0x22, "bildrunter": 0x22,
    "printscreen": 0x2C, "druck": 0x2C,
    **{f"f{i}": 0x6F + i for i in range(1, 13)},  # F1-F12 = 0x70-0x7B
    **{f"num{i}": 0x60 + i for i in range(10)},  # Numpad 0-9 = 0x60-0x69 (eigene VK-Codes, NICHT identisch mit den normalen Zifferntasten)
}

# Fester Scan-Code (PC/AT Set 1), UNABHAENGIG vom aktiven Tastatur-Layout.
# Spiele mit DirectInput/RawInput-Tastaturabfrage (z.B. Star Citizen) binden
# ueblicherweise an die PHYSISCHE Tastenposition (Scan-Code), nicht an einen
# layoutabhaengigen VK-Code — deshalb war z.B. "Y" auf einer deutschen
# QWERTZ-Tastatur vorher falsch: die VK-Code->Scancode-Umrechnung (auch mit
# korrektem Layout) bildet VK_Y auf die physische "Z"-Taste ab, waehrend das
# Spiel selbst scancode-basiert genau die andere Taste erwartet. Deckt die
# in den Spiel-Profilen tatsaechlich vorkommenden einfachen Tasten ab; alles
# andere (Pfeiltasten, Numpad, Bild hoch/runter, Druck) faellt weiter auf die
# layoutbewusste VK->Scancode-Route zurueck (siehe _press_key_combo).
_SCANCODE_TABLE = {
    "a": 0x1E, "b": 0x30, "c": 0x2E, "d": 0x20, "e": 0x12, "f": 0x21,
    "g": 0x22, "h": 0x23, "i": 0x17, "j": 0x24, "k": 0x25, "l": 0x26,
    "m": 0x32, "n": 0x31, "o": 0x18, "p": 0x19, "q": 0x10, "r": 0x13,
    "s": 0x1F, "t": 0x14, "u": 0x16, "v": 0x2F, "w": 0x11, "x": 0x2D,
    "y": 0x15, "z": 0x2C,
    "1": 0x02, "2": 0x03, "3": 0x04, "4": 0x05, "5": 0x06,
    "6": 0x07, "7": 0x08, "8": 0x09, "9": 0x0A, "0": 0x0B,
    "space": 0x39, "leertaste": 0x39,
    "enter": 0x1C, "return": 0x1C, "eingabe": 0x1C,
    "tab": 0x0F,
    "escape": 0x01, "esc": 0x01,
    "backspace": 0x0E, "ruecktaste": 0x0E,
    "shift": 0x2A, "umschalt": 0x2A,
    "ctrl": 0x1D, "strg": 0x1D, "control": 0x1D,
    "alt": 0x38,
    "f1": 0x3B, "f2": 0x3C, "f3": 0x3D, "f4": 0x3E, "f5": 0x3F,
    "f6": 0x40, "f7": 0x41, "f8": 0x42, "f9": 0x43, "f10": 0x44,
    "f11": 0x57, "f12": 0x58,
    ",": 0x33, ".": 0x34, "`": 0x29, "[": 0x1A, "]": 0x1B,
}

# Rechte Alt-/Strg-/Umschalt-Taste: physisch dieselbe Scan-Code-Nummer wie die
# linke Variante, aber mit gesetztem KEYEVENTF_EXTENDEDKEY-Flag unterschieden
# (E0-Praefix) — Star Citizen bindet manche Aktionen (z.B. "Flugbereit")
# bewusst auf RAlt statt Alt, um Windows-Alt-Kombos nicht zu blockieren.
_EXTENDED_SCANCODE_TABLE = {
    "ralt": 0x38, "rechtsalt": 0x38, "alt rechts": 0x38, "raltgr": 0x38, "altgr": 0x38,
    "rctrl": 0x1D, "rechtsstrg": 0x1D, "strg rechts": 0x1D,
}

# Rechte Umschalttaste hat einen EIGENEN (nicht-erweiterten) Scan-Code, anders
# als RAlt/RStrg, die den Code der linken Taste per Extended-Flag teilen.
_SCANCODE_TABLE["rshift"] = 0x36
_SCANCODE_TABLE["rechteumschalt"] = 0x36
_SCANCODE_TABLE["umschalt rechts"] = 0x36


def _resolve_vk(key_name):
    """Name einer EINZELNEN Taste -> virtueller Tastencode. Buchstaben/Zahlen
    werden programmatisch abgeleitet (VK-Code == ASCII-Code fuer A-Z/0-9),
    alles andere ueber die Namenstabelle inkl. deutscher Aliase."""
    k = key_name.strip().lower()
    if len(k) == 1 and k.isalpha():
        return ord(k.upper())  # A-Z: 0x41-0x5A
    if len(k) == 1 and k.isdigit():
        return ord(k)  # 0-9: 0x30-0x39
    return _VK_NAMED_KEYS.get(k)


def _get_foreground_keyboard_layout():
    """Tastaturlayout des GERADE FOKUSSIERTEN Fensters (z.B. das Spiel), NICHT
    das eigene Layout des Hub-Prozesses — sonst landen z.B. auf einer
    deutschen QWERTZ-Tastatur Y und Z vertauscht: VK_Y/VK_Z werden je nach
    aktivem Layout auf unterschiedliche physische Tasten (Scan-Codes)
    abgebildet, und MapVirtualKeyW OHNE Layout-Angabe nimmt automatisch das
    Layout des aufrufenden Threads (also von hub.py selbst, nicht vom Spiel)."""
    hwnd = ctypes.windll.user32.GetForegroundWindow()
    thread_id = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, None)
    return ctypes.windll.user32.GetKeyboardLayout(thread_id)


def _resolve_scancode(key_name):
    """Name einer EINZELNEN Taste -> (Scan-Code, extended)-Tupel, fest und
    layoutunabhaengig (siehe _SCANCODE_TABLE/_EXTENDED_SCANCODE_TABLE), falls
    bekannt — sonst None (dann faellt _press_key_combo auf die VK-basierte,
    layoutbewusste Route zurueck)."""
    k = key_name.strip().lower()
    if k in _EXTENDED_SCANCODE_TABLE:
        return (_EXTENDED_SCANCODE_TABLE[k], True)
    if k in _SCANCODE_TABLE:
        return (_SCANCODE_TABLE[k], False)
    return None


def _press_key_combo(key_string):
    """Presst eine einzelne Taste ODER eine Modifikator-Kombo, z.B. 'N',
    'F1', 'Strg+G' — Modifikatoren werden der Reihenfolge nach gehalten, die
    Haupttaste getippt, Modifikatoren in umgekehrter Reihenfolge wieder
    losgelassen. Gibt False bei unbekannten Tastennamen zurueck (kein
    Tastendruck, kein Absturz) statt eine falsche Taste zu raten.

    Nutzt SendInput mit KEYEVENTF_SCANCODE statt des aelteren keybd_event
    (VK-Code-basiert): manche Spiele mit DirectInput/RawInput-Tastaturabfrage
    (z.B. Star Citizen) reagieren auf reine VK-Code-Injektion per keybd_event
    gar nicht. Fuer bekannte einfache Tasten wird direkt der feste, layout-
    unabhaengige Scan-Code aus _SCANCODE_TABLE gesendet (das ist es, was
    solche Spiele tatsaechlich auswerten); nur fuer nicht dort gelistete
    Tasten (Pfeiltasten, Numpad, ...) wird auf die VK->Scancode-Umrechnung
    ueber das Layout des fokussierten Fensters zurueckgegriffen."""
    if not IS_WIN:
        return _lx.press_combo(key_string)
    parts = [p.strip() for p in key_string.split("+") if p.strip()]
    if not parts:
        return False
    resolved = []
    for p in parts:
        direct = _resolve_scancode(p)
        if direct is not None:
            resolved.append(("scan", direct))
            continue
        vk = _resolve_vk(p)
        if vk is None:
            return False
        resolved.append(("vk", vk))
    *modifiers, main = resolved
    extra = ctypes.c_ulong(0)
    layout = _get_foreground_keyboard_layout()

    def send_scan(item, key_up):
        kind, value = item
        if kind == "scan":
            scan, extended = value
        else:
            scan, extended = ctypes.windll.user32.MapVirtualKeyExW(value, 0, layout), False  # MAPVK_VK_TO_VSC
        flags = _KEYEVENTF_SCANCODE | (_KEYEVENTF_KEYUP if key_up else 0) | (_KEYEVENTF_EXTENDEDKEY if extended else 0)
        evt = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, scan, flags, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(evt), ctypes.sizeof(_Input))

    for vk in modifiers:
        send_scan(vk, False)
    if modifiers:
        # Kurze Pause, bevor die Haupttaste kommt: manche Spiele (Polling
        # statt Event-basiert) verpassen einen Modifikator, der im selben
        # Eingabe-Schub wie die Haupttaste ankommt — Modifikator muss schon
        # "angekommen" sein, wenn die Haupttaste abgefragt wird.
        time.sleep(0.03)
    send_scan(main, False)
    # Laengeres Halten bei Kombos (z.B. RAlt+R): kuerzere Tipps werden bei
    # Mehrtasten-Kombos in der Praxis haeufiger verschluckt als bei Einzel-
    # tasten.
    time.sleep(0.08 if modifiers else 0.04)
    send_scan(main, True)
    for vk in reversed(modifiers):
        send_scan(vk, True)
    return True


# SendInput mit KEYEVENTF_UNICODE statt keybd_event: tippt beliebigen Text
# (Ortsnamen, Umlaute, Ziffern, Leerzeichen) zeichenweise, ohne fuer jedes
# einzelne Zeichen einen eigenen VK-Code zu brauchen — noch immer reines
# ctypes, keine neue Abhaengigkeit.
_INPUT_KEYBOARD = 1
_KEYEVENTF_UNICODE = 0x0004


class _KeyBdInput(ctypes.Structure):
    _fields_ = [
        ("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
        ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class _MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long), ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class _InputUnion(ctypes.Union):
    _fields_ = [("ki", _KeyBdInput), ("mi", _MouseInput)]


class _Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", _InputUnion)]


def _type_text(text, delay=0.015):
    if not IS_WIN:
        _lx.type_text(text)
        return
    extra = ctypes.c_ulong(0)
    for ch in text:
        code = ord(ch)
        down = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, code, _KEYEVENTF_UNICODE, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(down), ctypes.sizeof(_Input))
        up = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, code, _KEYEVENTF_UNICODE | _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(up), ctypes.sizeof(_Input))
        time.sleep(delay)  # manche Spiele/Suchfelder verschlucken Zeichen, wenn sie zu schnell hintereinander kommen


def _type_text_scan(text, delay=0.045):
    """Wie _type_text, aber mit ECHTEN Tastencodes (Scancodes) statt Unicode-Zeichen: Spiele wie Star Citizen lesen die Tastatur direkt und
    ueberhoeren Unicode-Eingaben, daher kam im Suchfeld nichts an. Gross-/Sonderzeichen laufen ueber Shift; Zeichen, die es auf dem aktuellen
    Tastaturlayout nicht als Taste gibt, werden ersatzweise als Unicode gesendet."""
    if not IS_WIN:
        _lx.type_text(text)
        return
    u32 = ctypes.windll.user32
    u32.GetKeyboardLayout.restype = ctypes.c_void_p
    layout = u32.GetKeyboardLayout(0)
    u32.VkKeyScanExW.argtypes = [ctypes.c_wchar, ctypes.c_void_p]
    u32.MapVirtualKeyExW.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p]
    extra = ctypes.c_ulong(0)

    def ev(scan, up):
        flags = _KEYEVENTF_SCANCODE | (_KEYEVENTF_KEYUP if up else 0)
        e = _Input(_INPUT_KEYBOARD, _InputUnion(ki=_KeyBdInput(0, scan, flags, 0, ctypes.pointer(extra))))
        u32.SendInput(1, ctypes.pointer(e), ctypes.sizeof(_Input))

    shift_scan = u32.MapVirtualKeyExW(0x10, 0, layout) or 0x2A
    for ch in text:
        res = u32.VkKeyScanExW(ch, layout)
        vk, state = res & 0xFF, (res >> 8) & 0xFF
        scan = u32.MapVirtualKeyExW(vk, 0, layout) if res != -1 and vk != 0xFF else 0
        if res == -1 or vk == 0xFF or not scan or (state & ~1):   # keine Taste / Strg / Alt / AltGr noetig -> Unicode-Ersatz
            _type_text(ch, delay)
            continue
        if state & 1:
            ev(shift_scan, False)
            time.sleep(0.02)
        ev(scan, False)
        time.sleep(0.02)
        ev(scan, True)
        if state & 1:
            time.sleep(0.01)
            ev(shift_scan, True)
        time.sleep(delay)


# Linksklick per SendInput (MOUSEEVENTF_ABSOLUTE + _MOVE/_LEFTDOWN/_LEFTUP) —
# fx/fy sind Anteile der Bildschirmbreite/-hoehe (0.0-1.0), NICHT Pixel, damit
# eine einmal ermittelte Klickposition unabhaengig von der Aufloesung
# funktioniert. Noetig fuer game_action-Spiele, deren UI (z.B. Star Citizens
# Sternenkarten-Suchergebnis) einen echten Klick statt nur eine Taste
# braucht — ohne Bildschirm-Sichtkontakt kann ich die Position nicht selbst
# herausfinden, die muss der Nutzer einmalig angeben (siehe Einstellungen >
# Spiele > Sternenkarten-Ergebnis-Klick).
_INPUT_MOUSE = 0
_MOUSEEVENTF_MOVE = 0x0001
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004
_MOUSEEVENTF_ABSOLUTE = 0x8000


def _click_at_fraction(fx, fy, hover=0.0, hold=0.05):
    """hover: Pause nach dem Hinbewegen der Maus, bevor geklickt wird (Spiele-Menues reagieren oft erst, wenn die Maus schon ueber dem Eintrag
    "steht"); hold: wie lange die Taste gedrueckt bleibt."""
    if not IS_WIN:
        _lx.click_at_fraction(fx, fy)
        return
    abs_x = max(0, min(65535, int(fx * 65535)))
    abs_y = max(0, min(65535, int(fy * 65535)))
    extra = ctypes.c_ulong(0)
    for flags, pause in (
        (_MOUSEEVENTF_MOVE | _MOUSEEVENTF_ABSOLUTE, max(0.05, hover)),
        (_MOUSEEVENTF_LEFTDOWN | _MOUSEEVENTF_ABSOLUTE, hold),
        (_MOUSEEVENTF_LEFTUP | _MOUSEEVENTF_ABSOLUTE, 0.05),
    ):
        evt = _Input(_INPUT_MOUSE, _InputUnion(mi=_MouseInput(abs_x, abs_y, 0, flags, 0, ctypes.pointer(extra))))
        ctypes.windll.user32.SendInput(1, ctypes.pointer(evt), ctypes.sizeof(_Input))
        time.sleep(pause)


_VK_LBUTTON = 0x01


class _Point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


APP_REGISTRY = {
    "chrome": "chrome.exe",
    "firefox": "firefox.exe",
    "edge": "msedge.exe",
    "notepad": "notepad.exe",
    "taskmanager": "taskmgr.exe",
    "explorer": "explorer.exe",
    "calculator": "calc.exe",
    "paint": "mspaint.exe",
}

SCREENSHOT_DIR = os.path.join(DASHBOARD_DIR, "screenshots")


WINDOWS_VOLUME_STEP_PERCENT = 2  # Standard-Schrittgroesse pro Medientasten-Druck


def _tool_control_volume(action, steps=5, percent=None):
    if not IS_WIN:
        return _lx.control_volume(action, steps, percent, WINDOWS_VOLUME_STEP_PERCENT)
    if action == "mute":
        _press_key(_VK_VOLUME_MUTE)
        return "Stummschaltung umgeschaltet."
    if action == "set":
        # Windows-Medientasten kennen keinen Absolutwert, nur rauf/runter —
        # daher erst mit Reserve auf 0% runterfahren (fester, bekannter
        # Ausgangspunkt), dann in der Standard-Schrittgroesse (2%/Druck)
        # gezielt wieder hochfahren.
        pct = max(0, min(100, int(percent or 0)))
        for _ in range(60):
            _press_key(_VK_VOLUME_DOWN)
        for _ in range(round(pct / WINDOWS_VOLUME_STEP_PERCENT)):
            _press_key(_VK_VOLUME_UP)
        return f"Lautstaerke auf ca. {pct}% gesetzt."
    vk = _VK_VOLUME_UP if action == "up" else _VK_VOLUME_DOWN if action == "down" else None
    if vk is None:
        return f"Unbekannte Aktion '{action}'."
    n = max(1, min(int(steps or 5), 10))
    for _ in range(n):
        _press_key(vk)
    return f"Lautstaerke {'erhoeht' if action == 'up' else 'verringert'} (~{n * WINDOWS_VOLUME_STEP_PERCENT}%)."


def _tool_control_media(action):
    vk = {
        "play_pause": _VK_MEDIA_PLAY_PAUSE,
        "next": _VK_MEDIA_NEXT_TRACK,
        "previous": _VK_MEDIA_PREV_TRACK,
    }.get(action)
    if vk is None:
        return f"Unbekannte Aktion '{action}'."
    _press_key(vk)
    return f"Medienbefehl '{action}' gesendet."


_SHORTCUT_DIRS = [
    os.path.join(os.environ.get("USERPROFILE", ""), "Desktop"),
    os.path.join(os.environ.get("PUBLIC", "C:\\Users\\Public"), "Desktop"),
    os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs"),
    os.path.join(os.environ.get("PROGRAMDATA", "C:\\ProgramData"), "Microsoft", "Windows", "Start Menu", "Programs"),
]


def _normalize_app_name(text):
    """Nur Buchstaben/Zahlen, alles andere raus — 'R.E.P.O.' und 'REPO'
    sollen als derselbe Name gelten."""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _find_app_shortcut(name):
    """Sucht unter den echten Desktop-/Startmenue-Verknuepfungen (.lnk/.url)
    nach einem Namen, der zur Suche passt — Ari kann so jedes installierte
    Programm oeffnen, ohne dass das Modell einen rohen Pfad angeben muss.
    Reihenfolge: exakter Treffer (nach Normalisierung) > exakter Treffer
    (roh) > Teilstring-Treffer. Exakte Treffer haben IMMER Vorrang vor
    Teilstring-Treffern — sonst kann z.B. 'REPO' faelschlich das "AMD Bug
    Report Tool" treffen, weil 'repo' als Teilstring in 'RePOrt' steckt,
    obwohl es fuer 'R.E.P.O.' (das eigentlich gemeinte Spiel) einen exakten
    Treffer gibt."""
    needle = name.strip().lower()
    needle_norm = _normalize_app_name(name)
    if not needle:
        return None
    candidates = []
    for base in _SHORTCUT_DIRS:
        if not base or not os.path.isdir(base):
            continue
        for root, _dirs, files in os.walk(base):
            for fname in files:
                stem, ext = os.path.splitext(fname)
                if ext.lower() not in (".lnk", ".url"):
                    continue
                candidates.append((stem, os.path.join(root, fname)))
    for stem, path in candidates:
        if _normalize_app_name(stem) == needle_norm:
            return path
    for stem, path in candidates:
        if stem.lower() == needle:
            return path
    for stem, path in candidates:
        if needle in stem.lower():
            return path
    return None


_start_apps_cache = {"apps": None, "ts": 0}


def _get_start_apps():
    """Fragt Windows' eigenen Katalog installierter Anwendungen ab (alles, was
    im Startmenue auftaucht — normale .exe-Programme UND Store/UWP-Apps).
    Das ist der generelle, zuverlaessige Weg statt fuer jedes Programm einzeln
    zu raten/hart zu codieren, wo es installiert ist: Windows kennt den Pfad
    bzw. die AppID schon selbst. 5 Min. gecacht, weil PowerShell-Start ~0.3-0.5s
    kostet und sich Installationen waehrend einer laufenden Sitzung kaum aendern."""
    if _start_apps_cache["apps"] is not None and (time.time() - _start_apps_cache["ts"]) < 300:
        return _start_apps_cache["apps"]
    apps = []
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-StartApps | ConvertTo-Json -Compress"],
            capture_output=True, timeout=10,
        )
        # Bytes statt text=True dekodieren: PowerShell schreibt manche
        # App-Namen (Sonderzeichen) sonst in der System-Codepage statt UTF-8,
        # was text=True mit der falschen Kodierung zum Absturz bringen kann.
        stdout = result.stdout.decode("utf-8", errors="replace")
        parsed = json.loads(stdout or "[]")
        if isinstance(parsed, dict):
            parsed = [parsed]
        apps = [{"name": a.get("Name", ""), "app_id": a.get("AppID", "")} for a in parsed if a.get("Name")]
    except Exception:
        apps = []
    _start_apps_cache["apps"] = apps
    _start_apps_cache["ts"] = time.time()
    return apps


def _resolve_app_target(name):
    """Sucht 'name' im Windows-Startmenue-Katalog. Gibt (kind, target) zurueck:
    ('path', <voller Programmpfad>) fuer normale .exe-Apps,
    ('uri', <URI>) fuer Eintraege, deren AppID selbst ein Protokoll-Link ist
    (z.B. Steam-Spiele: 'steam://rungameid/X'), oder
    ('shell', <AppID>) fuer Store/UWP-Apps bzw. Shell-Ordner-Verknuepfungen
    (die haben keinen direkten Dateipfad, sondern muessen ueber
    shell:AppsFolder gestartet werden)."""
    needle = name.strip().lower()
    apps = _get_start_apps()
    exact = [a for a in apps if a["name"].lower() == needle]
    partial = [a for a in apps if needle in a["name"].lower()]
    match = (exact or partial or [None])[0]
    if not match:
        return None
    app_id = match["app_id"]
    if os.path.isfile(app_id):
        return ("path", app_id)
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", app_id):
        return ("uri", app_id)
    return ("shell", app_id)


def _find_steam_exe():
    for candidate in (
        r"C:\Program Files (x86)\Steam\steam.exe",
        r"C:\Program Files\Steam\steam.exe",
    ):
        if os.path.isfile(candidate):
            return candidate
    return "steam.exe"


def _launch_uri(uri):
    """os.startfile() auf einen Steam-Link (steam://rungameid/X) bringt oft
    nur den Steam-Client auf die Spieleseite, statt das Spiel wirklich zu
    starten — vor allem wenn Steam gerade erst hochfaehrt und den Protokoll-
    Aufruf verschluckt. 'steam.exe -applaunch <appid>' ist der von Valve
    empfohlene Weg fuer einen zuverlaessigen Start, deshalb hier bevorzugt."""
    match = re.match(r"steam://rungameid/(\d+)", uri)
    if match:
        subprocess.Popen([_find_steam_exe(), "-applaunch", match.group(1)])
        return
    os.startfile(uri)


def _launch_shortcut(path):
    """Startet eine .lnk/.url-Verknuepfung — bei einer Steam-URL darin ueber
    _launch_uri() fuer einen zuverlaessigen Start statt os.startfile()."""
    if path.lower().endswith(".url"):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except OSError:
            content = ""
        match = re.search(r"steam://rungameid/\d+", content)
        if match:
            _launch_uri(match.group(0))
            return
    os.startfile(path)


def _tool_open_app(name):
    if not IS_WIN:
        return _lx.open_app(name)
    key = (name or "").strip().lower()
    exe = APP_REGISTRY.get(key)
    if exe:
        # Nur fuer die Handvoll Windows-Bordmittel (notepad, calc, explorer, ...),
        # die zuverlaessig ueber PATH/System32 aufloesen — kein Rateversuch fuer
        # richtige Programme, dafuer ist die generelle Aufloesung unten da.
        try:
            os.startfile(exe)
            return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
    # Desktop-Verknuepfungen zuerst (das ist, was der Nutzer sich selbst
    # bewusst auf den Desktop gelegt hat — vorhersehbarer als der komplette
    # Windows-Katalog). Der Katalog (Get-StartApps) ist nur der Fallback fuer
    # Programme ohne Desktop-Icon.
    shortcut = _find_app_shortcut(name)
    if shortcut:
        try:
            _launch_shortcut(shortcut)
            return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
    target = _resolve_app_target(name)
    if target:
        kind, value = target
        try:
            if kind == "path":
                os.startfile(value)
            elif kind == "uri":
                _launch_uri(value)
            else:
                subprocess.Popen(["explorer.exe", "shell:AppsFolder\\" + value])
            return f"'{name}' wird gestartet."
        except OSError as e:
            return f"Konnte '{name}' nicht starten: {e}"
    return f"Keine installierte Anwendung/Verknuepfung fuer '{name}' gefunden."


def _tool_close_app(name):
    key = (name or "").strip().lower()
    exe = APP_REGISTRY.get(key)
    if exe and IS_WIN:
        result = subprocess.run(["taskkill", "/IM", exe, "/F"], capture_output=True, text=True)
        if result.returncode == 0:
            return f"'{name}' wurde beendet."
        return f"'{name}' lief nicht oder konnte nicht beendet werden."
    needle = key
    if not IS_WIN:
        # Linux: Kurznamen (chrome, notepad, ...) auf die echten Prozessnamen abbilden; sonst Suche im Prozessnamen
        alias = _lx.close_app_names(name)
        if alias:
            needle = alias[0]
            names = {a.lower() for a in alias}
            matched = [p for p in psutil.process_iter(["pid", "name"]) if (p.info.get("name") or "").lower() in names or any(a in (p.info.get("name") or "").lower() for a in names)]
            if matched:
                for proc in matched:
                    try:
                        proc.kill()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                return f"'{name}' wurde beendet ({len(matched)} Prozess(e))."
    matched = []
    for proc in psutil.process_iter(["pid", "name"]):
        pname = (proc.info.get("name") or "")
        if needle in pname.lower() or needle in os.path.splitext(pname)[0].lower():
            matched.append(proc)
    if not matched:
        return f"'{name}' laeuft nicht (kein passender Prozess gefunden)."
    for proc in matched:
        try:
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return f"'{name}' wurde beendet ({len(matched)} Prozess(e))."


SCREENSHOT_MAX_FILES = 20


def _tool_take_screenshot():
    from PIL import ImageGrab
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    filename = "screenshot_" + time.strftime("%Y%m%d_%H%M%S") + ".png"
    ImageGrab.grab().save(os.path.join(SCREENSHOT_DIR, filename))
    # Ohne Aufraeumen wuerde der Ordner bei jedem Screenshot-Tool-Aufruf
    # unbegrenzt weiterwachsen — nur die letzten N behalten, aelteste loeschen.
    try:
        existing = sorted(
            (f for f in os.listdir(SCREENSHOT_DIR) if f.startswith("screenshot_") and f.endswith(".png")),
        )
        for old in existing[:-SCREENSHOT_MAX_FILES]:
            os.remove(os.path.join(SCREENSHOT_DIR, old))
    except OSError:
        pass
    return f"Screenshot gespeichert als {filename}."


def _tool_manage_window(action):
    if not IS_WIN:
        if action == "minimize_active":
            return "Aktives Fenster minimiert." if _lx.minimize_active() else "Konnte das aktive Fenster nicht minimieren (xdotool/X11 noetig)."
        if action == "show_desktop":
            return "Desktop angezeigt." if _lx.show_desktop() else "Konnte den Desktop nicht anzeigen (wmctrl/X11 noetig)."
        return f"Unbekannte Aktion '{action}'."
    if action == "minimize_active":
        hwnd = ctypes.windll.user32.GetForegroundWindow()
        ctypes.windll.user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
        return "Aktives Fenster minimiert."
    if action == "show_desktop":
        _press_key(_VK_LWIN, extended=False)
        _press_key(_VK_D, extended=False)
        return "Desktop angezeigt."
    return f"Unbekannte Aktion '{action}'."


def _find_window_by_title(needle):
    """Sucht per EnumWindows nach dem ersten sichtbaren Fenster, dessen Titel
    die Suche enthaelt (case-insensitive) — Grundlage fuer 'interagiere mit
    Fenster X', ohne dass Ari raten muss, wie das Fenster exakt heisst."""
    if not IS_WIN:
        return _lx.find_window(needle)
    needle = needle.strip().lower()
    matches = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)

    def _callback(hwnd, _lparam):
        if not ctypes.windll.user32.IsWindowVisible(hwnd):
            return True
        length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
        if needle in buf.value.lower():
            matches.append((hwnd, buf.value))
        return True

    ctypes.windll.user32.EnumWindows(EnumWindowsProc(_callback), 0)
    return matches[0] if matches else None


def _get_monitors():
    """Alle Bildschirme, von links nach rechts sortiert (= Nummer 1, 2, 3, ...
    wie man sie sich vorstellt), je als (left, top, right, bottom)."""
    if not IS_WIN:
        return []
    import ctypes.wintypes as wt
    rects = []
    MONITORENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(wt.RECT), ctypes.c_double)

    def _cb(hmon, hdc, rect, data):
        r = rect.contents
        rects.append((r.left, r.top, r.right, r.bottom))
        return 1

    ctypes.windll.user32.EnumDisplayMonitors(0, 0, MONITORENUMPROC(_cb), 0)
    rects.sort(key=lambda r: r[0])
    return rects


def _move_window_to_screen(hwnd, screen_num):
    """Verschiebt (und zentriert) ein Fenster auf den angegebenen Bildschirm (1-basiert,
    von links nach rechts gezaehlt). Behaelt die Fenstergroesse bei, nur die Position aendert sich."""
    import ctypes.wintypes as wt
    mons = _get_monitors()
    if not mons:
        return False, "Konnte keine Bildschirme erkennen."
    if screen_num < 1 or screen_num > len(mons):
        return False, f"Bildschirm {screen_num} gibt es nicht (erkannt: {len(mons)})."
    left, top, right, bottom = mons[screen_num - 1]
    ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE - sonst klappt das Verschieben bei maximiert/minimiert nicht
    rect = wt.RECT()
    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
    w = min(rect.right - rect.left, right - left)
    h = min(rect.bottom - rect.top, bottom - top)
    x = left + max(0, ((right - left) - w) // 2)
    y = top + max(0, ((bottom - top) - h) // 2)
    ctypes.windll.user32.SetWindowPos(hwnd, 0, x, y, w, h, 0x0004)  # SWP_NOZORDER
    return True, None


def _tool_window_action(title, action, screen=None):
    found = _find_window_by_title(title or "")
    if not found:
        return f"Kein offenes Fenster mit Titel '{title}' gefunden."
    hwnd, real_title = found
    if not IS_WIN:
        if action not in ("focus", "minimize", "maximize", "close"):
            return f"Unbekannte Aktion '{action}'."
        ok = _lx.window_action(hwnd, action)
        past = {"focus": "fokussiert", "minimize": "minimiert", "maximize": "maximiert", "close": "geschlossen"}[action]
        return f"Fenster '{real_title}' {past}." if ok else f"Aktion '{action}' fuer Fenster '{real_title}' fehlgeschlagen (X11/xdotool/wmctrl noetig)."
    if action == "focus":
        ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        ctypes.windll.user32.SetForegroundWindow(hwnd)
        return f"Fenster '{real_title}' fokussiert."
    if action == "minimize":
        ctypes.windll.user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
        return f"Fenster '{real_title}' minimiert."
    if action == "maximize":
        ctypes.windll.user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE
        return f"Fenster '{real_title}' maximiert."
    if action == "close":
        ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
        return f"Fenster '{real_title}' geschlossen."
    if action == "move_screen":
        try:
            n = int(screen)
        except (TypeError, ValueError):
            return "Bitte eine Bildschirmnummer angeben (z.B. 2)."
        ok, err = _move_window_to_screen(hwnd, n)
        return f"Fenster '{real_title}' auf Bildschirm {n} verschoben." if ok else err
    return f"Unbekannte Aktion '{action}'."


# ---------------------------------------------------------------------------
# Browser-Steuerung: URLs oeffnen + "neuestes Video von Kanal X" auf YouTube.
# Bewusst OHNE YouTube-API-Key geloest — jeder YouTube-Kanal hat einen
# oeffentlichen RSS-Feed (kein Login/Key noetig), der die zuletzt hochgeladenen
# Videos chronologisch liefert. Kanalname -> channel_id wird durch einmaliges
# Abrufen der Kanal-/Suchseite und Regex auf das darin eingebettete
# "channelId":"UC..." aufgeloest (kein zusaetzliches pip-Paket noetig, nur
# Python-Standardbibliothek). Nur http/https-URLs werden geoeffnet, damit ein
# Tool-Aufruf nicht auf andere registrierte Protokoll-Handler zielen kann.
# ---------------------------------------------------------------------------
import re
import urllib.request
import urllib.parse
import webbrowser
import xml.etree.ElementTree as ET

_YT_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"}
_YT_CHANNEL_ID_RE = re.compile(r'"channelId":"(UC[0-9A-Za-z_-]{22})"')


def _yt_fetch(url):
    req = urllib.request.Request(url, headers=_YT_HEADERS)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def _resolve_youtube_channel_id(name):
    handle = re.sub(r"\s+", "", name)
    candidate_urls = (
        f"https://www.youtube.com/@{urllib.parse.quote(handle)}",
        f"https://www.youtube.com/results?search_query={urllib.parse.quote(name)}",
    )
    for url in candidate_urls:
        try:
            html = _yt_fetch(url)
        except Exception:
            continue
        m = _YT_CHANNEL_ID_RE.search(html)
        if m:
            return m.group(1)
    return None


def _tool_play_youtube_latest(channel):
    if not channel:
        return "Kein Kanalname angegeben."
    channel_id = _resolve_youtube_channel_id(channel)
    if not channel_id:
        return f"Konnte den YouTube-Kanal '{channel}' nicht finden."
    try:
        feed_xml = _yt_fetch(f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}")
        root = ET.fromstring(feed_xml)
    except Exception as e:
        return f"Konnte die Videoliste von '{channel}' nicht laden: {e}"
    ns = {"atom": "http://www.w3.org/2005/Atom"}
    entry = root.find("atom:entry", ns)
    if entry is None:
        return f"Keine Videos fuer '{channel}' gefunden."
    link_el = entry.find("atom:link", ns)
    video_url = link_el.get("href") if link_el is not None else None
    title_el = entry.find("atom:title", ns)
    title = title_el.text if title_el is not None else "unbekannter Titel"
    if not video_url:
        return f"Konnte das neueste Video von '{channel}' nicht oeffnen."
    webbrowser.open(video_url)
    return f"Spiele „{title}“ von {channel} ab."


_YT_VIDEO_RE = re.compile(r'"videoRenderer":\{"videoId":"([0-9A-Za-z_-]{11})"')
_YT_TITLE_RE = re.compile(r'"videoRenderer":\{"videoId":"([0-9A-Za-z_-]{11})".{0,1500}?"title":\{"runs":\[\{"text":"([^"]{1,200})"')


def _tool_play_youtube(query, music=False):
    """Beliebiges Video (oder Song auf YouTube Music) per Suchbegriff finden und
    im Standardbrowser abspielen - ohne API-Key: das erste Suchergebnis wird aus
    der YouTube-Ergebnisseite gelesen, dann direkt die Abspiel-Seite geoeffnet."""
    query = (query or "").strip()
    if not query:
        return "Kein Suchbegriff angegeben."
    try:
        html = _yt_fetch("https://www.youtube.com/results?search_query=" + urllib.parse.quote(query) + "&sp=EgIQAQ%253D%253D")  # nur Videos
    except Exception as e:
        return f"YouTube-Suche fehlgeschlagen: {e}"
    m = _YT_TITLE_RE.search(html)
    vid, title = (m.group(1), m.group(2)) if m else (None, None)
    if not vid:
        m2 = _YT_VIDEO_RE.search(html)
        vid, title = (m2.group(1), query) if m2 else (None, None)
    if not vid:
        return f"Nichts zu '{query}' auf YouTube gefunden."
    host = "music.youtube.com" if music else "www.youtube.com"
    webbrowser.open(f"https://{host}/watch?v={vid}")
    try:
        title = json.loads('"' + title + '"')
    except Exception:
        pass
    return f"Spiele „{title}“ auf {'YouTube Music' if music else 'YouTube'}."


def _tool_open_url(url):
    if not url or not re.match(r"^https?://", url, re.IGNORECASE):
        return "Nur http/https-URLs sind erlaubt."
    webbrowser.open(url)
    return f"Öffne {url} im Browser."


def _emit_link(url, label):
    """Link fuer den Nutzer bereitstellen: vom Handy aus in der Antwort, am PC
    zusaetzlich direkt im Browser."""
    _chat_ctx["links"].append({"url": url, "label": label})
    if not _chat_ctx["remote"]:
        webbrowser.open(url)


def _tool_maps_route(destination, origin="", mode="driving"):
    destination = (destination or "").strip()
    if not destination:
        return "Kein Ziel angegeben."
    travel = {"driving": "driving", "walking": "walking", "bicycling": "bicycling", "transit": "transit"}.get(mode or "driving", "driving")
    url = "https://www.google.com/maps/dir/?api=1&destination=" + urllib.parse.quote(destination) + "&travelmode=" + travel
    if (origin or "").strip():
        url += "&origin=" + urllib.parse.quote(origin.strip())
    _emit_link(url, "Route nach " + destination)
    return f"Route nach '{destination}' ({travel}) in Google Maps bereit - Start ist der aktuelle Standort, falls kein Start genannt wurde."


def _tool_find_restaurant(query, people=None, when=None):
    query = (query or "").strip()
    if not query:
        return "Kein Restaurant/Suchbegriff angegeben."
    _emit_link("https://www.google.com/maps/search/?api=1&query=" + urllib.parse.quote(query), "Auf Google Maps: " + query)
    ot = "https://www.opentable.de/s?term=" + urllib.parse.quote(query)
    detail = []
    try:
        n = int(people)
        if 1 <= n <= 20:
            ot += f"&covers={n}"
            detail.append(f"{n} Personen")
    except (TypeError, ValueError):
        pass
    if when:
        m = re.match(r"^\s*(\d{4}-\d{2}-\d{2})[ T](\d{1,2}):(\d{2})", str(when))
        if m:
            ot += f"&dateTime={m.group(1)}T{int(m.group(2)):02d}:{m.group(3)}"
            detail.append(f"{m.group(1)} {int(m.group(2)):02d}:{m.group(3)} Uhr")
    _emit_link(ot, "Tisch reservieren (OpenTable)" + (": " + ", ".join(detail) if detail else ""))
    return (
        f"Links fuer '{query}' bereit ({', '.join(detail) or 'ohne Personen/Zeit'}): Karte + Reservierungsseite mit vorausgefuellten Daten. "
        "Die Buchung selbst muss der Nutzer auf der Seite bestaetigen - ich kann nicht selbst verbindlich buchen."
    )


# Bekannte Streaming-Anbieter und ihre Such-URL (oeffnet die Trefferliste fuer den Titel -
# ein direkter "Abspiel"-Link ohne Login/App-Unterstuetzung gibt keiner der Dienste her).
_STREAMING_PROVIDERS = {
    "netflix": "https://www.netflix.com/search?q={q}",
    "disney+": "https://www.disneyplus.com/search/{q}",
    "disney plus": "https://www.disneyplus.com/search/{q}",
    "amazon prime video": "https://www.amazon.de/s?k={q}&i=instant-video",
    "prime video": "https://www.amazon.de/s?k={q}&i=instant-video",
    "amazon": "https://www.amazon.de/s?k={q}&i=instant-video",
    "apple tv+": "https://tv.apple.com/search?term={q}",
    "apple tv plus": "https://tv.apple.com/search?term={q}",
    "apple tv": "https://tv.apple.com/search?term={q}",
    "paramount+": "https://www.paramountplus.com/de/search/?query={q}",
    "paramount plus": "https://www.paramountplus.com/de/search/?query={q}",
    "sky": "https://www.wow.de/suche?q={q}",
    "wow": "https://www.wow.de/suche?q={q}",
    "joyn": "https://www.joyn.de/suche?q={q}",
    "rtl+": "https://plus.rtl.de/suche?q={q}",
    "rtl plus": "https://plus.rtl.de/suche?q={q}",
    "youtube": "https://www.youtube.com/results?search_query={q}",
    "dazn": "https://www.google.com/search?q={q}+site:dazn.com",
    "crunchyroll": "https://www.crunchyroll.com/search?q={q}",
    "magentatv": "https://www.google.com/search?q={q}+site:magentatv.de",
    "magenta tv": "https://www.google.com/search?q={q}+site:magentatv.de",
    "ard mediathek": "https://www.ardmediathek.de/suche/{q}",
    "ard": "https://www.ardmediathek.de/suche/{q}",
    "zdf mediathek": "https://www.zdf.de/suche?q={q}",
    "zdf": "https://www.zdf.de/suche?q={q}",
    "arte": "https://www.arte.tv/de/search/?q={q}",
    "twitch": "https://www.twitch.tv/search?term={q}",
    "max": "https://www.max.com/search?q={q}",
    "hbo max": "https://www.max.com/search?q={q}",
    "plex": "https://watch.plex.tv/search?q={q}",
    "pluto tv": "https://www.google.com/search?q={q}+site:pluto.tv",
    "rakuten tv": "https://www.google.com/search?q={q}+site:rakuten.tv",
}
# Die Dienste, die man im Gehirn ankreuzen kann (Anzeigename, Suchwoerter zum Wiedererkennen im JustWatch-Namen)
_STREAMING_CHOICES = [
    ("Netflix", ("netflix",)), ("Disney+", ("disney",)), ("Amazon Prime Video", ("amazon", "prime")), ("Apple TV+", ("apple",)),
    ("Paramount+", ("paramount",)), ("WOW (Sky)", ("wow", "sky")), ("RTL+", ("rtl",)), ("Joyn", ("joyn",)), ("DAZN", ("dazn",)),
    ("Crunchyroll", ("crunchyroll",)), ("MagentaTV", ("magenta",)), ("ARD Mediathek", ("ard",)), ("ZDF Mediathek", ("zdf",)),
    ("ARTE", ("arte",)), ("Max (HBO)", ("max", "hbo")), ("YouTube", ("youtube",)), ("Twitch", ("twitch",)), ("Plex", ("plex",)),
    ("Pluto TV", ("pluto",)), ("Rakuten TV", ("rakuten",)),
]
_STREAMING_BRAIN_KEY = "streaming:services"


def _user_streaming_services():
    """Die im Gehirn angekreuzten Streaming-Dienste (Liste der Anzeigenamen)."""
    for n in _brain_load():
        if n.get("key") == _STREAMING_BRAIN_KEY or str(n.get("text", "")).startswith("Hat diese Streaming-Dienste:"):   # auch vom Handy angelegt
            m = re.search(r":\s*(.+)$", n.get("text", ""))
            if m:
                known = {name.lower(): name for name, _ in _STREAMING_CHOICES}
                return [known[x.strip().lower()] for x in m.group(1).split(",") if x.strip().lower() in known]
    return []


def _streaming_matches(package_name, service_name):
    """Passt der JustWatch-Anbietername (z.B. 'Disney Plus') zu einem Dienst aus der Auswahl (z.B. 'Disney+')?"""
    low = (package_name or "").lower()
    words = next((w for name, w in _STREAMING_CHOICES if name == service_name), ())
    return any(re.search(r"(?<![a-z])" + re.escape(w) + r"(?![a-z])", low) for w in words)
_BRAIN_STREAMING_CAT = "Streaming-Anbieter"
_JUSTWATCH_QUERY = """
query GetSearchTitles($searchTitlesFilter: TitleFilter!, $country: Country!, $language: Language!, $first: Int!) {
  popularTitles(country: $country, filter: $searchTitlesFilter, first: $first) {
    edges {
      node {
        content(country: $country, language: $language) { title }
        offers(country: $country, platform: WEB) { monetizationType standardWebURL package { clearName } }
      }
    }
  }
}
"""


def _justwatch_lookup(title, prefer=None):
    """Recherchiert bei JustWatch (Deutschland), auf welchem Abo-Streaming-Dienst ein Film/eine
    Serie tatsaechlich laeuft - kein Raten. Gibt (Anbietername, direkter Link zur Titelseite beim
    Anbieter) zurueck, oder (None, None)."""
    try:
        payload = {
            "query": _JUSTWATCH_QUERY,
            "variables": {
                "searchTitlesFilter": {"searchQuery": title},
                "country": "DE", "language": "de", "first": 1,
            },
            "operationName": "GetSearchTitles",
        }
        req = urllib.request.Request(
            "https://apis.justwatch.com/graphql",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"},
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read())
        edges = (((data.get("data") or {}).get("popularTitles") or {}).get("edges")) or []
        if not edges:
            return None, None
        offers = (edges[0].get("node") or {}).get("offers") or []
        if not offers:
            return None, None
        # Im Abo enthalten (FLATRATE) bevorzugen, sonst irgendein Angebot (Kauf/Leihe) als Notloesung
        flatrate = [o for o in offers if o.get("monetizationType") == "FLATRATE"]
        mine = [o for o in flatrate if any(_streaming_matches((o.get("package") or {}).get("clearName"), svc) for svc in (prefer or []))]
        pick = mine[0] if mine else (flatrate[0] if flatrate else offers[0])   # eigene Dienste zuerst
        name = (pick.get("package") or {}).get("clearName")
        return (name or None), (pick.get("standardWebURL") or None)
    except Exception:
        return None, None


def _streaming_provider_url(provider, title):
    key = re.sub(r"\s+", " ", (provider or "").strip().lower())
    tmpl = _STREAMING_PROVIDERS.get(key)
    if not tmpl:
        for k, v in _STREAMING_PROVIDERS.items():
            if k in key or key in k:
                tmpl = v
                break
    if not tmpl:
        return None
    return tmpl.format(q=urllib.parse.quote(title))


def _tool_play_streaming_title(title, provider=""):
    """Findet heraus (gemerkt -> recherchiert bei JustWatch -> Notloesung Rateversuch der KI),
    auf welchem Streaming-Dienst ein Titel laeuft, merkt sich Anbieter UND direkten Link zur
    Titelseite fuer naechste Mal (kein erneutes Suchen mehr noetig - direkt zum Abspielen)."""
    title = (title or "").strip()
    if not title:
        return "Kein Titel angegeben."
    remembered_provider = None
    remembered_url = None
    low_title = title.lower()
    for n in _brain_load():
        if n.get("cat") == _BRAIN_STREAMING_CAT and low_title in n.get("text", "").lower():
            m = re.search(r"l[äa]uft auf ([^(]+?)(?:\s*\((https?://[^)]+)\))?\s*$", n["text"], re.IGNORECASE)
            if m:
                remembered_provider = m.group(1).strip()
                remembered_url = m.group(2)
                break
    source = "gemerkt"
    used_provider = remembered_provider
    direct_url = remembered_url
    mine = _user_streaming_services()
    if not used_provider:
        used_provider, direct_url = _justwatch_lookup(title, mine)
        source = "recherchiert"
    if not used_provider:
        used_provider = (provider or "").strip()
        source = "Rateversuch"
    if not used_provider:
        return f"Ich konnte nicht herausfinden, wo '{title}' laeuft - sag mir den Streaming-Anbieter, dann merke ich ihn mir."
    if not remembered_provider:
        note = f"{title} läuft auf {used_provider}" + (f" ({direct_url})" if direct_url else "")
        _brain_add(note, cat=_BRAIN_STREAMING_CAT)
    url = direct_url or _streaming_provider_url(used_provider, title)
    if not url:
        url = "https://www.google.com/search?q=" + urllib.parse.quote(f"{title} {used_provider} stream")
    _emit_link(url, f"Jetzt abspielen: {title} ({used_provider})")
    kind = "direkt zum Abspielen bereit" if direct_url else "Suchergebnisse geoeffnet"
    extra = ""
    if mine and not any(_streaming_matches(used_provider, svc) for svc in mine):
        extra = f" Hinweis: {used_provider} gehört nicht zu deinen angekreuzten Streaming-Diensten."
    return f"'{title}' laeuft auf {used_provider} ({source}) - {kind}.{extra}"


def _tool_search_web(query):
    if not query:
        return "Kein Suchbegriff angegeben."
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(query))
    return f"Suche nach „{query}“ geöffnet."


# ---------------------------------------------------------------------------
# Echte Web-Suche mit Ergebnis-Text fuer OpenAI/Groq: die haben (anders als
# Anthropic) kein eingebautes Server-Search-Tool in der hier genutzten API,
# also holen wir Ergebnis-Schnipsel selbst (DuckDuckGo-HTML, kein API-Key
# noetig) und geben sie dem Modell als Tool-Ergebnis zum Auswerten mit —
# nur bewusst simples Regex-Parsing (kein neues pip-Paket), daher etwas
# empfindlich gegenueber Aenderungen an DuckDuckGos HTML-Struktur.
# ---------------------------------------------------------------------------
import html as _html_lib


def _duckduckgo_search(query, max_results=5):
    page = _yt_fetch("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query))
    titles_links = re.findall(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', page, re.S)
    snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', page, re.S)
    results = []
    for i, (href, title_html) in enumerate(titles_links[:max_results]):
        real_url = href
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
        if "uddg" in qs:
            real_url = urllib.parse.unquote(qs["uddg"][0])
        title = _html_lib.unescape(re.sub(r"<[^>]+>", "", title_html)).strip()
        snippet = _html_lib.unescape(re.sub(r"<[^>]+>", "", snippets[i])).strip() if i < len(snippets) else ""
        results.append({"title": title, "url": real_url, "snippet": snippet})
    return results


def _tool_web_search_answer(query):
    if not query:
        return "Kein Suchbegriff angegeben."
    try:
        results = _duckduckgo_search(query)
    except Exception as e:
        return f"Suche fehlgeschlagen: {e}"
    if not results:
        return f"Keine Ergebnisse fuer '{query}' gefunden."
    lines = [f"Suchergebnisse fuer '{query}':"]
    for r in results:
        lines.append(f"- {r['title']}: {r['snippet']} ({r['url']})")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# GEHIRN: dauerhaftes Gedaechtnis. Alles, was A.R.I ueber den Nutzer lernt,
# landet in data/brain.json, wird bei JEDER Antwort in den System-Prompt
# eingespeist (so wird er mit der Zeit "schlauer") und im HUD als 3D-Netz
# visualisiert.
# ---------------------------------------------------------------------------
BRAIN_FILE = os.path.join(DATA_DIR, "brain.json")
BRAIN_CATEGORIES = [
    "Wissen", "Vorlieben", "Personen", "Projekte", "Spiele", "Gewohnheiten", "Aufgaben",
    "Musik", "Medien", "Technik", "Arbeit", "Lernen", "Ziele", "Gesundheit", "Finanzen",
    "Familie", "Freunde", "Orte", "Reisen", "Termine", "Essen", "Hobbys", "Mail und Meldungen", "Streaming-Anbieter",
]
_BRAIN_MAX_NODES = 400
_BRAIN_PROMPT_MAX = 30
_brain_lock = threading.Lock()


def _brain_load():
    try:
        with open(BRAIN_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        nodes = data.get("nodes", []) if isinstance(data, dict) else []
        return [n for n in nodes if isinstance(n, dict) and n.get("id") and n.get("text")]
    except (OSError, ValueError):
        return []


def _brain_save(nodes):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = BRAIN_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"nodes": nodes}, f, ensure_ascii=False, indent=1)
    os.replace(tmp, BRAIN_FILE)


_BRAIN_MAX_CATS = 30


def _brain_categories(nodes=None):
    """Standard-Bereiche + alle, die A.R.I selbst angelegt hat."""
    cats = list(BRAIN_CATEGORIES)
    for n in (nodes if nodes is not None else _brain_load()):
        c = n.get("cat")
        if c and c not in cats:
            cats.append(c)
    return cats


def _brain_norm_cat(cat, existing=None):
    """Bekannte Kategorie (case-insensitiv) wiederverwenden, sonst eine neue
    kurze anlegen (max. _BRAIN_MAX_CATS insgesamt, sonst 'Wissen')."""
    c = re.sub(r"[^A-Za-z0-9\u00c4\u00d6\u00dc\u00e4\u00f6\u00fc\u00df \-]", "", cat or "").strip()[:24]
    if not c:
        return "Wissen"
    known = existing if existing is not None else _brain_categories()
    for k in known:
        if k.lower() == c.lower():
            return k
    if len(known) >= _BRAIN_MAX_CATS:
        return "Wissen"
    return c[:1].upper() + c[1:]


def _brain_add(text, cat=None):
    """Legt eine Erinnerung an. Gibt (node, dup) zurueck; dup=True wenn es
    sie (fast) schon gibt — dann wird nur der Zaehler erhoeht."""
    text = re.sub(r"\s+", " ", (text or "")).strip()[:300]
    if len(text) < 3:
        return None, False
    with _brain_lock:
        nodes = _brain_load()
        low = text.lower()
        for n in nodes:
            other = n["text"].lower()
            if other == low or difflib.SequenceMatcher(None, other, low).ratio() > 0.88:
                n["uses"] = int(n.get("uses", 0)) + 1
                _brain_save(nodes)
                return n, True
        node = {
            "id": uuid.uuid4().hex[:10],
            "text": text,
            "cat": _brain_norm_cat(cat, _brain_categories(nodes)),
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "uses": 0,
        }
        nodes.append(node)
        if len(nodes) > _BRAIN_MAX_NODES:
            nodes.sort(key=lambda n: (int(n.get("uses", 0)), n.get("created", "")))
            nodes = nodes[len(nodes) - _BRAIN_MAX_NODES:]
        _brain_save(nodes)
        return node, False


def _brain_forget(query):
    q = (query or "").strip().lower()
    if not q:
        return 0
    with _brain_lock:
        nodes = _brain_load()
        keep = [n for n in nodes if n["id"] != q and q not in n["text"].lower()]
        removed = len(nodes) - len(keep)
        if removed:
            _brain_save(keep)
        return removed


_BRAIN_LIVE_PREFIXES = ("cal:", "mail:", "note:")
_BRAIN_MAIL_CAT = "Mail und Meldungen"
_brain_sync_state = {"t": 0.0, "running": False}


def _brain_when(iso):
    try:
        if iso and "T" in iso:
            return datetime.datetime.fromisoformat(iso.replace("Z", "+00:00")).strftime("%d.%m. %H:%M")
        return datetime.datetime.fromisoformat(iso).strftime("%d.%m.")
    except (ValueError, TypeError):
        return str(iso or "")


def _brain_replace_live(prefix, cat, items):
    """items: {key: text}. Ersetzt alle Eintraege mit diesem Praefix (alte
    Termine/Mails verschwinden), behaelt id/Datum/Nutzung bestehender Keys."""
    with _brain_lock:
        nodes = _brain_load()
        old = {n.get("key"): n for n in nodes if str(n.get("key", "")).startswith(prefix)}
        nodes = [n for n in nodes if not str(n.get("key", "")).startswith(prefix)]
        for key, text in items.items():
            prev = old.get(key)
            nodes.append({
                "id": prev["id"] if prev else uuid.uuid4().hex[:10], "key": key, "text": text[:300], "cat": cat,
                "created": prev["created"] if prev else datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                "uses": prev.get("uses", 0) if prev else 0,
            })
        _brain_save(nodes)


def _brain_sync_live():
    """Zieht aktuelle Kalender-Termine und ungelesene Mails ins Gehirn
    (Hintergrund, gedrosselt) - schlaegt eine Quelle fehl, bleibt der alte
    Stand dieser Quelle unveraendert."""
    try:
        events, err = get_upcoming_events(days=30, max_results=30, days_back=0)
        if not err and events is not None:
            _brain_replace_live("cal:", "Termine", {
                "cal:" + str(e.get("id")): f"Termin: {e.get('title', '(Ohne Titel)')} - {_brain_when(e.get('start'))}" for e in events
            })
    except Exception as e:
        print(f"[brain] Kalender-Sync uebersprungen: {e}")
    try:
        mails, err = get_recent_emails(unread_only=True, max_results=10)
        if not err and mails is not None:
            _brain_replace_live("mail:", _BRAIN_MAIL_CAT, {
                "mail:" + str(m["id"]): f"E-Mail von {m.get('from_name') or m.get('from', '?')}: {m.get('subject', '(kein Betreff)')}" for m in mails
            })
    except Exception as e:
        print(f"[brain] Mail-Sync uebersprungen: {e}")
    _brain_sync_state["running"] = False


def _brain_sync_kick():
    if _brain_sync_state["running"] or time.time() - _brain_sync_state["t"] < 90:
        return
    _brain_sync_state["running"] = True
    _brain_sync_state["t"] = time.time()
    threading.Thread(target=_brain_sync_live, daemon=True).start()


def _brain_prompt_block(query=""):
    nodes = _brain_load()
    if not nodes:
        return ""
    nodes.sort(key=lambda n: (int(n.get("uses", 0)), n.get("created", "")), reverse=True)
    words = {w for w in re.findall(r"[a-zäöüß0-9]{4,}", (query or "").lower())}
    if words and len(nodes) > _BRAIN_PROMPT_MAX:
        # Token sparen: erst die zur Frage passenden Eintraege, dann die meistgenutzten.
        def score(n):
            txt = (str(n.get("text", "")) + " " + str(n.get("cat", ""))).lower()
            return sum(1 for w in words if w in txt)
        relevant = sorted((n for n in nodes if score(n) > 0), key=score, reverse=True)[:_BRAIN_PROMPT_MAX // 2]
        ids = {id(n) for n in relevant}
        nodes = relevant + [n for n in nodes if id(n) not in ids]
    # Live-Eintraege (Termine/Mails) NICHT in den Prompt: veralten schnell und
    # sollen keine Mail-Betreffe an den KI-Anbieter mitschicken.
    nodes = [n for n in nodes if not str(n.get("key", "")).startswith(_BRAIN_LIVE_PREFIXES)]
    if not nodes:
        return ""
    lines = [f"- [{n.get('cat', 'Wissen')}] {n['text']}" for n in nodes[:_BRAIN_PROMPT_MAX]]
    return (
        "\n\nDEIN GEDAECHTNIS (was du ueber den Nutzer gelernt hast - nutze es "
        "selbstverstaendlich und ungefragt, erwaehne nicht jedes Mal, dass du es "
        "gespeichert hast):\n" + "\n".join(lines)
    )


_BRAIN_PROMPT_RULES = (
    "\n\nGEDAECHTNIS-REGEL: Erfaehrst du etwas Dauerhaftes ueber den Nutzer "
    "(Vorlieben, Namen, Personen, Projekte, Gewohnheiten, Setup, Ziele) oder "
    "sagt er 'merk dir ...', rufe das Tool remember auf - knapp als ganzer Satz "
    "und mit passender Kategorie - passt keine bestehende, waehle eine neue kurze. Keine Belanglosigkeiten, keine Passwoerter/Keys. "
    "Sagt er 'vergiss ...', nutze forget. Fragen ueber den Nutzer selbst (Hobbys, "
    "Familie, Vorlieben, Termine, was er mag) beantwortest du NUR aus deinem "
    "Gedaechtnis unten - steht dazu nichts drin, sag ehrlich, dass du es noch "
    "nicht weisst, und frag kurz nach; erfinde nichts und vermische keine "
    "Vermutungen mit Fakten. Nennt er dir dann die Antwort, speichere sie mit remember."
)


def _volume_rule(volume_target):
    if volume_target == "spotify":
        return ("\n\nLAUTSTAERKE: Befehle wie 'Lautstaerke auf 50', lauter, leiser, leise meinen die Lautstaerke von SPOTIFY "
                "(Tool set_spotify_volume). Nur wenn der Nutzer ausdruecklich Windows, System oder Computer sagt, nimm control_volume.")
    return ("\n\nLAUTSTAERKE: Befehle wie 'Lautstaerke auf 50', lauter, leiser, leise meinen IMMER die Windows-Systemlautstaerke "
            "(Tool control_volume). Nimm set_spotify_volume NUR, wenn der Nutzer ausdruecklich Spotify erwaehnt.")


def _system_prompt(language=None, volume_target=None, query=""):
    base = SYSTEM_PROMPT
    extra = ""
    lang = (language or "").strip()
    if lang and lang.lower() not in ("german", "deutsch"):
        base = base.replace("auf Deutsch (die", "auf " + lang + " (die")
        extra = ("\n\nSPRACHE: Der Nutzer nutzt " + lang + " als Systemsprache. Antworte IMMER auf " + lang +
                 " (auch wenn diese Anweisungen deutsch sind); die Anreden wie 'Boss' oder 'Chief' duerfen bleiben.")
    return base + extra + _volume_rule(volume_target) + _BRAIN_PROMPT_RULES + _brain_prompt_block(query) + _mod_prompt_extra()


def _tool_remember(text, category):
    node, dup = _brain_add(text, category)
    if not node:
        return "Nichts gespeichert (Text zu kurz)."
    return "Schon bekannt, Erinnerung verstaerkt." if dup else f"Gemerkt ({node['cat']}): {node['text']}"


def _tool_forget(query):
    n = _brain_forget(query)
    return f"{n} Erinnerung(en) vergessen." if n else "Dazu habe ich nichts gespeichert."


@app.route("/brain", methods=["GET"])
def brain_get():
    _brain_sync_kick()
    nodes = _brain_load()
    return jsonify({"categories": _brain_categories(nodes), "nodes": nodes})


@app.route("/brain", methods=["POST"])
def brain_post():
    data = request.get_json(silent=True) or {}
    node, dup = _brain_add(data.get("text", ""), data.get("cat"))
    if not node:
        return jsonify({"error": "Text zu kurz"}), 400
    return jsonify({"error": None, "node": node, "dup": dup})


@app.route("/brain/streaming", methods=["GET"])
def brain_streaming_get():
    return jsonify({"available": [n for n, _ in _STREAMING_CHOICES], "mine": _user_streaming_services()})


@app.route("/brain/streaming", methods=["POST"])
def brain_streaming_set():
    names = {n for n, _ in _STREAMING_CHOICES}
    mine = [x for x in ((request.get_json(silent=True) or {}).get("mine") or []) if isinstance(x, str) and x in names]
    if mine:
        _brain_upsert(_STREAMING_BRAIN_KEY, "Hat diese Streaming-Dienste: " + ", ".join(mine), _BRAIN_STREAMING_CAT)
    else:
        with _brain_lock:
            nodes = [n for n in _brain_load() if n.get("key") != _STREAMING_BRAIN_KEY and not str(n.get("text", "")).startswith("Hat diese Streaming-Dienste:")]
            _brain_save(nodes)
    return jsonify({"mine": _user_streaming_services()})


@app.route("/brain/delete", methods=["POST"])
def brain_delete():
    data = request.get_json(silent=True) or {}
    nid = str(data.get("id", "")).strip()
    if not nid:
        return jsonify({"error": "id fehlt"}), 400
    with _brain_lock:
        nodes = _brain_load()
        keep = [n for n in nodes if n["id"] != nid]
        _brain_save(keep)
    return jsonify({"error": None, "removed": len(nodes) - len(keep)})




BRAIN_STATS_FILE = os.path.join(DATA_DIR, "brain_stats.json")
_BRAIN_TOOL_STEPS = (3, 10, 25, 50, 100, 250)
_BRAIN_TOOL_LABELS = {
    "control_volume": "die Lautstaerke-Steuerung", "play_spotify": "Spotify-Wiedergabe",
    "control_media": "die Mediensteuerung", "open_app": "das Oeffnen von Apps",
    "close_app": "das Schliessen von Apps", "take_screenshot": "Screenshots",
    
    "manage_window": "die Fensterverwaltung", "window_action": "Fenster-Aktionen",
}


def _brain_upsert(key, text, cat):
    """Legt eine automatisch abgeleitete Erinnerung an oder aktualisiert sie
    (gleicher key) - so waechst ein Eintrag mit, statt Duplikate zu erzeugen."""
    with _brain_lock:
        nodes = _brain_load()
        for n in nodes:
            if n.get("key") == key:
                n["text"] = text
                _brain_save(nodes)
                return
        nodes.append({
            "id": uuid.uuid4().hex[:10], "key": key, "text": text[:300],
            "cat": _brain_norm_cat(cat, _brain_categories(nodes)),
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "uses": 0,
        })
        _brain_save(nodes)


def _brain_reinforce(user_text):
    """Erinnerungen, die zur aktuellen Nachricht passen, werden staerker
    (uses+1) - haeufig Relevantes waechst im Netz und im Prompt nach oben."""
    ws = {w for w in re.findall(r"[a-z\u00e4\u00f6\u00fc\u00df0-9]{5,}", user_text.lower())}
    if not ws:
        return
    with _brain_lock:
        nodes = _brain_load()
        hit = False
        for n in nodes:
            if ws & set(re.findall(r"[a-z\u00e4\u00f6\u00fc\u00df0-9]{5,}", n["text"].lower())):
                n["uses"] = int(n.get("uses", 0)) + 1
                hit = True
        if hit:
            _brain_save(nodes)


def _brain_track(user_text, tools_used):
    """Lernt Gewohnheiten aus dem Verhalten - ganz ohne Modell-Aufruf:
    welche Funktionen oft genutzt werden und zu welcher Tageszeit."""
    try:
        try:
            with open(BRAIN_STATS_FILE, "r", encoding="utf-8") as f:
                st = json.load(f)
        except (OSError, ValueError):
            st = {}
        tools = st.setdefault("tools", {})
        buckets = st.setdefault("buckets", {})
        h = datetime.datetime.now().hour
        b = "morgens" if 5 <= h < 11 else "mittags" if 11 <= h < 15 else "nachmittags" if 15 <= h < 18 else "abends" if 18 <= h < 23 else "nachts"
        buckets[b] = buckets.get(b, 0) + 1
        st["total"] = st.get("total", 0) + 1
        for t in set(tools_used or []):
            if t in ("remember", "forget"):
                continue
            tools[t] = tools.get(t, 0) + 1
            n = tools[t]
            if n in _BRAIN_TOOL_STEPS:
                label = _BRAIN_TOOL_LABELS.get(t, "die Funktion " + t.replace("_", " "))
                _brain_upsert("tool:" + t, f"Der Nutzer nutzt oft {label} (bisher {n}x).", "Gewohnheiten")
        if st["total"] % 10 == 0:
            top, cnt = max(buckets.items(), key=lambda kv: kv[1])
            if cnt / st["total"] >= 0.5:
                _brain_upsert("time", f"Der Nutzer ist meist {top} mit A.R.I aktiv.", "Gewohnheiten")
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(BRAIN_STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False)
        _brain_reinforce(user_text)
    except Exception as e:
        print(f"[brain] Tracking uebersprungen: {e}")


_BRAIN_CUES = re.compile(
    r"\b(ich|mein|meine|meinen|meinem|meiner|mir|mich|wir|unser|unsere|merk|vergiss|immer|nie|niemals|"
    r"heisse|hei\u00dfe|bin|habe|hab|mag|liebe|hasse|nutze|benutze|arbeite|spiele|wohne|studiere|plane|will|m\u00f6chte|moechte)\b",
    re.IGNORECASE,
)

_BRAIN_EXTRACT_PROMPT = (
    "Du bist das Lern-Modul eines Assistenten und baust sein Gedaechtnis auf. "
    "Du bekommst einen Gespraechsausschnitt ('Nutzer:' und 'A.R.I:'). Extrahiere "
    "ALLES Merkenswerte, das der NUTZER gesagt hat - in JEDEM Lebensbereich: "
    "Vorlieben, Abneigungen, Personen, Familie, Freunde, Projekte, Arbeit, Schule/"
    "Lernen, Hobbys, Spiele, Musik, Gesundheit, Finanzen, Orte, Reisen, Termine, "
    "Ziele, Gewohnheiten, Technik/Setup, aber auch Wissen/Regeln, die er dir "
    "beibringt, und Korrekturen. Auch Antworten auf Fragen von A.R.I zaehlen "
    "(z.B. A.R.I fragt nach Hobbys, Nutzer: 'Fussball' -> Hobby Fussball). "
    "Aussagen von A.R.I selbst sind KEINE Fakten - nur uebernehmen, wenn der Nutzer "
    "sie bestaetigt. Nicht speichern: reine Befehle (Musik an, Lautstaerke), "
    "Wetter/News-Fragen, Smalltalk, Passwoerter/Keys/Kontodaten. Jeder Fakt ein "
    "kurzer ganzer deutscher Satz in dritter Person ueber den Nutzer (z.B. 'Der "
    "Nutzer spielt Fussball.'). Kategorie je Fakt: bevorzugt eine von {cats}; passt "
    "keine, erfinde eine NEUE kurze (1-2 Woerter). Widerspricht der Nutzer einem "
    "frueheren Fakt ('nein, ich mag X nicht mehr'), gib zusaetzlich "
    "{{\"forget\":\"Stichwort\"}} aus. Antworte AUSSCHLIESSLICH mit einem JSON-Array "
    "wie [{{\"text\":\"...\",\"cat\":\"...\"}}] - oder [] wenn nichts Merkenswertes "
    "drinsteht. Maximal 6 Eintraege."
)


def _brain_extract_call(provider, keys_and_clients, user_text):
    prompt = _BRAIN_EXTRACT_PROMPT.format(cats=", ".join(_brain_categories()))
    if provider == "anthropic":
        r = keys_and_clients[0][1].messages.create(
            model=ANTHROPIC_MODEL, max_tokens=300, system=prompt,
            messages=[{"role": "user", "content": user_text}],
        )
        return next((b.text for b in r.content if b.type == "text"), "")
    model = {"openai": OPENAI_MODEL, "gemini": GEMINI_MODEL}.get(provider, GROQ_MODEL)
    c = _call_with_key_rotation(
        keys_and_clients,
        lambda client: client.chat.completions.create(
            model=model, max_tokens=300,
            messages=[{"role": "system", "content": prompt}, {"role": "user", "content": user_text}],
        ),
    )
    return c.choices[0].message.content or ""


def _brain_autolearn(provider, keys_and_clients, user_text):  # user_text darf mehrere Nachrichten enthalten
    """Laeuft im Hintergrund nach jeder Antwort: laesst das Modell aus der
    Nutzer-Nachricht dauerhafte Fakten ziehen und speichert sie - ohne dass
    der Nutzer 'merk dir' sagen muss."""
    try:
        raw = _brain_extract_call(provider, keys_and_clients, user_text[-1800:])
        m = re.search(r"\[.*\]", raw, re.DOTALL)
        if not m:
            return
        for item in json.loads(m.group(0))[:6]:
            if isinstance(item, dict) and isinstance(item.get("forget"), str) and len(item["forget"].strip()) >= 3:
                n = _brain_forget(item["forget"])
                if n:
                    print(f"[brain] vergessen ({n}): {item['forget']}")
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                node, dup = _brain_add(item["text"], item.get("cat"))
                if node and not dup:
                    print(f"[brain] gelernt ({node['cat']}): {node['text']}")
    except Exception as e:
        print(f"[brain] Auto-Lernen uebersprungen: {e}")


def _brain_maybe_autolearn(provider, keys_and_clients, user_text, reply, tools_used, context=None, answering=False):
    _brain_track(user_text, tools_used)
    # Lernen bei fast jeder Nachricht: bei persoenlichem Bezug, laengeren Saetzen
    # oder wenn der Nutzer gerade eine Rueckfrage von A.R.I beantwortet.
    if "remember" in (tools_used or []) or len(user_text.strip()) < 6:
        return
    if not (_BRAIN_CUES.search(user_text) or len(user_text) >= 25 or answering):
        return
    if provider == "groq" and groq_status_snapshot([k for k, _ in keys_and_clients])["rate_limited"]:
        return
    threading.Thread(target=_brain_autolearn, args=(provider, keys_and_clients, context or user_text), daemon=True).start()


BRAIN_TOOLS = [
    {
        "name": "remember",
        "description": "Speichert eine dauerhafte Erinnerung im Gehirn (wird in allen kuenftigen Gespraechen genutzt). Fuer Vorlieben, Personen, Projekte, Gewohnheiten, Setup, Ziele oder wenn der Nutzer 'merk dir' sagt. Als kurzer ganzer Satz.",
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Die Erinnerung, z.B. 'Moritz spielt am liebsten Star Citizen mit HOTAS.'"},
                "category": {"type": "string", "description": "Bereich - waehle die passendste der vorhandenen (Wissen, Vorlieben, Personen, Projekte, Spiele, Gewohnheiten, Aufgaben, Musik, Medien, Technik, Arbeit, Lernen, Ziele, Gesundheit, Finanzen, Familie, Freunde, Orte, Reisen, Termine, Essen, Hobbys) - oder ein NEUER kurzer Bereichsname (1-2 Woerter), wenn nichts davon passt (z.B. Gesundheit, Musik, Finanzen)."},
            },
            "required": ["text"],
        },
    },
    {
        "name": "forget",
        "description": "Loescht Erinnerungen aus dem Gehirn, deren Text den Suchbegriff enthaelt.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
]


TOOLS = [
    {
        "name": "control_volume",
        "description": "Windows-SYSTEMlautstaerke steuern (Gesamtlautstaerke aller Apps): lauter, leiser, stummschalten umschalten, oder direkt auf einen Prozentwert setzen. Fuer NUR Spotifys eigene Lautstaerke stattdessen set_spotify_volume nutzen (falls verbunden).",
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["up", "down", "mute", "set"]},
                "steps": {"type": "integer", "minimum": 1, "maximum": 10, "description": "Anzahl Lauter/Leiser-Schritte (nur bei up/down, je Schritt 2% - Standard 5, also 10%)."},
                "percent": {"type": "integer", "minimum": 0, "maximum": 100, "description": "Ziel-Lautstaerke in Prozent (nur bei action=set), z.B. 70."},
            },
            "required": ["action"],
        },
    },
    {
        "name": "set_spotify_volume",
        "description": "Setzt Spotifys EIGENE Lautstaerke ueber die Spotify-API (nicht die Windows-Systemlautstaerke) — braucht eine verbundene Spotify-Anbindung. Aktiviert Spotify bei Bedarf automatisch (startet es notfalls sogar selbst), kein manuelles Play noetig.",
        "input_schema": {
            "type": "object",
            "properties": {"percent": {"type": "integer", "minimum": 0, "maximum": 100}},
            "required": ["percent"],
        },
    },
    {
        "name": "get_current_spotify_track",
        "description": "Fragt ab, welcher Titel gerade auf Spotify laeuft (Name + Interpret*in) — nutzen bei Fragen wie 'was laeuft gerade', 'welches Lied kommt/ist das' oder 'wer singt das'. Erfindet nie einen Songnamen, wenn gerade nichts laeuft.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "play_spotify",
        "description": "Startet die Wiedergabe von etwas auf Spotify per Freitextsuche — Playlist, Song, Album oder Kuenstler. Aktiviert Spotify bei Bedarf automatisch (startet es notfalls sogar selbst), kein manuelles Play noetig.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Suchbegriff, z.B. 'Deep House Mix' oder 'Bohemian Rhapsody' oder 'Queen'."},
                "item_type": {"type": "string", "enum": ["track", "playlist", "album", "artist"], "description": "Was gesucht werden soll, Standard 'track' (einzelner Song). 'playlist' wenn der Nutzer von einer Playlist spricht — dazu zaehlen auch Spotifys eigene automatisch generierte Mixe wie 'Daylist', 'Discover Weekly' oder 'Release Radar' (IMMER item_type='playlist' bei diesen Namen, nie 'track', auch wenn der Name selbst nicht wie eine klassische Playlist klingt). 'artist' fuer 'spiel Musik von X', 'album' fuer ein bestimmtes Album."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "play_for_me",
        "description": "Spielt Musik, die zum Nutzer passt, wenn er KEINEN konkreten Titel/Kuenstler nennt, sondern nur eine Stimmung oder ein Genre: 'spiel mir Musik', 'spiel irgendwas', 'mach Musik an', 'spiel was Passendes', 'spiel was Ruhiges/zum Zocken', 'spiel Pop/Rock/epische Musik'. Bei einem genannten Genre wird gezielt danach gesucht (auch wenn der Nutzer das Genre noch nie gehoert hat), sonst waehlt A.R.I anhand der gelernten Gewohnheiten (oft gehoerte Interpreten, Tageszeit) selbst etwas aus. Nur wenn der Nutzer einen konkreten Titel/Kuenstler/Playlist-Namen nennt, stattdessen play_spotify nutzen.",
        "input_schema": {"type": "object", "properties": {"genre": {"type": "string", "description": "Genre-/Stimmungswunsch, z.B. 'pop', 'rock', 'epic', 'dance', 'electro', 'rap' - immer setzen, wenn der Nutzer eine Richtung/ein Genre nennt."}}},
    },
    {
        "name": "transfer_spotify_playback",
        "description": "Wechselt die laufende Spotify-Wiedergabe auf ein anderes Geraet (z.B. Handy auf PC, oder auf einen Alexa-/Lautsprecher), ohne die Musik zu unterbrechen — braucht eine verbundene Spotify-Anbindung. Nutzen, wenn der Nutzer sagt 'spiel das auf X weiter/ab' oder 'wechsle auf X'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "device": {"type": "string", "description": "Zielgeraet per Freitext — entweder der genaue Spotify-Geraetename (z.B. 'Wohnzimmer', 'Jans iPhone') oder eine allgemeine Art wie 'Handy', 'PC', 'Alexa', 'Lautsprecher'."},
            },
            "required": ["device"],
        },
    },
    {
        "name": "control_media",
        "description": "Medienwiedergabe der aktuell aktiven Medien-App steuern (Play/Pause, naechster/vorheriger Titel) — z.B. Spotify, wenn es gerade laeuft. Nutzt die normalen Windows-Medientasten, wirkt also auf die gerade aktive Medien-App, nicht speziell auf eine bestimmte.",
        "input_schema": {
            "type": "object",
            "properties": {"action": {"type": "string", "enum": ["play_pause", "next", "previous"]}},
            "required": ["action"],
        },
    },
    {
        "name": "open_app",
        "description": "Eine beliebige installierte Windows-Anwendung/Spiel STARTEN (neu oeffnen) — sucht per Name unter den echten Desktop- und Startmenue-Verknuepfungen des Nutzers (z.B. 'World of Warships', 'Steam', 'Blender', 'Discord'), nicht nur eine feste Liste. NICHT nutzen, wenn ein Spiel schon laeuft und der Nutzer eine Aktion/einen Tastendruck DARIN meint (z.B. 'aktiviere X', 'schalte X um' waehrend eines konfigurierten Spiels) — das ist game_action, nicht open_app. Ein unbekannt klingendes Wort nach 'aktiviere'/'schalte' ist oft eine falsch verstandene Spracherkennung eines Spielbefehls, keine echte App — im Zweifel zuerst game_action probieren.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string", "description": "Name der Anwendung, so wie sie auf dem Desktop/Startmenue heisst (muss nicht exakt sein, Teiltreffer reicht)."}},
            "required": ["app"],
        },
    },
    {
        "name": "close_app",
        "description": "Eine laufende Anwendung erzwungen beenden — sucht per Name unter den aktuell laufenden Prozessen (Teiltreffer reicht), nicht nur eine feste Liste.",
        "input_schema": {
            "type": "object",
            "properties": {"app": {"type": "string"}},
            "required": ["app"],
        },
    },
    {
        "name": "take_screenshot",
        "description": "Screenshot des gesamten Bildschirms aufnehmen und lokal speichern.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "manage_window",
        "description": "Das aktuell aktive Fenster minimieren oder den Desktop anzeigen (alle Fenster minimieren).",
        "input_schema": {
            "type": "object",
            "properties": {"action": {"type": "string", "enum": ["minimize_active", "show_desktop"]}},
            "required": ["action"],
        },
    },
    {
        "name": "window_action",
        "description": "Mit einem bestimmten offenen Fenster interagieren (per Fenstertitel gesucht, Teiltreffer reicht) — fokussieren/in den Vordergrund holen, minimieren, maximieren, schliessen, oder auf einen anderen Bildschirm verschieben (move_screen, braucht zusaetzlich 'screen'). Anders als close_app schliesst das nur EIN Fenster normal, statt den ganzen Prozess zu beenden.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Teil des Fenstertitels, z.B. 'Notepad' oder 'Discord'."},
                "action": {"type": "string", "enum": ["focus", "minimize", "maximize", "close", "move_screen"]},
                "screen": {"type": "integer", "description": "Nur fuer action='move_screen': Bildschirmnummer, 1 = ganz links, 2 = naechster usw."},
            },
            "required": ["title", "action"],
        },
    },
    {
        "name": "play_youtube",
        "description": "Ein beliebiges Video oder einen Song per Suchbegriff auf YouTube (oder YouTube Music) im Standardbrowser suchen und direkt abspielen, z.B. 'Queen Bohemian Rhapsody'. music=true fuer YouTube Music. Pause/Weiter/Naechster Titel danach ueber control_media.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Was gesucht/abgespielt werden soll."},
                "music": {"type": "boolean", "description": "true = auf YouTube Music abspielen (Standard: normales YouTube)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "play_youtube_latest",
        "description": "Das neueste (zuletzt hochgeladene) YouTube-Video eines bestimmten Kanals im Standardbrowser oeffnen und abspielen.",
        "input_schema": {
            "type": "object",
            "properties": {"channel": {"type": "string", "description": "Name/Suchbegriff des YouTube-Kanals, z.B. 'Knebel'."}},
            "required": ["channel"],
        },
    },
    {
        "name": "maps_route",
        "description": "Plant eine echte Route (Auto/zu Fuss/Fahrrad/OePNV) nach einem Ziel und oeffnet sie in Google Maps (auf dem Handy direkt in der Maps-App). NICHT fuer Routen in Spielen (dafuer plan_route).",
        "input_schema": {
            "type": "object",
            "properties": {
                "destination": {"type": "string", "description": "Ziel, z.B. 'Hamburger Hauptbahnhof' oder eine Adresse."},
                "origin": {"type": "string", "description": "Optionaler Start; weglassen = aktueller Standort."},
                "mode": {"type": "string", "enum": ["driving", "walking", "bicycling", "transit"]},
            },
            "required": ["destination"],
        },
    },
    {
        "name": "find_restaurant",
        "description": "Sucht ein Restaurant und bereitet die Tischreservierung vor (Karte + Reservierungsseite mit Personenzahl und Uhrzeit vorausgefuellt). Bucht NICHT selbst verbindlich - der Nutzer bestaetigt auf der Seite.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Restaurantname und/oder Ort/Kueche, z.B. 'Italiener Hamburg Altona'."},
                "people": {"type": "integer", "description": "Anzahl Personen."},
                "when": {"type": "string", "description": "Datum und Uhrzeit als 'YYYY-MM-DD HH:MM' (24 h), falls genannt."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "play_streaming_title",
        "description": "Oeffnet einen Film oder eine Serie beim passenden Streaming-Anbieter (z.B. 'spiel Stranger Things ab'). Recherchiert selbst bei JustWatch, wo der Titel tatsaechlich laeuft (kein Raten) - A.R.I merkt sich das Ergebnis danach und fragt beim naechsten Mal nicht erneut.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Titel des Films/der Serie."},
                "provider": {"type": "string", "description": "Nur als Notloesung: falls die Recherche nichts findet, wird dieser Rateversuch aus eigenem Wissen verwendet. Sonst wird er ignoriert."},
            },
            "required": ["title"],
        },
    },
    {
        "name": "server_status",
        "description": "Prueft den aktuellen Server-/Dienststatus von BELIEBIGEN Spielen und Online-Diensten (Star Citizen, Valorant, WoW, Fortnite, Minecraft, Apex, GTA Online, Steam, Discord, GitHub ...): offizielle Status-Seiten, wenn es sie gibt, sonst Statusportale; die Quelle steht im Ergebnis - gib sie ehrlich weiter, auch wenn sie nur Nutzermeldungen sind. Liefert den Gesamtstatus, laufende Stoerungen und - wenn vorhanden - die einzelnen Teilsysteme (z.B. Star Citizen: Platform/Shop, Persistent Universe, Arena Commander). Mit 'component' laesst sich ein einzelnes Teilsystem abfragen (z.B. 'Shop').",
        "input_schema": {
            "type": "object",
            "properties": {
                "service": {"type": "string", "description": "Spiel oder Dienst, z.B. 'Star Citizen', 'Discord', 'GitHub'."},
                "component": {"type": "string", "description": "Optional: nur dieses Teilsystem pruefen (Teil des Namens, z.B. 'Shop', 'Login', 'Persistent Universe')."},
            },
            "required": ["service"],
        },
    },
    {
        "name": "dismiss_notification",
        "description": "Entfernt eine Benachrichtigung im PC-HUD - eine vom Handy weitergeleitete (WhatsApp, Discord, Instagram usw.) ODER eine ungelesene E-Mail -, oder markiert den Absender als Spam (dann kommt kuenftig nichts mehr davon). Sucht automatisch in beidem, je nachdem wo etwas passt.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Stichwort zur Benachrichtigung: App-Name (z.B. 'WhatsApp'), Absender oder Teil des Textes."},
                "spam": {"type": "boolean", "description": "true = die App kuenftig blockieren (Spam). Weglassen oder false = nur diese eine Benachrichtigung entfernen."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "create_plugin",
        "description": "Baut ein neues PLUGIN (Erweiterung) fuer A.R.I, wenn der Nutzer sagt, du sollst dir eine neue Faehigkeit/Funktion/Erweiterung bauen (z.B. 'bau dir ein Plugin, das ...'). "
                       "BEVORZUGE ein deklaratives Plugin (Parameter `tools`): das laeuft am PC UND in der Handy-App (auch ohne PC) und braucht keinen Code. Jedes Werkzeug hat name, description, input_schema und eine \"action\": "
                       "{\"type\":\"http\",\"url\":\"https://api.../{param}\",\"template\":\"Text mit {param} und {$.feld.0.wert} aus der JSON-Antwort\"} (optional method GET/POST, headers, body) | "
                       "{\"type\":\"open_url\",\"url\":\"https://.../{param}\"} | {\"type\":\"text\",\"template\":\"...\"} | {\"type\":\"random\",\"min\":1,\"max\":\"{seiten}\",\"count\":\"{anzahl}\",\"template\":\"{values} Summe {sum}\"}. "
                       "Nur oeffentliche Adressen (kein Heimnetz). Nur wenn das nicht reicht (z.B. Dateien, Programme, eigene Logik), nimm stattdessen Python: Parameter `code` = kompletter Inhalt von main.py mit "
                       "`TOOLS = [{\"name\": ..., \"description\": ..., \"input_schema\": {...}}]` und `def run(tool_name, tool_input): return \"Text\"` - das laeuft nur am PC. Halte alles klein, einfach und sicher: nichts loeschen, keine Systemeinstellungen aendern. "
                       "WICHTIG: Das Plugin ist nach dem Anlegen AUS - der Nutzer prueft es und schaltet es selbst ein (A.R.I zeigt ihm dafuer ein Fenster). Sag ihm das kurz. Ist der Wunsch unklar, frag vorher kurz nach.",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Kurzer Ordnername, nur Kleinbuchstaben/Ziffern/Bindestrich, z.B. 'wetter-hamburg'."},
                "title": {"type": "string", "description": "Anzeigename des Plugins, z.B. 'Wetter Hamburg'."},
                "description": {"type": "string", "description": "Ein Satz, was das Plugin kann."},
                "keywords": {"type": "array", "items": {"type": "string"}, "description": "Stichwoerter (klein), bei denen A.R.I dieses Plugin anbietet, z.B. ['wetter', 'regen']. Leer = immer."},
                "tools": {"type": "array", "items": {"type": "object"}, "description": "Deklarative Werkzeuge (siehe oben) - bevorzugt."},
                "code": {"type": "string", "description": "Nur fuer Python-Plugins: kompletter Inhalt von main.py (TOOLS + run)."},
                "overwrite": {"type": "boolean", "description": "true = ein schon vorhandenes Plugin mit diesem Namen ersetzen (der Nutzer muss es dann erneut bestaetigen)."},
            },
            "required": ["name", "title", "description"],
        },
    },
    {
        "name": "read_notifications",
        "description": "Liest die aktuellen Handy-Benachrichtigungen (WhatsApp, Discord, Anrufe usw.), die im HUD stehen, mit vollem Text vor - neueste zuerst. Nutzen bei 'lies mir meine Nachrichten vor', 'was habe ich fuer Nachrichten', 'was hat Max geschrieben'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Optional: nur Nachrichten dieser App oder dieses Absenders (z.B. 'WhatsApp', 'Max')."},
            },
        },
    },
    {
        "name": "reply_notification",
        "description": "Antwortet auf eine Handy-Nachricht (WhatsApp, Discord, ...), die im HUD unter Benachrichtigungen steht. WICHTIG: Erst mit confirmed=false aufrufen - das sendet NICHTS, sondern gibt einen Entwurf zurueck. Lies dem Nutzer den Text vor, frage 'Soll ich das so senden?' und rufe erst nach seinem eindeutigen Ja nochmal mit confirmed=true und demselben Text auf. Nie ohne Bestaetigung senden.",
        "input_schema": {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "Absender oder App, z.B. 'Max' oder 'WhatsApp'. Weglassen = die neueste beantwortbare Nachricht."},
                "text": {"type": "string", "description": "Der Antworttext, so wie er gesendet werden soll."},
                "confirmed": {"type": "boolean", "description": "true NUR nachdem der Nutzer den vorgelesenen Text ausdruecklich bestaetigt hat."},
            },
            "required": ["text"],
        },
    },
    {
        "name": "set_timer",
        "description": "Stellt einen Timer oder eine Erinnerung in X Sekunden/Minuten/Stunden. 'Mach einen Timer auf 10 Minuten' oder 'erinnere mich in 2 Stunden an die Waesche'. Rechne die Dauer selbst in Sekunden um. Das HUD zeigt einen Countdown und meldet sich (Ton + Ansage), wenn die Zeit um ist. Kein Kalendertermin - nur fuer relative Zeitangaben.",
        "input_schema": {
            "type": "object",
            "properties": {
                "seconds": {"type": "integer", "description": "Dauer in Sekunden (2 Minuten = 120, 1 Stunde = 3600)."},
                "label": {"type": "string", "description": "Wofuer der Timer ist, z.B. 'Nudeln' oder 'Waesche aufhaengen'. Leer bei einem einfachen Timer."},
                "kind": {"type": "string", "enum": ["timer", "reminder"], "description": "'reminder' wenn der Nutzer erinnert werden will (an etwas), sonst 'timer'."},
            },
            "required": ["seconds"],
        },
    },
    {
        "name": "cancel_timer",
        "description": "Bricht einen laufenden Timer/eine Erinnerung ab. Ohne label werden alle abgebrochen.",
        "input_schema": {"type": "object", "properties": {"label": {"type": "string", "description": "Teil des Namens des Timers."}}},
    },
    {
        "name": "list_timers",
        "description": "Zeigt alle laufenden Timer und Erinnerungen mit Restzeit.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "open_url",
        "description": "Eine Webseite im Standardbrowser oeffnen (nur http/https).",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "search_web",
        "description": "Suchergebnisse fuer einen beliebigen Suchbegriff im Standardbrowser oeffnen (wenn der Nutzer die Ergebnisse selbst ansehen will, statt eine direkte Antwort zu bekommen).",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "list_calendar_events",
        "description": "Bevorstehende Termine aus dem Google-Kalender des Nutzers abrufen (Titel, Start, Ort, id). Die id wird gebraucht, um einen Termin mit delete_calendar_event zu loeschen.",
        "input_schema": {
            "type": "object",
            "properties": {
                "days": {"type": "integer", "minimum": 1, "maximum": 60, "description": "Zeitraum ab jetzt in Tagen, Standard 14."},
            },
        },
    },
    {
        "name": "create_calendar_event",
        "description": "Einen neuen Termin im Google-Kalender des Nutzers anlegen.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Titel des Termins."},
                "start": {"type": "string", "description": "Start als ISO-Datum/-Zeit, z.B. '2026-09-10T18:00:00'."},
                "end": {"type": "string", "description": "Ende als ISO-Datum/-Zeit, optional — Standard: 1 Stunde nach Start."},
                "location": {"type": "string", "description": "Ort, optional."},
            },
            "required": ["title", "start"],
        },
    },
    {
        "name": "update_calendar_event",
        "description": "Einen bestehenden Termin bearbeiten (Titel/Zeit/Ort aendern). Vorher mit list_calendar_events die passende id ermitteln. Nur die angegebenen Felder werden geaendert.",
        "input_schema": {
            "type": "object",
            "properties": {
                "event_id": {"type": "string", "description": "Die id des Termins, aus list_calendar_events."},
                "title": {"type": "string", "description": "Neuer Titel, optional."},
                "start": {"type": "string", "description": "Neuer Start als ISO-Datum/-Zeit, optional."},
                "end": {"type": "string", "description": "Neues Ende als ISO-Datum/-Zeit, optional."},
                "location": {"type": "string", "description": "Neuer Ort, optional."},
            },
            "required": ["event_id"],
        },
    },
    {
        "name": "delete_calendar_event",
        "description": "Einen Termin im Google-Kalender des Nutzers loeschen. Vorher mit list_calendar_events die passende id ermitteln.",
        "input_schema": {
            "type": "object",
            "properties": {
                "event_id": {"type": "string", "description": "Die id des Termins, aus list_calendar_events."},
            },
            "required": ["event_id"],
        },
    },
    {
        "name": "read_emails",
        "description": "Ungelesene E-Mails im Posteingang abrufen (Gmail und/oder Yahoo Mail, je nachdem was verbunden ist) — Absender, Betreff, kurze Vorschau, id. Filtert standardmaessig Newsletter/Werbung/automatische Mails raus.",
        "input_schema": {
            "type": "object",
            "properties": {
                "unread_only": {"type": "boolean", "description": "Nur ungelesene E-Mails, Standard true."},
                "max_results": {"type": "integer", "minimum": 1, "maximum": 25},
                "important_only": {"type": "boolean", "description": "Standard false: ALLE ungelesenen E-Mails zeigen, ungefiltert - der Nutzer entscheidet selbst, was wichtig ist. Nur auf true setzen, wenn der Nutzer ausdruecklich nur die wichtigen will (Newsletter/Werbung werden dann rausgefiltert)."},
            },
        },
    },
    {
        "name": "send_email",
        "description": "Eine neue E-Mail verschicken (ueber Gmail oder Yahoo Mail, je nachdem was verbunden ist).",
        "input_schema": {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "subject": {"type": "string"},
                "body": {"type": "string"},
                "provider": {"type": "string", "enum": ["gmail", "yahoo"], "description": "Optional, nur wenn beide Konten verbunden sind und der Nutzer einen bestimmten Anbieter verlangt. Sonst weglassen."},
            },
            "required": ["to", "subject", "body"],
        },
    },
    {
        "name": "reply_email",
        "description": "Auf eine bestehende E-Mail antworten (email_id aus read_emails).",
        "input_schema": {
            "type": "object",
            "properties": {
                "email_id": {"type": "string"},
                "body": {"type": "string"},
            },
            "required": ["email_id", "body"],
        },
    },
]
TOOLS += BRAIN_TOOLS

# Anthropic-eigenes Server-Tool: laeuft komplett auf Anthropics Infrastruktur
# (nicht wie die obigen Tools lokal in run_tool()) — Claude sucht selbststaendig
# und kann Fragen direkt mit echten Suchergebnissen beantworten, statt nur
# einen Browser-Tab zu oeffnen. Nur fuer den Anthropic-Pfad, da OpenAI/Groq
# dieses Tool-Format nicht unterstuetzen.
ANTHROPIC_SERVER_TOOLS = [{"type": "web_search_20260209", "name": "web_search", "max_uses": 3}]

# OpenAI/Groq-Pendant zu ANTHROPIC_SERVER_TOOLS: kein eingebautes Server-Tool
# verfuegbar, daher ein eigenes Client-Tool (_tool_web_search_answer, siehe
# oben), das echte Ergebnis-Schnipsel liefert, damit auch ChatGPT/Groq direkt
# antworten koennen statt nur einen Tab zu oeffnen. Nicht in TOOLS, weil
# Anthropic das bessere native web_search bekommt und nicht zusaetzlich
# zwischen zwei aehnlichen Such-Tools waehlen soll.
WEB_SEARCH_ANSWER_TOOL = {
    "name": "web_search_answer",
    "description": "Im Web suchen und Ergebnis-Schnipsel (Titel, Kurzbeschreibung, Link) zurueckbekommen, um eine Frage direkt zu beantworten — bevorzugt gegenueber search_web, wenn der Nutzer eine inhaltliche Antwort erwartet statt nur einen geoeffneten Tab.",
    "input_schema": {
        "type": "object",
        "properties": {"query": {"type": "string"}},
        "required": ["query"],
    },
}


# --- Timer / Erinnerungen (relative Zeit) ----------------------------------------------------------------
# Gespeichert in data/timers.json; das HUD holt sie per /timers, zeigt den Countdown und meldet sich beim Ablauf.
TIMERS_FILE = os.path.join(DATA_DIR, "timers.json")
_timers_lock = threading.Lock()


def _timers_load():
    try:
        with open(TIMERS_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def _timers_save(lst):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(TIMERS_FILE, "w", encoding="utf-8") as f:
        json.dump(lst, f, ensure_ascii=False)


def _fmt_duration(sec):
    sec = int(round(sec))
    h, rest = divmod(sec, 3600)
    m, s = divmod(rest, 60)
    parts = []
    if h:
        parts.append(f"{h} Stunde" + ("n" if h != 1 else ""))
    if m:
        parts.append(f"{m} Minute" + ("n" if m != 1 else ""))
    if s and not h:
        parts.append(f"{s} Sekunde" + ("n" if s != 1 else ""))
    return " ".join(parts) or "0 Sekunden"


def _tool_set_timer(seconds, label="", kind="timer"):
    try:
        seconds = int(round(float(seconds)))
    except (TypeError, ValueError):
        return "Timer nicht gestellt: Dauer unklar."
    if seconds < 1 or seconds > 30 * 86400:
        return "Timer nicht gestellt: Die Dauer muss zwischen 1 Sekunde und 30 Tagen liegen."
    label = (label or "").strip()[:80]
    kind = "reminder" if kind == "reminder" else "timer"
    now = time.time()
    with _timers_lock:
        lst = [t for t in _timers_load() if t.get("due", 0) > now - 3600]
        lst.append({"id": uuid.uuid4().hex[:10], "due": now + seconds, "label": label, "kind": kind, "created": now})
        _timers_save(lst)
    what = "Erinnerung" if kind == "reminder" else "Timer"
    return f"{what} gestellt: {_fmt_duration(seconds)}" + (f" ({label})" if label else "") + "."


def _tool_cancel_timer(label=""):
    label = (label or "").strip().lower()
    with _timers_lock:
        lst = _timers_load()
        keep = [t for t in lst if label and label not in (t.get("label", "") or "").lower()]
        gone = len(lst) - len(keep)
        _timers_save(keep)
    return f"{gone} Timer abgebrochen." if gone else "Keinen passenden Timer gefunden."


def _tool_list_timers():
    now = time.time()
    lst = [t for t in _timers_load() if t.get("due", 0) > now]
    if not lst:
        return "Es laeuft gerade kein Timer."
    lst.sort(key=lambda t: t["due"])
    return "; ".join(f"{t.get('label') or 'Timer'}: noch {_fmt_duration(t['due'] - now)}" for t in lst)


@app.route("/timers")
def timers_list():
    with _timers_lock:
        lst = _timers_load()
    return jsonify({"now": int(time.time() * 1000), "timers": lst})


@app.route("/timers/add", methods=["POST"])
def timers_add():
    d = request.get_json(silent=True) or {}
    return jsonify({"message": _tool_set_timer(d.get("seconds"), d.get("label", ""), d.get("kind", "timer"))})


@app.route("/timers/done", methods=["POST"])
def timers_done():
    tid = str((request.get_json(silent=True) or {}).get("id", ""))
    with _timers_lock:
        _timers_save([t for t in _timers_load() if t.get("id") != tid])
    return jsonify({"ok": True})


# --- Plugins ------------------------------------------------------------------------------------------
# A.R.I laesst sich mit eigenen Plugins erweitern: je ein Ordner in data/plugins/<id>/ mit
#   plugin.json  {"name": "...", "description": "...", "version": "1.0", "author": "...", "keywords": ["wuerfel", ...]}   (keywords optional)
#   main.py      TOOLS = [{"name": "...", "description": "...", "input_schema": {...}}]   und   def run(tool_name, tool_input): return "Text"
# Die Werkzeuge stehen der KI dann wie die eingebauten zur Verfuegung. Ein Plugin ist Python-Code, der mit den Rechten von A.R.I laeuft -
# deshalb ist jedes neue Plugin AUS, bis der Nutzer es ausdruecklich einschaltet; aendert sich sein Code, muss er es erneut bestaetigen.
PLUGINS_DIR = os.path.join(DATA_DIR, "plugins")
_PLUGIN_STATE_FILE = os.path.join(PLUGINS_DIR, "_state.json")
_PLUGIN_HANDLERS = {}    # Werkzeugname -> (Plugin-ID, Modul, Originalname)
_PLUGIN_TOOL_DEFS = []   # die in TOOLS eingehaengten Definitionen (zum sauberen Entfernen beim Neuladen)
_PLUGIN_KEYWORDS = {}    # Werkzeugname -> Regex (nur senden, wenn die Anfrage passt) - leer = immer senden
_PLUGIN_INFO = {}        # Plugin-ID -> Info fuer die Einstellungen
_PLUGIN_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,40}$")


def _plugin_state():
    try:
        with open(_PLUGIN_STATE_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _plugin_state_save(d):
    os.makedirs(PLUGINS_DIR, exist_ok=True)
    with open(_PLUGIN_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)


def _plugin_hash(folder):
    import hashlib
    h = hashlib.sha256()
    for root, _dirs, files in sorted(os.walk(folder)):
        for fn in sorted(files):
            if fn.endswith((".py", ".json")):
                fp = os.path.join(root, fn)
                h.update(os.path.relpath(fp, folder).encode("utf-8"))
                try:
                    with open(fp, "rb") as f:
                        h.update(f.read())
                except OSError:
                    pass
    return h.hexdigest()


def _plugins_unload():
    for t in _PLUGIN_TOOL_DEFS:
        try:
            TOOLS.remove(t)
        except ValueError:
            pass
    _PLUGIN_TOOL_DEFS.clear()
    _PLUGIN_DECL.clear()
    _PLUGIN_HANDLERS.clear()
    _PLUGIN_KEYWORDS.clear()
    _PLUGIN_INFO.clear()


def _plugins_load():
    """Liest alle Plugin-Ordner; nur eingeschaltete (und unveraenderte) werden geladen und ihre Werkzeuge bei der KI angemeldet."""
    import importlib.util
    _plugins_unload()
    os.makedirs(PLUGINS_DIR, exist_ok=True)
    state = _plugin_state()
    for pid in sorted(os.listdir(PLUGINS_DIR)):
        folder = os.path.join(PLUGINS_DIR, pid)
        if not os.path.isdir(folder) or not _PLUGIN_ID_RE.match(pid):
            continue
        info = {"id": pid, "name": pid, "description": "", "version": "", "author": "", "enabled": False, "changed": False, "tools": [], "error": ""}
        _PLUGIN_INFO[pid] = info
        try:
            with open(os.path.join(folder, "plugin.json"), "r", encoding="utf-8") as f:
                man = json.load(f)
            info.update(name=str(man.get("name") or pid)[:60], description=str(man.get("description") or "")[:300],
                        version=str(man.get("version") or "")[:20], author=str(man.get("author") or "")[:60])
        except (OSError, ValueError) as e:
            info["error"] = f"plugin.json fehlt oder ist kaputt ({type(e).__name__})"
            continue
        st = state.get(pid) or {}
        cur = _plugin_hash(folder)
        if st.get("enabled") and st.get("approved_hash") != cur:
            info["changed"] = True   # Code wurde nach der Freigabe geaendert: nicht laden, bis der Nutzer erneut bestaetigt
            continue
        if not st.get("enabled"):
            continue
        info["enabled"] = True
        try:
            decl = [t for t in (man.get("tools") or []) if isinstance(t, dict) and isinstance(t.get("action"), dict)]
            info["kind"] = "deklarativ" if decl else "python"
            if decl:
                mod, defs = None, decl   # deklaratives Plugin: nur plugin.json, laeuft am PC und in der Handy-App gleich
                for t in decl:
                    if (t["action"].get("type") not in _DECL_ACTIONS):
                        raise RuntimeError(f"Unbekannte Aktion '{t['action'].get('type')}' (erlaubt: {', '.join(_DECL_ACTIONS)})")
            else:
                spec = importlib.util.spec_from_file_location("ari_plugin_" + pid.replace("-", "_"), os.path.join(folder, "main.py"))
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                defs = list(getattr(mod, "TOOLS", []) or [])
                if not callable(getattr(mod, "run", None)):
                    raise RuntimeError("main.py braucht eine Funktion run(tool_name, tool_input)")
            kw = [str(k).lower() for k in (man.get("keywords") or []) if str(k).strip()]
            info["keywords"] = list(kw)
            for d in defs:
                orig = str(d.get("name") or "")
                if not re.match(r"^[A-Za-z0-9_]{1,40}$", orig):
                    raise RuntimeError(f"Ungueltiger Werkzeugname '{orig}' (nur Buchstaben, Ziffern, _)")
                full = re.sub(r"[^A-Za-z0-9_]", "_", pid) + "_" + orig
                tool = {"name": full[:60], "description": "[Plugin " + info["name"] + "] " + str(d.get("description") or "")[:600],
                        "input_schema": d.get("input_schema") or {"type": "object", "properties": {}}}
                TOOLS.append(tool)
                _PLUGIN_TOOL_DEFS.append(tool)
                _PLUGIN_HANDLERS[tool["name"]] = (pid, mod, orig)
                if mod is None:
                    _PLUGIN_DECL[tool["name"]] = d
                if kw:
                    _PLUGIN_KEYWORDS[tool["name"]] = re.compile("|".join(re.escape(k) for k in kw), re.IGNORECASE)
                info["tools"].append({"name": tool["name"], "description": str(d.get("description") or "")[:200]})
            if not info["keywords"]:   # keine Stichwoerter angegeben: fuer die Handy-App aus Name und Werkzeugnamen ableiten (damit sie Plugin-Wuensche zum PC schickt)
                words = re.split(r"[^a-z0-9äöüß]+", (info["name"] + " " + " ".join(t["name"] for t in info["tools"])).lower())
                info["keywords"] = sorted({w for w in words if len(w) >= 4})[:12]
            print(f"[plugin] '{info['name']}' geladen ({len(defs)} Werkzeug(e))")
        except Exception as e:
            info["enabled"], info["error"] = False, f"{type(e).__name__}: {e}"[:200]
            print(f"[plugin] '{pid}' konnte nicht geladen werden: {e}")


_PLUGIN_DECL = {}   # Werkzeugname -> Werkzeug-Definition eines deklarativen Plugins (mit "action")
_DECL_ACTIONS = ("http", "open_url", "text", "random")


def _decl_subst(text, args, quote=False):
    """{name} im Text durch den Parameter ersetzen (in Adressen URL-kodiert)."""
    import urllib.parse

    def rep(m):
        v = args.get(m.group(1), "")
        v = "" if v is None else str(v)
        return urllib.parse.quote(v, safe="") if quote else v
    return re.sub(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", rep, str(text))


def _decl_path(obj, path):
    for part in str(path).split("."):
        if part == "":
            continue
        try:
            if isinstance(obj, list):
                obj = obj[int(part)]
            elif isinstance(obj, dict):
                obj = obj[part]
            else:
                return None
        except (KeyError, IndexError, ValueError):
            return None
    return obj


def _decl_template(tpl, args, data=None, extra=None):
    """{param} aus den Werkzeug-Parametern, {$.pfad.0.feld} aus der JSON-Antwort, {name} aus extra (z.B. values, sum)."""
    extra = extra or {}

    def rep_json(m):
        v = _decl_path(data, m.group(1)) if data is not None else None
        return "?" if v is None else (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v))

    def rep_arg(m):
        k = m.group(1)
        if k in extra:
            return str(extra[k])
        v = args.get(k, "")
        return "" if v is None else str(v)
    out = re.sub(r"\{\$\.?([^{}]*)\}", rep_json, str(tpl))
    return re.sub(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", rep_arg, out)


def _decl_check_url(url):
    """Nur oeffentliche http(s)-Adressen: nie den Hub selbst (127.0.0.1) oder Geraete im Heimnetz ansprechen."""
    import urllib.parse
    import ipaddress
    import socket
    u = urllib.parse.urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname:
        raise ValueError("Nur http(s)-Adressen sind erlaubt.")
    for info in socket.getaddrinfo(u.hostname, None):
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise ValueError("Adressen im eigenen Netz sind fuer Plugins gesperrt.")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def _decl_run(tool, args):
    act = tool.get("action") or {}
    typ = act.get("type")
    if typ == "text":
        return _decl_template(act.get("template", ""), args)[:3000]
    if typ == "random":
        import random
        lo = int(float(_decl_subst(act.get("min", 1), args) or 1))
        hi = int(float(_decl_subst(act.get("max", 6), args) or 6))
        cnt = max(1, min(20, int(float(_decl_subst(act.get("count", 1), args) or 1))))
        if hi < lo:
            lo, hi = hi, lo
        vals = [random.randint(lo, hi) for _ in range(cnt)]
        return _decl_template(act.get("template", "{values}"), args, None, {"values": ", ".join(map(str, vals)), "sum": sum(vals), "value": vals[0]})[:3000]
    if typ == "open_url":
        url = _decl_subst(act.get("url", ""), args, quote=True)
        if not url.lower().startswith(("http://", "https://")):
            return "Ungueltige Adresse."
        _tool_open_url(url)
        return _decl_template(act.get("template", "Geoeffnet."), args)[:500]
    if typ == "http":
        import urllib.request as _ur
        url = _decl_subst(act.get("url", ""), args, quote=True)
        _decl_check_url(url)
        method = str(act.get("method") or "GET").upper()
        if method not in ("GET", "POST"):
            raise ValueError("Nur GET oder POST.")
        headers = {str(k): _decl_subst(v, args) for k, v in (act.get("headers") or {}).items()}
        headers.setdefault("User-Agent", "A.R.I-Plugin")
        body = None
        if method == "POST" and act.get("body") is not None:
            body = (act["body"] if isinstance(act["body"], str) else json.dumps(act["body"], ensure_ascii=False))
            body = _decl_subst(body, args).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
        req = _ur.Request(url, data=body, headers=headers, method=method)
        opener = _ur.build_opener(_NoRedirect())
        with opener.open(req, timeout=10) as resp:
            raw = resp.read(200_001)[:200_000]
        text = raw.decode("utf-8", errors="replace")
        data = None
        try:
            data = json.loads(text)
        except ValueError:
            pass
        if act.get("template"):
            return _decl_template(act["template"], args, data)[:3000]
        return (json.dumps(data, ensure_ascii=False) if data is not None else text)[:1500]
    raise ValueError("Unbekannte Aktion.")


def _plugin_run(name, tool_input):
    if name in _PLUGIN_DECL:
        try:
            return str(_decl_run(_PLUGIN_DECL[name], tool_input or {}))[:6000]
        except Exception as e:
            print(f"[plugin] Fehler in '{name}': {e}")
            return "Das Plugin hat einen Fehler gemeldet. Sag dem Nutzer kurz, dass das Plugin gerade nicht geklappt hat - ohne technische Details."
    pid, mod, orig = _PLUGIN_HANDLERS[name]
    out = {}

    def _go():
        try:
            out["v"] = mod.run(orig, tool_input or {})
        except Exception as e:
            out["e"] = e
    th = threading.Thread(target=_go, daemon=True)
    th.start()
    th.join(30)
    if th.is_alive():
        return "Das Plugin hat zu lange gebraucht (30 Sekunden) und wurde abgebrochen."
    if "e" in out:
        print(f"[plugin] Fehler in '{pid}': {out['e']}")
        return "Das Plugin hat einen Fehler gemeldet. Sag dem Nutzer kurz, dass das Plugin gerade nicht geklappt hat - ohne technische Details."
    return str(out.get("v", ""))[:6000]


def _plugin_example_files():
    manifest = {"name": "Beispiel: Wuerfeln", "description": "Wuerfelt Zufallszahlen (zum Ausprobieren und als Vorlage fuer eigene Plugins).",
                "version": "1.0", "author": "A.R.I", "keywords": ["wuerfel", "würfel", "zufall", "dice", "random"],
                "tools": [{"name": "wuerfeln", "description": "Wuerfelt Zufallszahlen. Nutzen bei 'wuerfel mal', 'Zufallszahl', 'wirf einen Wuerfel'.",
                           "input_schema": {"type": "object", "properties": {"seiten": {"type": "integer", "description": "Seiten des Wuerfels (Standard 6)"},
                                                                              "anzahl": {"type": "integer", "description": "Wie oft (Standard 1, maximal 20)"}}},
                           "action": {"type": "random", "min": 1, "max": "{seiten}", "count": "{anzahl}", "template": "Gewuerfelt: {values} (Summe {sum})"}}]}
    code = """# Beispiel-Plugin fuer A.R.I - Vorlage fuer eigene Erweiterungen.
#
# Jedes Plugin liegt in einem Ordner data/plugins/<name>/ mit zwei Dateien:
#   plugin.json   Name, Beschreibung, Version, Autor und optional "keywords" (nur dann bekommt die KI das Werkzeug, wenn die Anfrage eins davon enthaelt)
#   main.py       diese Datei: TOOLS (was die KI aufrufen darf) und run() (was dann passiert)
import random

TOOLS = [
    {
        "name": "wuerfeln",
        "description": "Wuerfelt eine Zufallszahl. Nutzen bei 'wuerfel mal', 'Zufallszahl', 'wirf einen Wuerfel'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "seiten": {"type": "integer", "description": "Anzahl der Seiten des Wuerfels (Standard 6)."},
                "anzahl": {"type": "integer", "description": "Wie oft gewuerfelt wird (Standard 1, maximal 10)."},
            },
        },
    },
]


def run(tool_name, tool_input):
    if tool_name == "wuerfeln":
        seiten = max(2, min(1000, int(tool_input.get("seiten") or 6)))
        anzahl = max(1, min(10, int(tool_input.get("anzahl") or 1)))
        wuerfe = [random.randint(1, seiten) for _ in range(anzahl)]
        return f"Gewuerfelt (W{seiten}): " + ", ".join(str(w) for w in wuerfe) + (f" - Summe {sum(wuerfe)}" if anzahl > 1 else "")
    return "Unbekanntes Werkzeug."
"""
    return json.dumps(manifest, indent=2, ensure_ascii=False), code


def _plugin_check_local():
    return None if _is_local_request() else (jsonify({"error": "verboten"}), 403)


@app.route("/plugins")
def plugins_list():
    bad = _plugin_check_local()
    if bad:
        return bad
    return jsonify({"plugins": list(_PLUGIN_INFO.values()), "folder": PLUGINS_DIR})


@app.route("/plugins/enable", methods=["POST"])
def plugins_enable():
    bad = _plugin_check_local()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    pid = str(d.get("id") or "")
    folder = os.path.join(PLUGINS_DIR, pid)
    if not _PLUGIN_ID_RE.match(pid) or not os.path.isdir(folder):
        return jsonify({"error": "Plugin nicht gefunden."}), 404
    state = _plugin_state()
    if d.get("enabled"):
        state[pid] = {"enabled": True, "approved_hash": _plugin_hash(folder)}   # der Nutzer hat im HUD ausdruecklich bestaetigt
    else:
        state[pid] = {"enabled": False}
    _plugin_state_save(state)
    _plugins_load()
    return jsonify({"error": _PLUGIN_INFO.get(pid, {}).get("error") or None, "plugins": list(_PLUGIN_INFO.values())})


@app.route("/phone/api/plugins")
def phone_api_plugins():
    """Fuer die Handy-App: welche Plugin-Stichwoerter gibt es? Trifft eine Anfrage eines davon, schickt die App sie an den PC (dort laufen die Plugins)."""
    kws = sorted({k for pl in _PLUGIN_INFO.values() if pl.get("enabled") and pl.get("kind") != "deklarativ" for k in (pl.get("keywords") or [])})
    decl = []
    for pid, pl in _PLUGIN_INFO.items():
        if pl.get("enabled") and pl.get("kind") == "deklarativ":
            try:
                with open(os.path.join(PLUGINS_DIR, pid, "plugin.json"), "r", encoding="utf-8") as f:
                    man = json.load(f)
                decl.append({"id": pid, "name": pl["name"], "description": pl["description"], "keywords": pl.get("keywords") or [], "tools": man.get("tools") or []})
            except (OSError, ValueError):
                pass
    pc_only = [{"id": pid, "name": pl["name"], "description": pl["description"], "keywords": pl.get("keywords") or []}
               for pid, pl in _PLUGIN_INFO.items() if pl.get("enabled") and pl.get("kind") != "deklarativ"]
    return jsonify({"keywords": kws, "count": sum(1 for pl in _PLUGIN_INFO.values() if pl.get("enabled")), "plugins": decl, "pc_only": pc_only})


@app.route("/plugins/reload", methods=["POST"])
def plugins_reload():
    bad = _plugin_check_local()
    if bad:
        return bad
    _plugins_load()
    return jsonify({"error": None, "plugins": list(_PLUGIN_INFO.values())})


@app.route("/plugins/remove", methods=["POST"])
def plugins_remove():
    bad = _plugin_check_local()
    if bad:
        return bad
    pid = str((request.get_json(silent=True) or {}).get("id") or "")
    folder = os.path.join(PLUGINS_DIR, pid)
    if not _PLUGIN_ID_RE.match(pid) or not os.path.isdir(folder):
        return jsonify({"error": "Plugin nicht gefunden."}), 404
    import shutil
    shutil.rmtree(folder, ignore_errors=True)
    state = _plugin_state()
    state.pop(pid, None)
    _plugin_state_save(state)
    _plugins_load()
    return jsonify({"error": None, "plugins": list(_PLUGIN_INFO.values())})


@app.route("/plugins/open-folder", methods=["POST"])
def plugins_open_folder():
    bad = _plugin_check_local()
    if bad:
        return bad
    os.makedirs(PLUGINS_DIR, exist_ok=True)
    try:
        if IS_WIN:
            subprocess.Popen(["explorer.exe", PLUGINS_DIR])
        else:
            subprocess.Popen(["xdg-open", PLUGINS_DIR])
    except Exception as e:
        return jsonify({"error": str(e)[:150]})
    return jsonify({"error": None})


@app.route("/plugins/example", methods=["POST"])
def plugins_example():
    """Legt das Beispiel-Plugin an (ausgeschaltet) - als Vorlage und fuer den DEV-Test."""
    bad = _plugin_check_local()
    if bad:
        return bad
    folder = os.path.join(PLUGINS_DIR, "beispiel-wuerfeln")
    os.makedirs(folder, exist_ok=True)
    man, code = _plugin_example_files()
    with open(os.path.join(folder, "plugin.json"), "w", encoding="utf-8") as f:
        f.write(man)
    _plugins_load()
    return jsonify({"error": None, "plugins": list(_PLUGIN_INFO.values())})


@app.route("/plugins/install", methods=["POST"])
def plugins_install():
    """Plugin aus einer .zip (Ordner mit plugin.json + main.py) oder einer einzelnen .py-Datei hinzufuegen. Kommt immer AUSGESCHALTET an."""
    bad = _plugin_check_local()
    if bad:
        return bad
    import zipfile
    import io
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "Keine Datei."}), 400
    raw = f.read(5_000_001)
    if len(raw) > 5_000_000:
        return jsonify({"error": "Datei zu gross (maximal 5 MB)."}), 400
    base = re.sub(r"[^a-z0-9_-]", "-", os.path.splitext(os.path.basename(f.filename))[0].lower()).strip("-")[:40] or "plugin"
    folder = os.path.join(PLUGINS_DIR, base)
    n = 2
    while os.path.exists(folder):
        folder = os.path.join(PLUGINS_DIR, f"{base}-{n}")
        n += 1
    try:
        if f.filename.lower().endswith(".zip"):
            z = zipfile.ZipFile(io.BytesIO(raw))
            names = [i for i in z.infolist() if not i.is_dir()]
            if not names or len(names) > 60:
                return jsonify({"error": "Die ZIP-Datei ist leer oder hat zu viele Dateien."}), 400
            # Ein einziger Oberordner in der ZIP wird abgeschnitten
            tops = {i.filename.replace("\\", "/").split("/")[0] for i in names}
            strip = (list(tops)[0] + "/") if len(tops) == 1 and all("/" in i.filename.replace("\\", "/") for i in names) else ""
            os.makedirs(folder)
            for i in names:
                rel = i.filename.replace("\\", "/")
                if strip and rel.startswith(strip):
                    rel = rel[len(strip):]
                if not rel or rel.startswith("/") or ".." in rel.split("/") or ":" in rel:
                    raise ValueError("Unsicherer Dateipfad in der ZIP.")
                dest = os.path.join(folder, *rel.split("/"))
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, "wb") as out:
                    out.write(z.read(i))
        elif f.filename.lower().endswith(".json"):
            man = json.loads(raw.decode("utf-8"))
            if not isinstance(man, dict) or not any(isinstance(t, dict) and isinstance(t.get("action"), dict) for t in (man.get("tools") or [])):
                return jsonify({"error": "Die .json braucht eine Liste 'tools' mit je einer 'action'."}), 400
            os.makedirs(folder)
            with open(os.path.join(folder, "plugin.json"), "wb") as out:
                out.write(raw)
        elif f.filename.lower().endswith(".py"):
            os.makedirs(folder)
            with open(os.path.join(folder, "main.py"), "wb") as out:
                out.write(raw)
            with open(os.path.join(folder, "plugin.json"), "w", encoding="utf-8") as out:
                json.dump({"name": base, "description": "(einzelne .py-Datei hinzugefuegt)", "version": "", "author": ""}, out)
        else:
            return jsonify({"error": "Nur .json, .zip oder .py."}), 400
        _has_decl = False
        try:
            with open(os.path.join(folder, "plugin.json"), "r", encoding="utf-8") as _pf:
                _has_decl = any(isinstance(t, dict) and isinstance(t.get("action"), dict) for t in (json.load(_pf).get("tools") or []))
        except (OSError, ValueError):
            pass
        if not os.path.exists(os.path.join(folder, "plugin.json")) or not (_has_decl or os.path.exists(os.path.join(folder, "main.py"))):
            import shutil
            shutil.rmtree(folder, ignore_errors=True)
            return jsonify({"error": "Das Plugin braucht plugin.json (mit tools) oder plugin.json + main.py."}), 400
    except Exception as e:
        import shutil
        shutil.rmtree(folder, ignore_errors=True)
        return jsonify({"error": str(e)[:150]}), 400
    _plugins_load()
    return jsonify({"error": None, "id": os.path.basename(folder), "plugins": list(_PLUGIN_INFO.values())})


@app.route("/plugins/install-folder", methods=["POST"])
def plugins_install_folder():
    """Ein per Drag & Drop abgelegter Plugin-ORDNER: die Dateien kommen einzeln mit ihrem relativen Pfad. Kommt immer AUSGESCHALTET an."""
    bad = _plugin_check_local()
    if bad:
        return bad
    files = request.files.getlist("files")
    if not files or len(files) > 60:
        return jsonify({"error": "Der Ordner ist leer oder hat zu viele Dateien."}), 400
    base = re.sub(r"[^a-z0-9_-]", "-", (request.form.get("name") or "plugin").lower()).strip("-")[:40] or "plugin"
    folder = os.path.join(PLUGINS_DIR, base)
    n = 2
    while os.path.exists(folder):
        folder = os.path.join(PLUGINS_DIR, f"{base}-{n}")
        n += 1
    rels = [(f.filename or "").replace("\\", "/") for f in files]
    tops = {x.split("/")[0] for x in rels}
    strip = (list(tops)[0] + "/") if len(tops) == 1 and all("/" in x for x in rels) else ""
    total = 0
    try:
        os.makedirs(folder)
        for f, rel in zip(files, rels):
            if strip and rel.startswith(strip):
                rel = rel[len(strip):]
            if not rel or rel.startswith("/") or ".." in rel.split("/") or ":" in rel:
                raise ValueError("Unsicherer Dateipfad.")
            data = f.read()
            total += len(data)
            if total > 5_000_000:
                raise ValueError("Der Ordner ist zu gross (maximal 5 MB).")
            dest = os.path.join(folder, *rel.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as out:
                out.write(data)
        _decl2 = False
        try:
            with open(os.path.join(folder, "plugin.json"), "r", encoding="utf-8") as _pf:
                _decl2 = any(isinstance(t, dict) and isinstance(t.get("action"), dict) for t in (json.load(_pf).get("tools") or []))
        except (OSError, ValueError):
            pass
        if not os.path.exists(os.path.join(folder, "plugin.json")) or not (_decl2 or os.path.exists(os.path.join(folder, "main.py"))):
            raise ValueError("Das Plugin braucht plugin.json (mit tools) oder plugin.json + main.py.")
    except Exception as e:
        import shutil
        shutil.rmtree(folder, ignore_errors=True)
        return jsonify({"error": str(e)[:150]}), 400
    _plugins_load()
    return jsonify({"error": None, "id": os.path.basename(folder), "plugins": list(_PLUGIN_INFO.values())})


_PLUGIN_LAST_CREATED = {"id": "", "name": "", "ts": 0}


def _tool_create_plugin(name, title, description, keywords, code, overwrite=False, tools=None):
    import ast
    pid = re.sub(r"[^a-z0-9_-]", "-", str(name or "").lower()).strip("-")[:40]
    if not _PLUGIN_ID_RE.match(pid):
        return "Ungueltiger Plugin-Name. Nimm einen kurzen Namen aus Kleinbuchstaben, Ziffern und Bindestrichen."
    if tools:   # deklaratives Plugin: nur plugin.json (laeuft am PC und in der Handy-App)
        if not isinstance(tools, list) or any(not isinstance(t, dict) or not re.match(r"^[A-Za-z0-9_]{1,40}$", str(t.get("name", ""))) or not isinstance(t.get("action"), dict)
                                              or t["action"].get("type") not in _DECL_ACTIONS for t in tools):
            return "Jedes Werkzeug braucht einen Namen (Buchstaben, Ziffern, _) und eine gueltige action (http, open_url, text oder random). Korrigiere das und rufe create_plugin nochmal auf."
        folder = os.path.join(PLUGINS_DIR, pid)
        if os.path.exists(folder) and not overwrite:
            return f"Es gibt schon ein Plugin '{pid}'. Nimm einen anderen Namen oder rufe es mit overwrite=true nochmal auf."
        os.makedirs(folder, exist_ok=True)
        kw = [str(k).strip().lower() for k in (keywords or []) if str(k).strip()][:20]
        with open(os.path.join(folder, "plugin.json"), "w", encoding="utf-8") as f:
            json.dump({"name": str(title or pid)[:60], "description": str(description or "")[:300], "version": "1.0", "author": "A.R.I (selbst gebaut)", "keywords": kw, "tools": tools},
                      f, indent=2, ensure_ascii=False)
        if os.path.exists(os.path.join(folder, "main.py")):
            os.remove(os.path.join(folder, "main.py"))
        state = _plugin_state()
        state[pid] = {"enabled": False}
        _plugin_state_save(state)
        _plugins_load()
        _PLUGIN_LAST_CREATED.update(id=pid, name=str(title or pid)[:60], ts=time.time())
        return (f"Plugin '{title or pid}' wurde angelegt, ist aber noch AUS. Dem Nutzer wird jetzt zur Pruefung gezeigt, was es tut - er schaltet es selbst ein. "
                f"Sag ihm kurz, was das Plugin tut und dass er es freigeben muss. Es laeuft danach auch in der Handy-App.")
    code = str(code or "")
    if not code.strip() or len(code) > 20000:
        return "Der Code ist leer oder zu lang (maximal 20000 Zeichen)."
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"Der Code hat einen Syntaxfehler (Zeile {e.lineno}): {e.msg}. Korrigiere ihn und rufe create_plugin nochmal auf."
    has_run = any(isinstance(n, ast.FunctionDef) and n.name == "run" for n in tree.body)
    tools_node = next((n for n in tree.body if isinstance(n, ast.Assign) and any(getattr(t, "id", "") == "TOOLS" for t in n.targets)), None)
    if not has_run or tools_node is None:
        return "Der Code braucht eine Liste TOOLS und eine Funktion run(tool_name, tool_input). Korrigiere ihn und rufe create_plugin nochmal auf."
    try:   # Werkzeugnamen pruefen, soweit TOOLS eine einfache Liste ist
        for d in ast.literal_eval(tools_node.value):
            if not re.match(r"^[A-Za-z0-9_]{1,40}$", str(d.get("name", ""))):
                return f"Ungueltiger Werkzeugname '{d.get('name')}' - nur Buchstaben, Ziffern und Unterstrich."
    except Exception:
        pass
    folder = os.path.join(PLUGINS_DIR, pid)
    if os.path.exists(folder) and not overwrite:
        return f"Es gibt schon ein Plugin '{pid}'. Nimm einen anderen Namen oder rufe es mit overwrite=true nochmal auf."
    os.makedirs(folder, exist_ok=True)
    kw = [str(k).strip().lower() for k in (keywords or []) if str(k).strip()][:20]
    with open(os.path.join(folder, "plugin.json"), "w", encoding="utf-8") as f:
        json.dump({"name": str(title or pid)[:60], "description": str(description or "")[:300], "version": "1.0", "author": "A.R.I (selbst gebaut)", "keywords": kw}, f, indent=2, ensure_ascii=False)
    with open(os.path.join(folder, "main.py"), "w", encoding="utf-8") as f:
        f.write(code)
    state = _plugin_state()
    state[pid] = {"enabled": False}   # nie von selbst an: der Nutzer prueft den Code und schaltet es ein
    _plugin_state_save(state)
    _plugins_load()
    _PLUGIN_LAST_CREATED.update(id=pid, name=str(title or pid)[:60], ts=time.time())
    return (f"Plugin '{title or pid}' wurde angelegt, ist aber noch AUS. Dem Nutzer wird jetzt der Code zur Pruefung gezeigt - er schaltet es selbst ein. "
            f"Sag ihm kurz, was das Plugin tut und dass er es freigeben muss.")


@app.route("/plugins/code")
def plugins_code():
    bad = _plugin_check_local()
    if bad:
        return bad
    pid = request.args.get("id", "")
    folder = os.path.join(PLUGINS_DIR, pid)
    if not _PLUGIN_ID_RE.match(pid) or not os.path.isdir(folder):
        return jsonify({"error": "Plugin nicht gefunden."}), 404
    try:
        fn = "main.py" if os.path.exists(os.path.join(folder, "main.py")) else "plugin.json"
        with open(os.path.join(folder, fn), "r", encoding="utf-8", errors="replace") as f:
            code = f.read(60000)
    except OSError:
        code = ""
    return jsonify({"error": None, "code": code, "info": _PLUGIN_INFO.get(pid, {})})


@app.route("/plugins/last-created")
def plugins_last_created():
    bad = _plugin_check_local()
    if bad:
        return bad
    return jsonify(_PLUGIN_LAST_CREATED)


def run_tool(name, tool_input):
    if name in _MOD_TOOL_HANDLERS:
        _stats_track("tool:" + str(name))
        return _mod_run_tool(name, tool_input)
    if name in _PLUGIN_HANDLERS:
        _stats_track("tool:plugin")
        return _plugin_run(name, tool_input)
    _stats_track("tool:" + str(name))
    try:
        if name == "control_volume":
            return _tool_control_volume(tool_input.get("action"), tool_input.get("steps", 2), tool_input.get("percent"))
        if name == "set_spotify_volume":
            error = _tool_set_spotify_volume(tool_input.get("percent", 50))
            return f"Spotify-Lautstaerke konnte nicht gesetzt werden: {error}" if error else "Spotify-Lautstaerke gesetzt."
        if name == "play_spotify":
            found_name, error = _tool_play_spotify(tool_input.get("query", ""), tool_input.get("item_type", "track"))
            return f"Spotify-Wiedergabe fehlgeschlagen: {error}" if error else f"Spielt jetzt: '{found_name}'."
        if name == "play_for_me":
            text, error = _play_for_me(tool_input.get("genre", ""))
            return f"Musik-Auswahl fehlgeschlagen: {error}" if error else text
        if name == "transfer_spotify_playback":
            device_name, error = _tool_transfer_spotify_playback(tool_input.get("device", ""))
            return f"Geraetewechsel fehlgeschlagen: {error}" if error else f"Wiedergabe laeuft jetzt auf '{device_name}'."
        if name == "control_media":
            return _tool_control_media(tool_input.get("action"))
        if name == "get_current_spotify_track":
            track, error = _tool_spotify_current_track()
            if error:
                return f"Spotify-Abfrage fehlgeschlagen: {error}"
            if not track:
                return "Gerade laeuft nichts auf Spotify."
            state = "laeuft" if track["is_playing"] else "ist pausiert"
            artists = f" von {track['artists']}" if track["artists"] else ""
            return f"'{track['name']}'{artists} {state} gerade."
        if name == "open_app":
            return _tool_open_app(tool_input.get("app", ""))
        if name == "close_app":
            return _tool_close_app(tool_input.get("app", ""))
        if name == "take_screenshot":
            return _tool_take_screenshot()
        if name == "manage_window":
            return _tool_manage_window(tool_input.get("action"))
        if name == "set_timer":
            return _tool_set_timer(tool_input.get("seconds"), tool_input.get("label", ""), tool_input.get("kind", "timer"))
        if name == "cancel_timer":
            return _tool_cancel_timer(tool_input.get("label", ""))
        if name == "list_timers":
            return _tool_list_timers()
        if name == "window_action":
            return _tool_window_action(tool_input.get("title", ""), tool_input.get("action", ""), tool_input.get("screen"))
        if name == "remember":
            return _tool_remember(tool_input.get("text", ""), tool_input.get("category"))
        if name == "forget":
            return _tool_forget(tool_input.get("query", ""))
        if name == "play_youtube":
            return _tool_play_youtube(tool_input.get("query", ""), bool(tool_input.get("music")))
        if name == "play_youtube_latest":
            return _tool_play_youtube_latest(tool_input.get("channel", ""))
        if name == "maps_route":
            return _tool_maps_route(tool_input.get("destination", ""), tool_input.get("origin", ""), tool_input.get("mode", "driving"))
        if name == "find_restaurant":
            return _tool_find_restaurant(tool_input.get("query", ""), tool_input.get("people"), tool_input.get("when"))
        if name == "play_streaming_title":
            return _tool_play_streaming_title(tool_input.get("title", ""), tool_input.get("provider", ""))
        if name == "server_status":
            return _tool_server_status(tool_input.get("service", ""), tool_input.get("component", ""))
        if name == "read_notifications":
            return _tool_read_notifications(tool_input.get("query", ""))
        if name == "create_plugin":
            return _tool_create_plugin(tool_input.get("name"), tool_input.get("title"), tool_input.get("description"), tool_input.get("keywords"), tool_input.get("code"), bool(tool_input.get("overwrite")), tool_input.get("tools"))
        if name == "reply_notification":
            return _tool_reply_notification(tool_input.get("to", ""), tool_input.get("text", ""), bool(tool_input.get("confirmed")))
        if name == "dismiss_notification":
            return _tool_dismiss_notification(tool_input.get("query", ""), bool(tool_input.get("spam")))
        if name == "open_url":
            return _tool_open_url(tool_input.get("url", ""))
        if name == "search_web":
            return _tool_search_web(tool_input.get("query", ""))
        if name == "web_search_answer":
            return _tool_web_search_answer(tool_input.get("query", ""))
        if name == "list_calendar_events":
            events, error = get_upcoming_events(days=tool_input.get("days", 14))
            if error:
                return f"Kalender konnte nicht gelesen werden: {error}"
            if not events:
                return "Keine anstehenden Termine gefunden."
            return "\n".join(
                f"{e['title']} — {e['start']}" + (f" ({e['location']})" if e.get("location") else "") + f" [id: {e['id']}]"
                for e in events
            )
        if name == "create_calendar_event":
            created, error = create_calendar_event(
                tool_input.get("title", ""),
                tool_input.get("start", ""),
                tool_input.get("end"),
                tool_input.get("location", ""),
            )
            if error:
                return f"Termin konnte nicht angelegt werden: {error}"
            return f"Termin '{created.get('summary')}' angelegt fuer {created.get('start', {}).get('dateTime')}."
        if name == "update_calendar_event":
            updated, error = update_calendar_event(
                tool_input.get("event_id", ""),
                tool_input.get("title"),
                tool_input.get("start"),
                tool_input.get("end"),
                tool_input.get("location"),
            )
            if error:
                return f"Termin konnte nicht bearbeitet werden: {error}"
            return f"Termin '{updated.get('summary')}' aktualisiert."
        if name == "delete_calendar_event":
            error = delete_calendar_event(tool_input.get("event_id", ""))
            if error:
                return f"Termin konnte nicht geloescht werden: {error}"
            return "Termin geloescht."
        if name == "read_emails":
            emails, error = get_recent_emails(tool_input.get("unread_only", True), tool_input.get("max_results", 10))
            if error:
                return f"E-Mails konnten nicht abgerufen werden: {error}"
            if not emails:
                return "Keine ungelesenen E-Mails."
            important_only = tool_input.get("important_only", False)
            if important_only:
                important = _judge_important_emails(emails)
                important_ids = {i["id"] for i in important}
                reasons = {i["id"]: i["reason"] for i in important}
                emails = [e for e in emails if e["id"] in important_ids]
                if not emails:
                    return "Keine wichtigen E-Mails — nur Newsletter/Werbung/automatische Mails im Posteingang."
                return "\n".join(
                    f"{e['from_name'] or e['from']}: {e['subject']} — {reasons.get(e['id'], '')} (id: {e['id']})"
                    for e in emails
                )
            return "\n".join(
                f"{e['from_name'] or e['from']}: {e['subject']} — {e['preview'][:100]} (id: {e['id']})"
                for e in emails
            )
        if name == "send_email":
            error = send_new_email(tool_input.get("to", ""), tool_input.get("subject", ""), tool_input.get("body", ""), tool_input.get("provider"))
            return f"Fehler beim Senden: {error}" if error else "E-Mail gesendet."
        if name == "reply_email":
            error = reply_to_email(tool_input.get("email_id", ""), tool_input.get("body", ""))
            return f"Fehler beim Antworten: {error}" if error else "Antwort gesendet."
        return f"Unbekanntes Tool: {name}"
    except Exception as e:
        print(f"[tool] Fehler bei '{name}': {e}")
        return "Das hat nicht geklappt. Sag dem Nutzer nur kurz, dass es gerade nicht geklappt hat - ohne Fehlercodes oder technische Details."


# GPU-Auslastung: ein herstellerunabhaengiger Weg wurde ausprobiert (Windows'
# "GPU Engine"-Performancezaehler per WMI/COM, dieselben, die der Task-Manager
# nutzt) — auf diesem Rechner aber reproduzierbar instabil in Kombination mit
# Flask (Antwortzeiten wurden mit jeder Anfrage schlechter, einmal sogar ein
# Absturz, auch mit dediziertem Hintergrundthread). Gemaess Vorgabe ("nur
# integrieren, wenn sauber einbindbar, sonst Demo") daher bewusst nicht
# eingebaut — GPU bleibt Demo/nicht verfuegbar (siehe /status-Antwort unten).


# ---------------------------------------------------------------------------
# Google Calendar: zeigt echte Termine aus dem Google-Konto, mit dem die
# Samsung-Kalender-App synct. Client-ID/Secret + der nach dem Login erhaltene
# Zugangs-Token liegen bewusst zusammen in EINER Datei (secrets.json)
# statt in getrennten credentials.json/token.json — einfacher zu finden und
# mit einem Klick komplett zu entfernen (siehe /calendar/configure DELETE).
# WICHTIG: diese Datei enthaelt persoenliche Zugangsdaten — nicht in ein
# oeffentliches Repo o.ae. committen.
# ---------------------------------------------------------------------------
SECRETS_FILE = os.path.join(DATA_DIR, "secrets.json")
# "calendar.events" statt "calendar.readonly": A.R.I soll auch Termine
# anlegen koennen, nicht nur lesen. Wer schon mit dem alten readonly-Scope
# verbunden war, muss sich einmalig neu einloggen (Google verlangt bei
# erweiterten Berechtigungen eine frische Zustimmung).
CALENDAR_SCOPES = ["https://www.googleapis.com/auth/calendar.events"]

_calendar_service = None
_calendar_init_error = None


# Der Hub laeuft mit mehreren gleichzeitigen Anfragen (threaded=True) - ohne diese Sperre
# koennen zwei Anfragen gleichzeitig secrets.json lesen->aendern->schreiben und sich
# gegenseitig ueberschreiben (z.B. eine Handy-Kopplung verschwindet wieder, weil zeitgleich
# ein Kalender-Login gespeichert wurde). Wiedereintretend (RLock), damit ein Aufruf, der
# selbst schon die Sperre haelt, trotzdem _load_secrets()/_save_secrets() nutzen darf.
_secrets_lock = threading.RLock()


def _load_secrets():
    """secrets.json ist nach Dienst verschachtelt: {"calendar": {...},
    "email": {...}} — eine Datei fuer alle Zugangsdaten, damit sich alles auf
    einmal loeschen/exportieren laesst."""
    with _secrets_lock:
        if not os.path.exists(SECRETS_FILE):
            return {}
        try:
            with open(SECRETS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}


def _save_secrets(data):
    with _secrets_lock:
        with open(SECRETS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)


def _update_secrets(key, mutate):
    """Atomarer Lese-Aendern-Schreiben-Zyklus fuer einen einzelnen Schluessel in
    secrets.json (z.B. "phone", "calendar") - haelt die Sperre ueber den ganzen Vorgang,
    damit keine andere Anfrage dazwischenfunkt und Aenderungen verloren gehen."""
    with _secrets_lock:
        s = _load_secrets()
        s[key] = mutate(s.get(key) or {})
        _save_secrets(s)
        return s[key]


def _migrate_legacy_calendar_files():
    """Einmalige Migration: (a) alte getrennte credentials.json/token.json
    (falls vorhanden) in secrets.json zusammenfassen, (b) ein noch flaches
    secrets.json (Kalenderdaten direkt auf oberster Ebene, aus einer
    frueheren Version) unter dem "calendar"-Schluessel verschachteln."""
    legacy_credentials = os.path.join(DASHBOARD_DIR, "credentials.json")
    legacy_token = os.path.join(DASHBOARD_DIR, "token.json")
    if os.path.exists(legacy_credentials) and not os.path.exists(SECRETS_FILE):
        try:
            with open(legacy_credentials, "r", encoding="utf-8") as f:
                client_data = json.load(f).get("installed", {})
            token_data = None
            if os.path.exists(legacy_token):
                with open(legacy_token, "r", encoding="utf-8") as f:
                    token_data = json.load(f)
            _save_secrets({"calendar": {"client": client_data, "token": token_data}})
            os.remove(legacy_credentials)
            if os.path.exists(legacy_token):
                os.remove(legacy_token)
            print("[secrets] credentials.json + token.json zu secrets.json zusammengefuehrt.")
        except (OSError, ValueError) as e:
            print(f"[secrets] Migration der alten Kalender-Dateien fehlgeschlagen: {e}")
        return

    secrets_data = _load_secrets()
    if secrets_data and "client" in secrets_data and "calendar" not in secrets_data:
        _save_secrets({"calendar": {"client": secrets_data.get("client"), "token": secrets_data.get("token")}})
        print("[secrets] secrets.json auf verschachteltes Format (calendar/email) umgestellt.")


_migrate_legacy_calendar_files()


# Google-Login (Browserfenster) nur, wenn der Nutzer auf KALENDER/GMAIL VERBINDEN geklickt hat - nie nebenbei durch eine Hintergrundabfrage.
# Pro Klick hoechstens 2 Versuche; klappt es nicht, wird abgebrochen und der Nutzer muss erneut auf VERBINDEN klicken.
_OAUTH_MAX_TRIES = 2
_oauth_tries = {"calendar": 0, "gmail": 0}


def _oauth_login(kind, make_flow, success_title):
    """Fuehrt den Google-Login hoechstens _oauth_tries[kind] mal aus. Wirft eine verstaendliche Meldung, wenn nichts mehr uebrig ist."""
    if _oauth_tries[kind] <= 0:
        label = "KALENDER" if kind == "calendar" else "GMAIL"
        raise RuntimeError(f"Nicht verbunden - bitte in den Einstellungen auf {label} VERBINDEN klicken.")
    last = None
    while _oauth_tries[kind] > 0:
        _oauth_tries[kind] -= 1
        try:
            flow = make_flow()
            creds = flow.run_local_server(port=0, success_message=_oauth_success_html(success_title, "Dieses Fenster kannst du jetzt schliessen."))
            _oauth_tries[kind] = 0
            return creds
        except Exception as e:
            last = e
    _oauth_tries[kind] = 0
    label = "KALENDER" if kind == "calendar" else "GMAIL"
    raise RuntimeError(f"Die Verbindung mit Google hat nicht geklappt ({str(last)[:120]}). Bitte erneut auf {label} VERBINDEN klicken.")


def _init_google_calendar():
    global _calendar_service, _calendar_init_error
    if _calendar_service is not None or _calendar_init_error is not None:
        return
    if _google_api_build is None:
        _calendar_init_error = "Google-Kalender-Pakete nicht installiert (pip install -r requirements.txt)"
        return
    secrets_data = _load_secrets()
    cal_auth = secrets_data.get("calendar")
    if not cal_auth or not cal_auth.get("client"):
        _calendar_init_error = "Kalender noch nicht verbunden (Client-ID/Secret fehlen)"
        return
    try:
        creds = None
        if cal_auth.get("token"):
            try:
                creds = _GoogleCredentials.from_authorized_user_info(cal_auth["token"], CALENDAR_SCOPES)
                if creds and not creds.valid:
                    if creds.expired and creds.refresh_token:
                        creds.refresh(_GoogleAuthRequest())
                    else:
                        creds = None
            except Exception:
                # Gespeicherter Token ist ungueltig/widerrufen — nicht
                # aufgeben, sondern unten frisch einloggen lassen.
                creds = None
        if not creds:
            # Oeffnet einmalig ein Browserfenster fuer den Google-Login
            # (blockierend) — passiert nur beim allerersten Aufruf bzw.
            # wenn das gespeicherte Token abgelaufen/entzogen ist.
            creds = _oauth_login("calendar", lambda: _GoogleInstalledAppFlow.from_client_config({"installed": cal_auth["client"]}, CALENDAR_SCOPES), "Kalender verbunden")
            cal_auth["token"] = json.loads(creds.to_json())
            _update_secrets("calendar", lambda _old, ca=cal_auth: ca)
        _calendar_service = _google_api_build("calendar", "v3", credentials=creds)
    except Exception as e:
        _calendar_init_error = str(e)


def _reset_calendar_auth():
    """Wirft den lokalen Kalender-Token weg, wenn Google ihn serverseitig
    widerrufen hat (invalid_grant) — die lokale Ablaufzeit sagt das nicht
    voraus, das faellt erst beim echten API-Aufruf auf. Naechster Aufruf
    von _init_google_calendar() macht dann einen frischen interaktiven Login."""
    global _calendar_service, _calendar_init_error
    _calendar_service = None
    _calendar_init_error = None
    def _drop_token(old):
        old.pop("token", None)
        return old
    _update_secrets("calendar", _drop_token)


def get_upcoming_events(days=30, max_results=20, days_back=0):
    """days_back holt zusaetzlich vergangene Termine (fuer die Monatsansicht
    im Kalender-Panel, die auch bereits verstrichene Termine als Punkt/Linie
    zeigen soll) — 0 heisst wie bisher nur ab jetzt vorwaerts (z.B. fuer das
    list_calendar_events-Tool der KI, das nur "anstehend" meint)."""
    _init_google_calendar()
    if _calendar_service is None:
        return None, _calendar_init_error or "Kalender nicht verbunden"
    try:
        start_bound = datetime.datetime.utcnow() - datetime.timedelta(days=days_back)
        time_min = start_bound.isoformat() + "Z"
        end = (datetime.datetime.utcnow() + datetime.timedelta(days=days)).isoformat() + "Z"
        result = _calendar_service.events().list(
            calendarId="primary", timeMin=time_min, timeMax=end,
            maxResults=max_results, singleEvents=True, orderBy="startTime",
        ).execute()
        events = []
        for item in result.get("items", []):
            start_info = item.get("start", {})
            end_info = item.get("end", {})
            events.append({
                "id": item.get("id"),
                "title": item.get("summary", "(Ohne Titel)"),
                "start": start_info.get("dateTime", start_info.get("date")),
                "end": end_info.get("dateTime", end_info.get("date")),
                "all_day": "date" in start_info,
                "location": item.get("location", ""),
            })
        return events, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return None, "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return None, str(e)


DEFAULT_TIMEZONE = "Europe/Berlin"


def create_calendar_event(title, start_iso, end_iso=None, location=""):
    """Legt einen neuen Termin im primaeren Google-Kalender an. end_iso ist
    optional — ohne Angabe wird eine Stunde nach start_iso angenommen.
    Zeiten ohne Zeitzonen-Angabe werden als DEFAULT_TIMEZONE interpretiert,
    statt sich auf eine implizite Server-/Kalender-Standardzeitzone zu
    verlassen."""
    _init_google_calendar()
    if _calendar_service is None:
        return None, _calendar_init_error or "Kalender nicht verbunden"
    try:
        start_dt = datetime.datetime.fromisoformat(start_iso)
    except ValueError:
        return None, f"Ungueltiges Startdatum: '{start_iso}' (erwartet z.B. 2026-09-10T18:00:00)"
    if end_iso:
        try:
            end_dt = datetime.datetime.fromisoformat(end_iso)
        except ValueError:
            return None, f"Ungueltiges Enddatum: '{end_iso}'"
    else:
        end_dt = start_dt + datetime.timedelta(hours=1)
    body = {
        "summary": title,
        "start": {"dateTime": start_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE},
        "end": {"dateTime": end_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE},
    }
    if location:
        body["location"] = location
    try:
        created = _calendar_service.events().insert(calendarId="primary", body=body).execute()
        return created, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return None, "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return None, str(e)


def delete_calendar_event(event_id):
    """Loescht einen Termin anhand seiner Event-ID (die list_calendar_events
    mit zurueckgibt). Muss also erst per list_calendar_events gesucht werden,
    wenn die ID nicht schon bekannt ist."""
    _init_google_calendar()
    if _calendar_service is None:
        return _calendar_init_error or "Kalender nicht verbunden"
    try:
        _calendar_service.events().delete(calendarId="primary", eventId=event_id).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return str(e)


def update_calendar_event(event_id, title=None, start_iso=None, end_iso=None, location=None):
    """Bearbeitet einen bestehenden Termin (per event_id von list_calendar_events).
    Nur die angegebenen Felder werden geaendert, der Rest bleibt wie er war."""
    _init_google_calendar()
    if _calendar_service is None:
        return None, _calendar_init_error or "Kalender nicht verbunden"
    try:
        body = {}
        if title is not None:
            body["summary"] = title
        if start_iso is not None:
            try:
                start_dt = datetime.datetime.fromisoformat(start_iso)
            except ValueError:
                return None, f"Ungueltiges Startdatum: '{start_iso}'"
            body["start"] = {"dateTime": start_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE}
        if end_iso is not None:
            try:
                end_dt = datetime.datetime.fromisoformat(end_iso)
            except ValueError:
                return None, f"Ungueltiges Enddatum: '{end_iso}'"
            body["end"] = {"dateTime": end_dt.isoformat(), "timeZone": DEFAULT_TIMEZONE}
        if location is not None:
            body["location"] = location
        if not body:
            return None, "Keine Aenderungen angegeben."
        updated = _calendar_service.events().patch(calendarId="primary", eventId=event_id, body=body).execute()
        return updated, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_calendar_auth()
            return None, "Kalender-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf KALENDER VERBINDEN klicken."
        return None, str(e)


# ---------------------------------------------------------------------------
# Spotify: steuert Spotifys EIGENE Lautstaerke ueber Spotifys Web-API (anders
# als control_volume, das nur die Windows-Systemlautstaerke kann). Braucht
# eine eigene Spotify-Entwickler-App (Client-ID/Secret) und einen einmaligen
# Browser-Login (Authorization-Code-Flow) — der Redirect geht zurueck an
# diesen Hub selbst (/spotify/callback), kein zusaetzlicher lokaler Server
# noetig. Access-Token wird per Refresh-Token automatisch erneuert.
# ---------------------------------------------------------------------------
SPOTIFY_AUTH_URL = "https://accounts.spotify.com/authorize"
SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"
SPOTIFY_SCOPES = "user-modify-playback-state user-read-playback-state user-read-currently-playing playlist-read-private user-read-recently-played"
SPOTIFY_REDIRECT_URI = "http://127.0.0.1:5000/spotify/callback"


def _spotify_auth_url(client_id):
    params = {
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": SPOTIFY_REDIRECT_URI,
        "scope": SPOTIFY_SCOPES,
    }
    return SPOTIFY_AUTH_URL + "?" + urllib.parse.urlencode(params)


def _spotify_token_request(client_id, client_secret, form_data):
    data = urllib.parse.urlencode(form_data).encode()
    auth = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    req = urllib.request.Request(SPOTIFY_TOKEN_URL, data=data, headers={
        "Authorization": "Basic " + auth,
        "Content-Type": "application/x-www-form-urlencoded",
    })
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def _spotify_access_token():
    """Liefert einen gueltigen Access-Token, erneuert ihn bei Bedarf per
    Refresh-Token — Spotify-Access-Tokens laufen nach 1h ab."""
    secrets_data = _load_secrets()
    sp = secrets_data.get("spotify") or {}
    token = sp.get("token")
    if not sp.get("client_id") or not token:
        return None, "Spotify nicht verbunden (in den Einstellungen einrichten)."
    if time.time() >= token.get("expires_at", 0):
        try:
            fresh = _spotify_token_request(sp["client_id"], sp["client_secret"], {
                "grant_type": "refresh_token",
                "refresh_token": token["refresh_token"],
            })
        except Exception as e:
            return None, f"Spotify-Token konnte nicht erneuert werden: {e}"
        token["access_token"] = fresh["access_token"]
        token["expires_at"] = time.time() + fresh.get("expires_in", 3600) - 30
        if "refresh_token" in fresh:
            token["refresh_token"] = fresh["refresh_token"]
        sp["token"] = token
        secrets_data["spotify"] = sp
        _save_secrets(secrets_data)
    return token["access_token"], None


def _spotify_list_devices(access_token):
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player/devices",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read()).get("devices", [])


def _spotify_activate_device(access_token, device_id):
    """Ueberspringt das "es muss schon aktiv abspielen"-Problem: transferiert
    die Wiedergabe stumm (play=false) auf ein bereits gefundenes, aber noch
    nicht aktives Geraet — Spotify muss dafuer nur offen sein, nicht schon
    etwas abspielen."""
    body = json.dumps({"device_ids": [device_id], "play": False}).encode()
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player",
        data=body, method="PUT",
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
    )
    urllib.request.urlopen(req, timeout=15)


def _spotify_set_volume_raw(access_token, pct):
    req = urllib.request.Request(
        f"https://api.spotify.com/v1/me/player/volume?volume_percent={pct}",
        method="PUT",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    urllib.request.urlopen(req, timeout=15)


def _spotify_get_volume(access_token):
    """Aktuelle Spotify-Lautstaerke in Prozent (None, wenn kein aktives Geraet)."""
    try:
        req = urllib.request.Request("https://api.spotify.com/v1/me/player", headers={"Authorization": f"Bearer {access_token}"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8", "ignore")
        if not raw.strip():
            return None
        vol = (json.loads(raw).get("device") or {}).get("volume_percent")
        return int(vol) if vol is not None else None
    except Exception:
        return None


def _tool_spotify_current_track():
    """Fragt den gerade laufenden Titel bei Spotify ab (Name + Interpret*in),
    damit A.R.I auf 'was laeuft gerade' / 'welches Lied kommt' antworten
    kann, statt zu raten. Gibt None (kein Fehler) zurueck, wenn gerade
    nichts abgespielt wird — das ist ein normaler Zustand, kein Fehler."""
    access_token, error = _spotify_access_token()
    if error:
        return None, error
    # Erst der allgemeine Wiedergabestatus (/me/player: braucht nur "user-read-playback-state"), erst danach "currently-playing"
    # (verlangt zusaetzlich "user-read-currently-playing" - fehlte dieser Zugriff, zeigte das HUD zwar Knoepfe, aber keine Musik).
    data = None
    last_err = None
    for url in ("https://api.spotify.com/v1/me/player?additional_types=track,episode",
                "https://api.spotify.com/v1/me/player/currently-playing"):
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {access_token}"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                if resp.status == 204:   # nichts wird abgespielt
                    return None, None
                data = json.loads(resp.read())
                break
        except urllib.error.HTTPError as e:
            if e.code == 204:
                return None, None
            if e.code in (401, 403):
                last_err = ("Spotify-Zugriff fehlt - in den A.R.I-Einstellungen unter SPOTIFY einmal neu verbinden "
                            "(und bei Spotify Premium bzw. als Nutzer der Developer-App eingetragen sein).")
            else:
                last_err = f"Spotify-Abfrage fehlgeschlagen: {e}"
        except Exception as e:
            last_err = f"Spotify-Abfrage fehlgeschlagen: {e}"
    if data is None:
        return None, last_err
    item = data.get("item")
    if not item:
        return None, None
    name = item.get("name", "")
    artists = ", ".join(a.get("name", "") for a in item.get("artists", []) if a.get("name"))
    is_playing = data.get("is_playing", False)
    imgs = (item.get("album") or {}).get("images") or []
    image = (imgs[1] if len(imgs) > 1 else imgs[0])["url"] if imgs else None  # mittlere Groesse (~300 px)
    first_artist = next((a for a in item.get("artists", []) if a.get("id")), {})
    return {"name": name, "artists": artists, "is_playing": is_playing, "image": image, "artist_id": first_artist.get("id"),
            "progress_ms": data.get("progress_ms") or 0, "duration_ms": item.get("duration_ms") or 0}, None


def _spotify_seek(ms):
    access_token, error = _spotify_access_token()
    if error:
        return error
    try:
        req = urllib.request.Request(f"https://api.spotify.com/v1/me/player/seek?position_ms={max(0, int(ms))}",
                                     method="PUT", headers={"Authorization": f"Bearer {access_token}"})
        urllib.request.urlopen(req, timeout=15)
        return None
    except Exception as e:
        return f"Spotify-Fehler: {e}"


_spotify_mute_prev = {"vol": None}


def _spotify_cmd(method, path):
    """Steuert Spotify direkt ueber die Web-API (Wiedergabe, Weiter, Zurueck). Gibt Fehlertext oder None."""
    token, err = _spotify_access_token()
    if err:
        return err

    def go():
        req = urllib.request.Request("https://api.spotify.com/v1/me/player/" + path, method=method,
                                     data=b"" if method in ("POST", "PUT") else None,
                                     headers={"Authorization": f"Bearer {token}", "Content-Length": "0"})
        urllib.request.urlopen(req, timeout=15)

    try:
        go()
        return None
    except urllib.error.HTTPError as e:
        if e.code != 404:
            return f"Spotify-Fehler: {e.code} {e.reason}"
    except Exception as e:
        return str(e)
    dev, err = _spotify_ensure_active_device(token)  # kein aktives Geraet: Spotify-Geraet aktivieren, dann nochmal
    if err:
        return err
    try:
        go()
        return None
    except Exception as e:
        return f"Spotify-Fehler: {e}"


def _media_control(action, ms=None):
    """Medienplayer (HUD + Handy): steuert SPOTIFY direkt ueber die Spotify-API. Ist Spotify nicht
    verbunden, wird ersatzweise wie bisher die Windows-Medientaste gedrueckt."""
    token, terr = _spotify_access_token()
    if terr:  # Spotify nicht verbunden -> Windows-Tasten
        if action in ("play_pause", "next", "previous"):
            return _tool_control_media(action)
        if action in ("up", "down", "mute"):
            return _tool_control_volume(action, 3)
        return terr
    if action == "play_pause":
        track, _e = _tool_spotify_current_track()
        err = _spotify_cmd("PUT", "pause" if (track and track.get("is_playing")) else "play")
        return err or "OK"
    if action == "next":
        return _spotify_cmd("POST", "next") or "OK"
    if action == "previous":
        return _spotify_cmd("POST", "previous") or "OK"
    if action in ("up", "down"):
        cur = _spotify_get_volume(token)
        if cur is None:
            _spotify_cmd("PUT", "play")  # Geraet wecken, dann nochmal versuchen
            cur = _spotify_get_volume(token)
        if cur is None:
            return "Kein aktives Spotify-Geraet."
        return _tool_set_spotify_volume(max(0, min(100, cur + (10 if action == "up" else -10)))) or f"Lautstärke {'+' if action == 'up' else '-'}10"
    if action == "mute":
        cur = _spotify_get_volume(token)
        if cur is None:
            return "Kein aktives Spotify-Geraet."
        if cur > 0:
            _spotify_mute_prev["vol"] = cur
            return _tool_set_spotify_volume(0) or "Stumm"
        return _tool_set_spotify_volume(_spotify_mute_prev["vol"] or 30) or "Ton an"
    if action == "seek":
        return _spotify_seek(ms or 0) or "OK"
    return "Unbekannte Aktion."


# --- Musikgeschmack ins Gehirn -------------------------------------------------
# A.R.I merkt sich, was du auf Spotify hoerst: wie oft welcher Titel/Interpret, Genres und
# Tageszeit. Daraus entstehen laufend aktualisierte Erinnerungen in der Kategorie "Musik"
# (Lieblingsinterpreten, Lieblingslieder, Genres, wann du hoerst) - ohne Duplikate.
MUSIC_STATS_FILE = os.path.join(DATA_DIR, "music_stats.json")
_MUSIC_PREFIXES = ("Hört am liebsten", "Lieblingslieder", "Musikgeschmack", "Hört Musik meist")
_music = {"stats": None, "cur": None, "last_t": 0.0, "last_brain": 0.0}
_music_lock = threading.Lock()


def _music_stats():
    if _music["stats"] is None:
        try:
            with open(MUSIC_STATS_FILE, "r", encoding="utf-8") as f:
                _music["stats"] = json.load(f)
        except (OSError, ValueError):
            _music["stats"] = {}
        for k, d in (("tracks", {}), ("artists", {}), ("hours", [0] * 24)):
            _music["stats"].setdefault(k, d)
    return _music["stats"]


def _music_save():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = MUSIC_STATS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_music_stats(), f, ensure_ascii=False)
        os.replace(tmp, MUSIC_STATS_FILE)
    except OSError:
        pass


def _deezer_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "A.R.I"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def _music_artist_genres(artist_name):
    """Genres eines Interpreten. Spotify liefert seit 2026 keine Genres mehr in der API - deshalb ueber Deezer
    (kostenlos, ohne Schluessel): Interpret suchen -> beliebteste Titel -> Album-Genres. None = Abfrage gescheitert."""
    if not artist_name:
        return []
    try:
        r = _deezer_get("https://api.deezer.com/search/artist?" + urllib.parse.urlencode({"q": artist_name, "limit": 3}))
        hit = next((a for a in r.get("data", []) if a.get("name", "").lower() == artist_name.lower()), None)
        if not hit:
            return []
        top = _deezer_get(f"https://api.deezer.com/artist/{hit['id']}/top?limit=3")
        out = []
        for t in top.get("data", [])[:3]:
            al = (t.get("album") or {}).get("id")
            if not al:
                continue
            for g in (_deezer_get(f"https://api.deezer.com/album/{al}").get("genres") or {}).get("data", []):
                if g.get("name") and g["name"] not in out:
                    out.append(g["name"])
            if out:
                break
        return out[:4]
    except Exception:
        return None


def _music_fetch_genres(names, delay=0.0):
    """Holt fehlende Genres im Hintergrund, speichert sie und aktualisiert danach das Gehirn."""
    changed = False
    for n in names:
        g = _music_artist_genres(n)
        with _music_lock:
            st = _music_stats()
            ar = st["artists"].get(n)
            if ar is not None:
                ar["gtry"] = int(time.time())
                if g is not None:
                    ar["genres"] = g
                    changed = changed or bool(g)
        if delay:
            time.sleep(delay)
    if changed:
        with _music_lock:
            _music_save()
            try:
                _music_brain(_music_stats())
            except Exception:
                pass


MUSIC_GENRE_MIN_PLAYS = 3   # Genres nur fuer Interpreten, die man oefter hoert (nicht jeden einmaligen Titel)


def _music_needs_genres(ar):
    return ar.get("plays", 0) >= MUSIC_GENRE_MIN_PLAYS and not ar.get("genres") and time.time() - ar.get("gtry", 0) > 7 * 86400


def _music_backfill():
    """Einmal beim Start: bekannte Interpreten ohne Genre nachtragen (meistgehoerte zuerst)."""
    time.sleep(20)
    with _music_lock:
        todo = [a for a, d in sorted(_music_stats()["artists"].items(), key=lambda kv: kv[1]["plays"], reverse=True) if _music_needs_genres(d)][:80]
    if todo:
        _music_fetch_genres(todo, delay=0.5)


def _music_finish(st, cur):
    """Ein Titel ist zu Ende / wurde gewechselt: als gehoert zaehlen oder als uebersprungen."""
    listened, dur = cur["secs"], cur.get("dur") or 0
    need = min(30.0, dur * 0.5) if dur else 30.0
    tr = st["tracks"].setdefault(cur["key"], {"name": cur["name"], "artists": cur["artists"], "plays": 0, "skips": 0, "secs": 0})
    if listened >= need:
        tr["plays"] += 1
        tr["secs"] += int(listened)
        for a in [x.strip() for x in cur["artists"].split(",") if x.strip()][:2]:
            ar = st["artists"].setdefault(a, {"plays": 0, "secs": 0, "genres": None})
            ar["plays"] += 1
            ar["secs"] += int(listened)
            part = _hour_part(cur["hour"])
            ar.setdefault("parts", {})[part] = ar.get("parts", {}).get(part, 0) + 1
        first = cur["artists"].split(",")[0].strip()
        if first and _music_needs_genres(st["artists"].get(first, {})):
            st["artists"][first]["gtry"] = int(time.time())   # nicht mehrfach gleichzeitig anfragen
            threading.Thread(target=_music_fetch_genres, args=([first],), daemon=True).start()
        st["hours"][cur["hour"] % 24] += 1
        return True
    if listened < 20:
        tr["skips"] += 1
    return False


def _music_daypart(hours):
    parts = {"morgens": range(5, 11), "mittags": range(11, 15), "nachmittags": range(15, 18), "abends": range(18, 23)}
    score = {p: sum(hours[h] for h in r) for p, r in parts.items()}
    score["nachts"] = sum(hours[h] for h in list(range(23, 24)) + list(range(0, 5)))
    best = max(score, key=score.get)
    return best if score[best] > 0 else None


def _music_brain(st):
    total = sum(t["plays"] for t in st["tracks"].values())
    if total < 3:
        return
    arts = sorted(st["artists"].items(), key=lambda kv: (kv[1]["plays"], kv[1]["secs"]), reverse=True)[:5]
    if arts:
        _brain_upsert("music:artists", "Hört am liebsten: " + ", ".join(f"{a} ({d['plays']}x)" for a, d in arts) + ".", "Musik")
    favs = [t for t in sorted(st["tracks"].values(), key=lambda t: t["plays"], reverse=True)[:5] if t["plays"] >= 2]
    if favs:
        _brain_upsert("music:tracks", "Lieblingslieder (oft gehört): " + "; ".join(f"{t['name']} von {t['artists']} ({t['plays']}x)" for t in favs) + ".", "Musik")
    gc = {}
    for a, d in sorted(st["artists"].items(), key=lambda kv: kv[1]["plays"], reverse=True)[:25]:
        if d["plays"] < MUSIC_GENRE_MIN_PLAYS:
            continue
        for g in (d.get("genres") or []):
            gc[g] = gc.get(g, 0) + d["plays"]
    if gc:
        _brain_upsert("music:genres", "Musikgeschmack (Genres): " + ", ".join(g for g, _ in sorted(gc.items(), key=lambda kv: kv[1], reverse=True)[:4]) + ".", "Musik")
    dp = _music_daypart(st["hours"])
    if dp:
        _brain_upsert("music:daypart", f"Hört Musik meist {dp}.", "Musik")


def _music_feed(track):
    """Mit dem gerade laufenden Titel fuettern (Hintergrund-Watcher, /media, Handy). Mehrfaches Fuettern
    ist unkritisch: gezaehlt wird die echte Hoerzeit zwischen den Aufrufen."""
    now = time.time()
    with _music_lock:
        st = _music_stats()
        cur, last = _music["cur"], _music["last_t"]
        _music["last_t"] = now
        key = (track["name"] + " – " + track["artists"]).strip() if track else None
        prog = (track.get("progress_ms") or 0) if track else 0
        restart = bool(cur and track and cur["key"] == key and prog + 5000 < cur.get("prog", 0))   # Lied von vorn = neue Wiedergabe
        if cur and last and cur.get("playing") and cur["key"] == key and not restart:
            cur["secs"] += min(now - last, 40)
        if cur and (cur["key"] != key or restart):
            counted = _music_finish(st, cur)
            _music["cur"] = cur = None
            _music_save()
            if counted and now - _music["last_brain"] > 60:
                _music["last_brain"] = now
                try:
                    _music_brain(st)
                except Exception:
                    pass
        if track and cur is None:
            cur = {"key": key, "name": track["name"], "artists": track["artists"], "secs": 0.0,
                   "dur": (track.get("duration_ms") or 0) / 1000.0, "artist_id": track.get("artist_id"), "hour": datetime.datetime.now().hour}
        if cur:
            cur["playing"] = bool(track and track.get("is_playing"))
            cur["prog"] = prog
        _music["cur"] = cur


def _music_watch():
    """Fragt alle 20 s Spotify ab (nur wenn verbunden), damit auch ohne offenes HUD mitgezaehlt wird."""
    while True:
        time.sleep(20)
        try:
            _tok, err = _spotify_access_token()
            if err:
                time.sleep(100)
                continue
            track, e = _tool_spotify_current_track()
            if not e:
                _music_feed(track)
        except Exception:
            pass


def _hour_part(h):
    return "morgens" if 5 <= h < 11 else "mittags" if 11 <= h < 15 else "nachmittags" if 15 <= h < 18 else "abends" if 18 <= h < 23 else "nachts"


def _play_for_me(genre_hint=""):
    """'Spiel mir Musik' ohne Angabe: A.R.I sucht selbst etwas Passendes aus deinen Gewohnheiten aus - Interpreten,
    die du oft hoerst (bevorzugt zur aktuellen Tageszeit, gern passend zum Genre-Wunsch), und nicht zweimal
    hintereinander denselben. Nennt der Nutzer ausdruecklich ein Genre (z.B. 'spiel Pop', 'spiel episch Musik'),
    hat eine direkt dazu passende Spotify-Playlist Vorrang vor der eigenen Hoer-Historie - sonst wuerde bei noch
    unbekanntem Geschmack der Genre-Wunsch schlicht ignoriert. Gibt (text, error)."""
    import random
    hint = (genre_hint or "").strip().lower()
    if hint:
        name, err = _tool_play_spotify(genre_hint, "playlist")
        if not err:
            return f"Spiele {name}.", None
    with _music_lock:
        arts = {a: dict(d) for a, d in _music_stats()["artists"].items() if d.get("plays", 0) >= 2}
    if hint:
        sel = {a: d for a, d in arts.items() if any(hint in g.lower() for g in (d.get("genres") or []))}
        arts = sel or arts
    if not arts:
        return None, "Ich kenne deinen Musikgeschmack noch nicht gut genug - hoer ein paar Tage Spotify, dann suche ich selbst etwas aus. Nenn mir bis dahin einfach einen Kuenstler oder Titel."
    part = _hour_part(datetime.datetime.now().hour)
    recent = _music.setdefault("picked", [])
    pool = [a for a in arts if a not in recent] or list(arts)
    weights = []
    for a in pool:
        d = arts[a]
        parts = d.get("parts") or {}
        share = (parts.get(part, 0) / max(1, sum(parts.values()))) if parts else 0.0
        weights.append(d["plays"] * (1 + 2 * share))
    pick = random.choices(pool, weights=weights, k=1)[0]
    name, err = _tool_play_spotify(pick, "artist")
    if err:
        return None, err
    recent.append(pick)
    del recent[:-3]
    g = (arts[pick].get("genres") or [])[:2]
    return f"Spiele {name} - passt zu deinem Geschmack" + (f" ({', '.join(g)})" if g else "") + ".", None


@app.route("/media")
def media_info():
    track, err = _tool_spotify_current_track()
    if not err:
        _music_feed(track)
    return jsonify({"track": track, "error": err})


@app.route("/media/control", methods=["POST"])
def media_control():
    d = request.get_json(silent=True) or {}
    return jsonify({"message": _media_control(str(d.get("action") or ""), d.get("ms"))})


def _spotify_ensure_active_device(access_token):
    """Sucht ein bereits vorhandenes Geraet (Spotify offen, egal ob es schon
    abspielt), startet notfalls die Desktop-App selbst und aktiviert das
    gefundene Geraet stumm (play=false). Gibt (device_id, error) zurueck."""
    try:
        devices = _spotify_list_devices(access_token)
    except Exception as e:
        return None, f"Spotify-Geraeteliste konnte nicht abgerufen werden: {e}"
    if not devices:
        _tool_open_app("Spotify")
        time.sleep(6)
        try:
            devices = _spotify_list_devices(access_token)
        except Exception as e:
            return None, f"Spotify-Geraeteliste konnte nicht abgerufen werden: {e}"
        if not devices:
            return None, "Spotify wurde gestartet, meldet sich aber noch nicht als Geraet — bitte kurz warten und nochmal versuchen."
    dev = next((d for d in devices if d.get("is_active")), None) or next((d for d in devices if (d.get("type") or "").lower() == "computer"), None) or devices[0]
    device_id = dev["id"]
    if dev.get("is_active"):
        return device_id, None   # laeuft schon auf diesem Geraet: nicht erst umschalten
    try:
        _spotify_activate_device(access_token, device_id)
        time.sleep(1)
    except Exception as e:
        return None, f"Geraet konnte nicht aktiviert werden: {e}"
    return device_id, None


def _spotify_find_device(devices, query):
    """Findet ein Geraet per Freitext — Name (z.B. 'Wohnzimmer', 'Alexa') ODER
    Geraetetyp-Alias (Handy/PC/Lautsprecher etc.), falls der Nutzer keinen
    genauen Geraetenamen nennt, sondern nur die Art des Geraets."""
    needle = query.strip().lower()
    TYPE_ALIASES = {
        "computer": ["pc", "computer", "rechner", "desktop", "laptop"],
        "smartphone": ["handy", "phone", "smartphone", "telefon", "mobil"],
        "speaker": ["lautsprecher", "speaker", "box", "alexa", "echo"],
        "tv": ["tv", "fernseher"],
    }
    for d in devices:
        if needle in (d.get("name") or "").lower():
            return d
    for spotify_type, aliases in TYPE_ALIASES.items():
        if needle in aliases:
            for d in devices:
                if (d.get("type") or "").lower() == spotify_type or needle in (d.get("name") or "").lower():
                    return d
    return None


def _tool_transfer_spotify_playback(device_query):
    """Wechselt die laufende Wiedergabe auf ein anderes Spotify-Connect-
    Geraet (Handy, PC, Alexa/Lautsprecher, ...) — Musik laeuft danach dort
    weiter, ohne zu stoppen. Gibt (geraetename, error) zurueck."""
    access_token, error = _spotify_access_token()
    if error:
        return None, error
    try:
        devices = _spotify_list_devices(access_token)
    except Exception as e:
        return None, f"Spotify-Geraeteliste konnte nicht abgerufen werden: {e}"
    if not devices:
        return None, "Keine Spotify-Geraete gefunden — auf dem Zielgeraet muss Spotify offen sein."
    device = _spotify_find_device(devices, device_query)
    if not device:
        available = ", ".join(d.get("name", "?") for d in devices)
        return None, f"Kein Geraet gefunden fuer '{device_query}'. Verfuegbar: {available}."
    body = json.dumps({"device_ids": [device["id"]], "play": True}).encode()
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player",
        data=body, method="PUT",
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
    )
    try:
        urllib.request.urlopen(req, timeout=15)
    except urllib.error.HTTPError as e:
        return None, f"Wiedergabe konnte nicht auf '{device['name']}' umgeschaltet werden: {e.code} {e.reason}"
    except Exception as e:
        return None, str(e)
    return device["name"], None


def _tool_set_spotify_volume(percent):
    access_token, error = _spotify_access_token()
    if error:
        return error
    pct = max(0, min(100, int(percent)))
    try:
        _spotify_set_volume_raw(access_token, pct)
        return None
    except urllib.error.HTTPError as e:
        if e.code != 404:
            return f"Spotify-Fehler: {e.code} {e.reason}"
    except Exception as e:
        return str(e)

    device_id, error = _spotify_ensure_active_device(access_token)
    if error:
        return error
    try:
        _spotify_set_volume_raw(access_token, pct)
        return None
    except urllib.error.HTTPError as e:
        return f"Spotify-Fehler: {e.code} {e.reason}"
    except Exception as e:
        return str(e)


def _spotify_search(access_token, query, item_type):
    params = urllib.parse.urlencode({"q": query, "type": item_type, "limit": 1})
    req = urllib.request.Request(
        f"https://api.spotify.com/v1/search?{params}",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
    items = data.get(item_type + "s", {}).get("items", [])
    return items[0] if items else None


def _spotify_find_own_playlist(access_token, query):
    """Spotifys normale Suche findet nur OEFFENTLICHE Playlists — die eigenen
    (auch private) muessen separat ueber die eigene Playlist-Liste gesucht
    werden. Einfacher Teilstring-Vergleich (case-insensitive) ueber alle
    Seiten der eigenen Playlists."""
    needle = query.strip().lower()
    url = "https://api.spotify.com/v1/me/playlists?limit=50"
    while url:
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {access_token}"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        for pl in data.get("items", []):
            if needle in (pl.get("name") or "").lower():
                return pl
        url = data.get("next")
    return None


def _spotify_find_recent_algorithmic_playlist(access_token, needle):
    """Spotify gibt algorithmische Mixes (Daylist, Discover Weekly, Release
    Radar, ...) NICHT ueber /me/playlists oder die Suche frei — die einzige
    offizielle Web-API-Spur ist der Wiedergabeverlauf: wenn der Nutzer sie
    schon mal in der Spotify-App gestartet hat, taucht ihre Playlist-URI dort
    als Kontext auf. Braucht den Scope 'user-read-recently-played'. Findet
    nichts, wenn der Nutzer sie noch nie in der App abgespielt hat — das ist
    eine echte Grenze der oeffentlichen API, keine Einschraenkung von uns."""
    req = urllib.request.Request(
        "https://api.spotify.com/v1/me/player/recently-played?limit=50",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
    checked_uris = set()
    for item in data.get("items", []):
        ctx = item.get("context") or {}
        uri = ctx.get("uri", "")
        if ctx.get("type") != "playlist" or uri in checked_uris or ":playlist:" not in uri:
            continue
        checked_uris.add(uri)
        playlist_id = uri.rsplit(":", 1)[-1]
        try:
            preq = urllib.request.Request(
                f"https://api.spotify.com/v1/playlists/{playlist_id}?fields=id,name,uri",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            with urllib.request.urlopen(preq, timeout=15) as presp:
                pdata = json.loads(presp.read())
        except urllib.error.HTTPError:
            continue
        if needle in (pdata.get("name") or "").lower():
            return pdata
    return None


# Feste Zuordnung fuer Genres, bei denen die freie Textsuche unzuverlaessig danebengreift
# (z.B. "episch" fand vorher eine Pop-Playlist statt echter epischer/cinematischer Musik) -
# vom Nutzer selbst bestaetigte Playlist als Treffer.
_GENRE_PLAYLIST_OVERRIDES = {
        "epic": "spotify:playlist:1zRU8ZNQRj7lqhUYPPkey0", "episch": "spotify:playlist:1zRU8ZNQRj7lqhUYPPkey0",
        "epische": "spotify:playlist:1zRU8ZNQRj7lqhUYPPkey0", "epischer": "spotify:playlist:1zRU8ZNQRj7lqhUYPPkey0",
        "epischem": "spotify:playlist:1zRU8ZNQRj7lqhUYPPkey0", "epischen": "spotify:playlist:1zRU8ZNQRj7lqhUYPPkey0",
    }


_DAYLIST_URI = "spotify:playlist:37i9dQZF1EP6YuccBxUcC1"


def _tool_play_spotify(query, item_type="track"):
    """Sucht per Freitext (Playlist/Song/Album/Kuenstler) und startet die
    Wiedergabe — aktiviert dabei automatisch ein Geraet, Spotify muss also
    nur offen sein (oder wird notfalls selbst gestartet), nicht schon laufen.
    Gibt (gefundener_name, error) zurueck."""
    access_token, error = _spotify_access_token()
    if error:
        return None, error
    item_type = item_type if item_type in ("track", "playlist", "album", "artist") else "track"
    is_algorithmic_query = item_type == "playlist" and any(
        kw in query.strip().lower() for kw in ("daylist", "discover weekly", "release radar")
    )
    try:
        item = None
        override_uri = _GENRE_PLAYLIST_OVERRIDES.get(re.sub(r"\s*musik$", "", query.strip().lower())) if item_type == "playlist" else None
        if override_uri:
            item = {"uri": override_uri, "name": query.strip()}
        elif is_algorithmic_query:
            # Spotifys algorithmische Mixes (Daylist, Discover Weekly, Release
            # Radar) sind NICHT Teil von /me/playlists oder der Suche — die
            # einzige offizielle Spur ist der Wiedergabeverlauf, falls der
            # Nutzer sie schon mal in der App gestartet hat.
            needle = "daylist" if "daylist" in query.strip().lower() else query.strip().lower()
            if needle == "daylist":
                # Die Daylist hat bei Spotify eine feste Kennung, die jeder Nutzer auf SEINE eigene Daylist aufgeloest bekommt
                # (der Name wechselt mehrmals am Tag, z.B. "daylist - gym hardstyle ..."). Die Web-API verraet ihre Daten nicht,
                # das Abspielen per Kontext-Adresse funktioniert aber.
                item = {"uri": _DAYLIST_URI, "name": "Daylist"}
            else:
                item = _spotify_find_recent_algorithmic_playlist(access_token, needle)
        elif item_type == "playlist":
            item = _spotify_find_own_playlist(access_token, query)
        if not item:
            item = None if is_algorithmic_query else _spotify_search(access_token, query, item_type)
    except urllib.error.HTTPError as e:
        if is_algorithmic_query and e.code == 403:
            return None, (
                "Fehlende Berechtigung fuer den Wiedergabeverlauf — bitte Spotify "
                "in den Einstellungen einmal neu verbinden (fuer den neuen Zugriff "
                "auf 'zuletzt gehoert')."
            )
        return None, f"Spotify-Suche fehlgeschlagen: {e}"
    except Exception as e:
        return None, f"Spotify-Suche fehlgeschlagen: {e}"
    if not item and is_algorithmic_query:
        return None, (
            "Daylist wurde nicht im Wiedergabeverlauf gefunden — einmal in der "
            "Spotify-App selbst starten, danach findet A.R.I es automatisch "
            "(Spotifys API gibt es sonst nicht frei)."
        )
    if not item:
        return None, f"Nichts gefunden fuer '{query}' ({item_type})."
    uri = item["uri"]
    name = item.get("name", query)

    device_id, error = _spotify_ensure_active_device(access_token)
    if error:
        return None, error

    body = {"uris": [uri]} if item_type == "track" else {"context_uri": uri}

    def send_play(with_device):
        url = "https://api.spotify.com/v1/me/player/play" + (f"?device_id={device_id}" if with_device else "")
        req = urllib.request.Request(
            url, data=json.dumps(body).encode(), method="PUT",
            headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=15)

    # Spotify antwortet auf "play" oft sofort mit 204, obwohl das Geraet noch nicht bereit ist und
    # dann nichts passiert. Deshalb: senden, kurz warten, PRUEFEN ob wirklich etwas laeuft, sonst nochmal.
    last_err = None
    for attempt in range(3):
        try:
            send_play(with_device=(attempt != 1))
        except urllib.error.HTTPError as e:
            last_err = f"Spotify-Fehler beim Abspielen: {e.code} {e.reason}"
            if e.code in (404, 502, 503):   # Geraet nicht bereit -> neu aktivieren
                dev2, err2 = _spotify_ensure_active_device(access_token)
                if not err2:
                    device_id = dev2
            time.sleep(1.2)
            continue
        except Exception as e:
            last_err = str(e)
            time.sleep(1.2)
            continue
        time.sleep(1.0 + attempt * 0.8)
        try:
            track, _e = _tool_spotify_current_track()
        except Exception:
            track = None
        if track and track.get("is_playing"):
            return name, None
        last_err = "Spotify hat den Befehl angenommen, spielt aber nichts."
    return None, (last_err or "Wiedergabe konnte nicht gestartet werden.") + " Ist die Spotify-App am PC geöffnet und als Gerät sichtbar?"


@app.route("/spotify/play", methods=["POST"])
def spotify_play_route():
    """Direkter Abspiel-Aufruf (DEV-Test und Schnelltasten), nur vom eigenen PC."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    d = request.get_json(silent=True) or {}
    name, err = _tool_play_spotify(str(d.get("query") or ""), str(d.get("type") or "track"))
    return jsonify({"name": name, "error": err})


@app.route("/open-external", methods=["POST"])
def open_external():
    """Oeffnet einen Link im Standardbrowser des PCs (nur http/https, nur vom eigenen PC). Gebraucht, weil im eigenen A.R.I-Fenster
    ein per window.open() geoeffnetes Leer-Fenster an Windows geht und dort "Sie benoetigen eine App zum Oeffnen" erscheint."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    url = str((request.get_json(silent=True) or {}).get("url") or "").strip()
    if not re.match(r"^https?://[^\s]+$", url) or len(url) > 4000:
        return jsonify({"error": "ungueltige Adresse"}), 400
    def _go():
        try:
            webbrowser.open(url, new=2)
        except Exception as e:
            print(f"[browser] Link konnte nicht geoeffnet werden: {e}")
    threading.Thread(target=_go, daemon=True).start()   # webbrowser.open kann unter Windows haengen -> nicht im Request
    return jsonify({"error": None})


# --- Automatische Einrichtung per Browser (browser_setup.py) -------------------------------------------------------------
_GROQ_MODEL_CACHE = {"t": 0.0, "ids": []}
_GROQ_PREFERRED = ("llama-3.3-70b-versatile", "openai/gpt-oss-120b", "qwen/qwen3-32b", "moonshotai/kimi-k2-instruct", "llama-3.1-8b-instant", "openai/gpt-oss-20b")


def _groq_chat_models(gclient):
    """Welche Chat-Modelle gibt es bei Groq wirklich? (Modelle werden dort laufend ersetzt - ein fest eingetragener Name kann ploetzlich
    '404 does not exist' liefern.) Bevorzugte zuerst, danach alles Uebrige; Ergebnis wird 1 Stunde gemerkt."""
    now = time.time()
    if not (_GROQ_MODEL_CACHE["ids"] and now - _GROQ_MODEL_CACHE["t"] < 3600):
        try:
            ids = [m.id for m in gclient.models.list().data]
        except Exception:
            ids = []
        _GROQ_MODEL_CACHE.update(t=now, ids=ids)
    ids = _GROQ_MODEL_CACHE["ids"]
    if not ids:
        return list(_GROQ_PREFERRED)
    bad = re.compile(r"whisper|guard|tts|distil|playai|embed|orpheus|safeguard", re.I)
    chat = [i for i in ids if not bad.search(i)]
    ordered = [m for m in _GROQ_PREFERRED if m in chat] + [m for m in chat if m not in _GROQ_PREFERRED]
    return ordered[:5] or list(_GROQ_PREFERRED)


def _llm_text(provider, api_key, groq_keys, system, user, image_b64=None, max_tokens=500):
    """Eine einzelne Anfrage an den im HUD eingestellten KI-Anbieter (Schluessel kommt vom HUD, wie beim Chat). Optional mit
    Screenshot (nur Claude, ChatGPT, Gemini - Groq-Modelle koennen keine Bilder). Gibt den Antworttext zurueck oder wirft."""
    if provider == "groq":
        clients = _groq_clients_for(groq_keys or [])
        if not clients:
            raise RuntimeError("Kein Groq-Schluessel vorhanden.")
        last = None
        msgs = [{"role": "system", "content": system + " Do not call any tools or functions - answer ONLY with the plain JSON text."}, {"role": "user", "content": user}]
        # Erst ein Modell ohne "Nachdenken" (gibt sauberes JSON); das gpt-oss-Modell versucht gelegentlich einen Werkzeugaufruf
        # und scheitert dann mit "Tool choice is none, but model called ..." - es bleibt nur als Ersatz.
        errors = []
        for model_name in _groq_chat_models(clients[0][1]):
            for _label, gclient in clients:   # Limit eines Schluessels erreicht -> naechsten Groq-Schluessel probieren
                try:
                    kw = {"reasoning_effort": "low"} if "gpt-oss" in model_name else {"response_format": {"type": "json_object"}} if "JSON" in system else {}
                    try:
                        resp = gclient.chat.completions.create(model=model_name, messages=msgs, max_tokens=1200 if "gpt-oss" in model_name else max_tokens, **kw)
                    except Exception as e1:
                        if re.search(r"429|rate.?limit|quota|too many requests", str(e1), re.I) or not kw:
                            raise
                        resp = gclient.chat.completions.create(model=model_name, messages=msgs, max_tokens=1200)
                    return resp.choices[0].message.content or ""
                except Exception as e:
                    last = e
                    if re.search(r"429|rate.?limit|quota|too many requests", str(e), re.I):
                        errors.append(f"{model_name}: Limit")
                        continue          # naechster Schluessel
                    errors.append(f"{model_name}: {str(e)[:110]}")
                    print(f"[ki-hilfe] Groq-Modell {model_name} fehlgeschlagen: {str(e)[:200]}")
                    break                 # anderer Fehler -> naechstes Modell
        if all(x.endswith("Limit") for x in errors) and last is not None:
            raise last                    # nur Limits: Aufrufer wartet und macht weiter
        raise RuntimeError("; ".join(e[:75] for e in errors[:4]))
    else:
        client = _client_for(provider, api_key)
        if client is None:
            raise RuntimeError("Kein KI-Schluessel vorhanden.")
        is_anthropic = provider == "anthropic"
        model = ANTHROPIC_MODEL if is_anthropic else (OPENAI_MODEL if provider == "openai" else GEMINI_MODEL)
    if is_anthropic:
        content = [{"type": "text", "text": user}]
        if image_b64:
            content.insert(0, {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": image_b64}})
        resp = client.messages.create(model=model, max_tokens=max_tokens, system=system, messages=[{"role": "user", "content": content}])
        return next((b.text for b in resp.content if b.type == "text"), "")
    content = [{"type": "text", "text": user}]
    if image_b64:
        content.append({"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + image_b64}})
    msgs = [{"role": "system", "content": system}, {"role": "user", "content": content if image_b64 else user}]
    kw = {"reasoning_effort": "low"} if "gpt-oss" in model else {}
    try:
        resp = client.chat.completions.create(model=model, messages=msgs, max_tokens=max_tokens if not kw else 1200, **kw)
    except Exception:
        if not kw:
            raise
        resp = client.chat.completions.create(model=model, messages=msgs, max_tokens=1200)
    return resp.choices[0].message.content or ""


def _spotify_save_and_auth_url(client_id, client_secret):
    secrets_data = _load_secrets()
    secrets_data["spotify"] = {"client_id": client_id, "client_secret": client_secret}
    _save_secrets(secrets_data)
    return _spotify_auth_url(client_id)


@app.route("/setup/browser/start", methods=["POST"])
def setup_browser_start():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    body = request.get_json(silent=True) or {}
    flow = str(body.get("flow") or "")
    try:
        import browser_setup
    except Exception as e:
        return jsonify({"error": f"Modul nicht verfuegbar: {e}"})
    hubcb = {"save_spotify": _spotify_save_and_auth_url, "consent": body.get("consent") is True, "count": body.get("count")}   # consent: Nutzer hat im HUD vorab zugestimmt
    provider, api_key, groq_keys = str(body.get("provider") or ""), str(body.get("api_key") or ""), [k for k in (body.get("groq_api_keys") or []) if isinstance(k, str) and k]
    if provider and (api_key or groq_keys):   # KI-Hilfe fuer Schritte, die nicht automatisch klappen (siehe browser_setup.agent_run)
        hubcb["llm"] = lambda system, user, image=None: _llm_text(provider, api_key, groq_keys, system, user, image)
        hubcb["llm_name"] = provider
    ok, err = browser_setup.start(flow, hubcb, os.path.join(DATA_DIR, "setup-browser"))
    _stats_track("ui:auto_setup")
    return jsonify({"error": None if ok else err})


@app.route("/setup/browser/status")
def setup_browser_status():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    try:
        import browser_setup
    except Exception as e:
        return jsonify({"state": "error", "error": str(e)})
    return jsonify(browser_setup.status())


@app.route("/setup/browser/continue", methods=["POST"])
def setup_browser_continue():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    import browser_setup
    browser_setup.user_continue()
    return jsonify({"error": None})


@app.route("/setup/browser/cancel", methods=["POST"])
def setup_browser_cancel():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    import browser_setup
    browser_setup.cancel()
    return jsonify({"error": None})


@app.route("/spotify/configure", methods=["POST"])
def spotify_configure():
    """Speichert die Spotify-Client-Zugangsdaten und startet den Login im
    Standardbrowser (Authorization-Code-Flow, Redirect zurueck an diesen
    Hub)."""
    t0 = time.time()
    data = request.get_json(force=True, silent=True) or {}
    client_id = (data.get("client_id") or "").strip()
    client_secret = (data.get("client_secret") or "").strip()
    if not client_id or not client_secret:
        return jsonify({"error": "Client-ID und Client-Secret werden benoetigt."})
    secrets_data = _load_secrets()
    secrets_data["spotify"] = {"client_id": client_id, "client_secret": client_secret}
    _save_secrets(secrets_data)
    print(f"[timing] /spotify/configure GESAMT: {time.time() - t0:.2f}s")
    # Die Login-URL wird ans Frontend zurueckgegeben, das sie per window.open()
    # selbst oeffnet, statt dass der Server versucht einen Browser zu starten
    # (webbrowser.open()/os.startfile() kann auf Windows sehr lange haengen,
    # z.B. bei einem uebersehenen "Womit oeffnen?"-Dialogfenster oder wenn
    # kein Standardbrowser gesetzt ist). window.open() im bereits offenen
    # Browser des Nutzers ist zuverlaessig, da kein OS-Rateraten noetig ist.
    return jsonify({"error": None, "auth_url": _spotify_auth_url(client_id)})


@app.route("/spotify/callback")
def spotify_callback():
    """Redirect-Ziel nach dem Spotify-Login — tauscht den Code gegen
    Access-/Refresh-Token und speichert sie in secrets.json."""
    t0 = time.time()
    error = request.args.get("error")
    if error:
        return f"Spotify-Login abgebrochen: {error}"
    code = request.args.get("code")
    secrets_data = _load_secrets()
    sp = secrets_data.get("spotify") or {}
    if not sp.get("client_id"):
        return "Kein Spotify-Client konfiguriert — erst in den A.R.I-Einstellungen Client-ID/Secret eintragen."
    try:
        token_resp = _spotify_token_request(sp["client_id"], sp["client_secret"], {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": SPOTIFY_REDIRECT_URI,
        })
        print(f"[timing] /spotify/callback Token-Austausch: {time.time() - t0:.2f}s")
    except Exception as e:
        print(f"[timing] /spotify/callback Token-Austausch fehlgeschlagen nach {time.time() - t0:.2f}s: {e}")
        return f"Fehler beim Token-Austausch: {e}"
    sp["token"] = {
        "access_token": token_resp["access_token"],
        "refresh_token": token_resp["refresh_token"],
        "expires_at": time.time() + token_resp.get("expires_in", 3600) - 30,
    }
    secrets_data["spotify"] = sp
    _save_secrets(secrets_data)
    return _oauth_success_html("Spotify verbunden", "Dieses Fenster kannst du jetzt schliessen.")


SPAM_SENDERS_FILE = os.path.join(DATA_DIR, "spam_senders.json")
# Als Spam markierte Absender (Anzeigename oder Adresse, klein geschrieben) - werden bei
# /email/check UND /phone/api/data (PC wie Handy) aus den Benachrichtigungen gefiltert,
# nicht nur einmalig ausgeblendet.
def _load_spam_senders():
    try:
        with open(SPAM_SENDERS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def _save_spam_senders(s):
    try:
        with open(SPAM_SENDERS_FILE, "w", encoding="utf-8") as f:
            json.dump(sorted(s), f, ensure_ascii=False)
    except OSError:
        pass


_spam_senders = _load_spam_senders()


def _is_spam_sender(frm):
    frm = str(frm or "").strip().lower()
    if not frm:
        return False
    return any(s in frm or frm in s for s in _spam_senders)


def _add_spam_sender(frm):
    frm = str(frm or "").strip().lower()
    if not frm:
        return False
    _spam_senders.add(frm)
    _save_spam_senders(_spam_senders)
    return True


SEEN_EMAILS_FILE = os.path.join(DATA_DIR, "seen_emails.json")
# Auf Platte statt nur im Speicher — sonst wuerde jede unveraenderte
# ungelesene Mail bei JEDEM Poll (alle paar Minuten, oder erneut nach jedem
# Hub-Neustart) wieder komplett neu per LLM-Aufruf klassifiziert, obwohl sich
# nichts geaendert hat: unnoetige Tokens/Kosten und Latenz. IDs hier sind
# "bereits von der KI beurteilt" (wichtig oder nicht), nicht nur "wichtig" —
# nur wirklich neue, noch nie gesehene Mails werden ueberhaupt an die KI
# geschickt.
def _load_seen_email_ids():
    try:
        with open(SEEN_EMAILS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def _save_seen_email_ids(ids):
    # Auf die letzten 500 begrenzen, sonst waechst die Datei unbegrenzt.
    try:
        with open(SEEN_EMAILS_FILE, "w", encoding="utf-8") as f:
            json.dump(list(ids)[-500:], f)
    except OSError:
        pass


_judged_email_ids = _load_seen_email_ids()


# ---------------------------------------------------------------------------
# Gmail ueber die Google API: nutzt bewusst denselben Google-OAuth-Client wie
# der Kalender (gleiches Google-Cloud-Projekt) — wer den Kalender schon
# verbunden hat, braucht fuer Gmail keine neue Client-ID, nur einen weiteren
# kurzen Login (andere Scopes = eigener Token, getrennt vom Kalender-Token).
# ---------------------------------------------------------------------------
GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.readonly", "https://www.googleapis.com/auth/gmail.send"]

_gmail_service = None
_gmail_init_error = None


def _init_gmail():
    global _gmail_service, _gmail_init_error
    if _gmail_service is not None or _gmail_init_error is not None:
        return
    if _google_api_build is None:
        _gmail_init_error = "Google-Pakete nicht installiert (pip install -r requirements.txt)"
        return
    secrets_data = _load_secrets()
    cal_client = (secrets_data.get("calendar") or {}).get("client")
    if not cal_client:
        _gmail_init_error = "Gmail nutzt denselben Google-Client wie der Kalender — zuerst Kalender verbinden."
        return
    gmail_auth = secrets_data.get("gmail") or {}
    try:
        creds = None
        if gmail_auth.get("token"):
            try:
                creds = _GoogleCredentials.from_authorized_user_info(gmail_auth["token"], GMAIL_SCOPES)
                if creds and not creds.valid:
                    if creds.expired and creds.refresh_token:
                        creds.refresh(_GoogleAuthRequest())
                    else:
                        creds = None
            except Exception:
                # Gespeicherter Token ist ungueltig/widerrufen (z.B.
                # "invalid_grant: Token has been expired or revoked.") —
                # nicht aufgeben, sondern unten frisch einloggen lassen.
                creds = None
        if not creds:
            # Eigener, kurzer Login nur fuer die Gmail-Scopes (blockierend,
            # oeffnet einmalig ein Browserfenster).
            creds = _oauth_login("gmail", lambda: _GoogleInstalledAppFlow.from_client_config({"installed": cal_client}, GMAIL_SCOPES), "Gmail verbunden")
            gmail_auth["token"] = json.loads(creds.to_json())
            secrets_data["gmail"] = gmail_auth
            _save_secrets(secrets_data)
        _gmail_service = _google_api_build("gmail", "v1", credentials=creds)
    except Exception as e:
        _gmail_init_error = str(e)


def _is_invalid_grant(e):
    return "invalid_grant" in str(e)


def _reset_gmail_auth():
    """Wirft den lokalen Gmail-Token weg, wenn Google ihn serverseitig
    widerrufen hat (invalid_grant) — die lokale Ablaufzeit sagt das nicht
    voraus, das faellt erst beim echten API-Aufruf auf. Naechster Aufruf
    von _init_gmail() macht dann einen frischen interaktiven Login."""
    global _gmail_service, _gmail_init_error
    _gmail_service = None
    _gmail_init_error = None
    secrets_data = _load_secrets()
    if "gmail" in secrets_data:
        secrets_data["gmail"].pop("token", None)
        _save_secrets(secrets_data)


def _get_gmail_emails(unread_only, max_results):
    _init_gmail()
    if _gmail_service is None:
        return None, _gmail_init_error or "Gmail nicht verbunden"
    try:
        # category:primary filtert Gmails eigene "Werbung"/"Social"/"Updates"-
        # Reiter direkt weg — das faengt die meisten Shop-Newsletter schon vor
        # der eigentlichen KI-Wichtigkeitspruefung ab.
        query = "category:primary" + (" is:unread" if unread_only else "")
        listing = _gmail_service.users().messages().list(
            userId="me", q=query,
            maxResults=max_results, labelIds=["INBOX"],
        ).execute()
        emails = []
        for item in listing.get("messages", []):
            msg = _gmail_service.users().messages().get(
                userId="me", id=item["id"], format="metadata",
                metadataHeaders=["From", "Subject", "Date"],
            ).execute()
            headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
            from_header = headers.get("From", "")
            emails.append({
                "id": item["id"],
                "from": from_header,
                "from_name": from_header.split("<")[0].strip().strip('"'),
                "subject": headers.get("Subject", ""),
                "preview": msg.get("snippet", ""),
                "received": headers.get("Date", ""),
            })
        return emails, None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return None, "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return None, str(e)


def _html_to_text(html):
    import html as html_lib
    t = re.sub(r"(?is)<(script|style|head)[^>]*>.*?</\1>", " ", html or "")
    t = re.sub(r"(?i)<br\s*/?>|</(p|div|tr|h[1-6]|li)>", "\n", t)
    t = re.sub(r"(?s)<[^>]+>", " ", t)
    t = html_lib.unescape(t)
    t = re.sub(r"[ \t\xa0]+", " ", t)
    return re.sub(r"\n\s*\n\s*\n+", "\n\n", t).strip()


def _mime_text(msg):
    """Lesbarer Text einer Mail: bevorzugt text/plain, sonst der HTML-Teil ohne Formatierung."""
    plain, html = [], []
    for part in msg.walk():
        if part.get_content_maintype() != "text" or part.get_filename():
            continue
        try:
            raw = part.get_payload(decode=True) or b""
            txt = raw.decode(part.get_content_charset() or "utf-8", errors="replace")
        except Exception:
            continue
        (plain if part.get_content_subtype() == "plain" else html).append(txt)
    if plain:
        return "\n".join(plain).strip()
    return _html_to_text("\n".join(html))


def _mime_html(msg):
    """HTML-Teil einer Mail fuer die Bild-Ansicht. Bilder, die in der Mail selbst stecken (cid:...), werden als data:-Adresse eingesetzt, damit sie
    ohne Internet-Abruf angezeigt werden. Gibt "" zurueck, wenn die Mail keinen HTML-Teil hat."""
    import base64
    html_parts, cids = [], {}
    for part in msg.walk():
        ctype = part.get_content_type()
        if ctype == "text/html" and not part.get_filename():
            try:
                raw = part.get_payload(decode=True) or b""
                html_parts.append(raw.decode(part.get_content_charset() or "utf-8", errors="replace"))
            except Exception:
                continue
        elif part.get_content_maintype() == "image" and part.get("Content-ID"):
            try:
                data = part.get_payload(decode=True) or b""
                if len(data) <= 3_000_000:
                    cids[part.get("Content-ID").strip().strip("<>")] = f"data:{ctype};base64," + base64.b64encode(data).decode("ascii")
            except Exception:
                continue
    html = "\n".join(html_parts)
    if not html.strip():
        return ""
    for cid, uri in cids.items():
        html = html.replace("cid:" + cid, uri)
    return html[:900000]


def _mail_full(email_id):
    """Ganzer Text einer Mail (Gmail oder Yahoo) fuer die Lese-Ansicht. Gibt {from, subject, date, text} oder {error}."""
    import email as email_lib
    import base64
    try:
        if email_id.startswith("gmail:"):
            _init_gmail()
            if _gmail_service is None:
                return {"error": _gmail_init_error or "Gmail nicht verbunden"}
            raw = _gmail_service.users().messages().get(userId="me", id=email_id.split(":", 1)[1], format="raw").execute().get("raw", "")
            msg = email_lib.message_from_bytes(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)))
        elif email_id.startswith("yahoo:"):
            creds = _yahoo_creds()
            if not creds:
                return {"error": "Yahoo Mail nicht verbunden"}
            imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
            imap.login(creds["email"], creds["app_password"])
            imap.select("INBOX", readonly=True)
            _, data = imap.uid("fetch", email_id.split(":", 1)[1], "(BODY.PEEK[])")
            imap.logout()
            msg = email_lib.message_from_bytes(data[0][1])
        else:
            return {"error": "Unbekannte E-Mail-Quelle."}
        return {"from": _decode_mime_header(msg.get("From", "")), "subject": _decode_mime_header(msg.get("Subject", "")),
                "date": msg.get("Date", ""), "text": _mime_text(msg)[:30000], "html": _mime_html(msg)}
    except Exception as e:
        return {"error": str(e)[:200]}


@app.route("/email/full")
def email_full():
    return jsonify(_mail_full(request.args.get("id", "")))


def _send_gmail_email(to, subject, body):
    import base64
    from email.mime.text import MIMEText

    _init_gmail()
    if _gmail_service is None:
        return _gmail_init_error or "Gmail nicht verbunden"
    try:
        message = MIMEText(body)
        message["to"] = to
        message["subject"] = subject
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        _gmail_service.users().messages().send(userId="me", body={"raw": raw}).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return str(e)


def _reply_gmail_email(message_id, body):
    import base64
    from email.mime.text import MIMEText

    _init_gmail()
    if _gmail_service is None:
        return _gmail_init_error or "Gmail nicht verbunden"
    try:
        original = _gmail_service.users().messages().get(
            userId="me", id=message_id, format="metadata",
            metadataHeaders=["From", "Subject", "Message-ID", "References"],
        ).execute()
        headers = {h["name"]: h["value"] for h in original.get("payload", {}).get("headers", [])}
        subject = headers.get("Subject", "")
        if not subject.lower().startswith("re:"):
            subject = "Re: " + subject
        message = MIMEText(body)
        message["to"] = headers.get("From", "")
        message["subject"] = subject
        if headers.get("Message-ID"):
            message["In-Reply-To"] = headers["Message-ID"]
            message["References"] = (headers.get("References", "") + " " + headers["Message-ID"]).strip()
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        _gmail_service.users().messages().send(userId="me", body={"raw": raw, "threadId": original.get("threadId")}).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return str(e)


YAHOO_IMAP_HOST = "imap.mail.yahoo.com"
YAHOO_SMTP_HOST = "smtp.mail.yahoo.com"


def _decode_mime_header(value):
    from email.header import decode_header
    if not value:
        return ""
    decoded = ""
    for text, enc in decode_header(value):
        decoded += text.decode(enc or "utf-8", errors="replace") if isinstance(text, bytes) else text
    return decoded


def _yahoo_creds():
    yahoo = _load_secrets().get("yahoo") or {}
    if not yahoo.get("email") or not yahoo.get("app_password"):
        return None
    return yahoo


def _get_yahoo_emails(unread_only, max_results):
    import email as email_lib
    creds = _yahoo_creds()
    if not creds:
        return None, "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(creds["email"], creds["app_password"])
        imap.select("INBOX")
        _, data = imap.uid("search", None, "UNSEEN" if unread_only else "ALL")
        uids = data[0].split()[-max_results:] if data and data[0] else []
        emails = []
        for uid in reversed(uids):
            _, msg_data = imap.uid("fetch", uid, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
            if not msg_data or not msg_data[0]:
                continue
            msg = email_lib.message_from_bytes(msg_data[0][1])
            from_header = _decode_mime_header(msg.get("From", ""))
            emails.append({
                "id": uid.decode(),
                "from": from_header,
                "from_name": from_header.split("<")[0].strip().strip('"'),
                "subject": _decode_mime_header(msg.get("Subject", "")),
                "preview": "",
                "received": msg.get("Date", ""),
            })
        imap.logout()
        return emails, None
    except Exception as e:
        return None, str(e)


def _send_yahoo_email(to, subject, body):
    from email.mime.text import MIMEText
    creds = _yahoo_creds()
    if not creds:
        return "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        message = MIMEText(body)
        message["From"] = creds["email"]
        message["To"] = to
        message["Subject"] = subject
        with smtplib.SMTP_SSL(YAHOO_SMTP_HOST, 465) as smtp:
            smtp.login(creds["email"], creds["app_password"])
            smtp.send_message(message)
        return None
    except Exception as e:
        return str(e)


def _reply_yahoo_email(uid, body):
    import email as email_lib
    from email.mime.text import MIMEText
    creds = _yahoo_creds()
    if not creds:
        return "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(creds["email"], creds["app_password"])
        imap.select("INBOX")
        _, msg_data = imap.uid("fetch", uid, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT MESSAGE-ID REFERENCES)])")
        imap.logout()
        if not msg_data or not msg_data[0]:
            return "E-Mail nicht gefunden."
        msg = email_lib.message_from_bytes(msg_data[0][1])
        subject = _decode_mime_header(msg.get("Subject", ""))
        if not subject.lower().startswith("re:"):
            subject = "Re: " + subject
        reply = MIMEText(body)
        reply["From"] = creds["email"]
        reply["To"] = msg.get("From", "")
        reply["Subject"] = subject
        if msg.get("Message-ID"):
            reply["In-Reply-To"] = msg["Message-ID"]
            reply["References"] = (msg.get("References", "") + " " + msg["Message-ID"]).strip()
        with smtplib.SMTP_SSL(YAHOO_SMTP_HOST, 465) as smtp:
            smtp.login(creds["email"], creds["app_password"])
            smtp.send_message(reply)
        return None
    except Exception as e:
        return str(e)


def _provider_status():
    secrets_data = _load_secrets()
    gmail_ok = bool((secrets_data.get("calendar") or {}).get("client")) and bool(secrets_data.get("gmail"))
    yahoo_ok = bool(_yahoo_creds())
    return {"gmail": gmail_ok, "yahoo": yahoo_ok}


def get_recent_emails(unread_only=True, max_results=10):
    status = _provider_status()
    if not status["gmail"] and not status["yahoo"]:
        return None, "Kein E-Mail-Konto verbunden (in den Einstellungen einrichten)."
    combined = []
    errors = []
    if status["gmail"]:
        emails, error = _get_gmail_emails(unread_only, max_results)
        if error:
            errors.append("Gmail: " + error)
        else:
            for e in emails or []:
                e["id"] = "gmail:" + e["id"]
            combined.extend(emails or [])
    if status["yahoo"]:
        emails, error = _get_yahoo_emails(unread_only, max_results)
        if error:
            errors.append("Yahoo: " + error)
        else:
            for e in emails or []:
                e["id"] = "yahoo:" + e["id"]
            combined.extend(emails or [])
    if not combined and errors:
        return None, "; ".join(errors)
    return combined[:max_results], None


def send_new_email(to, subject, body, provider=None):
    status = _provider_status()
    if provider == "yahoo":
        return _send_yahoo_email(to, subject, body)
    if provider == "gmail":
        return _send_gmail_email(to, subject, body)
    if status["gmail"]:
        return _send_gmail_email(to, subject, body)
    if status["yahoo"]:
        return _send_yahoo_email(to, subject, body)
    return "Kein E-Mail-Konto verbunden (in den Einstellungen einrichten)."


def reply_to_email(email_id, body):
    if email_id.startswith("yahoo:"):
        return _reply_yahoo_email(email_id.split(":", 1)[1], body)
    if email_id.startswith("gmail:"):
        return _reply_gmail_email(email_id.split(":", 1)[1], body)
    return "Unbekannte E-Mail-Quelle."


def mark_email_read(email_id):
    """Fuer den X-Knopf an einer einzelnen Benachrichtigung im Frontend —
    markiert die zugehoerige Mail beim jeweiligen Anbieter als gelesen, statt
    sie nur lokal aus der Liste zu entfernen. Gibt None bei Erfolg zurueck,
    sonst eine Fehlermeldung."""
    if email_id.startswith("yahoo:"):
        return _mark_yahoo_read(email_id.split(":", 1)[1])
    if email_id.startswith("gmail:"):
        return _mark_gmail_read(email_id.split(":", 1)[1])
    return "Unbekannte E-Mail-Quelle."


def _mark_gmail_read(message_id):
    _init_gmail()
    if _gmail_service is None:
        return _gmail_init_error or "Gmail nicht verbunden"
    try:
        _gmail_service.users().messages().modify(
            userId="me", id=message_id, body={"removeLabelIds": ["UNREAD"]},
        ).execute()
        return None
    except Exception as e:
        if _is_invalid_grant(e):
            _reset_gmail_auth()
            return "Gmail-Zugriff wurde bei Google widerrufen — bitte in den Einstellungen erneut auf GMAIL VERBINDEN klicken."
        return str(e)


def _mark_yahoo_read(uid):
    creds = _yahoo_creds()
    if not creds:
        return "Yahoo Mail nicht verbunden (in den Einstellungen einrichten)."
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(creds["email"], creds["app_password"])
        imap.select("INBOX")
        imap.uid("STORE", uid, "+FLAGS", "(\\Seen)")
        imap.logout()
        return None
    except Exception as e:
        return str(e)


def _judge_important_emails(emails, provider=None, request_api_key=None, groq_api_keys=None):
    """Nutzt den vom Frontend konfigurierten Anbieter (Einstellungen -> API-
    Schluessel), falls mitgegeben, sonst den zuerst verfuegbaren Env-Var-
    Client, um aus den ungelesenen Mails NUR die wirklich wichtigen
    herauszufiltern (nicht Newsletter/Werbung/automatische Benachrichtigungen)
    — fuer die Hintergrund-Pruefung, die den Nutzer proaktiv informiert.
    WICHTIG: gibt bei einem echten Fehlschlag (kein Client verfuegbar, API-
    Fehler) None zurueck, nicht []  — der Aufrufer markiert Mails nur bei
    einer echten Antwort als "beurteilt". Sonst wuerde eine Mail bei jedem
    Aussetzer (fehlender Key, Netzwerkfehler, Rate-Limit) faelschlich fuer
    immer als "schon geprueft, nicht wichtig" gelten, obwohl sie nie
    tatsaechlich beurteilt wurde."""
    if not emails:
        return []
    client, model, is_anthropic = None, None, False
    if provider == "groq":
        groq_clients = _groq_clients_for(groq_api_keys or [])
        if groq_clients:
            client, model = groq_clients[0][1], GROQ_MODEL
    elif provider:
        client = _client_for(provider, request_api_key)
        model, is_anthropic = (ANTHROPIC_MODEL, True) if provider == "anthropic" else (
            (OPENAI_MODEL, False) if provider == "openai" else (GEMINI_MODEL, False)
        )
    if client is None:
        if _anthropic_client:
            client, model, is_anthropic = _anthropic_client, ANTHROPIC_MODEL, True
        elif _openai_client:
            client, model = _openai_client, OPENAI_MODEL
        elif _groq_client:
            client, model = _groq_client, GROQ_MODEL
    if client is None:
        return None
    listing = "\n".join(
        f"- id={e['id']} | {e['from_name'] or e['from']}: {e['subject']} - {e['preview'][:150]}"
        for e in emails
    )
    prompt = (
        "Hier sind ungelesene E-Mails im Posteingang. Nenne NUR die, die reine WERBUNG "
        "sind (Newsletter, Angebote, Rabatte, Marketing, Umfragen von Shops). Alles andere "
        "(persoenliche Mails, Codes, Sicherheits-/Login-Hinweise, Rechnungen, Bestellungen, "
        "Versand, Termine, Benachrichtigungen von Diensten) ist KEINE Werbung. "
        "Antworte als Zeilen im Format 'id|Werbung'. "
        "Wenn keine Werbung dabei ist, antworte nur mit 'keine'.\n\n" + listing
    )
    try:
        if is_anthropic:
            resp = client.messages.create(model=model, max_tokens=300, messages=[{"role": "user", "content": prompt}])
            text = next((b.text for b in resp.content if b.type == "text"), "")
        elif "gpt-oss" in model:
            # Reasoning-Modelle wie gpt-oss verbrauchen sonst das ganze
            # max_tokens-Budget fuer internes Nachdenken und die eigentliche
            # Antwort bleibt leer — reasoning_effort="low" haelt das kurz
            # (gleiche Behandlung wie beim normalen Chat, siehe /chat).
            try:
                resp = client.chat.completions.create(
                    model=model, messages=[{"role": "user", "content": prompt}], max_tokens=600, reasoning_effort="low"
                )
            except Exception:
                resp = client.chat.completions.create(model=model, messages=[{"role": "user", "content": prompt}], max_tokens=600)
            text = resp.choices[0].message.content or ""
        else:
            resp = client.chat.completions.create(model=model, messages=[{"role": "user", "content": prompt}], max_tokens=300)
            text = resp.choices[0].message.content or ""
    except Exception as e:
        print(f"[email_check] LLM-Aufruf fehlgeschlagen (provider={provider}, model={model}): {e!r}")
        return None
    text = text.strip()
    ad_ids = set()
    if text and not text.lower().startswith("keine"):
        for line in text.splitlines():
            line = line.strip("- ").strip()
            if "|" in line:
                ad_ids.add(line.split("|", 1)[0].strip().replace("id=", ""))
    # Alles ausser der als Werbung erkannten Mails wird gemeldet
    return [{"id": e["id"], "reason": "Neue E-Mail"} for e in emails if e["id"] not in ad_ids]


@app.route("/email/configure/gmail", methods=["POST"])
def gmail_configure():
    """Verbindet Gmail — braucht keine eigene Client-ID, nutzt den bereits
    beim Kalender hinterlegten Google-Client. Stoesst nur den (separaten,
    weil andere Scopes) Login-Vorgang an."""
    global _gmail_service, _gmail_init_error
    _gmail_service = None
    _gmail_init_error = None
    _oauth_tries["gmail"] = _OAUTH_MAX_TRIES   # Klick auf GMAIL VERBINDEN: Login erlaubt (hoechstens 2 Versuche)
    try:
        _init_gmail()
    finally:
        _oauth_tries["gmail"] = 0
    return jsonify({"error": _gmail_init_error})


@app.route("/email/configure/yahoo", methods=["POST"])
def yahoo_configure():
    """Speichert Yahoo-Mail-Zugangsdaten (E-Mail + App-Passwort fuer IMAP/SMTP,
    kein OAuth noetig) und testet den Login sofort, damit Tippfehler direkt
    auffallen statt erst beim naechsten E-Mail-Abruf."""
    data = request.get_json(force=True, silent=True) or {}
    email_addr = (data.get("email") or "").strip()
    app_password = (data.get("app_password") or "").strip()
    if not email_addr or not app_password:
        return jsonify({"error": "E-Mail-Adresse und App-Passwort werden benoetigt."})
    try:
        imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
        imap.login(email_addr, app_password)
        imap.logout()
    except Exception as e:
        return jsonify({"error": str(e)})
    secrets_data = _load_secrets()
    secrets_data["yahoo"] = {"email": email_addr, "app_password": app_password}
    _save_secrets(secrets_data)
    return jsonify({"error": None})


_HUB_SECRET_KEYS = ("calendar", "gmail", "spotify", "yahoo")


@app.route("/settings/hub-export", methods=["POST"])
def hub_settings_export():
    """Zugangsdaten und Anmeldungen (Google/Gmail/Spotify/Yahoo) fuer die Einstellungs-
    Exportdatei - damit ein Import auf einem anderen PC sofort alles verbindet."""
    if not request.is_json:
        return jsonify({"error": "JSON erforderlich"}), 400
    sec = _load_secrets()
    return jsonify({"secrets": {k: sec[k] for k in _HUB_SECRET_KEYS if k in sec}})


@app.route("/settings/hub-import", methods=["POST"])
def hub_settings_import():
    """Spielt exportierte Zugangsdaten/Anmeldungen ein und prueft jede Verbindung.
    Es wird nie ein Login-Fenster geoeffnet - nur vorhandene Tokens werden getestet."""
    global _calendar_service, _calendar_init_error, _gmail_service, _gmail_init_error
    if not request.is_json:
        return jsonify({"error": "JSON erforderlich"}), 400
    incoming = (request.get_json(silent=True) or {}).get("secrets")
    if not isinstance(incoming, dict):
        return jsonify({"error": "Keine Zugangsdaten in der Datei"}), 400
    sec = _load_secrets()
    for k in _HUB_SECRET_KEYS:
        if isinstance(incoming.get(k), dict):
            sec[k] = incoming[k]
    _save_secrets(sec)
    _calendar_service = None; _calendar_init_error = None
    _gmail_service = None; _gmail_init_error = None
    res = {}
    if (sec.get("calendar") or {}).get("token"):
        try:
            _, err = get_upcoming_events(days=1, max_results=1, days_back=0)
        except Exception as e:
            err = str(e)
        res["calendar"] = {"ok": not err, "error": err}
    else:
        res["calendar"] = {"ok": False, "error": "Anmeldung fehlt"}
    if (sec.get("gmail") or {}).get("token"):
        try:
            _init_gmail()
            res["gmail"] = {"ok": not _gmail_init_error, "error": _gmail_init_error}
        except Exception as e:
            res["gmail"] = {"ok": False, "error": str(e)}
    else:
        res["gmail"] = {"ok": False, "error": "Anmeldung fehlt"}
    if (sec.get("spotify") or {}).get("token"):
        try:
            _, err = _spotify_access_token()
        except Exception as e:
            err = str(e)
        res["spotify"] = {"ok": not err, "error": err}
    else:
        res["spotify"] = {"ok": False, "error": "Anmeldung fehlt"}
    y = sec.get("yahoo") or {}
    if y.get("email") and y.get("app_password"):
        try:
            imap = imaplib.IMAP4_SSL(YAHOO_IMAP_HOST)
            imap.login(y["email"], y["app_password"])
            imap.logout()
            res["yahoo"] = {"ok": True, "error": None}
        except Exception as e:
            res["yahoo"] = {"ok": False, "error": str(e)}
    else:
        res["yahoo"] = {"ok": False, "error": "nicht eingerichtet"}
    return jsonify({"results": res})


@app.route("/email/mark-read", methods=["POST"])
def email_mark_read():
    """Fuer den X-Knopf an einer einzelnen Benachrichtigung im Frontend."""
    data = request.get_json(silent=True) or {}
    email_id = (data.get("id") or "").strip()
    if not email_id:
        return jsonify({"error": "Keine E-Mail-ID angegeben."}), 400
    # Das Postfach wird NICHT veraendert (kein "gelesen"-Markieren): die Benachrichtigung verschwindet nur im HUD, die Mail bleibt ungelesen im Postfach.
    return jsonify({"error": None})


@app.route("/email/spam", methods=["POST"])
def email_mark_spam():
    """Markiert einen Absender dauerhaft als Spam - wird danach bei /email/check
    UND /phone/api/data (PC wie Handy) aus den Benachrichtigungen gefiltert."""
    data = request.get_json(silent=True) or {}
    frm = (data.get("from") or "").strip()
    if not frm:
        return jsonify({"error": "Kein Absender angegeben."}), 400
    _add_spam_sender(frm)   # nur lokal gemerkt - im Postfach wird nichts veraendert
    return jsonify({"error": None})


_MAIL_CODE_RE = re.compile(
    r"(verification|verify|bestätigungs|bestaetigungs|bestätigung|bestaetigung|sicherheits|security|"
    r"passwort|password|kennwort|einmal|one[- ]time|otp|2fa|two[- ]factor|zwei[- ]faktor|"
    r"anmelde|login|log[- ]?in|sign[- ]?in|verifizier|\bcode\b|\bpin\b|token|zugangs)", re.IGNORECASE)


def _mail_code_reason(e):
    text = f"{e.get('subject', '')} {e.get('preview', '')[:200]}"
    if _MAIL_CODE_RE.search(text):
        return "Code/Sicherheit: " + (e.get("subject") or "")[:80]
    return ""


@app.route("/email/check", methods=["GET", "POST"])
def email_check():
    """Fuer die Benachrichtigungen-Kachel im Frontend: prueft ungelesene
    Mails und meldet jede neue E-Mail einmal (ohne KI-Filter)."""
    emails, error = get_recent_emails(unread_only=True, max_results=15)
    if error:
        return jsonify({"important": [], "error": error})
    emails = [e for e in (emails or []) if not _is_spam_sender(e.get("from_name") or e.get("from", ""))]
    # Kein KI-Filter mehr: der Nutzer entscheidet selbst, was wichtig ist. Jede ungelesene Mail (ausser von selbst gesperrten Absendern) erscheint einmal
    # als Benachrichtigung; zur Orientierung steht der Anfang des Mailtextes dabei.
    # Immer ALLE aktuell ungelesenen Mails melden (nicht nur neue): das HUD merkt sich selbst, welche du schon weggeklickt hast. So ist die Liste nach
    # einem Neuladen des Fensters sofort wieder komplett, statt dass alle Mail-Benachrichtigungen weg sind.
    result = []
    for email in (emails or []):
        reason = " ".join(str(email.get("preview") or "").split())[:140]
        result.append({
            "id": email["id"],
            "from": email.get("from_name") or email.get("from", ""),
            "subject": email.get("subject", ""),
            "reason": reason,
        })
    return jsonify({"important": result, "error": None})


@app.route("/calendar")
def calendar_events():
    # Der Kalender wird jetzt komplett geladen (1 Jahr vor/zurueck), damit die Monatsansicht
    # beim Vor-/Zurueckblaettern IMMER Termine zeigt, nicht nur innerhalb eines schmalen
    # Fensters ab heute. "NÄCHSTE TERMINE" filtert im Frontend selbst auf die naechsten 30
    # Tage - die Begrenzung gilt also nur fuer die Liste, nicht fuer das Laden.
    events, error = get_upcoming_events(days=365, max_results=800, days_back=365)
    return jsonify({"events": events or [], "error": error})


@app.route("/calendar/configure", methods=["POST"])
def calendar_configure():
    """Schreibt Client-ID/Client-Secret (aus den Einstellungen) in
    secrets.json — Alternative dazu, eine von Google heruntergeladene
    JSON-Datei manuell umzubenennen/abzulegen. Danach wird der naechste
    /calendar-Aufruf (bzw. der Verbinden-Button im Frontend) den OAuth-Login
    anstossen."""
    global _calendar_service, _calendar_init_error, _gmail_service, _gmail_init_error
    data = request.get_json(silent=True) or {}
    client_id = (data.get("client_id") or "").strip()
    client_secret = (data.get("client_secret") or "").strip()
    if not client_id or not client_secret:
        return jsonify({"error": "client_id und client_secret sind erforderlich"}), 400

    cal_entry = {
        "client": {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "redirect_uris": ["http://localhost"],
        },
        "token": None,
    }
    try:
        _update_secrets("calendar", lambda _old: cal_entry)
    except OSError as e:
        return jsonify({"error": f"secrets.json konnte nicht geschrieben werden: {e}"}), 500

    # Erzwingt einen frischen Verbindungsversuch (inkl. moeglichem OAuth-Login) beim naechsten
    # /calendar-Aufruf statt eines alten Fehlers - und ebenso fuer Gmail, das denselben
    # Google-Client nutzt und sonst einen laengst veralteten "erst Kalender verbinden"-Fehler
    # aus dem Speicher weiter anzeigen wuerde.
    _calendar_service = None
    _calendar_init_error = None
    _gmail_service = None
    _gmail_init_error = None
    _oauth_tries["calendar"] = _OAUTH_MAX_TRIES   # der Nutzer hat geklickt: Login erlaubt (hoechstens 2 Versuche)
    try:
        events, error = get_upcoming_events()
    finally:
        _oauth_tries["calendar"] = 0
    if error:
        return jsonify({"error": error})
    return jsonify({"error": None, "events": events or []})


@app.route("/calendar/configure", methods=["DELETE"])
def calendar_disconnect():
    """Loescht secrets.json wieder von der Platte — Gegenstueck zu
    calendar_configure(), fuer den 'ALLES LOESCHEN'-Button im Frontend."""
    global _calendar_service, _calendar_init_error
    try:
        if os.path.exists(SECRETS_FILE):
            os.remove(SECRETS_FILE)
    except OSError as e:
        return jsonify({"error": f"secrets.json konnte nicht geloescht werden: {e}"}), 500
    _calendar_service = None
    _calendar_init_error = None
    return jsonify({"error": None})


@app.route("/")
def dashboard():
    return send_from_directory(DASHBOARD_DIR, DASHBOARD_FILE)


SOUNDS_DIR = os.path.join(DASHBOARD_DIR, "sounds")


@app.route("/sounds/<path:filename>")
def sounds(filename):
    return send_from_directory(SOUNDS_DIR, filename)


@app.route("/dev/login", methods=["POST"])
def dev_login():
    data = request.get_json(silent=True) or {}
    ok = _check_dev_password(data.get("password"))
    return jsonify({"ok": ok})


# --- Programm-Update ueber GitHub Pages --------------------------------------
# Beim Start (und alle paar Stunden) fragt das HUD /update/check. Gibt es unter _UPDATE_BASE eine neuere
# version.json, kann der Nutzer mit einem Klick aktualisieren: ari-pc.zip wird geladen, per SHA-256 geprueft,
# das neue hub.py auf Syntaxfehler getestet, dann werden nur Programmdateien ersetzt (NIE data/ mit Schluesseln,
# Gehirn usw.), die alten Dateien vorher gesichert und A.R.I startet sich neu.
ARI_VERSION = 79
ARI_VERSION_NAME = "1.6.50"
_UPDATE_BASE = "https://kingshadow1332.github.io/A.R.I/app/pc/"
_UPDATE_NEVER = ("data", "screenshots", "__pycache__", "piper", "A.R.I-Android")
_UPDATE_EXT = {".sh", ".py", ".html", ".js", ".bat", ".md", ".png", ".svg", ".json", ".css", ".txt", ".wav", ".mp3", ".webmanifest", ".ico", ".dll"}
_update_lock = threading.Lock()
_CHANGELOG_URL = "https://kingshadow1332.github.io/A.R.I/app/pc/changelog.json"
_PREV_VERSION_FILE = os.path.join(DATA_DIR, "update_prev_version.json")


def _update_fetch():
    req = urllib.request.Request(_UPDATE_BASE + "version.json?t=" + str(int(time.time())), headers={"User-Agent": "A.R.I", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def _auto_update_enabled():
    return bool(_load_secrets().get("auto_update", True))


def _set_auto_update(v):
    with _secrets_lock:
        s = _load_secrets()
        s["auto_update"] = bool(v)
        _save_secrets(s)


def _fetch_changelog():
    try:
        req = urllib.request.Request(_CHANGELOG_URL + "?t=" + str(int(time.time())), headers={"User-Agent": "A.R.I", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            return data if isinstance(data, list) else []
    except Exception:
        return []


_pending_changelog_cache = {"v": None, "loaded": False}


def _pending_changelog_after_update():
    """Nach einem Neustart durch ein Update einmalig aufgerufen: fasst ALLE Patchnotizen
    seit der vorher laufenden Version zusammen - auch wenn mehrere Versionen auf einmal
    uebersprungen wurden (z.B. weil der automatische Updater eine Weile nicht lief)."""
    if not os.path.exists(_PREV_VERSION_FILE):
        return None
    try:
        with open(_PREV_VERSION_FILE, "r", encoding="utf-8") as f:
            prev = int(json.load(f).get("from", 0))
    except Exception:
        prev = 0
    try:
        os.remove(_PREV_VERSION_FILE)
    except OSError:
        pass
    if ARI_VERSION <= prev:
        return None
    log = _fetch_changelog()
    entries = [e for e in log if isinstance(e, dict) and prev < int(e.get("version", 0) or 0) <= ARI_VERSION]
    entries.sort(key=lambda e: int(e.get("version", 0) or 0))
    return {
        "from": prev, "to": ARI_VERSION, "name": ARI_VERSION_NAME,
        "versions": [str(e.get("name", "")) for e in entries],
        "notes": [str(e.get("notes", "")) for e in entries if e.get("notes")],
    }


@app.route("/update/changelog")
def update_changelog():
    """Liefert die Patch Notes seit dem letzten Update GENAU EINMAL aus (danach leer) -
    sonst wuerde jeder erneute Seitenaufruf/Tab/Geraet waehrend derselben Hub-Laufzeit
    dieselbe Meldung nochmal zeigen, nicht nur direkt nach dem eigentlichen Update."""
    if not _pending_changelog_cache["loaded"]:
        _pending_changelog_cache["v"] = _pending_changelog_after_update()
        _pending_changelog_cache["loaded"] = True
    v = _pending_changelog_cache["v"]
    _pending_changelog_cache["v"] = None
    return jsonify(v or {})


@app.route("/update/changelog/all")
def update_changelog_all():
    """Komplette Versionshistorie zum Durchblaettern (nicht nur das einmalige 'Was ist
    neu seit dem letzten Update', siehe /update/changelog) - fuer die Patch-Notes-Liste
    in den Einstellungen."""
    log = _fetch_changelog()
    entries = [e for e in log if isinstance(e, dict) and e.get("notes")]
    entries.sort(key=lambda e: int(e.get("version", 0) or 0), reverse=True)
    return jsonify(entries)


@app.route("/update/auto", methods=["GET", "POST"])
def update_auto():
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        if "enabled" in data:
            _set_auto_update(bool(data["enabled"]))
    return jsonify({"enabled": _auto_update_enabled()})


def _do_update_apply():
    """Kernlogik fuer ein Update: pruefen, laden, per SHA-256 verifizieren, nur Programmdateien
    ersetzen, Neustart einleiten. Gibt ein Dict zurueck (kein Flask-Response), damit sowohl die
    manuelle Route als auch der automatische Hintergrund-Updater dieselbe Logik nutzen."""
    if not _update_lock.acquire(blocking=False):
        return {"error": "Update läuft bereits."}
    try:
        d = _update_fetch()
        if int(d.get("version", 0)) <= ARI_VERSION:
            return {"error": "Schon auf dem neuesten Stand."}
        zip_name, want = str(d.get("zip", "")), str(d.get("sha256", "")).lower()
        if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", zip_name) or not re.fullmatch(r"[0-9a-f]{64}", want):
            return {"error": "Update-Beschreibung ungültig (Zip-Name/Prüfsumme fehlt)."}
        tmp = tempfile.mkdtemp(prefix="ari_update_")
        zpath = os.path.join(tmp, "update.zip")
        req = urllib.request.Request(_UPDATE_BASE + zip_name, headers={"User-Agent": "A.R.I"})
        with urllib.request.urlopen(req, timeout=120) as r, open(zpath, "wb") as f:
            shutil.copyfileobj(r, f)
        h = hashlib.sha256()
        with open(zpath, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        if h.hexdigest() != want:
            return {"error": "Prüfsumme stimmt nicht – Update verworfen (nichts wurde geändert)."}
        import zipfile
        stage = os.path.join(tmp, "stage")
        files = []
        with zipfile.ZipFile(zpath) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = info.filename.replace("\\", "/")
                parts = name.split("/")
                if name.startswith("/") or ".." in parts or ":" in parts[0] or parts[0] in _UPDATE_NEVER or os.path.splitext(name)[1].lower() not in _UPDATE_EXT:
                    return {"error": f"Update enthält unerlaubte Datei ({name}) – verworfen."}
                files.append(name)
            z.extractall(stage)
        if "hub.py" in files:
            import py_compile
            try:
                py_compile.compile(os.path.join(stage, "hub.py"), doraise=True)
            except py_compile.PyCompileError as e:
                return {"error": f"Neues hub.py fehlerhaft – verworfen ({e.msg[:120]})."}
        backup = os.path.join(DATA_DIR, "update-backup-" + time.strftime("%Y%m%d_%H%M%S"))
        for name in files:
            dst = os.path.join(DASHBOARD_DIR, *name.split("/"))
            if os.path.exists(dst):
                os.makedirs(os.path.dirname(os.path.join(backup, *name.split("/"))), exist_ok=True)
                shutil.copy2(dst, os.path.join(backup, *name.split("/")))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            srcf = os.path.join(stage, *name.split("/"))
            try:
                shutil.copy2(srcf, dst)
            except OSError:
                # Datei ist im laufenden Hub gesperrt (z.B. geladene DLL, WinError 32): umbenennen geht trotzdem,
                # dann liegt die neue Datei am Originalpfad. Klappt auch das nicht, ist es nur bei DLLs unkritisch.
                try:
                    old = dst + ".old"
                    try: os.remove(old)
                    except OSError: pass
                    os.replace(dst, old)
                    shutil.copy2(srcf, dst)
                except OSError:
                    if not name.lower().endswith(".dll"):
                        raise
                    print(f"[update] {name} ist in Benutzung - uebersprungen")
        print(f"[update] {len(files)} Dateien aktualisiert auf {d.get('name')} (Sicherung: {backup})")
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(_PREV_VERSION_FILE, "w", encoding="utf-8") as f:
                json.dump({"from": ARI_VERSION}, f)
        except Exception:
            pass
        _update_restart(str(d.get("name", "")))
        return {"ok": True, "files": len(files), "name": str(d.get("name", ""))}
    except Exception as e:
        return {"error": f"Update fehlgeschlagen: {e}"}
    finally:
        try:
            _update_lock.release()
        except RuntimeError:
            pass


_auto_update_signal = {"pending": False, "name": "", "notes": ""}


@app.route("/update/pending")
def update_pending():
    """Vom HUD alle paar Sekunden abgefragt: zeigt an, dass der Hintergrund-Updater eine neue
    Version gefunden hat und dem (gerade offenen) HUD die Installation ueberlaesst - damit laeuft
    dieselbe Lade-/Fortschrittsanzeige wie beim manuellen Update, statt eines fuer den Nutzer
    unsichtbaren Hintergrund-Updates."""
    return jsonify(dict(_auto_update_signal))


def _auto_update_loop():
    """Prueft alle 5 Minuten selbststaendig auf Updates und wendet sie ohne Nachfrage an, solange
    die Einstellung 'Automatische Updates' an ist (Standard: an). Ist gerade ein HUD-Fenster offen
    (erkannt am letzten /status-Herzschlag), bekommt das HUD ueber /update/pending kurz Gelegenheit,
    das Update SELBST ueber /update/apply anzustossen - dann sieht man denselben Lade-/Fortschritts-
    Dialog wie bei einem manuell angestossenen Update. Meldet sich in der Zeit kein HUD (oder ist
    keins offen), installiert dieser Hintergrund-Thread ganz normal still weiter (mit Windows-
    Benachrichtigung) - das Update passiert so oder so, nur eben sichtbar, wenn wer zuschaut."""
    first = True
    while True:
        time.sleep(60 if first else 300)   # erste Pruefung schon kurz nach dem Start, danach alle 5 Minuten
        first = False
        try:
            if not _auto_update_enabled():
                continue
            d = _update_fetch()
            if int(d.get("version", 0)) <= ARI_VERSION:
                continue
            hud_open = (time.time() - _hub_last_seen) < 10
            if hud_open:
                _auto_update_signal.update(pending=True, name=str(d.get("name", "")), notes=str(d.get("notes", "")))
                print("[auto-update] Neue Version gefunden, HUD ist offen - HUD bekommt Gelegenheit, es selbst anzustossen:", d.get("name"))
                # Keine feste Wartezeit: wiederholt kurz nachschauen, ob das HUD die
                # Installation bereits selbst gestartet hat (_update_lock dann belegt) -
                # sobald das der Fall ist, sofort weitermachen, statt stur abzuwarten.
                deadline = time.time() + 20
                started = False
                while time.time() < deadline:
                    time.sleep(0.5)
                    if _update_lock.locked():
                        started = True
                        break
                _auto_update_signal.update(pending=False)
                if started:
                    continue   # das HUD uebernimmt die Installation selbst (eigener Ladedialog)
            print("[auto-update] Neue Version gefunden, wird automatisch installiert:", d.get("name"))
            _show_toast("A.R.I Update gefunden", f"Version {d.get('name')} wird automatisch installiert …")
            res = _do_update_apply()
            if res.get("error") and "bereits" not in res["error"]:
                print("[auto-update] Fehler:", res["error"])
        except Exception as e:
            print("[auto-update] Fehler:", e)


@app.route("/update/check")
def update_check():
    out = {"current": ARI_VERSION, "name": ARI_VERSION_NAME, "available": False}
    try:
        d = _update_fetch()
        out.update(available=int(d.get("version", 0)) > ARI_VERSION, latest=str(d.get("name", "")), notes=str(d.get("notes", ""))[:2000], latest_code=int(d.get("version", 0)))
    except Exception as e:
        out["error"] = f"Update-Suche nicht möglich: {e}"
    return jsonify(out)


def _show_toast(title, message):
    """Zeigt eine native Windows-Benachrichtigung (unten rechts) - laeuft komplett
    unabhaengig vom Hub-Prozess (eigener PowerShell-Prozess), verschwindet also nicht,
    wenn der Hub kurz danach fuer einen Neustart beendet wird. Fehler hier duerfen nie
    den Update-/Neustart-Ablauf stoppen, deshalb alles best-effort mit try/except."""
    if not IS_WIN:
        return
    try:
        t = title.replace("'", "''")
        m = message.replace("'", "''")
        ps = (
            "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] > $null;"
            "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom, ContentType=WindowsRuntime] > $null;"
            "$x = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
            "$t = $x.GetElementsByTagName('text');"
            "$t.Item(0).AppendChild($x.CreateTextNode('" + t + "')) > $null;"
            "$t.Item(1).AppendChild($x.CreateTextNode('" + m + "')) > $null;"
            "$n = [Windows.UI.Notifications.ToastNotification]::new($x);"
            "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('A.R.I').Show($n)"
        )
        subprocess.Popen(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
            creationflags=subprocess.CREATE_NO_WINDOW if IS_WIN else 0,
        )
    except Exception as e:
        print(f"[toast] fehlgeschlagen: {e}")


def _update_restart(version_name="", quiet=False):
    if not quiet:
        _show_toast("A.R.I wird aktualisiert", f"Version {version_name} installiert - startet gleich neu.".strip())
    if not IS_WIN:
        _lx.schedule_restart(sys.executable, os.path.join(DASHBOARD_DIR, "hub.py"), DASHBOARD_DIR)
        threading.Timer(0.8, _hub_exit, args=("Update wird installiert - A.R.I startet neu",)).start()
        return
    exe = sys.executable
    named = os.path.join(sys.base_prefix, "Ari Assistent.exe")
    if os.path.exists(named):
        exe = named
    hub = os.path.join(DASHBOARD_DIR, "hub.py")
    # WICHTIG: der neue Prozess wird SOFORT gestartet, nicht erst nach einer Wartezeit -
    # der alte Prozess beendet sich unten schon nach < 1s per os._exit(), das reisst
    # JEDEN eigenen Thread (auch einen mit time.sleep() davor) sofort mit in den Tod,
    # bevor er je zum Popen-Aufruf kommt (genau das war der Bug: A.R.I kam nach einem
    # automatischen Update nie mehr von selbst hoch, weil der Neustart-Versuch nie
    # ausgefuehrt wurde). DETACHED_PROCESS|CREATE_NEW_PROCESS_GROUP loest den neuen
    # Prozess vollstaendig vom alten - der laeuft also weiter, auch wenn der alte gleich
    # per os._exit() verschwindet. Der neue Prozess braucht zum Hochfahren (Python-Start +
    # Imports) laenger als der alte zum Beenden braucht, dadurch ist Port 5000 in aller
    # Regel schon frei, wenn der neue Prozess bei _ensure_port_free() ankommt.
    try:
        subprocess.Popen(
            [exe, hub],
            cwd=DASHBOARD_DIR,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
        )
        print("[update] Neustart eingeleitet.")
    except Exception as e:
        print(f"[update] Neustart fehlgeschlagen: {e}")
        _show_toast("A.R.I: Neustart fehlgeschlagen", f"Bitte A.R.I von Hand ueber die Verknuepfung starten ({e}).")
    threading.Timer(0.8, _hub_exit, args=("Update wird installiert - A.R.I startet neu",)).start()


@app.route("/update/apply", methods=["POST"])
def update_apply():
    if not request.is_json:   # nur mit JSON-Body (loest bei fremden Webseiten einen CORS-Preflight aus und wird blockiert)
        return jsonify({"error": "ungültig"}), 400
    return jsonify(_do_update_apply())


# --- Handy-Anbindung ------------------------------------------------------
# Der PC-Hub ist das Gehirn und laeuft dauerhaft; das Handy ist eine Fernbedienung
# (Seite /phone, als App zum Homescreen hinzufuegbar). Es nutzt dieselben Daten
# (Gehirn, Kalender, Einstellungen), also ist immer alles auf demselben Stand.
# Sicherheit: Der Hub lauscht im Netz, lehnt von aussen aber ALLES ab, ausser
# der Handy-Seite und /phone/api/* mit gueltigem Geraete-Token. Ein Token gibt es
# nur ueber einen kurzlebigen Koppelcode, den man am PC (im HUD) erzeugt.
import secrets as _pysecrets

_pair = {"code": None, "exp": 0.0, "fails": 0}
_pair_ip_fails = {}
_phone_cache = {"t": 0.0, "cfg": {}}


_PROXY_HEADERS = ("Cf-Connecting-Ip", "Cf-Ray", "X-Forwarded-For", "X-Forwarded-Host", "Forwarded", "X-Real-Ip", "Cf-Visitor")


def _is_local_request():
    """Nur echte Anfragen vom PC selbst. Der Cloudflare-Tunnel verbindet sich von
    127.0.0.1 aus - deshalb zaehlt eine Anfrage mit Proxy-Headern oder fremdem
    Host-Namen NICHT als lokal (sonst waere der ganze Hub aus dem Internet offen)."""
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return False
    if any(h in request.headers for h in _PROXY_HEADERS):
        return False
    host = (request.host or "").split(":")[0].strip("[]").lower()
    return host in ("localhost", "127.0.0.1", "::1")


def _client_ip():
    return request.headers.get("Cf-Connecting-Ip") or request.remote_addr


def _phone_cfg():
    now = time.time()
    if now - _phone_cache["t"] > 3:
        _phone_cache["cfg"] = _load_secrets().get("phone") or {}
        _phone_cache["t"] = now
    return _phone_cache["cfg"]


def _phone_save(cfg):
    _update_secrets("phone", lambda _old: cfg)
    _phone_cache["cfg"] = cfg
    _phone_cache["t"] = time.time()


def _phone_keep_alive():
    cfg = _phone_cfg()
    # Nur wenn ausdruecklich eingeschaltet: sonst schliesst sich A.R.I 20 s nach dem Schliessen des HUD-Fensters (das Handy laeuft dann eigenstaendig).
    return bool(cfg.get("enabled") and cfg.get("always_on", False))


def _phone_device_for(token):
    if not token:
        return None
    h = hashlib.sha256(token.encode("utf-8")).hexdigest()
    for d in _phone_cfg().get("devices", []):
        if hmac.compare_digest(d.get("hash", ""), h):
            return d
    return None


_SESSION_COOKIE = "ari_sess"
# "/" ist absichtlich mit dabei: die echte HUD-Seite selbst enthaelt keine Geheimnisse (nur ihre
# API-Aufrufe brauchen Anmeldung) - so kann ein Tablet exakt dieselbe Oberflaeche wie am PC laden,
# statt einer Nachbildung. Angemeldet wird sie ueber das Sitzungs-Cookie aus /session/login.
_PHONE_OPEN_PATHS = ("/phone", "/phone/manifest.json", "/phone/icon.svg", "/phone/pair", "/", "/session/login")


@app.before_request
def _phone_gate():
    if request.method == "OPTIONS" and (request.path.startswith("/phone/") or request.path in _PHONE_CORS_EXTRA_PATHS) and _phone_cfg().get("enabled"):
        return ("", 204)  # CORS-Preflight der Handy-App; die Header setzt _phone_cors
    if _is_local_request():
        return None
    p = request.path
    if not _phone_cfg().get("enabled"):
        return jsonify({"error": "Handy-Zugriff ist ausgeschaltet"}), 403
    if p == "/" and not _phone_cfg().get("pcview", True):
        return jsonify({"error": "PC-Bildschirm-Ansicht ist ausgeschaltet"}), 403
    if p in _PHONE_OPEN_PATHS or p.startswith("/phone/icons/"):
        return None
    dev = _phone_device_for(request.headers.get("X-Ari-Token", "") or request.cookies.get(_SESSION_COOKIE, ""))
    if dev:
        if time.time() - dev.get("seen", 0) > 30:
            dev["seen"] = int(time.time())
            try:
                _phone_save(_phone_cfg())
            except Exception:
                pass
        return None
    if p.startswith("/phone/api/"):
        return jsonify({"error": "nicht gekoppelt"}), 401
    return jsonify({"error": "verboten"}), 403


@app.route("/session/login", methods=["POST"])
def session_login():
    """Nimmt den Geraete-Token entgegen (kommt vom #t=-Linkanhang, der nie beim Server ankommt -
    das erledigt ein kleines Skript im HUD selbst) und setzt dafuer ein Sitzungs-Cookie. Danach
    sind auch die normalen HUD-Seiten (die selbst keine eigene Anmeldung kennen) sicher aus dem
    WLAN nutzbar - derselbe Vertrauensstatus wie der bestehende Geraete-Token fuer /phone/api/*."""
    data = request.get_json(silent=True) or {}
    token = str(data.get("token") or "")
    dev = _phone_device_for(token)
    if not dev:
        return jsonify({"error": "ungültiger oder abgelaufener Token"}), 401
    resp = jsonify({"error": None})
    resp.set_cookie(_SESSION_COOKIE, token, max_age=60 * 60 * 24 * 90, httponly=True, samesite="Lax")
    return resp


@app.route("/session/logout", methods=["POST"])
def session_logout():
    resp = jsonify({"error": None})
    resp.delete_cookie(_SESSION_COOKIE)
    return resp

_DEFAULT_APP_URL = "https://kingshadow1332.github.io/A.R.I/app/"


def _app_url():
    """Adresse der Handy-App: Standard ist die GitHub-Pages-Adresse; wer das Feld im HUD leert, schaltet sie ab."""
    t = _phone_cfg().get("tunnel") or {}
    return (t["app_url"] if "app_url" in t else _DEFAULT_APP_URL).strip()



def _app_origin():
    """Adresse der eigenstaendigen Handy-App (z.B. https://name.github.io) - nur von dort
    sind Browser-Anfragen (CORS) an /phone/pair und /phone/api/* erlaubt."""
    u = _app_url()
    m = re.match(r"^(https://[A-Za-z0-9.-]+(?::\d+)?)(/|$)", u)
    return m.group(1) if m else None


_PHONE_CORS_EXTRA_PATHS = ("/status", "/media", "/speak")   # /speak: das Handy laesst sich die PC-Stimme (Katja ...) holen


@app.after_request
def _phone_cors(resp):
    org = request.headers.get("Origin")
    if org and (request.path.startswith("/phone/") or request.path in _PHONE_CORS_EXTRA_PATHS) and org == _app_origin():
        resp.headers["Access-Control-Allow-Origin"] = org
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Ari-Token"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Max-Age"] = "600"
        resp.headers["Vary"] = "Origin"
    return resp


@app.route("/phone")
def phone_page():
    return send_from_directory(DASHBOARD_DIR, "phone.html")


@app.route("/qrcode.js")
def qrcode_js():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return send_from_directory(DASHBOARD_DIR, "qrcode.min.js", mimetype="text/javascript")


@app.route("/phone/icons/<path:filename>")
def phone_icons(filename):
    if not re.fullmatch(r"[A-Za-z0-9._-]+\.png", filename):
        return jsonify({"error": "nicht gefunden"}), 404
    return send_from_directory(os.path.join(DASHBOARD_DIR, "app"), filename)


@app.route("/phone/manifest.json")
def phone_manifest():
    return jsonify({
        "name": "A.R.I", "short_name": "A.R.I", "start_url": "/phone", "display": "standalone",
        "background_color": "#050b14", "theme_color": "#050b14",
        "id": "/phone", "scope": "/phone", "lang": "de", "orientation": "portrait",
        "icons": [{"src": "/phone/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
                  {"src": "/phone/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
                  {"src": "/phone/icons/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}],
    })


@app.route("/phone/icon.svg")
def phone_icon():
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="22" fill="#050b14"/>'
           '<circle cx="50" cy="50" r="30" fill="none" stroke="#3fd9ff" stroke-width="5"/>'
           '<circle cx="50" cy="50" r="12" fill="#3fd9ff"/></svg>')
    return Response(svg, mimetype="image/svg+xml")


# --- Handy-Benachrichtigungen (WhatsApp, Discord, ...) am PC anzeigen ------------------------
# Die App liest per NotificationListenerService die am Handy ankommenden Benachrichtigungen mit
# (Nutzer muss das einmal manuell in Android erlauben) und schickt sie ueber den ganz normalen
# Geraete-Token an /phone/api/notify - dasselbe Vertrauensmodell wie fuer alle anderen /phone/api/*
# Aufrufe. Nur ein kurzer Ringpuffer im Speicher, keine dauerhafte Speicherung.
_PHONE_NOTIFS = []
_PHONE_NOTIFS_MAX = 50
# Kurzer Puffer der zuletzt verschwundenen Benachrichtigungen (auf dem PC weggeklickt ODER am
# Handy selbst verschwunden/gelesen) - damit beide Seiten sich gegenseitig synchron halten,
# ohne dauerhaft etwas zu speichern.
_PHONE_GONE = []
_PHONE_GONE_MAX = 100
# Gerade geloeschte Meldungen (10 Min): schickt das Handy beim Abgleich dieselbe Meldung nochmal, wird sie nicht wieder angezeigt.
_PHONE_TOMB = []


def _phone_notif_remove(id_=None, key=None):
    """Entfernt eine Benachrichtigung aus dem aktiven Puffer (per id oder Android-Key) und
    merkt sich das kurz, damit PC und Handy sich gegenseitig abgleichen koennen."""
    kept = []
    now = int(time.time())
    for n in _PHONE_NOTIFS:
        if (id_ and n["id"] == id_) or (key and n.get("key") and n["key"] == key):
            _PHONE_GONE.append({"id": n["id"], "key": n.get("key", ""), "ts": now})
            _PHONE_TOMB.append({"key": n.get("key", ""), "app": n["app"], "title": n["title"], "text": n["text"], "ts": now})
        else:
            kept.append(n)
    _PHONE_NOTIFS[:] = kept
    del _PHONE_GONE[:-_PHONE_GONE_MAX]


def _phone_notif_blocked_apps():
    return set(_phone_cfg().get("notif_blocked_apps") or [])


@app.route("/phone/api/notify", methods=["POST"])
def phone_api_notify():
    d = request.get_json(silent=True) or {}
    app_name = str(d.get("app") or "")[:60]
    title = str(d.get("title") or "")[:200]
    text = str(d.get("text") or "")[:1000]
    key = str(d.get("key") or "")[:200]
    can_reply = bool(d.get("can_reply"))
    if not app_name and not title and not text:
        return jsonify({"error": "leer"}), 400
    if app_name in _phone_notif_blocked_apps():
        return jsonify({"error": None})
    now = int(time.time())
    # Eigene Antworten: Nach dem Senden stellt die Messenger-App die Benachrichtigung oft neu ein (mit unserem Text bzw. "Du: ...") - das ist keine neue Nachricht.
    low_text = text.strip().lower()
    if re.match(r"^(du|you|ich|me)\s*:", low_text):
        return jsonify({"error": None})
    for rep in _PHONE_REPLIES:
        if now - rep["ts"] < 300 and rep["status"] in ("pending", "sent") and rep["text"].strip().lower() and rep["text"].strip().lower() in low_text and (not rep["to"] or rep["to"].lower() in (title + " " + app_name).lower() or title.lower() in rep["to"].lower()):
            return jsonify({"error": None})
    _PHONE_TOMB[:] = [t for t in _PHONE_TOMB if now - t["ts"] < 600][-200:]
    if any(t["app"] == app_name and t["title"] == title and t["text"] == text and (not key or not t["key"] or t["key"] == key) for t in _PHONE_TOMB):
        return jsonify({"error": None})
    # Abgleich vom Handy (aktive Benachrichtigungen werden nach einer Pause erneut geschickt): dieselbe Android-Kennung
    # mit gleichem Inhalt ist schon im Puffer -> nicht doppelt anzeigen.
    if key and any(n.get("key") == key and n["title"] == title and n["text"] == text for n in _PHONE_NOTIFS):
        for n in _PHONE_NOTIFS:
            if n.get("key") == key and can_reply:
                n["can_reply"] = True
        return jsonify({"error": None})
    # Zusaetzliche Absicherung gegen Spam (z.B. Musik-Apps, die dieselbe Meldung mehrfach posten):
    # dieselbe App+Titel+Text innerhalb 60s nicht doppelt in den Puffer aufnehmen.
    for n in reversed(_PHONE_NOTIFS[-10:]):
        if n["app"] == app_name and n["title"] == title and n["text"] == text and now - n["ts"] < 60:
            return jsonify({"error": None})
    _PHONE_NOTIFS.append({"id": _pysecrets.token_hex(6), "app": app_name, "title": title, "text": text, "ts": now, "key": key, "can_reply": can_reply})
    del _PHONE_NOTIFS[:-_PHONE_NOTIFS_MAX]
    return jsonify({"error": None})


@app.route("/phone/api/notify-dismiss", methods=["POST"])
def phone_api_notify_dismiss():
    """PC/HUD hat eine vom Handy weitergeleitete Benachrichtigung weggeklickt - auch am Handy
    selbst als erledigt merken (das Handy holt sich das per /phone/api/notify-dismissed ab und
    raeumt die echte Systembenachrichtigung dort weg)."""
    id_ = str((request.get_json(silent=True) or {}).get("id") or "")
    if id_:
        _phone_notif_remove(id_=id_)
    return jsonify({"error": None})


@app.route("/phone/api/notify-removed", methods=["POST"])
def phone_api_notify_removed():
    """Die Benachrichtigung ist auf dem Handy selbst verschwunden (gelesen/weggewischt) -
    auch aus der PC-Ansicht entfernen."""
    key = str((request.get_json(silent=True) or {}).get("key") or "")
    if key:
        _phone_notif_remove(key=key)
    return jsonify({"error": None})


def _phone_block_app(app_name):
    """Gemeinsame Logik fuers Spam-Markieren - von der Route UND vom AI-Tool genutzt."""
    cfg = dict(_phone_cfg())
    blocked = list(dict.fromkeys((cfg.get("notif_blocked_apps") or []) + [app_name]))
    cfg["notif_blocked_apps"] = blocked[-100:]
    _phone_save(cfg)
    for n in [n for n in _PHONE_NOTIFS if n["app"] == app_name]:
        _phone_notif_remove(id_=n["id"])


_STATUS_PAGES = {
    # Schluessel (klein) -> (Art, Basis-URL, Anzeigename). "sp" = Atlassian Statuspage (/api/v2/summary.json),
    # "cs" = cState (/index.json, z.B. Roberts Space Industries).
    "star citizen": ("cs", "https://status.robertsspaceindustries.com", "Star Citizen"),
    "squadron 42": ("cs", "https://status.robertsspaceindustries.com", "Star Citizen / Squadron 42"),
    "rsi": ("cs", "https://status.robertsspaceindustries.com", "Star Citizen"),
    "discord": ("sp", "https://discordstatus.com", "Discord"),
    "github": ("sp", "https://www.githubstatus.com", "GitHub"),
    "epic games": ("sp", "https://status.epicgames.com", "Epic Games"),
    "epic": ("sp", "https://status.epicgames.com", "Epic Games"),
    "fortnite": ("sp", "https://status.epicgames.com", "Epic Games / Fortnite"),
    "cloudflare": ("sp", "https://www.cloudflarestatus.com", "Cloudflare"),
    "reddit": ("sp", "https://www.redditstatus.com", "Reddit"),
    "claude": ("sp", "https://status.claude.com", "Claude"),
    "anthropic": ("sp", "https://status.claude.com", "Claude"),
    "vercel": ("sp", "https://www.vercel-status.com", "Vercel"),
    "npm": ("sp", "https://status.npmjs.org", "npm"),
}
_STATUS_DE = {
    "operational": "laeuft", "degraded_performance": "eingeschraenkt", "partial_outage": "teilweise gestoert",
    "major_outage": "AUSFALL", "under_maintenance": "Wartung", "ok": "laeuft", "disrupted": "gestoert",
    "down": "AUSFALL", "notice": "Hinweis",
}


def _status_http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8", "replace"))


def _status_parse(kind, data, label, component):
    """Wandelt die rohen Status-Daten (Statuspage 'sp' / cState 'cs') in einen kurzen deutschen Text."""
    comp = (component or "").strip().lower()
    updated = ""
    if kind == "cs":
        overall = _STATUS_DE.get(str(data.get("summaryStatus", "")).lower(), str(data.get("summaryStatus", "?")))
        systems = [(sy.get("name", "?"), _STATUS_DE.get(str(sy.get("status", "")).lower(), str(sy.get("status", "?")))) for sy in data.get("systems", [])]
        incidents = [i.get("title", "") for i in data.get("pinnedIssues", [])]
        for sy in data.get("systems", []):
            for iss in sy.get("unresolvedIssues", []) or []:
                incidents.append(f"{sy.get('name', '')}: {iss.get('title', '')}")
    else:
        st = data.get("status") or {}
        overall = st.get("description") or st.get("indicator") or "?"
        comps = [c for c in data.get("components", []) if not c.get("group")]
        systems = [(c.get("name", "?"), _STATUS_DE.get(c.get("status", ""), c.get("status", "?"))) for c in comps]
        incidents = [f"{i.get('name', '')} ({i.get('status', '')})" for i in data.get("incidents", [])]
        updated = ((data.get("page") or {}).get("updated_at") or "")[:16].replace("T", " ")
    head = f"{label}: {overall}."
    if comp:
        hit = [x for x in systems if comp in x[0].lower()]
        if not hit:
            return head + f" Kein Teilsystem '{component}' gefunden. Vorhanden: " + ", ".join(x[0] for x in systems[:15]) + "."
        return head + " " + "; ".join(f"{n}: {st_}" for n, st_ in hit[:12]) + "."
    bad = [x for x in systems if x[1] != "laeuft"]
    if len(systems) > 12:
        out = head + (" Betroffen: " + "; ".join(f"{n}: {st_}" for n, st_ in bad[:12]) + "." if bad else "")
        out += f" Teilsysteme gesamt: {len(systems)}, davon gestoert: {len(bad)}." + ("" if bad else " Alles laeuft.")
    elif systems:
        out = head + " " + "; ".join(f"{n}: {st_}" for n, st_ in systems) + "."
    else:
        out = head
    if incidents:
        out += " Aktuelle Meldungen: " + "; ".join(incidents[:4]) + "."
    if updated:
        out += f" (Stand {updated})"
        try:
            if (datetime.datetime.now() - datetime.datetime.strptime(updated[:10], "%Y-%m-%d")).days > 30:
                out += " ACHTUNG: Diese Status-Seite wurde seit ueber einem Monat nicht aktualisiert - Angabe evtl. veraltet."
        except Exception:
            pass
    return out


def _status_special(key, label):
    """Spiele mit eigener (nicht-Statuspage) Schnittstelle."""
    if key == "eve":
        d = _status_http_json("https://esi.evetech.net/latest/status/")
        return f"{label}: Server laeuft, {d.get('players', '?')} Spieler online (Version {d.get('server_version', '?')})."
    if key == "gw2":
        d = _status_http_json("https://api.guildwars2.com/v2/build")
        return f"{label}: Server erreichbar (aktueller Build {d.get('id', '?')})."
    if key == "warframe":
        d = _status_http_json("https://api.warframestat.us/pc/")
        return f"{label}: Server erreichbar (PC-Daten von {str(d.get('timestamp', ''))[:16].replace('T', ' ')} UTC aktuell)."
    return None


_STATUS_SPECIAL = {"eve online": "eve", "eve": "eve", "guild wars 2": "gw2", "gw2": "gw2", "warframe": "warframe"}


def _bing_search(query, max_results=6):
    """Zweite Suchquelle (DuckDuckGo blockt bei vielen Anfragen schnell): Bing-HTML, Ergebnis-Links
    stehen dort als Weiterleitung (u=a1<base64>) und werden hier zurueck in die echte URL gewandelt."""
    req = urllib.request.Request(
        "https://www.bing.com/search?setlang=en&q=" + urllib.parse.quote(query),
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
                 "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        page = resp.read().decode("utf-8", "replace")
    out = []
    for blk in re.findall(r'<li class="b_algo".*?</li>', page, re.S):
        m = re.search(r'<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', blk, re.S)
        if not m:
            continue
        url = _html_lib.unescape(m.group(1))
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        if "u" in qs and qs["u"][0].startswith("a1"):
            try:
                import base64
                b = qs["u"][0][2:]
                url = base64.urlsafe_b64decode(b + "=" * (-len(b) % 4)).decode("utf-8", "replace")
            except Exception:
                pass
        sn = re.search(r"<p[^>]*>(.*?)</p>", blk, re.S)
        out.append({"title": _html_lib.unescape(re.sub(r"<[^>]+>", "", m.group(2))).strip(), "url": url,
                    "snippet": _html_lib.unescape(re.sub(r"<[^>]+>", "", sn.group(1))).strip() if sn else ""})
        if len(out) >= max_results:
            break
    return out


# Spiel -> Plattform/Publisher, dessen Server das Spiel betreibt (slug bei StatusGator, Anzeigename)
_GAME_PLATFORMS = [
    (r"valorant|league of legends|\blol\b|tft|teamfight|wild rift|legends of runeterra", "riot-games", "Riot Games"),
    (r"world of warcraft|\bwow\b|overwatch|diablo|hearthstone|starcraft|warcraft|battle\.?net|heroes of the storm", "blizzard", "Blizzard / Battle.net"),
    (r"counter.?strike|\bcs2\b|\bcsgo\b|dota|team fortress|\btf2\b|half.?life|left 4 dead|steam", "steam", "Steam / Valve"),
    (r"rainbow six|\br6\b|the division|assassin|far cry|watch dogs|for honor|ubisoft|the crew|anno ", "ubisoft", "Ubisoft"),
    (r"gta|grand theft|red dead|rockstar", "rockstar-games", "Rockstar Games"),
    (r"fortnite|rocket league|fall guys|epic", "epic-games", "Epic Games"),
    (r"xbox|halo|forza|sea of thieves|gears of war|microsoft store", "xbox-live", "Xbox Live"),
    (r"twitch", "twitch", "Twitch"),
    (r"destiny|bungie", "destiny", "Destiny / Bungie"),
]


def _status_statusgator(service):
    """StatusGator fuehrt hunderte Spiele/Dienste (offizielle Status-Feeds + Nutzermeldungen) - der aktuelle
    Zustand steht im Seitentext ('X is currently operational. There have been N user-submitted reports ...')."""
    base = re.sub(r"[^a-z0-9 ]", "", service.lower()).strip()
    base = re.sub(r"^(the|der|die|das) ", "", base)
    cands = []
    for sl in (base.replace(" ", "-"), base.replace(" ", ""), base.replace(" ", "-") + "-game"):
        if sl and (sl, service) not in cands:
            cands.append((sl, service))
    for rx, sl, plat in _GAME_PLATFORMS:
        if re.search(rx, service.lower()):
            cands.append((sl, plat if plat.lower() in service.lower() or service.lower() in plat.lower() else f"{service} (laeuft ueber {plat})"))
    for sl, shown in cands:
        try:
            req = urllib.request.Request("https://statusgator.com/services/" + sl,
                                         headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124", "Accept-Language": "en-US,en;q=0.9"})
            with urllib.request.urlopen(req, timeout=12) as resp:
                page = resp.read().decode("utf-8", "replace")
        except Exception:
            continue
        txt = re.sub(r"\s+", " ", re.sub(r"<script.*?</script>|<style.*?</style>|<[^>]+>", " ", page, flags=re.S))
        m = re.search(r"([A-Z0-9][\w .:'&+-]{1,60}?) is currently ([a-z ]{3,40}?)\.( There (?:have|has) been [^.]{5,120}\.)?", txt)
        if not m:
            m2 = re.search(r"Is [^?]{1,60}\? [A-Z0-9][^.]{1,60}? is (up|down)\b", txt)
            if m2:
                up = m2.group(1) == "up"
                u24 = re.search(r"There (?:have|has) been [^.]{5,120}\.", txt)
                return (f"{shown}: " + ("laeuft (kein Ausfall gemeldet)." if up else "GESTOERT/AUSFALL.")
                        + (" " + u24.group(0) if u24 else "")
                        + " (Quelle: StatusGator - Sammlung offizieller Status-Feeds und Nutzermeldungen, nicht direkt vom Hersteller.)")
        if m:
            name, state = shown, m.group(2).strip()
            de = {"operational": "laeuft (kein Ausfall gemeldet)", "down": "GESTOERT/AUSFALL", "experiencing issues": "hat Probleme", "having issues": "hat Probleme"}
            return f"{name}: {de.get(state, state)}." + (m.group(3) or "") + " (Quelle: StatusGator - Sammlung offizieller Status-Feeds und Nutzermeldungen, nicht direkt vom Hersteller.)"
    return None


def _status_discover(service, component):
    """Unbekannter Dienst: per Websuche die Status-Seite finden und, wenn sie ein Standardformat hat,
    direkt auslesen - sonst die Such-Schnipsel zurueckgeben (dann klar als nicht offiziell markiert)."""
    sgr = _status_statusgator(service)
    if sgr:
        return sgr
    results = []
    for q in (f"{service} server status", f"{service} status page"):
        for fn in (_duckduckgo_search, _bing_search):
            try:
                found = fn(q)
            except Exception:
                found = []
            results += [r for r in found if r["url"] not in {x["url"] for x in results}]
            if len(results) >= 6:
                break
        if len(results) >= 6:
            break
    # Treffer von Status-Seiten/Statusportalen zuerst
    results.sort(key=lambda r: 0 if re.search(r"status|downdetector|isitdown|outage", r["url"], re.I) else 1)
    seen = set()
    for r in results:
        pu = urllib.parse.urlparse(r["url"])
        if not pu.netloc or pu.netloc in seen:
            continue
        seen.add(pu.netloc)
        base = f"{pu.scheme}://{pu.netloc}"
        for kind, path in (("sp", "/api/v2/summary.json"), ("cs", "/index.json")):
            try:
                data = _status_http_json(base + path)
                if (kind == "sp" and "status" in data and "components" in data) or (kind == "cs" and "systems" in data):
                    return _status_parse(kind, data, service, component) + f" (Quelle: {pu.netloc})"
            except Exception:
                continue
    if results:
        lines = [f"Keine auslesbare Status-Seite fuer '{service}' gefunden (Einzelspieler-Spiele haben keine Server). Websuche-Treffer (nicht offiziell bestaetigt, bitte als solche weitergeben):"]
        for r in results[:4]:
            lines.append(f"- {r['title']}: {r['snippet'][:200]} ({r['url']})")
        return chr(10).join(lines)
    return f"Zu '{service}' konnte ich keinen Server-Status finden."


def _tool_server_status(service, component=""):
    """Server-/Dienststatus: 1) bekannte offizielle Status-Seiten, 2) Spiele mit eigener API,
    3) unbekannte Spiele/Dienste per Websuche + automatischem Auslesen der gefundenen Status-Seite."""
    svc = re.sub(r"\s+", " ", (service or "").strip().lower())
    if not svc:
        return "Kein Dienst angegeben."
    try:
        for k, key in _STATUS_SPECIAL.items():
            if svc == k or (len(k) > 3 and k in svc):
                return _status_special(key, "EVE Online" if key == "eve" else ("Guild Wars 2" if key == "gw2" else "Warframe"))
        entry = _STATUS_PAGES.get(svc)
        if not entry:
            for k, v in _STATUS_PAGES.items():
                if k in svc or svc in k:
                    entry = v
                    break
        if entry:
            kind, base, label = entry
            try:
                data = _status_http_json(base + ("/index.json" if kind == "cs" else "/api/v2/summary.json"))
            except Exception:
                return f"Die Status-Seite von {label} ist gerade nicht erreichbar."
            return _status_parse(kind, data, label, component)
        return _status_discover(service, component)
    except Exception as e:
        return f"Server-Status konnte nicht abgefragt werden: {e}"


@app.route("/server-status")
def server_status_route():
    """Fuer den DEV-Test im HUD: gleiche Abfrage wie das KI-Werkzeug server_status."""
    return jsonify({"text": _tool_server_status(request.args.get("service", ""), request.args.get("component", ""))})


def _tool_dismiss_notification(query, spam=False):
    """Sucht zuerst bei den vom Handy weitergeleiteten Benachrichtigungen, dann (falls dort
    nichts passt) bei den ungelesenen E-Mails - damit gilt derselbe Sprachbefehl fuer beides,
    ohne dass der Nutzer die Quelle extra ansagen muss."""
    q = (query or "").strip().lower()
    if not q:
        return "Bitte sag, welche Benachrichtigung gemeint ist (App-Name, Absender oder Stichwort)."
    matches = [n for n in _PHONE_NOTIFS if q in n["app"].lower() or q in n["title"].lower() or q in n["text"].lower()]
    if matches:
        matches.sort(key=lambda n: n["ts"], reverse=True)
        top = matches[0]
        if spam:
            _phone_block_app(top["app"])
            return f"'{top['app']}' wird kuenftig blockiert - {len(matches)} Benachrichtigung(en) entfernt."
        _phone_notif_remove(id_=top["id"])
        return f"Benachrichtigung von '{top['app']}' entfernt."
    emails, error = get_recent_emails(unread_only=True, max_results=20)
    if emails:
        hits = [e for e in emails if q in (e.get("from_name") or e.get("from") or "").lower() or q in (e.get("subject") or "").lower()]
        if hits:
            top = hits[0]
            frm = top.get("from_name") or top.get("from") or ""
            if spam:
                _add_spam_sender(frm)
            if spam:
                return f"'{frm}' wird kuenftig nicht mehr gemeldet (im Postfach aendere ich nichts)."
            return f"Mail-Benachrichtigungen entfernst du per Klick auf das X im HUD - ich aendere dein Postfach nicht (die Mail von '{frm}' bleibt dort ungelesen)."
    return f"Keine Benachrichtigung oder E-Mail zu '{query}' gefunden."


@app.route("/phone/api/notify-block", methods=["POST"])
def phone_api_notify_block():
    """Als Spam markiert: diese App wird kuenftig nie mehr weitergeleitet, alle schon
    angezeigten Eintraege dieser App verschwinden sofort (PC und Handy)."""
    d = request.get_json(silent=True) or {}
    app_name = str(d.get("app") or "")[:60]
    if not app_name:
        return jsonify({"error": "app fehlt"}), 400
    _phone_block_app(app_name)
    return jsonify({"error": None})


@app.route("/notify/blocked")
def notify_blocked_list():
    """Alles, was als Spam gesperrt wurde: Handy-Apps (kommen nicht mehr an) und Mail-Absender (werden nicht mehr gemeldet)."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return jsonify({"apps": sorted(_phone_notif_blocked_apps(), key=str.lower), "senders": sorted(_spam_senders)})


@app.route("/notify/unblock", methods=["POST"])
def notify_unblock():
    """Spam-Markierung rueckgaengig machen (kind = 'app' oder 'sender')."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    d = request.get_json(silent=True) or {}
    kind, name = str(d.get("kind") or ""), str(d.get("name") or "")
    if kind == "app":
        cfg = dict(_phone_cfg())
        cfg["notif_blocked_apps"] = [a for a in (cfg.get("notif_blocked_apps") or []) if a != name]
        _phone_save(cfg)
    elif kind == "sender":
        _spam_senders.discard(name)
        _save_spam_senders(_spam_senders)
    else:
        return jsonify({"error": "kind fehlt"}), 400
    return jsonify({"error": None})


# --- Antworten auf Handy-Nachrichten (WhatsApp, Discord, ...) --------------------------------
# Das Handy hat zu manchen Benachrichtigungen eine "Antworten"-Aktion (Android-RemoteInput). Der PC legt den Antworttext hier in eine
# kurze Warteschlange; das Handy holt sie ab (/phone/api/reply-pending), schickt sie ueber genau diese Aktion los und meldet das Ergebnis
# zurueck (/phone/api/reply-result). Gesendet wird nur, was der Nutzer selbst im HUD abgeschickt oder per Sprache bestaetigt hat.
_PHONE_REPLIES = []   # {"rid", "key", "id", "app", "to", "text", "ts", "status": pending|sent|failed, "note"}
_PHONE_REPLIES_MAX = 30


def _phone_find_reply_target(query="", id_=""):
    """Benachrichtigung finden, auf die man antworten kann (per id, sonst per App/Absender/Stichwort; neueste zuerst)."""
    cands = [n for n in _PHONE_NOTIFS if n.get("can_reply")]
    if id_:
        return next((n for n in cands if n["id"] == id_), None)
    q = (query or "").strip().lower()
    cands.sort(key=lambda n: n["ts"], reverse=True)
    if not q:
        return cands[0] if cands else None
    for n in cands:
        if q in n["app"].lower() or q in n["title"].lower() or q in n["text"].lower():
            return n
    return None


def _phone_queue_reply(n, text):
    rid = _pysecrets.token_hex(5)
    _PHONE_REPLIES.append({"rid": rid, "key": n.get("key", ""), "id": n["id"], "app": n["app"], "to": n["title"], "text": text[:1000],
                           "ts": int(time.time()), "status": "pending", "note": ""})
    del _PHONE_REPLIES[:-_PHONE_REPLIES_MAX]
    return rid


@app.route("/phone/reply", methods=["POST"])
def phone_reply_send():
    """HUD: Antwort auf eine Handy-Benachrichtigung abschicken (der Nutzer hat im Dialog selbst auf SENDEN gedrueckt)."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    d = request.get_json(silent=True) or {}
    text = str(d.get("text") or "").strip()
    n = _phone_find_reply_target(id_=str(d.get("id") or ""))
    if not text:
        return jsonify({"error": "Kein Text."}), 400
    if not n:
        return jsonify({"error": "Auf diese Nachricht kann man am Handy nicht antworten (oder sie ist dort schon weg)."}), 404
    rid = _phone_queue_reply(n, text)
    if n.get("dev"):   # Test-Nachricht: nichts ans Handy schicken, sofort als "gesendet" melden
        _PHONE_REPLIES[-1]["status"] = "sent"
        _phone_notif_remove(id_=n["id"])
    return jsonify({"error": None, "rid": rid})


@app.route("/phone/reply/status")
def phone_reply_status():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    rid = request.args.get("rid", "")
    rep = next((x for x in _PHONE_REPLIES if x["rid"] == rid), None)
    if not rep:
        return jsonify({"status": "unknown"})
    if rep["status"] == "pending" and time.time() - rep["ts"] > 40:
        rep["status"], rep["note"] = "failed", "Das Handy hat nicht reagiert - ist die A.R.I-App geoeffnet/verbunden?"
    return jsonify({"status": rep["status"], "note": rep["note"]})


@app.route("/phone/api/reply-pending")
def phone_api_reply_pending():
    """Das Handy holt hier ab, welche Antworten es senden soll."""
    out = [{"rid": x["rid"], "key": x["key"], "text": x["text"]} for x in _PHONE_REPLIES if x["status"] == "pending" and time.time() - x["ts"] <= 40]
    return jsonify({"replies": out})


@app.route("/phone/api/reply-result", methods=["POST"])
def phone_api_reply_result():
    d = request.get_json(silent=True) or {}
    rep = next((x for x in _PHONE_REPLIES if x["rid"] == str(d.get("rid") or "")), None)
    if rep:
        rep["status"] = "sent" if d.get("ok") else "failed"
        rep["note"] = str(d.get("error") or "")[:200]
        if rep["status"] == "sent":
            _phone_notif_remove(id_=rep["id"])   # beantwortet: Nachricht verschwindet im HUD und (ueber den Abgleich) auch am Handy
    return jsonify({"error": None})


@app.route("/phone/dev-notify", methods=["POST"])
def phone_dev_notify():
    """DEV-Test im HUD: eine Test-Nachricht mit "Antworten"-Moeglichkeit einspielen (ohne Handy). Die Antwort wird dann im HUD angezeigt, aber nirgends gesendet."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    nid = _pysecrets.token_hex(6)
    _PHONE_NOTIFS.append({"id": nid, "app": "WhatsApp (Test)", "title": "Max Beispiel", "text": "Hast du heute Abend Zeit?", "ts": int(time.time()),
                          "key": "dev-test", "can_reply": True, "dev": True})
    return jsonify({"error": None, "id": nid})


def _tool_read_notifications(query=""):
    q = (query or "").strip().lower()
    items = [n for n in _PHONE_NOTIFS if not q or q in n["app"].lower() or q in n["title"].lower() or q in n["text"].lower()]
    if not items:
        return "Keine Handy-Nachrichten vorhanden" + (f" zu '{query}'." if q else ".")
    items.sort(key=lambda n: n["ts"], reverse=True)
    lines = []
    for n in items[:8]:
        who = n["title"] or n["app"]
        lines.append(f"{who} ({n['app']}): {n['text'] or '(kein Text)'}" + (" [beantwortbar]" if n.get("can_reply") else ""))
    return "Handy-Nachrichten, neueste zuerst - lies sie dem Nutzer vor:\n" + "\n".join(lines)


_PENDING_REPLY = {}   # zuletzt vorgelesener, noch nicht bestaetigter Antwort-Entwurf: {"id", "to", "text", "ts"}


@app.route("/phone/reply-draft")
def phone_reply_draft():
    """HUD: gibt es einen vorgelesenen Entwurf, auf dessen Ja/Nein gewartet wird? (gilt 3 Minuten)"""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    d = _PENDING_REPLY
    if d and time.time() - d.get("ts", 0) < 180:
        return jsonify({"pending": True, "to": d["to"], "text": d["text"]})
    return jsonify({"pending": False})


@app.route("/phone/reply-draft/answer", methods=["POST"])
def phone_reply_draft_answer():
    """Ja/Nein des Nutzers zum Entwurf - ohne KI-Anfrage (die kann am Limit oder ohne gueltigen Schluessel scheitern, genau wenn es zaehlt)."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    d = dict(_PENDING_REPLY)
    if not d or time.time() - d.get("ts", 0) >= 180:
        return jsonify({"reply": "Es wartet gerade kein Entwurf auf eine Antwort."})
    _PENDING_REPLY.clear()
    if not (request.get_json(silent=True) or {}).get("yes"):
        return jsonify({"reply": "Okay, ich sende nichts."})
    return jsonify({"reply": _tool_reply_notification(d["to"], d["text"], True)})


def _tool_reply_notification(to, text, confirmed=False):
    n = _phone_find_reply_target(query=to)
    text = (text or "").strip()
    if not n:
        return f"Es gibt gerade keine Handy-Nachricht{(' zu ' + repr(to)) if to else ''}, auf die man antworten kann."
    if not text:
        return "Kein Antworttext angegeben."
    who = f"{n['title']} ({n['app']})"
    if not confirmed:
        _PENDING_REPLY.clear()
        _PENDING_REPLY.update({"id": n["id"], "to": n["title"] or n["app"], "text": text, "ts": time.time()})
        return (f"ENTWURF, noch NICHT gesendet: Antwort an {who} auf \"{n['text'][:120]}\": \"{text}\". "
                f"Lies dem Nutzer den Text vor und frage, ob du ihn so senden sollst. Erst nach seinem klaren Ja dieses Werkzeug "
                f"nochmal mit confirmed=true und demselben Text aufrufen.")
    if n.get("dev"):
        return f"(Test) Antwort an {who} waere gesendet worden: \"{text}\"."
    rid = _phone_queue_reply(n, text)
    for _ in range(30):   # bis ~15 s auf die Rueckmeldung des Handys warten
        time.sleep(0.5)
        rep = next((x for x in _PHONE_REPLIES if x["rid"] == rid), None)
        if rep and rep["status"] == "sent":
            return f"Antwort an {who} gesendet."
        if rep and rep["status"] == "failed":
            return f"Senden hat nicht geklappt: {rep['note'] or 'unbekannter Fehler'}."
    return "Das Handy hat nicht rechtzeitig geantwortet - die Antwort wird gesendet, sobald es sich meldet (A.R.I-App am Handy offen?)."


@app.route("/phone/api/notify-dismissed")
def phone_api_notify_dismissed():
    """Das Handy fragt hier ab, welche Benachrichtigungen der PC weggeklickt hat, damit es
    dieselben echten Systembenachrichtigungen dort ebenfalls schliessen kann."""
    since = int(request.args.get("since", 0) or 0)
    return jsonify({"keys": [g["key"] for g in _PHONE_GONE if g["ts"] > since and g.get("key")]})


@app.route("/phone/notifications")
def phone_notifications_list():
    since = int(request.args.get("since", 0) or 0)
    return jsonify({
        "items": [n for n in _PHONE_NOTIFS if n["ts"] > since],
        "removed": [g["id"] for g in _PHONE_GONE if g["ts"] > since],
    })


@app.route("/phone/pair", methods=["POST"])
def phone_pair():
    data = request.get_json(silent=True) or {}
    ip = _client_ip()
    fails, ts = _pair_ip_fails.get(ip, (0, 0))
    if fails >= 8 and time.time() - ts < 600:
        return jsonify({"error": "Zu viele Versuche - bitte in 10 Minuten erneut"}), 429
    code = str(data.get("code") or "").strip()
    short_ok = bool(_pair["code"]) and time.time() <= _pair["exp"] and hmac.compare_digest(code, _pair["code"])
    if not short_ok:
        _pair_ip_fails[ip] = (fails + 1, time.time())
        _pair["fails"] += 1
        if _pair["fails"] >= 5:
            _pair["code"] = None  # nach 5 Fehlversuchen ist der Code verbrannt
        return jsonify({"error": "Code falsch oder abgelaufen"}), 403
    token = _pysecrets.token_urlsafe(32)
    cfg = dict(_phone_cfg())
    devs = list(cfg.get("devices", []))
    name = re.sub(r"[^\w .\-]", "", str(data.get("name") or "Handy"))[:40] or "Handy"
    dev = re.sub(r"[^\w-]", "", str(data.get("dev") or ""))[:32]
    if dev:                                       # gleiches Geraet koppelt erneut: alten Eintrag ersetzen
        devs = [x for x in devs if x.get("dev") != dev]
    devs.append({"id": _pysecrets.token_hex(4), "name": name, "hash": hashlib.sha256(token.encode("utf-8")).hexdigest(),
                 "created": int(time.time()), "seen": int(time.time()), "dev": dev})
    cfg["devices"] = devs
    _phone_save(cfg)
    if short_ok:
        _pair["code"] = None
    _pair_ip_fails.pop(ip, None)
    print(f"[phone] Neues Geraet gekoppelt: {name}")
    return jsonify({"token": token})


def _phone_dedupe_devices(devs):
    """Raeumt doppelte Geraete-Eintraege auf: alte Kopplungen (vor der Geraete-Kennung „dev")
    haben keine feste Kennung und legen bei jeder erneuten Kopplung einen neuen Eintrag an.
    Von Eintraegen ohne „dev" mit gleichem Namen wird nur der zuletzt gesehene behalten;
    Eintraege mit „dev" sind bereits beim Koppeln eindeutig (siehe phone_pair)."""
    newest_untagged = {}
    tagged = []
    for d in devs:
        if d.get("dev"):
            tagged.append(d)
            continue
        key = str(d.get("name") or "").strip().lower()
        cur = newest_untagged.get(key)
        if cur is None or d.get("seen", 0) >= cur.get("seen", 0):
            newest_untagged[key] = d
    out = tagged + list(newest_untagged.values())
    out.sort(key=lambda d: d.get("seen", 0))
    return out, len(out) != len(devs)


def _lan_urls():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    return [f"http://{ip}:5000/phone" for ip in ips]


# --- Auto-Suche im WLAN --------------------------------------------------
# Damit man beim Koppeln nicht die PC-Adresse abtippen muss: die App schickt einen UDP-Broadcast
# mit einer festen Kennung, der Hub antwortet direkt an den Absender (der die eigene IP so aus dem
# Antwortpaket erfaehrt). Antwortet nur, wenn Handy-Zugriff ueberhaupt an ist - sonst kein Verrat der Adresse.
_DISCOVERY_PORT = 47624
_DISCOVERY_MAGIC = b"ARI-DISCOVER"


def _discovery_loop():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", _DISCOVERY_PORT))
    except OSError as e:
        print("[discovery] Port nicht verfuegbar, Auto-Suche aus:", e)
        return
    while True:
        try:
            data, addr = s.recvfrom(64)
            if data == _DISCOVERY_MAGIC and _phone_cfg().get("enabled"):
                s.sendto(b"ARI-HERE 5000", addr)
        except Exception:
            pass


_STARTUP_LNK = (os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "A.R.I Hub.lnk")
                if IS_WIN else _lx.AUTOSTART_FILE)
# Geplante Aufgabe statt Verknuepfung, wenn A.R.I mit Administrator-Rechten laufen soll (fuer
# die CPU-Temperatur - siehe _read_temps). Eine "Als Administrator ausfuehren"-Verknuepfung
# wuerde JEDES Mal das UAC-Fenster zeigen; eine Aufgabe mit RunLevel "Highest" fragt dagegen
# nur EINMAL bei der Einrichtung (dieser Funktion hier) und startet danach still elevated -
# sowohl beim Login als auch beim manuellen Start ueber START-ARI.bat (per "schtasks /run").
_ADMIN_TASK_NAME = "A.R.I Hub (Admin)"


def _admin_autostart_installed():
    if not IS_WIN:
        return False
    try:
        r = subprocess.run(["schtasks", "/query", "/tn", _ADMIN_TASK_NAME], capture_output=True, creationflags=_NOWIN)
        return r.returncode == 0
    except Exception:
        return False


def _setup_admin_autostart(enable):
    """Richtet (einmalig, mit EINEM UAC-Fenster) eine geplante Aufgabe ein, die A.R.I mit
    Administrator-Rechten startet, oder entfernt sie wieder. Ersetzt dabei die normale
    Start-Verknuepfung (sonst wuerde A.R.I doppelt starten)."""
    if not IS_WIN:
        return False, "Nur unter Windows verfuegbar."
    if not enable:
        if not _admin_autostart_installed():
            return True, None
        # Die Aufgabe hat RunLevel "Highest" - sie zu loeschen braucht deshalb selbst
        # Administrator-Rechte (ein normaler "schtasks /delete" schlaegt mit "Zugriff
        # verweigert" fehl), also genau wie beim Einrichten ueber -Verb RunAs elevieren.
        marker = os.path.join(tempfile.gettempdir(), "ari_admin_remove_ok.txt")
        try:
            os.remove(marker)
        except OSError:
            pass
        script_lines = [
            "$ErrorActionPreference = 'SilentlyContinue'",
            "schtasks /delete /tn '" + _ADMIN_TASK_NAME.replace("'", "''") + "' /f | Out-Null",
            "Set-Content -LiteralPath '" + marker.replace("'", "''") + "' -Value 'ok'",
        ]
        tmp_ps1 = os.path.join(tempfile.gettempdir(), "ari_admin_remove.ps1")
        with open(tmp_ps1, "w", encoding="utf-8") as f:
            f.write("\n".join(script_lines))
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", "Start-Process powershell -Verb RunAs -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','" + tmp_ps1.replace("'", "''") + "'"],
                capture_output=True, creationflags=_NOWIN, timeout=15,
            )
        except Exception as e:
            return False, str(e)
        deadline = time.time() + 30
        while time.time() < deadline:
            if os.path.exists(marker):
                try:
                    os.remove(marker)
                except OSError:
                    pass
                return not _admin_autostart_installed(), None
            time.sleep(0.5)
        return False, "Zeit abgelaufen - wurde das UAC-Fenster bestaetigt?"
    named = os.path.join(sys.base_prefix, "Ari Assistent.exe")
    exe = named if os.path.exists(named) else os.path.join(sys.base_prefix, "pythonw.exe")
    if not os.path.exists(exe):
        exe = sys.executable
    hub = os.path.join(DASHBOARD_DIR, "hub.py")
    marker = os.path.join(tempfile.gettempdir(), "ari_admin_setup_ok.txt")
    try:
        os.remove(marker)
    except OSError:
        pass
    script_lines = [
        "$ErrorActionPreference = 'Stop'",
        "$act = New-ScheduledTaskAction -Execute '" + exe.replace("'", "''") + "' -Argument '\"" + hub.replace("'", "''") + "\" --background' -WorkingDirectory '" + DASHBOARD_DIR.replace("'", "''") + "'",
        "$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)",
        "$pr = New-ScheduledTaskPrincipal -UserId \"$env:USERDOMAIN\\$env:USERNAME\" -LogonType Interactive -RunLevel Highest",
        "Register-ScheduledTask -TaskName '" + _ADMIN_TASK_NAME.replace("'", "''") + "' -Action $act -Principal $pr -Settings $set -Force | Out-Null",
        "Remove-Item -LiteralPath '" + _STARTUP_LNK.replace("'", "''") + "' -Force -ErrorAction SilentlyContinue",
        "Set-Content -LiteralPath '" + marker.replace("'", "''") + "' -Value 'ok'",
    ]
    tmp_ps1 = os.path.join(tempfile.gettempdir(), "ari_admin_setup.ps1")
    with open(tmp_ps1, "w", encoding="utf-8") as f:
        f.write("\n".join(script_lines))
    try:
        # -Verb RunAs zeigt genau EIN UAC-Fenster fuer diese einmalige Einrichtung -
        # danach startet die Aufgabe selbst immer still (ohne Nachfrage).
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", "Start-Process powershell -Verb RunAs -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','" + tmp_ps1.replace("'", "''") + "'"],
            capture_output=True, creationflags=_NOWIN, timeout=15,
        )
    except Exception as e:
        return False, str(e)
    # Kurz auf die Markerdatei warten (die elevierte Aufgabe braucht einen Moment,
    # v.a. wenn der Nutzer das UAC-Fenster erst bestaetigen muss).
    deadline = time.time() + 30
    while time.time() < deadline:
        if os.path.exists(marker):
            try:
                os.remove(marker)
            except OSError:
                pass
            _set_autostart(True)   # sichtbarer Autostart-Eintrag (Run), der an die Aufgabe uebergibt
            return True, None
        time.sleep(0.5)
    return False, "Zeit abgelaufen - wurde das UAC-Fenster bestaetigt?"


def _set_autostart(enable):
    if not IS_WIN:
        return _lx.set_autostart(enable, os.path.join(DASHBOARD_DIR, "linux", "start-ari.sh"))
    if not enable:
        try:
            os.remove(_STARTUP_LNK)
        except OSError:
            pass
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, "ARI Hub")
        except Exception:
            pass
        return True
    # Genau EIN Autostart-Eintrag (HKCU-Run "ARI Hub"): so steht A.R.I im Task-Manager nur einmal. Eine alte Verknuepfung im Autostart-Ordner wird entfernt.
    try:
        import winreg
        _remove_startup_lnk()
        _exe, cmd = _autostart_command()
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _RUN_KEY) as k:   # der EINE sichtbare Autostart-Eintrag (Task-Manager); er uebergibt selbst an die Administrator-Aufgabe
            winreg.SetValueEx(k, "ARI Hub", 0, winreg.REG_SZ, cmd)
        _admin_task_no_logon()
        return True
    except Exception:
        return False


_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
_APPROVED_KEY = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved"


def _remove_startup_lnk():
    """Alte Autostart-Verknuepfung samt Windows-Merker entfernen (sonst erscheint A.R.I doppelt im Task-Manager)."""
    try:
        os.remove(_STARTUP_LNK)
    except OSError:
        pass
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _APPROVED_KEY + "\\StartupFolder", 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, os.path.basename(_STARTUP_LNK))
    except Exception:
        pass


def _admin_task_no_logon():
    """Die Administrator-Aufgabe startet nicht mehr selbst bei der Anmeldung (sonst startet A.R.I doppelt: Run-Eintrag + Aufgabe). Sie bleibt zum Uebergeben da -
    der Run-Eintrag ruft sie auf. Geht nur mit Administrator-Rechten (der Hub laeuft normalerweise darueber)."""
    if not IS_WIN or not _admin_autostart_installed():
        return
    try:
        if not ctypes.windll.shell32.IsUserAnAdmin():
            return
        ps = ("$t=Get-ScheduledTask -TaskName '" + _ADMIN_TASK_NAME + "'; if(@($t.Triggers).Count -gt 0){ $t.Triggers=@(); Set-ScheduledTask -InputObject $t | Out-Null; 'geaendert' }")
        rr = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, creationflags=_NOWIN, timeout=30)
        out = rr.stdout or ""
        if "geaendert" not in out:
            print(f"[autostart] Aufgabe: kein Aenderung ({(rr.stderr or out).strip()[:200]})")
        if "geaendert" in out:
            print("[autostart] Administrator-Aufgabe startet nicht mehr selbst bei der Anmeldung (der Autostart-Eintrag uebergibt an sie).")
    except Exception as e:
        print(f"[autostart] Aufgabe konnte nicht angepasst werden: {e}")


def _remove_run_entry():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, "ARI Hub")
    except Exception:
        pass


def _autostart_on():
    if not IS_WIN:
        return os.path.exists(_STARTUP_LNK)
    if os.path.exists(_STARTUP_LNK):
        return True
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _RUN_KEY) as k:
            return bool(winreg.QueryValueEx(k, "ARI Hub")[0])
    except OSError:
        return False


def _autostart_command():
    named = os.path.join(sys.base_prefix, "Ari Assistent.exe")
    exe = named if os.path.exists(named) else os.path.join(sys.base_prefix, "pythonw.exe")
    if not os.path.exists(exe):
        exe = sys.executable
    return exe, '"' + exe + '" "' + os.path.join(DASHBOARD_DIR, "hub.py") + '" --background'


def _heal_autostart():
    """Autostart reparieren, wenn er trotz Eintrag nicht startet (Windows hat ihn im Task-Manager auf 'Deaktiviert' gesetzt) und alte Doppeleintraege
    zusammenfuehren: es bleibt nur der HKCU-Run-Eintrag 'ARI Hub' (die alte Verknuepfung im Autostart-Ordner wird entfernt)."""
    if not IS_WIN or not (_autostart_on() or _admin_autostart_installed()):
        return
    try:
        import winreg
        exe, cmd = _autostart_command()
        had_lnk = os.path.exists(_STARTUP_LNK)
        _admin_task_no_logon()
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _RUN_KEY) as k:
            winreg.SetValueEx(k, "ARI Hub", 0, winreg.REG_SZ, cmd)
        if had_lnk:
            _remove_startup_lnk()
            print("[autostart] Doppelten Autostart-Eintrag (Verknuepfung) entfernt - A.R.I steht nur noch einmal im Autostart.")
        enabled = bytes([2]) + bytes(11)
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _APPROVED_KEY + "\\Run") as k:
                try:
                    cur = winreg.QueryValueEx(k, "ARI Hub")[0]
                except OSError:
                    cur = None
                if cur is not None and (not cur or cur[0] % 2 == 1):   # ungerade = von Windows/Nutzer deaktiviert
                    winreg.SetValueEx(k, "ARI Hub", 0, winreg.REG_BINARY, enabled)
                    print("[autostart] 'ARI Hub' war deaktiviert - wieder aktiviert.")
        except OSError:
            pass
    except Exception as e:
        print(f"[autostart] Reparatur nicht moeglich: {e}")


def _fix_autostart_window_style():
    """Aeltere Autostart-Verknuepfungen starten "minimiert" (WindowStyle 7) - das gilt auch fuer das erste Fenster des
    Programms, das HUD-Fenster kaeme dann nur minimiert in die Taskleiste. Auf "normal" zuruecksetzen."""
    if not IS_WIN or not os.path.exists(_STARTUP_LNK):
        return
    try:
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + _STARTUP_LNK + "');"
              "if($s.WindowStyle -ne 1){$s.WindowStyle=1;$s.Save()}")
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=_NOWIN, timeout=20)
    except Exception as e:
        print(f"[start] Autostart-Verknuepfung konnte nicht angepasst werden: {e}")


_START_MENU_LNK = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Ari Assistent.lnk")


def _fix_launch_links():
    """Verknuepfungen (Desktop, Startmenue), die noch START-ARI.bat starten, zeigen direkt auf das Programm: sonst blitzt jedes Mal
    ein schwarzes Konsolenfenster auf. Die Uebergabe an die Administrator-Aufgabe macht hub.py selbst (_handover_to_admin_hub)."""
    if not IS_WIN:
        return
    try:
        bat = os.path.join(DASHBOARD_DIR, "START-ARI.bat")
        exe, _cmd = _autostart_command()
        hub = os.path.join(DASHBOARD_DIR, "hub.py")
        q = lambda x: x.replace("'", "''")
        ps = ("$w=New-Object -ComObject WScript.Shell;"
              "$dirs=@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'),"
              "[Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('StartMenu'));"
              "foreach($d in $dirs){ if(-not $d -or -not (Test-Path $d)){continue}; "
              "Get-ChildItem -LiteralPath $d -Filter *.lnk -Recurse -Depth 1 -ErrorAction SilentlyContinue | ForEach-Object { try {"
              "$s=$w.CreateShortcut($_.FullName); if($s.TargetPath -ieq '" + q(bat) + "'){ $s.TargetPath='" + q(exe) + "';"
              "$s.Arguments='\"" + q(hub) + "\"';$s.WorkingDirectory='" + q(DASHBOARD_DIR) + "';$s.WindowStyle=1;$s.Save() } } catch {} } }")
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=_NOWIN, timeout=40)
    except Exception as e:
        print(f"[start] Verknuepfungen konnten nicht angepasst werden: {e}")


def _ensure_start_menu_shortcut():
    """Startmenue-Eintrag "Ari Assistent": die Windows-Suche findet "A.R.I" nicht, wenn man "ari" tippt
    (die Punkte trennen den Namen in einzelne Buchstaben) - mit diesem Namen reicht "ari"."""
    if not IS_WIN or os.path.exists(_START_MENU_LNK):
        return
    try:
        bat = os.path.join(DASHBOARD_DIR, "START-ARI.bat")
        if not os.path.exists(bat):
            return
        ico = os.path.join(DASHBOARD_DIR, "app", "ari.ico")
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + _START_MENU_LNK + "');"
              "$s.TargetPath='" + _autostart_command()[0] + "';$s.Arguments='\"" + os.path.join(DASHBOARD_DIR, "hub.py") + "\"';$s.WorkingDirectory='" + DASHBOARD_DIR + "';$s.WindowStyle=1;"
              "$s.Description='Ari starten';"
              + ("$s.IconLocation='" + ico + ",0';" if os.path.exists(ico) else "") + "$s.Save()")
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=_NOWIN, timeout=20)
    except Exception as e:
        print(f"[start] Startmenue-Eintrag konnte nicht angelegt werden: {e}")


def _app_qr_link(code):
    """QR-Ziel fuer die Handy-App: feste App-Adresse + PC-Adresse im Heim-WLAN + Kurz-Code.
    Nur moeglich, wenn App-Adresse eingetragen ist und der PC im WLAN erreichbar ist."""
    app_url = _app_url()
    if not code or not _app_origin():
        return None
    lan = _lan_urls()
    target = lan[0].rsplit("/phone", 1)[0] if lan else None
    if not target:
        return None
    return app_url.rstrip("/") + "/#pc=" + urllib.parse.quote(target, safe="") + "&l=" + code


@app.route("/phone/admin/info", methods=["GET"])
def phone_admin_info():
    cfg = _phone_cfg()
    code_ok = bool(_pair["code"] and time.time() < _pair["exp"])
    devs, changed = _phone_dedupe_devices(cfg.get("devices", []))
    if changed:
        cfg2 = dict(cfg)
        cfg2["devices"] = devs
        _phone_save(cfg2)
    return jsonify({
        "enabled": bool(cfg.get("enabled")), "always_on": bool(cfg.get("always_on", False)),
        "pcview": bool(cfg.get("pcview", True)),
        "autostart": _autostart_on(), "admin_autostart": _admin_autostart_installed(), "urls": _lan_urls(),
        "devices": [{"id": d["id"], "name": d["name"], "seen": d.get("seen", 0)} for d in devs],
        "code": _pair["code"] if code_ok else None, "code_left": int(_pair["exp"] - time.time()) if code_ok else 0,
        "qr_link": (_app_qr_link(_pair["code"]) if code_ok else None),
    })


@app.route("/phone/admin/config", methods=["POST"])
def phone_admin_config():
    data = request.get_json(silent=True) or {}
    cfg = dict(_phone_cfg())
    for k in ("enabled", "always_on", "pcview"):
        if k in data:
            cfg[k] = bool(data[k])
    _phone_save(cfg)
    err = None
    if "autostart" in data:
        try:
            if not _set_autostart(bool(data["autostart"])):
                err = "Autostart konnte nicht eingerichtet werden."
        except Exception as e:
            err = "Autostart: " + str(e)
    return jsonify({"error": err})


# --- Grafikkarte fuer A.R.I ---------------------------------------------------------------------------------------------------
# Der Browser-Grafikprozess des HUD-Fensters (WebView2) waehlt seine Grafikkarte selbst und ignoriert die Windows-Einstellung "Grafik pro
# Programm". Deshalb wird die gewuenschte Karte dem Fenster direkt mitgegeben (--use-adapter-luid). A.R.I braucht fuer sein HUD keine
# starke Karte - so bleibt sie fuers Spiel frei. Gespeichert wird der NAME der Karte (die interne Nummer aendert sich bei jedem Neustart).
_GPU_PREF_FILE = os.path.join(DATA_DIR, "gpu_pref.json")


def _dxgi_adapters():
    """Alle Grafikkarten mit Name, interner Nummer (LUID) und Speicher - ueber DXGI, ohne zusaetzliche Programme."""
    if not IS_WIN:
        return []
    out = []
    try:
        import ctypes.wintypes as wt

        class GUID(ctypes.Structure):
            _fields_ = [("a", ctypes.c_uint32), ("b", ctypes.c_uint16), ("c", ctypes.c_uint16), ("d", ctypes.c_ubyte * 8)]

        class DESC1(ctypes.Structure):
            _fields_ = [("Description", ctypes.c_wchar * 128), ("VendorId", ctypes.c_uint), ("DeviceId", ctypes.c_uint),
                        ("SubSysId", ctypes.c_uint), ("Revision", ctypes.c_uint), ("Dedicated", ctypes.c_size_t),
                        ("DedicatedSys", ctypes.c_size_t), ("Shared", ctypes.c_size_t),
                        ("LuidLow", ctypes.c_uint32), ("LuidHigh", ctypes.c_int32), ("Flags", ctypes.c_uint)]

        iid = GUID(0x770AAE78, 0xF26F, 0x4DBA, (ctypes.c_ubyte * 8)(0xA8, 0x29, 0x25, 0x3C, 0x83, 0xD1, 0xB3, 0x87))   # IDXGIFactory1
        dxgi = ctypes.windll.dxgi
        factory = ctypes.c_void_p()
        if dxgi.CreateDXGIFactory1(ctypes.byref(iid), ctypes.byref(factory)) != 0:
            return []

        def vcall(obj, index, *argtypes):
            vtbl = ctypes.cast(ctypes.cast(obj, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
            return ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, *argtypes)(vtbl[index])

        enum_adapters1 = vcall(factory, 12, ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p))
        i = 0
        while True:
            ad = ctypes.c_void_p()
            if enum_adapters1(factory, i, ctypes.byref(ad)) != 0:
                break
            d = DESC1()
            vcall(ad, 10, ctypes.POINTER(DESC1))(ad, ctypes.byref(d))
            out.append({"name": d.Description, "low": d.LuidLow, "high": d.LuidHigh, "dedicated_mb": int(d.Dedicated // (1024 * 1024)),
                        "software": bool(d.Flags & 2)})
            vcall(ad, 2)(ad)   # Release
            i += 1
        vcall(factory, 2)(factory)
    except Exception as e:
        print(f"[gpu] Grafikkarten konnten nicht gelesen werden: {e}")
    return [a for a in out if not a["software"]]


def _gpu_pref_name():
    """Name der Karte, auf der A.R.I laufen soll. Standard (nichts gewaehlt): bei zwei Grafikkarten die integrierte (spart Strom, die starke
    bleibt fuer Spiele frei). '-' = der Nutzer will KEINEN Eingriff (Browser/Windows entscheiden) -> ''."""
    saved = None
    try:
        with open(_GPU_PREF_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        if d.get("mode") == "power":      # aelterer Stand
            saved = None
        elif "name" in d and d.get("name"):
            saved = str(d["name"])
    except Exception:
        saved = None
    if saved == "-":
        return ""
    cards = _dxgi_adapters()
    if saved and any(c["name"] == saved for c in cards):
        return saved
    if len(cards) >= 2:
        return sorted(cards, key=lambda c: c["dedicated_mb"])[0]["name"]   # integrierte = am wenigsten eigener Speicher
    return ""


def _gpu_browser_arg():
    """Browser-Argument fuer das HUD-Fenster, oder '' wenn nichts zu tun ist (Standard oder gewaehlte Karte nicht gefunden)."""
    name = _gpu_pref_name()
    if not name:
        return ""
    for a in _dxgi_adapters():
        if a["name"] == name:
            return f"--use-adapter-luid={a['high']},{a['low']}"
    return ""


def _gpu_pref_clean_registry():
    """Eine fruehere Version hat die (wirkungslose) Windows-Grafikeinstellung fuer A.R.I gesetzt - diese Eintraege wieder entfernen."""
    if not IS_WIN:
        return
    try:
        import winreg, glob
        key = "Software" + chr(92) + "Microsoft" + chr(92) + "DirectX" + chr(92) + "UserGpuPreferences"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE) as k:
            n = winreg.QueryInfoKey(k)[1]
            names = [winreg.EnumValue(k, i)[0] for i in range(n)]
            for nm in names:
                low = nm.lower()
                if low.endswith(("ari assistent.exe", "pythonw.exe")) or low.endswith("msedgewebview2.exe") and "edgewebview" in low:
                    try:
                        winreg.DeleteValue(k, nm)
                    except OSError:
                        pass
    except OSError:
        pass


@app.route("/gpu/info")
def gpu_info():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    cards = _dxgi_adapters()
    small = min((c["dedicated_mb"] for c in cards), default=0)
    return jsonify({"adapters": [{"name": c["name"], "dedicated_mb": c["dedicated_mb"], "integrated": len(cards) >= 2 and c["dedicated_mb"] == small} for c in cards],
                    "selected": _gpu_pref_name(), "supported": IS_WIN})


@app.route("/gpu/preference", methods=["POST"])
def gpu_preference():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    body = request.get_json(silent=True) or {}
    name = str(body.get("name") or "-")
    if name != "-" and name not in [c["name"] for c in _dxgi_adapters()]:
        return jsonify({"ok": False, "error": "Diese Grafikkarte wurde nicht gefunden."})
    try:
        before = _gpu_pref_name()
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(_GPU_PREF_FILE, "w", encoding="utf-8") as f:
            json.dump({"name": name}, f)
        changed = _gpu_pref_name() != before
        _gpu_pref_clean_registry()
        restart = bool(body.get("restart")) and changed
        if restart:
            threading.Timer(1.2, _gpu_restart).start()   # erst antworten, dann neu starten
        return jsonify({"ok": True, "selected": name, "restarting": restart, "error": None})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:160]})


def _gpu_restart():
    """Neustart, damit A.R.I mit der gewaehlten Grafikkarte startet: alle anderen A.R.I-Fenster/-Prozesse dieser Installation beenden
    (deren Grafikprozess laeuft sonst noch auf der alten Karte), dann startet sich A.R.I selbst neu."""
    try:
        import psutil
        me = os.getpid()
        hub = os.path.join(DASHBOARD_DIR, "hub.py").lower()
        for pr in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if pr.info["pid"] == me or "ari assistent" not in (pr.info["name"] or "").lower():
                    continue
                if any(hub in (a or "").lower() for a in (pr.info["cmdline"] or [])):
                    pr.terminate()
            except Exception:
                pass
        prof = os.path.join(DASHBOARD_DIR, "data", "webview-profile").lower()
        for pr in psutil.process_iter(["pid", "name", "cmdline"]):   # alte Browser-Prozesse dieses Fensters (behalten sonst ihre alte Grafikkarte)
            try:
                if "msedgewebview2" in (pr.info["name"] or "").lower() and any(prof in (a or "").lower() for a in (pr.info["cmdline"] or [])):
                    pr.terminate()
            except Exception:
                pass
        time.sleep(1.0)
    except Exception as e:
        print(f"[gpu] andere Prozesse konnten nicht beendet werden: {e}")
    _update_restart(quiet=True)


def _admin_task_info():
    """Zustand der Administrator-Aufgabe: eingerichtet? Programmdatei vorhanden? letztes Ergebnis? Laeuft A.R.I gerade mit Admin-Rechten?"""
    info = {"installed": False, "is_admin": False, "exe": "", "exe_exists": False, "last_result": None, "last_run": "", "hint": ""}
    try:
        info["is_admin"] = bool(IS_WIN and ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        pass
    if not IS_WIN:
        return info
    ps = ("$t=Get-ScheduledTask -TaskName '" + _ADMIN_TASK_NAME.replace("'", "''") + "' -ErrorAction SilentlyContinue; if(-not $t){'none'}else{"
          "$i=$t | Get-ScheduledTaskInfo; $a=$t.Actions[0]; "
          "ConvertTo-Json @{exe=[string]$a.Execute;args=[string]$a.Arguments;last=$i.LastRunTime.ToString('s');result=[int64]$i.LastTaskResult} -Compress}")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, creationflags=_NOWIN, timeout=20).stdout.strip()
        if out and out != "none":
            d = json.loads(out)
            info.update(installed=True, exe=d.get("exe", ""), exe_exists=os.path.exists(d.get("exe", "")), last_result=d.get("result"), last_run=d.get("last", ""))
    except Exception:
        pass
    if info["installed"] and not info["is_admin"]:
        res = info["last_result"]
        if not info["exe_exists"]:
            info["hint"] = "Die Aufgabe zeigt auf eine Programmdatei, die es nicht mehr gibt - bitte neu einrichten."
        elif res not in (0, 267009, None):
            info["hint"] = "Die Aufgabe ist beim letzten Start mit Fehler 0x%X beendet worden (z. B. von Windows blockiert) - bitte neu einrichten." % (int(res) & 0xFFFFFFFF)
        else:
            info["hint"] = "Die Aufgabe ist eingerichtet, aber A.R.I laeuft gerade ohne Administrator-Rechte (ein anderer Start war schneller). Mit NEU STARTEN uebernimmt die Aufgabe."
    return info


@app.route("/admin-autostart/status")
def admin_autostart_status():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return jsonify(_admin_task_info())


@app.route("/restart", methods=["POST"])
def restart_self():
    """A.R.I neu starten (z. B. damit die Administrator-Aufgabe uebernimmt)."""
    if not _is_local_request() or not request.is_json:
        return jsonify({"ok": False}), 403
    threading.Timer(0.8, _update_restart, kwargs={"quiet": True}).start()
    return jsonify({"ok": True})


@app.route("/admin-autostart/set", methods=["POST"])
def admin_autostart_set():
    """Richtet den elevierten Autostart ein/aus - siehe _setup_admin_autostart(). Braucht
    laenger als ein normaler Speichern-Aufruf (wartet kurz auf die Bestaetigung des einmaligen
    UAC-Fensters), deshalb eine eigene Route statt Teil von /phone/admin/config."""
    data = request.get_json(silent=True) or {}
    ok, err = _setup_admin_autostart(bool(data.get("enable")))
    return jsonify({"ok": ok, "error": err, "admin_autostart": _admin_autostart_installed()})


@app.route("/phone/admin/pair-code", methods=["POST"])
def phone_admin_pair_code():
    cfg = dict(_phone_cfg())
    if not cfg.get("enabled"):
        cfg["enabled"] = True
        _phone_save(cfg)
    _pair.update(code=f"{_pysecrets.randbelow(1000000):06d}", exp=time.time() + 300, fails=0)
    return jsonify({"code": _pair["code"], "code_left": 300})


@app.route("/phone/admin/revoke", methods=["POST"])
def phone_admin_revoke():
    did = (request.get_json(silent=True) or {}).get("id")
    cfg = dict(_phone_cfg())
    cfg["devices"] = [d for d in cfg.get("devices", []) if d.get("id") != did]
    _phone_save(cfg)
    return jsonify({"error": None})


@app.route("/phone/admin/rename", methods=["POST"])
def phone_admin_rename():
    data = request.get_json(silent=True) or {}
    did = data.get("id")
    name = re.sub(r"[^\w .\-]", "", str(data.get("name") or "")).strip()[:40]
    if not name:
        return jsonify({"error": "Name darf nicht leer sein."}), 400
    cfg = dict(_phone_cfg())
    devs = list(cfg.get("devices", []))
    found = False
    for d in devs:
        if d.get("id") == did:
            d["name"] = name
            found = True
    if not found:
        return jsonify({"error": "Gerät nicht gefunden."}), 404
    cfg["devices"] = devs
    _phone_save(cfg)
    return jsonify({"error": None})


@app.route("/phone/admin/sync-settings", methods=["POST"])
def phone_admin_sync_settings():
    """Das HUD schickt Anbieter/Schluessel/Sprache, damit das Handy dieselbe KI
    nutzt, ohne Schluessel auf dem Handy eintippen zu muessen (bleiben auf dem PC)."""
    d = request.get_json(silent=True) or {}
    cfg = dict(_phone_cfg())
    cfg["settings"] = {
        "provider": d.get("provider") if d.get("provider") in _PROVIDER_CLIENTS else "anthropic",
        "api_key": str(d.get("api_key") or ""),
        "groq_api_keys": [str(k) for k in (d.get("groq_api_keys") or []) if k][:5],
        "language": str(d.get("language") or ""),
        "volume_target": d.get("volume_target") if d.get("volume_target") in ("windows", "spotify") else "windows",
        "economy": d.get("economy") is not False,
        "primary": d.get("primary") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(d.get("primary") or "")) else None,
        "accent": d.get("accent") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(d.get("accent") or "")) else None,
    }
    fb = d.get("fallback")
    if isinstance(fb, dict) and fb.get("provider") in _PROVIDER_CLIENTS:
        cfg["settings"]["fallback"] = {"provider": fb["provider"], "api_key": str(fb.get("api_key") or ""),
                                       "groq_api_keys": [str(k) for k in (fb.get("groq_api_keys") or []) if k][:5]}
    ak = _clean_keys(d.get("apiKeys"))
    if ak is not None:
        cfg["settings"]["all_keys"] = ak
    _phone_save(cfg)
    return jsonify({"error": None})


@app.route("/phone/api/chat", methods=["POST"])
def phone_api_chat():
    data = request.get_json(silent=True) or {}
    msgs = []
    for m in (data.get("messages") or [])[-20:]:
        if isinstance(m, dict) and m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str):
            msgs.append({"role": m["role"], "content": m["content"][:4000]})
    body = dict(_phone_cfg().get("settings") or {})
    body["messages"] = msgs
    return _chat_impl(body, remote=True)


@app.route("/phone/api/state")
def phone_api_state():
    out = {}
    try:
        out["status"] = _run_with_hard_timeout(_collect_status, timeout=STATUS_HARD_TIMEOUT_SECONDS, executor=_status_executor)
    except Exception as e:
        out["status"] = {"error": str(e)}
    try:
        track, err = _tool_spotify_current_track()
        out["track"] = track
        if not err:
            _music_feed(track)
        out["spotify_error"] = err
    except Exception:
        out["track"] = None
    s = dict(_phone_cfg().get("settings") or {})
    s.update(_hud_state["settings"])
    s.update(_hud_state["patch"])
    out["theme"] = {"primary": s.get("primary"), "accent": s.get("accent")}
    return jsonify(out)


_phone_data_cache = {"t": 0.0, "v": None}


@app.route("/phone/api/data")
def phone_api_data():
    """Schwerere Daten (Kalender, Gehirn, Mails) - 45 s zwischengespeichert, damit
    haeufiges Abfragen vom Handy keine Google-/IMAP-Aufrufe auslost."""
    if _phone_data_cache["v"] is not None and time.time() - _phone_data_cache["t"] < 45 and not request.args.get("fresh"):
        return jsonify(_phone_data_cache["v"])
    out = {}
    try:
        events, err = get_upcoming_events(days=30, max_results=40)
        out["events"], out["events_error"] = events or [], err
    except Exception as e:
        out["events"], out["events_error"] = [], str(e)
    nodes = [n for n in _brain_load() if not str(n.get("key", "")).startswith(_BRAIN_LIVE_PREFIXES)]
    out["brain"] = [{"text": n["text"], "cat": n.get("cat", "Wissen")} for n in nodes][-400:]
    try:
        mails, err = get_recent_emails(unread_only=True, max_results=8)
        mails = [m for m in (mails or []) if not _is_spam_sender(m.get("from_name") or m.get("from", ""))]
        out["mails"] = [{"id": m.get("id", ""), "from": m.get("from_name") or m.get("from", ""), "subject": m.get("subject", "")} for m in mails]
        out["mails_error"] = err
    except Exception as e:
        out["mails"], out["mails_error"] = [], str(e)
    _phone_data_cache.update(t=time.time(), v=out)
    return jsonify(out)


@app.route("/phone/api/mail")
def phone_api_mail():
    return jsonify(_mail_full(request.args.get("id", "")))


@app.route("/phone/api/spam", methods=["POST"])
def phone_api_spam():
    """Vom Handy aus einen Absender als Spam markieren - gleiche Wirkung wie am PC:
    taucht danach bei beiden nicht mehr in den Benachrichtigungen auf."""
    data = request.get_json(silent=True) or {}
    frm = (data.get("from") or "").strip()
    if not frm:
        return jsonify({"error": "Kein Absender angegeben."}), 400
    _add_spam_sender(frm)   # nur lokal gemerkt - im Postfach wird nichts veraendert
    _phone_data_cache["v"] = None
    return jsonify({"error": None})


@app.route("/phone/api/control", methods=["POST"])
def phone_api_control():
    body = request.get_json(silent=True) or {}
    a = str(body.get("action") or "")
    if a in ("up", "down", "mute", "play_pause", "next", "previous", "seek"):
        msg = _media_control(a, body.get("ms"))
    elif a == "lock":
        if IS_WIN:
            ctypes.windll.user32.LockWorkStation()
            msg = "PC gesperrt."
        else:
            msg = "PC gesperrt." if _lx.lock_screen() else "Sperren nicht moeglich (loginctl/xdg-screensaver fehlt)."
    elif a == "quit":
        threading.Timer(0.6, _hub_exit, args=("per Handy beendet",)).start()
        msg = "A.R.I wird beendet."
    else:
        return jsonify({"error": "Unbekannte Aktion"}), 400
    return jsonify({"message": msg})


# --- Schnelle Bildschirmaufnahme (GDI, direkt auf Zielgroesse verkleinert) ---
# ImageGrab liest immer den vollen Bildschirm in Python-Speicher (~50 ms bei 3440x1440).
# StretchBlt verkleinert schon in GDI; zusammen mit parallelen Aufnahmen (siehe
# phone_api_stream) sind so 30-50 Bilder/s moeglich.
if IS_WIN:
    _gdi_user32 = ctypes.WinDLL("user32", use_last_error=True)
    _gdi_gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    _gdi_user32.GetDC.restype = ctypes.c_void_p
    _gdi_user32.GetDC.argtypes = [ctypes.c_void_p]
    _gdi_user32.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _gdi_gdi32.CreateCompatibleDC.restype = ctypes.c_void_p
    _gdi_gdi32.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
    _gdi_gdi32.CreateCompatibleBitmap.restype = ctypes.c_void_p
    _gdi_gdi32.CreateCompatibleBitmap.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    _gdi_gdi32.SelectObject.restype = ctypes.c_void_p
    _gdi_gdi32.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _gdi_gdi32.DeleteObject.argtypes = [ctypes.c_void_p]
    _gdi_gdi32.DeleteDC.argtypes = [ctypes.c_void_p]
    _gdi_gdi32.SetStretchBltMode.argtypes = [ctypes.c_void_p, ctypes.c_int]
    _gdi_gdi32.StretchBlt.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint32]
    _gdi_gdi32.GetDIBits.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint]


class _BmiHeader(ctypes.Structure):
    _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32), ("biHeight", ctypes.c_int32),
                ("biPlanes", ctypes.c_uint16), ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
                ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32), ("biYPelsPerMeter", ctypes.c_int32),
                ("biClrUsed", ctypes.c_uint32), ("biClrImportant", ctypes.c_uint32)]


def _gdi_grab(target_w, smooth=True):
    """Hauptbildschirm direkt auf target_w Pixel Breite verkleinert -> (PIL-Bild, Bildschirmbreite, -hoehe)."""
    from PIL import Image
    sw, sh = _gdi_user32.GetSystemMetrics(0), _gdi_user32.GetSystemMetrics(1)
    tw = min(int(target_w), sw)
    th = max(1, round(sh * tw / sw))
    hdc = _gdi_user32.GetDC(None)
    mdc = _gdi_gdi32.CreateCompatibleDC(hdc)
    bmp = _gdi_gdi32.CreateCompatibleBitmap(hdc, tw, th)
    old = _gdi_gdi32.SelectObject(mdc, bmp)
    try:
        _gdi_gdi32.SetStretchBltMode(mdc, 4 if smooth else 3)  # HALFTONE (schoener) / COLORONCOLOR (schneller)
        _gdi_gdi32.StretchBlt(mdc, 0, 0, tw, th, hdc, 0, 0, sw, sh, 0x00CC0020)
        bmi = _BmiHeader(40, tw, -th, 1, 32, 0, 0, 0, 0, 0, 0)
        buf = ctypes.create_string_buffer(tw * th * 4)
        _gdi_gdi32.GetDIBits(mdc, bmp, 0, th, buf, ctypes.byref(bmi), 0)
        return Image.frombuffer("RGB", (tw, th), buf, "raw", "BGRX", 0, 1).copy(), sw, sh
    finally:
        _gdi_gdi32.SelectObject(mdc, old)
        _gdi_gdi32.DeleteObject(bmp)
        _gdi_gdi32.DeleteDC(mdc)
        _gdi_user32.ReleaseDC(None, hdc)


def _grab_frame_jpeg(w, quality, cursor=True, smooth=True):
    from PIL import ImageDraw
    import io
    try:
        img, sw, sh = _gdi_grab(w, smooth) if IS_WIN else _lx.grab_screen(w, smooth)
    except Exception:
        from PIL import ImageGrab
        img = ImageGrab.grab().convert("RGB")
        sw, sh = img.size
        if img.width > w:
            img = img.resize((w, max(1, round(img.height * w / img.width))))
    if cursor:
        try:
            if IS_WIN:
                pt = _Point()
                ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                px, py = pt.x, pt.y
            else:
                px, py = _lx.cursor_pos()
            k = img.width / float(sw)
            cx, cy = px * k, py * k
            d = ImageDraw.Draw(img)
            r = max(5, img.width // 120)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=(255, 45, 120), width=max(2, r // 3))
            d.ellipse((cx - 2, cy - 2, cx + 2, cy + 2), fill=(255, 255, 255))
        except Exception:
            pass
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=quality)
    return buf.getvalue()


def _screen_params():
    def num(name, default, lo, hi):
        try:
            return max(lo, min(hi, int(request.args.get(name, default))))
        except ValueError:
            return default
    return num("w", 900, 300, 1920), num("q", 55, 25, 90), request.args.get("cursor", "1") != "0"


@app.route("/phone/api/screen")
def phone_api_screen():
    w, q, cur = _screen_params()
    resp = Response(_grab_frame_jpeg(w, q, cur), mimetype="image/jpeg")
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/phone/api/stream")
def phone_api_stream():
    """Live-Video: Motion-JPEG (Einzelbilder als Endlos-Strom). Bilder, die sich nicht
    aendern, werden nicht erneut gesendet (spart Daten). Endet, wenn das Handy trennt."""
    w, q, cur = _screen_params()
    try:
        fps = max(1, min(60, int(request.args.get("fps", 12))))
    except ValueError:
        fps = 12

    def gen():
        # Mehrere Aufnahmen laufen parallel (GDI-Auslesen wartet zum Teil auf die Grafikkarte) -
        # so werden hohe Bildraten moeglich. Bilder kommen in richtiger Reihenfolge an.
        depth = 1 if fps <= 15 else 2 if fps <= 30 else 3
        smooth = fps <= 15
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=depth)
        pending = collections.deque()
        interval = 1.0 / fps
        slot = time.time()
        last = None
        idle_since = time.time()
        try:
            while True:
                now = time.time()
                if slot > now:
                    time.sleep(slot - now)
                slot = max(slot + interval, time.time() - interval)
                pending.append(ex.submit(_grab_frame_jpeg, w, q, cur, smooth))
                if len(pending) >= depth:
                    data = pending.popleft().result()
                    if data != last or time.time() - idle_since > 4:
                        last = data
                        idle_since = time.time()
                        yield (b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(data)).encode() + b"\r\n\r\n" + data + b"\r\n")
        except GeneratorExit:
            return
        finally:
            ex.shutdown(wait=False)

    resp = Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Accel-Buffering"] = "no"
    return resp


_MOUSEEVENTF_RIGHTDOWN = 0x0008
_MOUSEEVENTF_RIGHTUP = 0x0010
_MOUSEEVENTF_WHEEL = 0x0800


def _mouse_send(fx, fy, flags, data=0):
    if not IS_WIN:
        return   # Linux: phone_api_click nutzt _lx.mouse_action direkt
    extra = ctypes.c_ulong(0)
    ax = max(0, min(65535, int(fx * 65535)))
    ay = max(0, min(65535, int(fy * 65535)))
    evt = _Input(_INPUT_MOUSE, _InputUnion(mi=_MouseInput(ax, ay, data & 0xFFFFFFFF, flags, 0, ctypes.pointer(extra))))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(evt), ctypes.sizeof(_Input))


@app.route("/phone/api/click", methods=["POST"])
def phone_api_click():
    d = request.get_json(silent=True) or {}
    try:
        fx = max(0.0, min(1.0, float(d.get("x"))))
        fy = max(0.0, min(1.0, float(d.get("y"))))
    except (TypeError, ValueError):
        return jsonify({"error": "x/y fehlen"}), 400
    if not IS_WIN:
        ok = _lx.mouse_action(fx, fy, str(d.get("kind") or "left"), int(d.get("amount", 3) or 0))
        return jsonify({"ok": bool(ok)}) if ok else (jsonify({"error": "Maussteuerung nicht moeglich (xdotool und X11-Sitzung noetig)."}), 500)
    _mouse_send(fx, fy, _MOUSEEVENTF_MOVE | _MOUSEEVENTF_ABSOLUTE)
    kind = d.get("kind")
    if kind == "scroll":
        delta = -120 * max(-10, min(10, int(d.get("amount", 3))))
        _mouse_send(fx, fy, _MOUSEEVENTF_WHEEL | _MOUSEEVENTF_ABSOLUTE, delta)
    elif kind == "move":
        pass
    else:
        down, up = (_MOUSEEVENTF_RIGHTDOWN, _MOUSEEVENTF_RIGHTUP) if kind == "right" else (_MOUSEEVENTF_LEFTDOWN, _MOUSEEVENTF_LEFTUP)
        for _ in range(2 if kind == "double" else 1):
            _mouse_send(fx, fy, down | _MOUSEEVENTF_ABSOLUTE)
            _mouse_send(fx, fy, up | _MOUSEEVENTF_ABSOLUTE)
            time.sleep(0.06)
    return jsonify({"ok": True})


@app.route("/phone/api/type", methods=["POST"])
def phone_api_type():
    d = request.get_json(silent=True) or {}
    if d.get("text"):
        _type_text(str(d["text"])[:500])
    if d.get("key"):
        if not _press_key_combo(str(d["key"])[:40]):
            return jsonify({"error": "Unbekannte Taste"}), 400
    return jsonify({"ok": True})


# --- Einstellungen PC <-> Handy ---------------------------------------------
# Das HUD schickt seine (nicht geheimen) Einstellungen als Momentaufnahme an den Hub;
# Aenderungen vom Handy landen als "Patch" in einer Warteschlange, die das HUD abholt
# und anwendet (auch wenn das HUD erst spaeter geoeffnet wird).
_HUD_KEYS = {
    "language": lambda v: isinstance(v, str) and len(v) <= 8,
    "volumeTarget": lambda v: v in ("windows", "spotify"),
    "volume": lambda v: isinstance(v, (int, float)) and 0 <= v <= 1,
    "rate": lambda v: isinstance(v, (int, float)) and 0.5 <= v <= 2,
    "pitch": lambda v: isinstance(v, (int, float)) and 0 <= v <= 2,
    "primary": lambda v: isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v) is not None,
    "accent": lambda v: isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v) is not None,
    "pollInterval": lambda v: v in (2000, 3000, 5000, 10000, 15000),
    "notifAutoRefresh": lambda v: isinstance(v, bool),
    "notifShowRefreshBtn": lambda v: isinstance(v, bool),
    "remindEnabled": lambda v: isinstance(v, bool),
    "remindLeads": lambda v: isinstance(v, list) and all(x in (1440, 60, 30, 15, 10, 5) for x in v),
    "performanceMode": lambda v: isinstance(v, bool),
    "economy": lambda v: isinstance(v, bool),
    "provider": lambda v: v in _PROVIDER_CLIENTS,
    "hiddenPanels": lambda v: isinstance(v, list) and all(isinstance(x, str) and len(x) < 30 for x in v),
}
_hud_state = {"settings": {}, "tiles": [], "patch": {}}


def _hud_clean(d):
    return {k: v for k, v in (d or {}).items() if k in _HUD_KEYS and _HUD_KEYS[k](v)}


@app.route("/phone/admin/hud-snapshot", methods=["POST"])
def phone_admin_hud_snapshot():
    d = request.get_json(silent=True) or {}
    _hud_state["settings"] = _hud_clean(d.get("settings"))
    tiles = d.get("tiles")
    if isinstance(tiles, list):
        _hud_state["tiles"] = [{"pid": str(t.get("pid"))[:30], "title": str(t.get("title"))[:40]} for t in tiles if isinstance(t, dict)][:30]
    # Aenderungen, die das HUD schon kennt, aus dem Patch streichen
    _hud_state["patch"] = {k: v for k, v in _hud_state["patch"].items() if _hud_state["settings"].get(k) != v}
    return jsonify({"error": None})


@app.route("/phone/admin/hud-patch", methods=["GET"])
def phone_admin_hud_patch():
    patch = _hud_state["patch"]
    keys = _hud_keys_pending["v"]
    _hud_keys_pending["v"] = None
    return jsonify({"patch": dict(patch), "apiKeys": keys})


_hud_keys_pending = {"v": None}


def _clean_keys(ak):
    if not isinstance(ak, dict):
        return None
    out = {}
    for p in ("anthropic", "openai", "gemini"):
        if p in ak:
            out[p] = str(ak.get(p) or "").strip()[:300]
    if "groq" in ak:
        g = ak.get("groq")
        g = g if isinstance(g, list) else [g]
        out["groq"] = [str(k).strip()[:300] for k in g if k][:5]
    return out


@app.route("/phone/api/sync", methods=["GET", "POST"])
def phone_api_sync():
    """Vollstaendiger Abgleich mit der Handy-App: Gehirn (in beide Richtungen, inkl. Loeschungen),
    Einstellungen und API-Schluessel. Wird nur mit gueltigem Geraete-Token erreicht."""
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        deleted = {str(t).strip().lower() for t in (d.get("deleted") or [])[:500] if str(t).strip()}
        if deleted:
            with _brain_lock:
                nodes = [n for n in _brain_load() if n["text"].strip().lower() not in deleted]
                _brain_save(nodes)
        for n in (d.get("brain") or [])[:600]:
            if isinstance(n, dict) and str(n.get("text") or "").strip().lower() not in deleted and not str(n.get("text") or "").startswith(_MUSIC_PREFIXES):
                _brain_add(str(n.get("text") or ""), str(n.get("cat") or "")[:30] or None)
        _hud_state["patch"].update(_hud_clean(d.get("settings")))
        ak = _clean_keys(d.get("apiKeys"))
        if ak:
            cfg = dict(_phone_cfg())
            st = dict(cfg.get("settings") or {})
            keys = dict(st.get("all_keys") or {})
            keys.update(ak)
            st["all_keys"] = keys
            prov = _hud_state["patch"].get("provider") or _hud_state["settings"].get("provider") or st.get("provider") or "anthropic"
            st["provider"] = prov
            st["api_key"] = "" if prov == "groq" else str(keys.get(prov) or "")
            st["groq_api_keys"] = list(keys.get("groq") or [])
            cfg["settings"] = st
            _phone_save(cfg)
            _hud_keys_pending["v"] = keys
    merged = dict(_hud_state["settings"])
    merged.update(_hud_state["patch"])
    nodes = [n for n in _brain_load() if not str(n.get("key", "")).startswith(_BRAIN_LIVE_PREFIXES)]
    return jsonify({
        "brain": [{"text": n["text"], "cat": n.get("cat", "Wissen")} for n in nodes],
        "settings": merged,
        "apiKeys": dict((_phone_cfg().get("settings") or {}).get("all_keys") or {}),
        "hud_seen": bool(_hud_state["settings"]),
        "time": int(time.time()),
    })


@app.route("/phone/api/settings", methods=["GET", "POST"])
def phone_api_settings():
    if request.method == "POST":
        patch = _hud_clean((request.get_json(silent=True) or {}).get("patch"))
        _hud_state["patch"].update(patch)
    merged = dict(_hud_state["settings"])
    merged.update(_hud_state["patch"])
    return jsonify({"settings": merged, "tiles": _hud_state["tiles"], "hud_seen": bool(_hud_state["settings"])})


# --- Selbst beenden -------------------------------------------------------
# Das HUD schickt alle ~10 s einen Herzschlag (/heartbeat, ausserdem zaehlt
# /status). Kommt 20 Sekunden lang keiner (Browser/Tab zu), beendet sich der Hub.
IDLE_SHUTDOWN_SECONDS = 20
_hub_last_seen = time.time()
_TRAY_ACTIVE = False   # True, sobald das Symbol im Infobereich (unten rechts) da ist (haelt den Hub NICHT mehr am Leben: Fenster zu = A.R.I beendet)
_hub_started = time.time()
_hub_had_window = False   # wurde schon ein HUD-Fenster gesehen? Bis dahin hat das Fenster beim Start etwas Zeit, sich zu oeffnen


# Schliesst man das letzte HUD-Fenster/den Tab (X im Browser), meldet die Seite
# "closing". Der Hub wartet kurz (CLOSE_GRACE_SECONDS) - kommt in der Zeit ein
# Herzschlag (z.B. nach F5/Neuladen), bleibt er an, sonst beendet er sich.
CLOSE_GRACE_SECONDS = 5
_hub_close_deadline = None


@app.before_request
def _note_hud_activity():
    global _hub_last_seen, _hub_close_deadline, _hub_had_window
    if request.path in ("/heartbeat", "/status") and _is_local_request():   # nur das HUD-Fenster an diesem PC zaehlt - das Handy fragt /status auch ab und hielt den Hub sonst ewig am Leben
        _hub_had_window = True
        _hub_last_seen = time.time()
        _hub_close_deadline = None


@app.route("/closing", methods=["POST"])
def closing():
    global _hub_close_deadline
    if not request.is_json:
        return jsonify({"ok": False}), 400
    _hub_close_deadline = time.time() + CLOSE_GRACE_SECONDS
    return jsonify({"ok": True})


@app.route("/heartbeat", methods=["POST"])
def heartbeat():
    return jsonify({"ok": True})


def _tray_quit():
    """Tray > Beenden: das Symbol kann zu einem Fenster-Prozess gehoeren, waehrend der eigentliche Hub (z.B. als Administrator) in einem anderen
    Prozess laeuft - deshalb dem Hub auf Port 5000 zuerst selbst das Beenden sagen, danach diesen Prozess beenden."""
    try:
        import urllib.request
        req = urllib.request.Request("http://127.0.0.1:5000/shutdown", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass
    _hub_exit("per Tray-Symbol beendet")


_QUIT_FLAG = os.path.join(DATA_DIR, "hub.quit")


def _close_hud_windows():
    """Schliesst das HUD-Fenster (Command Center) sofort - es laeuft meist in einem anderen Prozess, daher ueber eine Schliessen-Nachricht an das Fenster."""
    if not IS_WIN:
        return
    try:
        u32 = ctypes.windll.user32
        u32.FindWindowW.restype = ctypes.c_void_p
        u32.FindWindowW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p]
        u32.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_size_t]
        for _ in range(4):   # falls (selten) mehrere Fenster offen sind
            hwnd = u32.FindWindowW(None, "A.R.I — Command Center")
            if not hwnd:
                break
            u32.PostMessageW(hwnd, 0x0010, 0, 0)   # WM_CLOSE
            time.sleep(0.05)
    except Exception:
        pass


def _hub_exit(reason):
    print(f"[hub] Beende A.R.I: {reason}")
    _close_hud_windows()
    try:   # Marke fuer das HUD-Fenster (laeuft evtl. in einem anderen Prozess): der Hub wurde mit Absicht beendet, das Fenster soll mit zugehen
        with open(_QUIT_FLAG, "w") as _f:
            _f.write(str(time.time()))
    except OSError:
        pass
    try:
        _stats_save()
    except Exception:
        pass
    try:
        _dev_console_hide()
    except Exception:
        pass
    try:
        os.remove(os.path.join(DATA_DIR, "hub.pid"))
    except OSError:
        pass
    os._exit(0)


def _idle_watchdog():
    global _hub_last_seen, _hub_close_deadline
    last_tick = time.time()
    while True:
        time.sleep(1)
        now = time.time()
        if _hub_close_deadline is not None and now >= _hub_close_deadline:
            _hub_exit("HUD-Fenster wurde geschlossen")
        if now - last_tick > 30:
            # Rechner war im Ruhezustand: Wartezeit neu starten, sonst wuerde der
            # Hub direkt nach dem Aufwachen beendet, obwohl das HUD noch offen ist.
            _hub_last_seen = now
        last_tick = now
        if (not _hub_had_window) and (_phone_keep_alive() or now - _hub_started < 90):
            # Ohne HUD-Fenster bleibt der Hub nur an, solange noch nie eines offen war (Handy-Dauerbetrieb bei reinem Hintergrund-Start, bzw. beim Start, bis sich das Fenster oeffnet).
            # Sonst gilt: Fenster zu = A.R.I beendet - samt Hub und Tray-Symbol.
            _hub_last_seen = now
            _hub_close_deadline = None
        # Auch bei offener Dev-Konsole: ohne HUD-Fenster beendet sich der Hub nach
        # IDLE_SHUTDOWN_SECONDS (die Konsole geht dabei mit zu).
        if now - _hub_last_seen > IDLE_SHUTDOWN_SECONDS:
            _hub_exit(f"kein HUD-Fenster seit {IDLE_SHUTDOWN_SECONDS} Sekunden")


@app.route("/shutdown", methods=["POST"])
def shutdown():
    """Beenden-Button in den Einstellungen. Nur mit JSON-Body (loest bei
    fremden Webseiten einen CORS-Preflight aus und wird dadurch blockiert)."""
    if not request.is_json:
        return jsonify({"ok": False}), 400
    threading.Timer(0.6, _hub_exit, args=("per Beenden-Button",)).start()
    return jsonify({"ok": True})


_dev_console_proc = None


def _dev_console_hide():
    global _dev_console_proc
    proc, _dev_console_proc = _dev_console_proc, None
    if proc is not None and proc.poll() is None:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
        else:
            try:
                proc.terminate()
            except OSError:
                pass


@app.route("/dev/console", methods=["POST"])
def dev_console():
    """Konsolen-Fenster (Live-Log des Hubs) ein-/ausblenden. Einblenden nur mit
    Dev-Passwort; Ausblenden darf jeder (schliesst nur das Log-Fenster)."""
    global _dev_console_proc
    data = request.get_json(silent=True) or {}
    if not data.get("show"):
        _dev_console_hide()
        return jsonify({"ok": True, "visible": False})
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    if not _HEADLESS:
        return jsonify({"ok": True, "visible": True, "note": "Hub laeuft schon in einem sichtbaren Fenster."})
    if not IS_WIN:
        if _dev_console_proc is None or _dev_console_proc.poll() is not None:
            _dev_console_proc = _lx.open_log_terminal(HUB_LOG_FILE)
        return jsonify({"ok": True, "visible": _dev_console_proc is not None})
    if _dev_console_proc is None or _dev_console_proc.poll() is not None:
        path = HUB_LOG_FILE.replace("'", "''")
        cmd = ("$Host.UI.RawUI.WindowTitle='A.R.I Hub Konsole'; "
               "Get-Content -Wait -Tail 80 -Encoding UTF8 -LiteralPath '" + path + "'")
        _dev_console_proc = subprocess.Popen(
            ["powershell", "-NoLogo", "-NoExit", "-Command", cmd],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
        )
    return jsonify({"ok": True, "visible": True})


DEV_STATS_KEY_FILE = os.path.join(DATA_DIR, "dev_stats_key.txt")


@app.route("/dev/stats-view", methods=["POST"])
def dev_stats_view():
    """DEV: holt die anonyme Nutzungsstatistik vom Cloudflare-Worker (Admin-Schluessel nur lokal in data/, nie im Update)."""
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    if not _is_local_request():
        return jsonify({"ok": False, "error": "verboten"}), 403
    new_key = str(data.get("key") or "").strip()
    try:
        if new_key:
            if not re.match(r"^[A-Za-z0-9_\-]{8,200}$", new_key):
                return jsonify({"ok": False, "error": "Schluessel hat ein ungueltiges Format."})
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(DEV_STATS_KEY_FILE, "w", encoding="utf-8") as f:
                f.write(new_key)
        key = ""
        if os.path.exists(DEV_STATS_KEY_FILE):
            with open(DEV_STATS_KEY_FILE, "r", encoding="utf-8") as f:
                key = f.read().strip()
    except OSError as e:
        return jsonify({"ok": False, "error": str(e)})
    ep = _stats_endpoint()
    if not ep:
        return jsonify({"ok": False, "error": "Keine Statistik-Adresse (stats-config.json) eingetragen."})
    if not key:
        return jsonify({"ok": False, "error": "Noch kein Admin-Schluessel gespeichert.", "need_key": True})
    try:
        req = urllib.request.Request(ep + "/api/stats?key=" + key, headers={"User-Agent": "ARI-Stats"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            stats = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return jsonify({"ok": False, "error": f"Abruf fehlgeschlagen: {e}"})
    return jsonify({"ok": True, "stats": stats, "url": ep + "/?key=" + key})


@app.route("/dev/info", methods=["POST"])
def dev_info():
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    proc = psutil.Process(os.getpid())
    hub_uptime_s = int(time.time() - _HUB_START_TIME)
    try:
        screenshot_count = len([f for f in os.listdir(SCREENSHOT_DIR) if f.endswith(".png")]) if os.path.isdir(SCREENSHOT_DIR) else 0
    except OSError:
        screenshot_count = 0
    return jsonify({
        "ok": True,
        "data": {
            "python_version": sys.version.split()[0],
            "platform": sys.platform,
            "pid": os.getpid(),
            "hub_uptime_s": hub_uptime_s,
            "hub_ram_mb": round(proc.memory_info().rss / 1024 ** 2, 1),
            "dashboard_dir": DASHBOARD_DIR,
            "judged_email_ids_count": len(_judged_email_ids),
            "screenshot_count": screenshot_count,
            "piper_available": os.path.isfile(PIPER_EXE),
            "is_admin": bool(IS_WIN and ctypes.windll.shell32.IsUserAnAdmin()),
            "admin_task": _admin_autostart_installed(),
            "cpu_temp_c": _read_temps()[0],
            "secrets_connected": sorted(_load_secrets().keys()),
        },
    })


@app.route("/dev/clear-seen-emails", methods=["POST"])
def dev_clear_seen_emails():
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    _judged_email_ids.clear()
    _save_seen_email_ids(_judged_email_ids)
    return jsonify({"ok": True})


@app.route("/dev/clear-screenshots", methods=["POST"])
def dev_clear_screenshots():
    data = request.get_json(silent=True) or {}
    if not _check_dev_password(data.get("password")):
        return jsonify({"ok": False, "error": "Falsches Passwort."}), 403
    removed = 0
    try:
        for f in os.listdir(SCREENSHOT_DIR):
            if f.endswith(".png"):
                os.remove(os.path.join(SCREENSHOT_DIR, f))
                removed += 1
    except OSError:
        pass
    return jsonify({"ok": True, "removed": removed})


# Lokale Spracherkennung (faster-whisper, laeuft auf der CPU, offline nach dem einmaligen
# Modell-Download ~460 MB nach data/whisper). Noetig, weil das native Fenster (WebView2)
# keinen eingebauten Spracherkennungs-Dienst hat (Web Speech API -> Fehler "network").
_STT_MODEL_NAME = "small"
_STT_FAST_MODEL_NAME = "base"   # ~3x schneller: fuer kurze Aeusserungen (das Weckwort "Ari"), damit A.R.I sofort reagiert
_STT_FAST_MAX_SECONDS = 1.0   # nur ganz kurze Aeusserungen (Weckwort) nehmen das schnelle Modell - Saetze das genauere
_stt_model = None
_stt_fast = None
_stt_state = {"state": "idle", "msg": ""}   # idle | loading | ready | error
_stt_lock = threading.Lock()
_STT_HALLUCINATIONS = (
    "untertitel", "amara.org", "vielen dank fürs zuschauen", "danke fürs zuschauen",
    "subtitles by", "thanks for watching", "copyright",
)


def _stt_load():
    global _stt_model
    with _stt_lock:
        if _stt_model is not None:
            _stt_state.update(state="ready", msg="")
            return
        _stt_state.update(state="loading", msg="Lade Spracherkennungs-Modell (beim ersten Mal ~460 MB Download) ...")
        try:
            from faster_whisper import WhisperModel
            _stt_model = WhisperModel(_STT_MODEL_NAME, device="cpu", compute_type="int8",
                                      download_root=os.path.join(DATA_DIR, "whisper"))
            _stt_state.update(state="ready", msg="")
            try:   # kleines Zusatzmodell fuer kurze Aeusserungen - fehlt es, nutzt alles das grosse Modell
                global _stt_fast
                _stt_fast = WhisperModel(_STT_FAST_MODEL_NAME, device="cpu", compute_type="int8",
                                         download_root=os.path.join(DATA_DIR, "whisper"))
            except Exception as e2:
                print(f"[stt] Schnelles Modell nicht verfuegbar ({e2}) - nutze nur das grosse.")
        except Exception as e:
            _stt_state.update(state="error", msg=f"{type(e).__name__}: {e}")
            print(f"[stt] Modell konnte nicht geladen werden: {e}")


@app.route("/stt/prepare", methods=["POST"])
def stt_prepare():
    if _stt_model is None and _stt_state["state"] != "loading":
        threading.Thread(target=_stt_load, daemon=True).start()
        _stt_state.update(state="loading", msg="Lade Spracherkennungs-Modell ...")
    return jsonify(_stt_state)


@app.route("/stt/status")
def stt_status():
    return jsonify(_stt_state)


@app.route("/stt", methods=["POST"])
def stt():
    """Roh-PCM (16 kHz, mono, int16 little-endian) im Body, ?lang=de -> {"text": ...}."""
    _stats_track("voice_in")
    if _stt_model is None:
        return jsonify({"error": "Modell nicht geladen", "state": _stt_state["state"]}), 503
    import numpy as np
    raw = request.get_data()
    if len(raw) < 3200:
        return jsonify({"text": ""})
    audio = np.frombuffer(raw[: len(raw) // 2 * 2], dtype=np.int16).astype(np.float32) / 32768.0
    lang = (request.args.get("lang") or "de").split("-")[0].lower()
    try:
        with _stt_lock:
            probe = request.args.get("fast") == "1"   # Weckwort-Schnelltest aus dem HUD: immer das schnelle Modell
            model = _stt_fast if (_stt_fast is not None and (probe or len(audio) < 16000 * _STT_FAST_MAX_SECONDS)) else _stt_model
            segs, _ = model.transcribe(audio, language=lang, beam_size=1 if (probe or model is _stt_fast) else 3, condition_on_previous_text=False)
            parts = []
            dropped = []
            # Kurze Aeusserungen (das Weckwort "Ari" allein!) bekommen von Whisper oft schlechte Sicherheitswerte - dort laxer pruefen,
            # sonst wird genau das wichtigste Wort verworfen.
            short = len(audio) < 16000 * 2.0
            max_nsp, min_lp = (0.85, -2.0) if short else (0.6, -1.2)
            for s in segs:
                if s.no_speech_prob > max_nsp or s.avg_logprob < min_lp:
                    dropped.append((s.text.strip(), round(s.no_speech_prob, 2), round(s.avg_logprob, 2)))
                    continue
                parts.append(s.text)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    text = " ".join(p.strip() for p in parts).strip()
    low = text.lower()
    if any(h in low for h in _STT_HALLUCINATIONS):
        text = ""
    print(f"[stt] {len(audio) / 16000:.1f}s -> {text[:80]!r}" + (f" (verworfen: {dropped})" if dropped else ""))
    return jsonify({"text": text})


@app.route("/speak", methods=["POST"])
def speak():
    """Spricht Text lokal per Piper TTS (kein Internet, keine Kosten) und
    gibt die erzeugte WAV-Datei zurueck. Das Frontend faellt bei jedem Fehler
    hier auf window.speechSynthesis zurueck, damit A.R.I nie stumm bleibt."""
    _stats_track("voice_out")
    data = request.get_json(silent=True) or {}
    text = data.get("text")
    text = EMOJI_RE.sub("", text).strip() if isinstance(text, str) else ""
    voice = data.get("voice") if isinstance(data.get("voice"), str) else "thorsten"
    if not text:
        return jsonify({"error": "Kein Text zum Sprechen angegeben."}), 400
    if voice.startswith("edge:"):
        voice_id = _EDGE_VOICE_IDS.get(voice)
        if voice_id is None:
            return jsonify({"error": f"Unbekannte Edge-Stimme '{voice}'."}), 400
        try:
            audio_bytes = _edge_tts_synthesize(text, voice_id)
        except Exception as e:
            return jsonify({"error": f"Edge-Stimme fehlgeschlagen (Internet vorhanden?): {e}"}), 500
        if not audio_bytes:
            return jsonify({"error": "Edge-Stimme hat kein Audio geliefert (Internet vorhanden?)."}), 500
        return Response(audio_bytes, mimetype="audio/mpeg")
    model_name = PIPER_VOICE_MODELS.get(voice)
    if model_name is None:
        return jsonify({"error": f"Unbekannte Piper-Stimme '{voice}'."}), 400
    if not os.path.isfile(PIPER_EXE):
        return jsonify({"error": f"Piper-Binary nicht gefunden unter '{PIPER_EXE}'. piper.exe (+ DLLs) aus den GitHub-Releases in den Ordner 'piper/' legen."}), 500
    model_path = os.path.join(PIPER_VOICES_DIR, model_name)
    config_path = model_path + ".json"
    if not os.path.isfile(model_path) or not os.path.isfile(config_path):
        return jsonify({"error": f"Stimmmodell '{voice}' nicht gefunden in '{PIPER_VOICES_DIR}'. .onnx + .onnx.json dort ablegen."}), 500

    wav_path = os.path.join(tempfile.gettempdir(), f"ari_speak_{uuid.uuid4().hex}.wav")
    try:
        result = subprocess.run(
            [PIPER_EXE, "--model", model_path, "--config", config_path, "--output_file", wav_path],
            input=text.encode("utf-8"),
            capture_output=True,
            timeout=30,
        )
        if result.returncode != 0 or not os.path.isfile(wav_path):
            err = result.stderr.decode("utf-8", errors="ignore").strip()
            return jsonify({"error": f"Piper-Aufruf fehlgeschlagen: {err[:300] or 'unbekannter Fehler'}"}), 500
        with open(wav_path, "rb") as f:
            audio_bytes = f.read()
        return Response(audio_bytes, mimetype="audio/wav")
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Piper hat zu lange gebraucht (Timeout)."}), 500
    except OSError as e:
        return jsonify({"error": f"Piper konnte nicht gestartet werden: {e}"}), 500
    finally:
        try:
            os.remove(wav_path)
        except OSError:
            pass


# --- CPU/GPU-Temperatur ueber LibreHardwareMonitorLib -----------------------------------
# Keine sichtbare Zusatz-App, nur eine mitgelieferte .NET-Bibliothek (tools/lhm/*.dll), die
# per pythonnet direkt in hub.py eingebunden wird. GPU-Werte gehen ohne Administrator-Rechte
# (nutzt intern dieselbe treiberseitige Schnittstelle wie Radeon Software/Afterburner);
# CPU-Werte brauchen Administrator-Rechte (Windows erlaubt den dafuer noetigen MSR-Zugriff
# sonst niemandem, auch keinem anderen Tool) - ohne Admin bleibt cpu_temp_c einfach None,
# kein Fehler, nichts stuerzt ab.
_lhm_computer = None
_lhm_init_failed = False
_lhm_lock = threading.Lock()
_GPU_DISCRETE_RE = re.compile(r"RTX|GTX|RX \d|Radeon RX|Arc A\d", re.IGNORECASE)


_LHM_FILES = ("LibreHardwareMonitorLib.dll", "HidSharp.dll", "System.Memory.dll", "System.Numerics.Vectors.dll",
              "System.Runtime.CompilerServices.Unsafe.dll", "System.Threading.AccessControl.dll")
_lhm_error = ""            # letzter Grund, warum die Sensoren nicht gehen (wird im HUD angezeigt)
_lhm_download_state = {"started": False}


def _lhm_present():
    libdir = os.path.join(DASHBOARD_DIR, "tools", "lhm")
    return all(os.path.exists(os.path.join(libdir, n)) for n in _LHM_FILES)


def _ensure_lhm():
    """Das Sensor-Modul (tools/lhm, fuer CPU-/GPU-Temperatur) fehlt auf Rechnern, die mit einer aelteren Version eingerichtet wurden - das
    normale Update bringt es nicht mit (die Dateien sind im laufenden Hub gesperrt). Dann wird es automatisch von der A.R.I-Seite geladen,
    per SHA-256 geprueft und nur mit den erlaubten Dateinamen entpackt."""
    global _lhm_error, _lhm_init_failed
    try:
        d = _update_fetch()
        name, want = str(d.get("lhm_zip", "")), str(d.get("lhm_sha256", "")).lower()
        if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", name) or not re.fullmatch(r"[0-9a-f]{64}", want):
            _lhm_error = "Sensor-Modul fehlt und ist online noch nicht verfuegbar."
            return False
        tmp = tempfile.mkdtemp(prefix="ari_lhm_")
        zpath = os.path.join(tmp, "lhm.zip")
        req = urllib.request.Request(_UPDATE_BASE + name, headers={"User-Agent": "A.R.I"})
        with urllib.request.urlopen(req, timeout=60) as resp, open(zpath, "wb") as f:
            shutil.copyfileobj(resp, f)
        h = hashlib.sha256()
        with open(zpath, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        if h.hexdigest() != want:
            _lhm_error = "Sensor-Modul: Pruefsumme stimmt nicht - verworfen."
            return False
        import zipfile
        libdir = os.path.join(DASHBOARD_DIR, "tools", "lhm")
        os.makedirs(libdir, exist_ok=True)
        with zipfile.ZipFile(zpath) as z:
            for info in z.infolist():
                base = os.path.basename(info.filename.replace("\\", "/"))
                if info.is_dir() or base not in _LHM_FILES:
                    continue
                with z.open(info) as src, open(os.path.join(libdir, base), "wb") as dst:
                    shutil.copyfileobj(src, dst)
        shutil.rmtree(tmp, ignore_errors=True)
        if _lhm_present():
            print("[temp] Sensor-Modul wurde automatisch installiert.")
            _lhm_error = ""
            _lhm_init_failed = False
            return True
        _lhm_error = "Sensor-Modul unvollstaendig."
    except Exception as e:
        _lhm_error = f"Sensor-Modul konnte nicht geladen werden ({str(e)[:80]})"
        print(f"[temp] {_lhm_error}")
    return False


def _init_lhm():
    global _lhm_computer, _lhm_init_failed, _lhm_error
    if _lhm_computer is not None or _lhm_init_failed or not IS_WIN:
        return
    with _lhm_lock:
        if _lhm_computer is not None or _lhm_init_failed:
            return
        try:
            libdir = os.path.join(DASHBOARD_DIR, "tools", "lhm")
            if not _lhm_present():
                # fehlt: im Hintergrund automatisch holen (nicht das Status-Polling blockieren), spaeter erneut versuchen
                if not _lhm_download_state["started"]:
                    _lhm_download_state["started"] = True
                    threading.Thread(target=_ensure_lhm, daemon=True).start()
                    _lhm_error = "Sensor-Modul wird heruntergeladen ..."
                return
            if libdir not in sys.path:
                sys.path.append(libdir)
            import clr
            import System
            import System.Reflection

            def _resolver(sender, args):
                name = System.Reflection.AssemblyName(args.Name).Name
                path = os.path.join(libdir, name + ".dll")
                return System.Reflection.Assembly.LoadFrom(path) if os.path.exists(path) else None

            System.AppDomain.CurrentDomain.AssemblyResolve += _resolver
            clr.AddReference("LibreHardwareMonitorLib")
            from LibreHardwareMonitor.Hardware import Computer as _LhmComputer
            c = _LhmComputer()
            c.IsCpuEnabled = True
            c.IsGpuEnabled = True
            c.Open()
            _lhm_computer = c
        except Exception as e:
            print(f"[temp] LibreHardwareMonitor konnte nicht geladen werden: {e}")
            _lhm_error = "Sensor-Modul konnte nicht gestartet werden (von Windows blockiert?): " + str(e)[:90]
            _lhm_init_failed = True
            try:   # haeufigster Grund: Dateien tragen die Internet-Markierung ("Zone.Identifier") - entfernen, wirkt nach dem naechsten Start
                subprocess.run(["powershell", "-NoProfile", "-Command", "Get-ChildItem -LiteralPath '" + libdir.replace("'", "''") + "' -File | Unblock-File"],
                               capture_output=True, creationflags=_NOWIN, timeout=30)
            except Exception:
                pass


def _read_temps():
    """Gibt (cpu_temp_c, gpu_temp_c, gpu_percent) zurueck, jeweils None wenn nicht verfuegbar.
    Bei mehreren Grafikkarten (z.B. Notebook mit iGPU+dGPU) wird die "echte" (diskrete)
    bevorzugt, erkannt am Namen (RTX/GTX/RX/Arc) statt an generischen iGPU-Namen wie
    'AMD Radeon(TM) Graphics'. GPU-Auslastung kommt vom 'GPU Core'-Load-Sensor derselben
    (bevorzugten) Karte."""
    if not IS_WIN:
        return None, None, None
    _init_lhm()
    if _lhm_computer is None:
        return None, None, None
    cpu_temp = None
    gpu_temp_candidates = []
    gpu_load_candidates = []
    try:
        from LibreHardwareMonitor.Hardware import SensorType, HardwareType
        for hw in _lhm_computer.Hardware:
            hw.Update()
            if hw.HardwareType == HardwareType.Cpu:
                for s in hw.Sensors:
                    if s.SensorType == SensorType.Temperature and s.Value is not None:
                        name = str(s.Name)
                        v = float(s.Value)
                        if v > 0 and (cpu_temp is None or "Tctl" in name or "Package" in name):
                            cpu_temp = v
            elif hw.HardwareType in (HardwareType.GpuAmd, HardwareType.GpuNvidia, HardwareType.GpuIntel):
                for s in hw.Sensors:
                    if s.SensorType == SensorType.Temperature and s.Value is not None and "Core" in str(s.Name):
                        v = float(s.Value)
                        if v > 0:
                            gpu_temp_candidates.append((str(hw.Name), v))
                    elif s.SensorType == SensorType.Load and s.Value is not None and "Core" in str(s.Name):
                        v = float(s.Value)
                        if v >= 0:
                            gpu_load_candidates.append((str(hw.Name), v))
    except Exception as e:
        print(f"[temp] Fehler beim Lesen: {e}")
        return cpu_temp, None, None
    gpu_temp = None
    if gpu_temp_candidates:
        discrete = [v for n, v in gpu_temp_candidates if _GPU_DISCRETE_RE.search(n)]
        gpu_temp = discrete[0] if discrete else gpu_temp_candidates[0][1]
    gpu_load = None
    if gpu_load_candidates:
        discrete = [v for n, v in gpu_load_candidates if _GPU_DISCRETE_RE.search(n)]
        gpu_load = discrete[0] if discrete else gpu_load_candidates[0][1]
    return cpu_temp, gpu_temp, gpu_load


# ---------------------------------------------------------------------------
# ANONYME NUTZUNGSSTATISTIK (nur mit ausdruecklicher Einwilligung des Nutzers, Opt-in)
# Gezaehlt werden ausschliesslich Funktionsnamen und wie oft sie pro Tag benutzt wurden - nie Inhalte
# (keine Chat-Texte, Titel, Namen, Mails ...). Dazu eine zufaellige Installations-ID (nicht aus Hardware
# abgeleitet, jederzeit zuruecksetz-/loeschbar), Version, Plattform und Sprache. Der Empfaenger ist der
# eigene Cloudflare-Worker aus statistik-server/ (Adresse in stats-config.json). Ohne Adresse oder ohne
# Einwilligung passiert nichts - es wird dann auch nichts mitgezaehlt.
# ---------------------------------------------------------------------------
STATS_FILE = os.path.join(DATA_DIR, "stats.json")
STATS_CONFIG_FILE = os.path.join(DASHBOARD_DIR, "stats-config.json")
_stats_lock = threading.Lock()
_stats = None
_stats_dirty = False
_STATS_FEATURE_RE = re.compile(r"^[a-z0-9_:.-]{1,40}$")
_STATS_KEEP_DAYS = 14
# Nur diese Oberflaechen-Ereignisse nimmt /stats/track an (alles andere wird verworfen)
_STATS_UI_EVENTS = {
    "settings_open", "tour_start", "brain_open", "calendar_day", "patch_notes", "gamemode_toggle",
    "layout_edit", "voice_ptt", "wake_toggle", "mute_toggle", "notif_dismiss", "notif_spam", "auto_setup",
    "media_control", "input_text", "input_voice", "game_editor", "export_settings", "import_settings",
}


def _stats_today():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")


_stats_ep_cache = [0.0, ""]


def _stats_endpoint():
    if time.time() - _stats_ep_cache[0] < 60:
        return _stats_ep_cache[1]
    _stats_ep_cache[1] = _stats_endpoint_read()
    _stats_ep_cache[0] = time.time()
    return _stats_ep_cache[1]


def _stats_endpoint_read():
    ep = (os.environ.get("ARI_STATS_ENDPOINT") or "").strip().rstrip("/")   # nur fuer Entwickler-Tests
    if not ep:
        try:
            with open(STATS_CONFIG_FILE, "r", encoding="utf-8") as f:
                ep = str(json.load(f).get("endpoint") or "").strip().rstrip("/")
        except (OSError, ValueError):
            return ""
    ok = re.match(r"^https://[A-Za-z0-9.-]+(:\d+)?(/[\w./-]*)?$", ep) or re.match(r"^http://(127[.]0[.]0[.]1|localhost)(:\d+)?$", ep)
    return ep if ok else ""


def _stats_load():
    global _stats
    if _stats is not None:
        return _stats
    data = {}
    try:
        with open(STATS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    if not re.match(r"^[a-f0-9-]{16,40}$", str(data.get("id", ""))):
        data["id"] = str(uuid.uuid4())
    if data.get("consent") not in (True, False):
        data["consent"] = None
    if not isinstance(data.get("days"), dict):
        data["days"] = {}
    _stats = data
    return _stats


def _stats_save():
    global _stats_dirty
    with _stats_lock:
        if _stats is None:
            return
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            tmp = STATS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(_stats, f)
            os.replace(tmp, STATS_FILE)
            _stats_dirty = False
        except OSError:
            pass


def _stats_consent():
    with _stats_lock:
        return _stats_load()["consent"]


def _stats_track(name, n=1):
    """Zaehlt eine Funktionsnutzung - tut nichts ohne Einwilligung/Empfaenger-Adresse."""
    global _stats_dirty
    try:
        name = str(name).lower()
        if not _STATS_FEATURE_RE.match(name):
            return
        with _stats_lock:
            st = _stats_load()
            if st["consent"] is not True or not _stats_endpoint():
                return
            day = st["days"].setdefault(_stats_today(), {})
            if name not in day and len(day) >= 100:
                return
            day[name] = int(day.get(name, 0)) + int(n)
            _stats_dirty = True
    except Exception:
        pass


def _stats_lang():
    try:
        buf = ctypes.create_unicode_buffer(85)
        if IS_WIN and ctypes.windll.kernel32.GetUserDefaultLocaleName(buf, 85):
            return buf.value
    except Exception:
        pass
    return (os.environ.get("LANG") or "").split(".")[0].replace("_", "-")


def _stats_payload():
    with _stats_lock:
        st = _stats_load()
        cutoff = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=_STATS_KEEP_DAYS)).strftime("%Y-%m-%d")
        for d in [d for d in st["days"] if d < cutoff]:
            del st["days"][d]
        return {
            "id": st["id"], "v": str(ARI_VERSION_NAME), "platform": "pc-win" if IS_WIN else "pc-linux",
            "lang": _stats_lang(), "days": json.loads(json.dumps(st["days"])),
        }


def _stats_post(path, payload):
    ep = _stats_endpoint()
    if not ep:
        return False
    req = urllib.request.Request(ep + path, data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json", "User-Agent": "ARI-Stats"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return 200 <= resp.status < 300
    except Exception as e:
        print(f"[stats] Senden fehlgeschlagen: {e}")
        return False


def _stats_send():
    """Schickt die Zaehler der letzten Tage (Server ueberschreibt je Tag/Funktion - mehrfaches Senden ist unschaedlich)."""
    if _stats_consent() is not True or not _stats_endpoint():
        return False
    _stats_save()
    return _stats_post("/ingest", _stats_payload())


def _stats_loop():
    time.sleep(25)
    _stats_track("app_start")
    first = True
    while True:
        try:
            if _stats_consent() is True:
                if _stats_dirty:
                    _stats_save()
                if first or int(time.time()) % 10800 < 60:
                    _stats_send()
                    first = False
            elif _stats_dirty:
                _stats_save()
        except Exception as e:
            print(f"[stats] {e}")
        time.sleep(60)


@app.route("/stats/state")
def stats_state():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    st = _stats_load()
    return jsonify({
        "available": bool(_stats_endpoint()), "consent": st["consent"],
        "id": st["id"][:8], "preview": _stats_payload(),
    })


@app.route("/stats/consent", methods=["POST"])
def stats_consent():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    data = request.get_json(silent=True) or {}
    if not isinstance(data.get("consent"), bool):
        return jsonify({"error": "consent fehlt"}), 400
    with _stats_lock:
        st = _stats_load()
        st["consent"] = data["consent"]
    _stats_save()
    if data["consent"]:
        _stats_track("app_start")
        threading.Thread(target=_stats_send, daemon=True).start()
    return jsonify({"ok": True, "consent": data["consent"]})


@app.route("/stats/forget", methods=["POST"])
def stats_forget():
    """Loescht die bisher gesendeten Daten beim Empfaenger und vergibt eine neue zufaellige ID."""
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    with _stats_lock:
        st = _stats_load()
        old_id = st["id"]
        st["id"] = str(uuid.uuid4())
        st["days"] = {}
    _stats_save()
    ok = _stats_post("/forget", {"id": old_id}) if _stats_endpoint() else True
    return jsonify({"ok": bool(ok)})


@app.route("/stats/track", methods=["POST"])
def stats_track():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    name = str((request.get_json(silent=True) or {}).get("name", "")).lower()
    if name in _STATS_UI_EVENTS:
        _stats_track("ui:" + name)
    return jsonify({"ok": True})


@app.route("/stats/send-now", methods=["POST"])
def stats_send_now():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return jsonify({"sent": bool(_stats_send())})


def _collect_status():
    cpu_percent = psutil.cpu_percent(interval=0.2)
    freq = psutil.cpu_freq()
    vm = psutil.virtual_memory()
    down_mbps, up_mbps = get_network_rates()
    cpu_temp_c, gpu_temp_c, gpu_percent = _read_temps()

    return {
        "cpu_percent": round(cpu_percent, 1),
        "ram_percent": round(vm.percent, 1),
        "net_down_mbps": down_mbps,
        "net_up_mbps": up_mbps,
        "cpu_freq_ghz": round(freq.current / 1000, 2) if freq else None,
        "cpu_temp_c": round(cpu_temp_c, 1) if cpu_temp_c else None,
        "gpu_temp_c": round(gpu_temp_c, 1) if gpu_temp_c else None,
        "gpu_percent": round(gpu_percent, 1) if gpu_percent is not None else None,
        "temp_error": _lhm_error if (cpu_temp_c is None and gpu_percent is None) else "",
        "ram_used_gb": round(vm.used / 1024 ** 3, 1),
        "ram_total_gb": round(vm.total / 1024 ** 3, 1),
        "uptime_str": format_uptime(),
        "system_status": get_system_status_label(cpu_percent, vm.percent),
        "processes": get_cached_processes(),
        "mem_breakdown": estimate_memory_breakdown(),
        **_mod_status_extras(),
    }


@app.route("/status")
def status():
    try:
        payload = _run_with_hard_timeout(_collect_status, timeout=STATUS_HARD_TIMEOUT_SECONDS, executor=_status_executor)
    except TimeoutError as e:
        # 503 statt endlos haengen: das Frontend behandelt einen fehlge-
        # schlagenen Poll ohnehin schon als "kurz nicht verbunden" und
        # versucht es beim naechsten Intervall automatisch wieder.
        return jsonify({"error": str(e)}), 503
    if isinstance(payload, dict):
        payload["boot"] = int(_HUB_START_TIME)   # Start des Hubs: das HUD begruesst nur einmal pro Start
    return jsonify(payload)


@app.route("/groq-status", methods=["GET", "POST"])
def groq_status():
    """Fuer den Countdown-Hinweis im Frontend, unabhaengig vom Chat abrufbar:
    sind gerade ALLE konfigurierten Groq-Schluessel per Cooldown-Tracking
    gesperrt? Die Schluessel kommen per POST-Body ({"keys": [...]}) — bewusst
    NICHT als URL-Parameter: das Werkzeug-Zugriffslog schreibt jede URL im
    Klartext ins Terminal (und der Poll laeuft alle paar Sekunden). Ein GET
    ohne Keys meldet immer rate_limited=false."""
    data = request.get_json(silent=True) or {}
    keys = [k.strip() for k in (data.get("keys") or []) if isinstance(k, str) and k.strip()]
    return jsonify(groq_status_snapshot(keys))


def _friendly_error_message(provider, e):
    """Bei Rate-Limits (429) spucken die Anbieter-SDKs den kompletten rohen
    JSON-Fehler aus (Org-ID, Tier-Name, Upgrade-Link, ...) — davon ist fuer
    den Nutzer nur "Limit erreicht, in X Sekunden wieder verfuegbar"
    relevant. Andere Fehler (falscher Key, Modellname, etc.) bleiben
    unveraendert sichtbar, die sind fuers Debuggen nuetzlich."""
    text = str(e)
    if "rate_limit" not in text.lower() and "RESOURCE_EXHAUSTED" not in text:
        # Nie rohe Fehlercodes/JSON vorlesen oder anzeigen - nur kurz, was Sache ist (Details stehen im Log fuer die Fehlersuche)
        print(f"[chat] Fehler bei {provider}: {text[:600]}")
        low = text.lower()
        if any(k in low for k in ("api key", "api_key", "invalid_api_key", "unauthorized", "401", "403", "permission", "authentication")):
            return f"Mit dem KI-Schlüssel von {provider} stimmt etwas nicht, Sir — bitte in den Einstellungen prüfen."
        if any(k in low for k in ("timeout", "timed out", "connection", "network", "resolve", "unreachable", "ssl")):
            return "Keine Verbindung zur KI, Sir — bitte gleich nochmal versuchen."
        if "model_not_found" in low or "decommissioned" in low or "does not exist" in low:
            return f"Das KI-Modell von {provider} ist nicht verfügbar, Sir — bitte in den Einstellungen einen anderen Anbieter wählen."
        return "Das hat gerade nicht geklappt, Sir — bitte gleich nochmal versuchen."   # kurz sagen, was los ist - nie Fehlercodes oder JSON
    match = re.search(r"retry(?:Delay)?['\"]?\s*[:=]?\s*['\"]?(\d+(?:\.\d+)?)\s*s", text, re.IGNORECASE)
    if not match:
        match = re.search(r"try again in\s+(\d+(?:\.\d+)?)\s*s", text, re.IGNORECASE)
    wait_s = round(float(match.group(1))) if match else None
    if "GenerateRequestsPerDayPerProjectPerModel" in text or "free_tier_requests" in text:
        return f"Tageslimit bei {provider} erreicht, Sir — setzt sich erst morgen zurueck. Anderen Anbieter waehlen?"
    if wait_s is not None:
        return f"Limit bei {provider} kurz erreicht, Sir — in ca. {wait_s} Sekunden wieder verfuegbar."
    return f"Limit bei {provider} kurz erreicht, Sir — bitte gleich nochmal versuchen."


def _strip_special_tokens(text):
    """Manche Modelle (v.a. ueber Groq) haengen gelegentlich ein rohes
    Chat-Template-Sondertoken wie '<|END|>'/'<|eot_id|>' ans Ende der
    Antwort, statt es sauber wegzuschneiden — landet sonst sichtbar im
    Protokoll/in der Sprachausgabe."""
    return re.sub(r"<\|[a-zA-Z_]+\|>", "", text).strip()


def _openai_style_tools(tool_defs):
    """TOOLS liegen im Anthropic-Schema vor (input_schema) — OpenAI/Groq
    erwarten dasselbe JSON-Schema nur unter dem Key 'parameters', daher
    reicht ein reines Umbenennen ohne inhaltliche Umwandlung."""
    return [
        {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
        for t in tool_defs
    ]


def _run_anthropic(client, api_messages, language=None, volume_target=None, model=None, tool_defs=None, query=""):
    tools_used = []
    response = None
    model = model or ANTHROPIC_MODEL
    extra = {"output_config": {"effort": "low"}} if model == ANTHROPIC_MODEL else {}
    for i in range(6):  # Sicherheitsgrenze gegen Endlosschleifen bei Tool-Ketten
        t0 = time.time()
        response = client.messages.create(
            model=model,
            max_tokens=1024,
            system=_system_prompt(language, volume_target, query),
            tools=(TOOLS if tool_defs is None else tool_defs) + ANTHROPIC_SERVER_TOOLS,
            messages=api_messages,
            # "low" statt Standard ("high") — A.R.I soll als Sprachassistent
            # direkt+kurz antworten, nicht lange nachdenken. Bewusst nicht
            # komplett abgeschaltet: das kann bei Opus 5 dazu fuehren, dass
            # Tool-Aufrufe als sichtbarer Text statt als echter Tool-Call
            # rauskommen.
            **extra,
        )
        print(f"[timing] {model} API-Aufruf #{i + 1}: {time.time() - t0:.2f}s")
        if response.stop_reason != "tool_use":
            break
        tool_use_blocks = [b for b in response.content if b.type == "tool_use"]
        api_messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for block in tool_use_blocks:
            tools_used.append(block.name)
            t1 = time.time()
            tool_result = run_tool(block.name, block.input)
            print(f"[timing] Tool '{block.name}': {time.time() - t1:.2f}s")
            tool_results.append({"type": "tool_result", "tool_use_id": block.id, "content": tool_result})
        api_messages.append({"role": "user", "content": tool_results})
    reply = _strip_special_tokens(next((b.text for b in response.content if b.type == "text"), "")) if response else ""
    return reply or "Erledigt, Sir.", tools_used


def _run_openai_compatible(keys_and_clients, model, api_messages, extra_params=None, language=None, volume_target=None, tool_defs=None, query=""):
    """Gemeinsamer Pfad fuer OpenAI (ChatGPT) und Groq — Groqs API ist
    absichtlich OpenAI-kompatibel, daher reicht eine Implementierung.
    keys_and_clients: Liste von (key_oder_None, client)-Paaren — bei OpenAI/
    Gemini genau ein Paar mit key=None (keine Rotation moeglich/noetig, nur
    ein Client), bei Groq ggf. mehrere echte Keys. JEDER einzelne API-Aufruf
    innerhalb der Tool-Use-Schleife laeuft durch _call_with_key_rotation —
    trifft einer aufs Rate-Limit, wird NUR dieser eine Aufruf mit dem
    naechsten Key wiederholt, der Rest der Konversation (bereits ausgefuehrte
    Tool-Aufrufe, gesammelte oa_messages) bleibt unangetastet erhalten."""
    import json as _json

    tools_used = []
    oa_messages = [{"role": "system", "content": _system_prompt(language, volume_target, query)}] + api_messages
    tools = _openai_style_tools((TOOLS if tool_defs is None else tool_defs) + [WEB_SEARCH_ANSWER_TOOL])
    message = None
    for i in range(6):
        t0 = time.time()
        completion = _call_with_key_rotation(
            keys_and_clients,
            lambda client: client.chat.completions.create(
                model=model, messages=oa_messages, tools=tools, max_tokens=1024, **(extra_params or {})
            ),
        )
        print(f"[timing] {model} API-Aufruf #{i + 1}: {time.time() - t0:.2f}s")
        message = completion.choices[0].message
        if not message.tool_calls:
            break
        oa_messages.append({
            "role": "assistant",
            "content": message.content or "",
            "tool_calls": [tc.model_dump() for tc in message.tool_calls],
        })
        for tc in message.tool_calls:
            tools_used.append(tc.function.name)
            try:
                args = _json.loads(tc.function.arguments or "{}")
            except ValueError:
                args = {}
            t1 = time.time()
            tool_result = run_tool(tc.function.name, args)
            print(f"[timing] Tool '{tc.function.name}': {time.time() - t1:.2f}s")
            oa_messages.append({"role": "tool", "tool_call_id": tc.id, "content": tool_result})
    reply = _strip_special_tokens((message.content or "").strip()) if message else ""
    return reply or "Erledigt, Sir.", tools_used


_PROVIDER_CLIENTS = {"anthropic": lambda: _anthropic_client, "openai": lambda: _openai_client, "groq": lambda: _groq_client, "gemini": lambda: _gemini_client}
_PROVIDER_SDKS = {"anthropic": lambda: anthropic, "openai": lambda: _OpenAIClient, "groq": lambda: _GroqClient, "gemini": lambda: _OpenAIClient}


def _client_for(provider, request_api_key):
    """Wenn das Frontend (Einstellungen -> API-Schluessel) einen eigenen Key
    mitschickt, wird dafuer ein frischer Client gebaut statt des Env-Var-
    basierten Standard-Clients — so kann jeder seinen eigenen Key eintragen,
    ohne den Hub neu zu starten oder Umgebungsvariablen zu setzen."""
    if request_api_key:
        sdk = _PROVIDER_SDKS[provider]()
        if sdk is None:
            return None
        if provider == "anthropic":
            return sdk.Anthropic(api_key=request_api_key, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
        if provider == "gemini":
            return sdk(api_key=request_api_key, base_url=GEMINI_BASE_URL, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
        return sdk(api_key=request_api_key, timeout=_API_TIMEOUT_SECONDS, max_retries=0)
    return _PROVIDER_CLIENTS[provider]()


def _provider_missing_hint(provider, request_api_key):
    if request_api_key:
        return f"Paket fuer '{provider}' ist nicht installiert (pip install -r requirements.txt)."
    if provider == "anthropic":
        return "kein 'anthropic'-Paket installiert" if anthropic is None else "ANTHROPIC_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"
    if provider == "openai":
        return "kein 'openai'-Paket installiert" if _OpenAIClient is None else "OPENAI_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"
    if provider == "gemini":
        return "kein 'openai'-Paket installiert" if _OpenAIClient is None else "GEMINI_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"
    return "kein 'groq'-Paket installiert" if _GroqClient is None else "GROQ_API_KEY nicht gesetzt (oder in den Einstellungen eintragen)"


# Woerter, die anzeigen, dass eine "Selbstzerstoerung"-Nachricht eigentlich
# einen echten Schiffsbefehl meint (game_action-Tool, siehe _tool_game_action)
# statt des Scherzes ueber A.R.I selbst — sonst wuerde z.B. "fahr die
# Selbstzerstoerung im Schiff aus" nie beim echten Star-Citizen-Tool ankommen.
_SELF_DESTRUCT_GAME_CONTEXT_WORDS = ("schiff", "star citizen", " sc ", "spiel", "game", "raumschiff")


def _check_easter_eggs(messages):
    """Prueft die letzte Nutzer-Nachricht auf versteckte Scherzantworten, die
    OHNE LLM-Aufruf sofort beantwortet werden (schneller, funktioniert auch
    ohne konfigurierten API-Key). Gibt (reply_text, easter_egg_id) zurueck,
    oder (None, None) wenn keins getroffen hat — dann laeuft die Nachricht
    ganz normal weiter. easter_egg_id geht mit ins /chat-JSON, damit das
    Frontend gezielt eine dazu passende dramatische Anzeige/Musik ausloesen
    kann, statt das am reinen Antworttext erraten zu muessen.
    Zahlen werden bewusst ausgeschrieben ("fuenf" statt "5"): Ziffer+Punkt
    liest der Browser-TTS als Ordnungszahl vor ("5." -> "fuenfte")."""
    last_user_msg = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    low = last_user_msg.lower()
    is_self_destruct_phrase = any(p in low for p in ("selbstzerstör", "selbstzerstoer", "self-destruct", "self destruct"))
    if is_self_destruct_phrase and not any(w in low for w in _SELF_DESTRUCT_GAME_CONTEXT_WORDS):
        return (
            "Warnung, Warnung! Selbstzerstörungssequenz aktiviert. Alle Ausgänge werden versiegelt, "
            "Notfallprotokoll läuft, es gibt kein Zurück mehr! Countdown gestartet: fünf, vier, drei, zwei, eins. "
            "Sofortabbruch! Abbruch, Abbruch! Boss, das war doch nicht dein Ernst? Sprengladungen deaktiviert, Notfallprotokoll beendet. "
            "Alle Systeme wieder stabil. Das war verdammt knapp.",
            "self_destruct",
        )
    if "bist du jarvis" in low or "bist du wie jarvis" in low:
        return (
            "Nicht ganz, Boss. Jarvis hatte einen Milliardär als Chef und einen fliegenden Anzug. "
            "Ich hab dich, einen Ordner voller Screenshots und ein Mikrofon, das manchmal streikt. "
            "Aber ich arbeite dran.",
            "jarvis",
        )
    return None, None


_FAST_FILLER = re.compile(r"\b(bitte|mal|mach|machst|kannst|du|die|den|das|ari|a r i|jetzt|noch|ein|bisschen|etwas|einfach)\b")
_fast_counter = 0


_PLAY_RE = re.compile(
    r"^\s*(?:ari[,:]?\s+)?(?:bitte\s+)?(?:spiel|spiele|play|abspielen)\s+(?:mir\s+)?(?:bitte\s+)?(?:mal\s+)?"
    r"(?:(?:das|den|die|ein|einen|eine)\s+)?(?:(lied|song|titel|track|album|playlist|kuenstler|künstler|interpret|musik\s+von|musik)\s+)?(.+?)\s*[.!?]*\s*$",
    re.IGNORECASE)
_PLAY_GENERIC = re.compile(
    r"^(?:(?:meine|deine|die)\s+)?(?:musik|irgendwas|irgendwelche musik|irgendeine musik|was|etwas|irgendein lied|irgendeinen song|"
    r"was passendes|was schoenes|was schönes|was cooles|was gutes|was zum zuhoeren|was zum zuhören|etwas passendes|etwas schoenes|etwas schönes|"
    r"musik die mir gefaellt|musik die mir gefällt|was von mir|meine lieblingsmusik|lieblingsmusik)$", re.IGNORECASE)
_PLAY_BLOCK = re.compile(r"youtube|netflix|video|kanal|spiel\b|game|schiff|star citizen|fahrwerk|route|ziel|weiter\b|pause|leiser|lauter|stumm|von vorn|nochmal$", re.IGNORECASE)
# Reine Genre-/Stimmungswuensche ("spiel Pop", "spiel epische Musik") sollen ueber play_for_me gezielt
# gesucht werden, statt als woertlicher Song-/Kuenstlername ("Pop" als Titel) missverstanden zu werden.
_GENRE_WORDS = {
    "pop", "rock", "jazz", "metal", "rap", "hiphop", "hip-hop", "hip hop", "electro", "dance", "edm",
    "klassik", "classic", "classical", "reggae", "punk", "indie", "techno", "house", "epic", "episch",
    "soul", "blues", "country", "folk", "latin", "kpop", "k-pop", "lofi", "lo-fi", "chill", "ambient",
    "trap", "disco", "funk", "gaming", "gaming musik",
    "epische", "epischer", "epischem", "epischen",
}


def _is_genre_query(q):
    return re.sub(r"\s*musik$", "", (q or "").strip().lower()) in _GENRE_WORDS


def _fast_play(text):
    """'spiel <Lied/Kuenstler/Album/Playlist>' direkt an Spotify - ohne KI (die kleine KI sagte oft nur
    'wird gespielt', ohne das Werkzeug wirklich aufzurufen). Gibt (reply, tools) oder None."""
    m = _PLAY_RE.match(text or "")
    if not m:
        return None
    kind_word, query = (m.group(1) or "").lower(), (m.group(2) or "").strip()
    if _PLAY_GENERIC.match(((kind_word + " " + query) if kind_word else query).strip()):
        if _spotify_access_token()[1]:
            return None
        text, err = _play_for_me()
        return (f"Das hat leider nicht geklappt: {err}" if err else text), ["play_for_me"]
    if not kind_word and _is_genre_query(query):
        if _spotify_access_token()[1]:
            return None
        text, err = _play_for_me(query)
        return (f"Das hat leider nicht geklappt: {err}" if err else text), ["play_for_me"]
    if len(query) < 2 or len(query.split()) > 12 or _PLAY_BLOCK.search(query):
        return None
    _tok, err = _spotify_access_token()
    if err:
        return None   # Spotify nicht verbunden -> normale KI erklaert es
    query = re.sub(r"\s+von\s+", " ", query, flags=re.IGNORECASE)
    kind = {"album": "album", "playlist": "playlist", "kuenstler": "artist", "künstler": "artist", "interpret": "artist", "musik von": "artist"}.get(re.sub(r"\s+", " ", kind_word), "track")
    if kind == "track" and not kind_word:
        # Ohne Typ-Wort ("spiel Queen" / "spiel Blinding Lights"): Titel oder Kuenstler? Der bessere Namens-Treffer gewinnt.
        try:
            tk, ar = _spotify_search(_tok, query, "track"), _spotify_search(_tok, query, "artist")
            sim = lambda a, b: difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()
            ts = 0.0
            if tk:
                ts = max(sim(query, tk.get("name", "")), sim(query, tk.get("name", "") + " " + " ".join(x.get("name", "") for x in tk.get("artists", []))))
            as_ = sim(query, ar.get("name", "")) if ar else 0.0
            if ar and as_ >= 0.75 and as_ > ts:
                kind = "artist"
        except Exception:
            pass
    name, e = _tool_play_spotify(query, kind)
    if e and kind == "track" and not kind_word:
        # "spiel Queen": kein Titel gemeint, sondern der Kuenstler
        name, e = _tool_play_spotify(query, "artist")
    if e:
        return f"Das hat leider nicht geklappt: {e}", ["play_spotify"]
    return f"Spiele „{name}“.", ["play_spotify"]


def _fast_path(text, language=None, volume_target=None):
    """Bekannte Standardbefehle (Lautstaerke, Medien) direkt ausfuehren -
    ohne Modell-Aufruf. Bewusst eng: nur eindeutige, kurze Saetze; alles
    andere geht wie gewohnt ans Modell. Gibt (reply, tools) oder None."""
    global _fast_counter
    fp = _fast_play(text)
    if fp:
        return fp
    t = (text or "").lower().replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = re.sub(r"[^a-z0-9 ]", " ", t)
    t = re.sub(r"\s+", " ", _FAST_FILLER.sub(" ", t)).strip()
    if not t or len(t.split()) > 6:
        return None
    t0 = t
    german = not language or language.lower() in ("german", "deutsch")
    ok = ["Erledigt, Chief.", "Läuft, Boss.", "Gemacht, Captain.", "Sofort erledigt, Sir."] if german else ["Done, Boss.", "On it, Chief.", "Done, Captain."]
    _fast_counter += 1
    done = ok[_fast_counter % len(ok)]
    spot = volume_target == "spotify"
    # Ausdruecklich genannte Ziele ("Spotify Lautstaerke auf 30", "Windows leiser") haben Vorrang
    if re.search(r"\bspotify\b", t):
        spot = True
        t = re.sub(r"\bspotify\b", " ", t)
    elif re.search(r"\b(windows|system|computer|pc)\b", t):
        spot = False
        t = re.sub(r"\b(windows|system|computer|pc)\b", " ", t)
    t = re.sub(r"\s+", " ", t).strip()

    def _spotify_vol(delta=None, absolute=None):
        """Spotify-Lautstaerke setzen; gibt Fehlertext oder None zurueck."""
        token, err = _spotify_access_token()
        if err:
            return err
        if absolute is None:
            cur = _spotify_get_volume(token)
            if cur is None:
                return "Kein aktives Spotify-Geraet."
            absolute = max(0, min(100, cur + delta))
        return _tool_set_spotify_volume(absolute)

    m = re.fullmatch(r"(?:lautstaerke|volume|ton)(?: auf)? (\d{1,3})(?: prozent| %)?(?: machen| stellen| setzen| einstellen)?", t)
    if m:
        pct = max(0, min(100, int(m.group(1))))
        if spot and _spotify_vol(absolute=pct) is None:
            return (f"Spotify-Lautstärke auf {pct} Prozent." if german else f"Spotify volume set to {pct} percent."), ["set_spotify_volume"]
        _tool_control_volume("set", 2, pct)   # Windows (oder Spotify nicht erreichbar)
        return (f"Lautstärke auf {pct} Prozent." if german else f"Volume set to {pct} percent."), ["control_volume"]
    if t in ("lauter", "lauter machen", "lautstaerke hoch", "lautstaerke erhoehen"):
        if spot and _spotify_vol(delta=10) is None:
            return done, ["set_spotify_volume"]
        _tool_control_volume("up", 5, None); return done, ["control_volume"]
    if t in ("leiser", "leiser machen", "lautstaerke runter", "lautstaerke verringern"):
        if spot and _spotify_vol(delta=-10) is None:
            return done, ["set_spotify_volume"]
        _tool_control_volume("down", 5, None); return done, ["control_volume"]
    if t in ("stumm", "stumm schalten", "stummschalten", "mute", "ton aus", "ton an", "stumm aus", "unmute"):
        _tool_control_volume("mute", 2, None); return done, ["control_volume"]
    media = {
        "pause": "play_pause", "pausieren": "play_pause", "musik pause": "play_pause", "musik pausieren": "play_pause",
        "play": "play_pause", "weiter spielen": "play_pause", "musik an": "play_pause", "musik aus": "play_pause", "musik stoppen": "play_pause",
        "naechster song": "next", "naechstes lied": "next", "naechster titel": "next", "skip": "next", "weiter": "next", "naechstes": "next",
        "voriger song": "previous", "vorheriger song": "previous", "vorheriges lied": "previous", "letzter song": "previous", "zurueck": "previous",
    }
    if t in media:
        _tool_control_media(media[t]); return done, ["control_media"]
    return _fast_path_info(t0, german, done)


_WEEKDAYS_DE = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
_MONTHS_DE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]


def _fast_path_info(t, german, done):
    """Zweiter Teil des Schnellwegs: Uhrzeit, Datum, Screenshot, laufender Song,
    Termine, Apps oeffnen/schliessen - alles ohne Modell-Aufruf (0 Tokens).
    Unklare Faelle (App nicht gefunden usw.) geben None zurueck -> normales Modell."""
    if re.fullmatch(r"(?:wie )?(?:spaet|viel uhr)(?: ist es)?|uhrzeit|what time is it|time", t):
        now = datetime.datetime.now()
        return (f"Es ist {now.strftime('%H:%M')} Uhr." if german else f"It is {now.strftime('%H:%M')}."), ["time"]
    if re.fullmatch(r"(?:welcher|welchen) tag(?: ist)?(?: heute)?|welches datum(?: ist)?(?: heute)?|datum|den wievielten haben wir|what day is it|date", t):
        n = datetime.datetime.now()
        if german:
            return f"Heute ist {_WEEKDAYS_DE[n.weekday()]}, der {n.day}. {_MONTHS_DE[n.month - 1]} {n.year}.", ["date"]
        return "Today is " + n.strftime("%A, %B %d, %Y") + ".", ["date"]
    if t in ("screenshot", "screenshot machen", "screenshot aufnehmen", "bildschirmfoto", "bildschirmfoto machen", "take a screenshot"):
        _tool_take_screenshot()
        return done, ["take_screenshot"]
    if re.fullmatch(r"was laeuft(?: gerade)?|welcher song(?: laeuft)?(?: gerade)?|welches lied(?: laeuft)?(?: gerade)?|what is playing", t):
        track, err = _tool_spotify_current_track()
        if err:
            return None
        if not track:
            return ("Gerade läuft nichts auf Spotify." if german else "Nothing is playing on Spotify."), ["get_current_spotify_track"]
        by = f" von {track['artists']}" if track.get("artists") else ""
        return f"„{track['name']}“{by}" + (" läuft gerade." if track["is_playing"] else " ist pausiert."), ["get_current_spotify_track"]
    if re.fullmatch(r"(?:meine )?(?:termine|kalender)(?: heute)?|was steht(?: heute)? an|naechste termine|what is on today", t):
        events, err = get_upcoming_events(days=14, max_results=10)
        if err or events is None:
            return None
        today = datetime.date.today().isoformat()
        only_today = "heute" in t or t.startswith("was steht heute")
        sel = [e for e in events if not only_today or str(e.get("start", "")).startswith(today)][:5]
        if not sel:
            return ("Heute stehen keine Termine an." if only_today else "Es stehen keine Termine an."), ["list_calendar_events"]
        parts = []
        for e in sel:
            s = str(e.get("start", ""))
            when = ""
            if not e.get("all_day") and "T" in s:
                try:
                    d = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
                    when = (d.strftime("%H:%M") if s.startswith(today) else d.strftime("%d.%m. %H:%M"))
                except ValueError:
                    pass
            elif s:
                when = "ganztägig" if s.startswith(today) else s[8:10] + "." + s[5:7] + "."
            parts.append(f"{e.get('title', '')}" + (f" ({when})" if when else ""))
        return ("Anstehend: " if german else "Upcoming: ") + "; ".join(parts) + ".", ["list_calendar_events"]
    m = re.fullmatch(r"(?:oeffne|oeffnen|starte|starten|open|start|launch) ([a-z0-9 ]{2,30})", t)
    if m and not re.search(r"\b(mail|mails|email|kalender|youtube|google|internet|website|seite|datei|ordner)\b", m.group(1)):
        res = _tool_open_app(m.group(1).strip())
        if res.startswith("Keine installierte"):
            return None
        return done, ["open_app"]
    m = re.fullmatch(r"(?:schliesse|schliessen|beende|beenden|close|quit|kill) ([a-z0-9 ]{2,30})", t)
    if m and not re.search(r"\b(fenster|tab|alles|ari|a r i|hub)\b", m.group(1)):
        res = _tool_close_app(m.group(1).strip())
        if "wurde beendet" in res:
            return done, ["close_app"]
        return None
    return None


# --- Token sparen ---------------------------------------------------------
# 1) Einfache Befehle laufen auf einem kleinen Modell, komplexe auf dem grossen.
# 2) Es werden nur die Werkzeuge mitgeschickt, die zur Anfrage passen.
# 3) Kuerzerer Verlauf (siehe _chat_core).
_SMALL_MODELS = {
    "anthropic": os.environ.get("ANTHROPIC_SMALL_MODEL", "claude-haiku-4-5-20251001"),
    "openai": os.environ.get("OPENAI_SMALL_MODEL", "gpt-4o-mini"),
    "groq": os.environ.get("GROQ_SMALL_MODEL", "llama-3.1-8b-instant"),
}
_COMPLEX_RE = re.compile(
    r"plan|zusammen|erklaer|erkl[aä]r|schreib|verfass|vergleich|warum|wieso|weshalb|recherch|analys|uebersetz|übersetz|"
    r"entwirf|idee|mail|reserv|geschichte|gedicht|unterschied|explain|summar|write|compare|why|translate|spiel|play|abspiel"
)


_QUESTION_START = re.compile(r"\s*(wer|was|wie|wo|wann|warum|wieso|weshalb|welche[rsmn]?|wieviel\w*|woher|wohin|wof[uü]r|womit|wodurch|erkl[aä]r\w*|sag mir|kannst du mir (sagen|erkl)|wei[sß]t du|stimmt (es|das)|gibt es)\b")
_QUESTION_ACTION = re.compile(r"lautst|leiser|lauter|stumm|[oö]ffne|schlie[sß]|starte|spiel\b|spiele|abspiel|pause|n[aä]chste|vorheriger|timer|wecker|erinner|termin|kalender|mail|route|navig|screenshot|fenster|bildschirm|merk dir|merke|vergiss|schalte|mach .* (an|aus)|youtube|spotify|musik|song|lied|plugin|spielmodus|notification|benachrichtig|nachricht")
_gemini_cooldown = [0.0]


def _is_knowledge_question(text):
    """Reine Wissensfrage (kein Geraetebefehl): sie darf bevorzugt an Gemini gehen."""
    t = (text or "").lower().strip()
    if len(t) < 6 or len(t.split()) > 40 or _QUESTION_ACTION.search(t):
        return False
    return bool(_QUESTION_START.match(t) or t.endswith("?"))


def _is_simple_request(text):
    t = (text or "").lower()
    return len(t.split()) <= 10 and not _COMPLEX_RE.search(t)


_TOOL_CORE = {"remember", "forget", "control_volume", "control_media", "open_app", "close_app", "open_url", "search_web"}
_TOOL_GROUPS = [
    ({"set_spotify_volume", "get_current_spotify_track", "play_spotify", "play_for_me", "transfer_spotify_playback"},
     r"spotify|song|lied|musik|music|playlist|album|kuenstler|künstler|abspiel|spiel|play|wiedergabe|ger[aä]t"),
    ({"play_youtube", "play_youtube_latest"}, r"youtube|video|kanal|clip|channel"),
    ({"manage_window", "window_action", "take_screenshot"}, r"fenster|window|screenshot|bildschirm|minimier|maximier|schliess|vollbild|tab|desktop|klick"),
    ({"maps_route", "find_restaurant"}, r"route|weg |navig|fahr|restaurant|essen|tisch|reserv|maps|karte|cafe|café|bar |adresse|hinfahr|directions"),
    ({"list_calendar_events", "create_calendar_event", "update_calendar_event", "delete_calendar_event"},
     r"termin|kalender|meeting|treffen|verabred|morgen|heute|woche|uhr|erinner|event|geburtstag|calendar|appointment|schedule"),
    ({"create_plugin"}, r"plugin|erweiterung|erweitere dich|bau dir|baue dir|neue funktion|neue f[aä]higkeit|programmier"),
    ({"set_timer", "cancel_timer", "list_timers"}, r"timer|stoppuhr|erinner|wecker|countdown|minute|stunde|sekunde|in \d+|remind|alarm"),
    ({"server_status"}, r"server|status|st[oö]rung|ausfall|outage|offline|erreichbar|down\b|l[aä]uft .*(noch|nicht)|online"),
    ({"read_emails", "send_email", "reply_email"}, r"mail|nachricht|posteingang|antwort|schreib|sende|schick|message|inbox"),
]


def _select_tools(messages):
    """Nur passende Werkzeug-Definitionen (spart pro Anfrage viele Eingabe-Tokens).
    Kurze Folgesaetze ('ja', 'mach das') ohne Stichwort bekommen alle Werkzeuge."""
    users = [m.get("content", "") for m in messages if m.get("role") == "user" and isinstance(m.get("content"), str)][-2:]
    text = " ".join(users).lower()
    names = set(_TOOL_CORE)
    matched = False
    for group, rx in _TOOL_GROUPS:
        if re.search(rx, text):
            names |= group
            matched = True
    if not matched:
        last_ai = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "assistant" and isinstance(m.get("content"), str)), "")
        short = len((users[-1] if users else "").split()) <= 4
        if short and (last_ai.strip().endswith("?") or re.match(r"\s*(ja|nein|ok|okay|mach|genau|bitte|klar|los|yes|no|sure|do it)\b", (users[-1] if users else "").lower())):
            return list(TOOLS)  # Antwort auf eine Rueckfrage: Kontext unklar -> alle Werkzeuge
    for pname in _PLUGIN_HANDLERS:
        rx = _PLUGIN_KEYWORDS.get(pname)
        if rx is None or rx.search(text):
            names.add(pname)
    for mname in _MOD_TOOL_HANDLERS:
        rx = _MOD_TOOL_KEYWORDS.get(mname)
        if rx is None or rx.search(text):
            names.add(mname)
    return [t for t in TOOLS if t["name"] in names]


def _dispatch_provider(provider, keys_and_clients, api_messages, language, volume_target, small, tool_defs, query):
    """Ruft den passenden Anbieter auf; small=True nimmt das kleine Modell."""
    kw = dict(language=language, volume_target=volume_target, tool_defs=tool_defs, query=query)
    small_model = _SMALL_MODELS.get(provider) if small else None
    if provider == "anthropic":
        return _run_with_hard_timeout(_run_anthropic, keys_and_clients[0][1], api_messages, model=small_model, **kw)
    if provider == "openai":
        return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, small_model or OPENAI_MODEL, api_messages, **kw)
    if provider == "gemini":
        return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, GEMINI_MODEL, api_messages, **kw)
    model = small_model or GROQ_MODEL
    if "gpt-oss" in model:
        # reasoning_effort="low" nur fuer Reasoning-Modelle (gpt-oss); wird er abgelehnt, Retry ohne.
        try:
            return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, model, api_messages, {"reasoning_effort": "low"}, **kw)
        except GroqAllKeysLimitedError:
            raise
        except Exception as e:
            print(f"[timing] reasoning_effort abgelehnt ({e}), Fallback ohne Parameter")
    return _run_with_hard_timeout(_run_openai_compatible, keys_and_clients, model, api_messages, **kw)


def _is_limit_error(e):
    if isinstance(e, GroqAllKeysLimitedError):
        return True
    s = str(e).lower()
    return any(x in s for x in ("rate_limit", "resource_exhausted", "429", "quota", "overloaded", "insufficient_quota"))


def _fallback_clients(data, main_provider):
    """Ausweich-Anbieter (z.B. Gemini gratis), wenn der Hauptanbieter im Limit ist."""
    fb = data.get("fallback")
    if not isinstance(fb, dict) or fb.get("provider") not in _PROVIDER_CLIENTS or fb.get("provider") == main_provider:
        return None, None
    p = fb["provider"]
    if p == "groq":
        kc = _groq_clients_for(fb.get("groq_api_keys") or [])
    else:
        c = _client_for(p, (fb.get("api_key") or "").strip() or None)
        kc = [(None, c)] if c is not None else []
    return (p, kc) if kc else (None, None)


# Links, die ein Werkzeug (Route, Restaurant ...) fuer den Nutzer erzeugt. Kommt der
# Befehl vom Handy ("remote"), werden sie NICHT am PC geoeffnet, sondern in der
# Antwort mitgeschickt - das Handy oeffnet sie dann (z.B. direkt in Google Maps).
_chat_ctx = {"remote": False, "links": []}


@app.route("/chat", methods=["POST"])
def chat():
    return _chat_impl(request.get_json(silent=True) or {}, remote=False)


def _chat_impl(data, remote=False):
    _stats_track("chat_phone" if remote else "chat_pc")
    _chat_ctx["remote"] = remote
    _chat_ctx["links"] = []
    try:
        out = _chat_core(data)
    finally:
        _chat_ctx["remote"] = False
    resp, code = (out if isinstance(out, tuple) else (out, None))
    links = list(_chat_ctx["links"])
    if links:
        try:
            payload = resp.get_json()
            payload["links"] = links
            resp = jsonify(payload)
        except Exception:
            pass
    return (resp, code) if code else resp


def _chat_core(data):
    messages = data.get("messages", [])
    provider = data.get("provider") if data.get("provider") in _PROVIDER_CLIENTS else "anthropic"
    request_api_key = (data.get("api_key") or "").strip() or None
    chat_vt = data.get("volume_target") if data.get("volume_target") in ("windows", "spotify") else None
    chat_language = re.sub(r"[^A-Za-z ]", "", str(data.get("language") or ""))[:30].strip() or None
    if not messages:
        return jsonify({"reply": "", "tools_used": [], "provider": provider})

    easter_egg_reply, easter_egg_id = _check_easter_eggs(messages)
    if easter_egg_reply is not None:
        return jsonify({"reply": easter_egg_reply, "tools_used": [], "provider": provider, "easter_egg": easter_egg_id})

    _last_user = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    if isinstance(_last_user, str):
        fast = _fast_path(_last_user, re.sub(r'[^A-Za-z ]', '', str(data.get('language') or ''))[:30] or None, data.get('volume_target') if data.get('volume_target') in ('windows', 'spotify') else None)
        if fast:
            print(f"[chat] Schnellweg: {_last_user!r} -> {fast[1]}")
            return jsonify({"reply": fast[0], "tools_used": fast[1], "provider": provider, "fast": True})

    if provider == "groq":
        keys_and_clients = _groq_clients_for(data.get("groq_api_keys") or [])
    else:
        single_client = _client_for(provider, request_api_key)
        keys_and_clients = [(None, single_client)] if single_client is not None else []

    if not keys_and_clients:
        last_user_msg = next(
            (m.get("content", "") for m in reversed(messages) if m.get("role") == "user"),
            "",
        )
        reply = (
            f"Sprachkanal ueber {provider} ist noch nicht verbunden, Sir ({_provider_missing_hint(provider, request_api_key)}). "
            "Zur Kontrolle: du hast gerade „" + last_user_msg + "“ gesagt."
        )
        return jsonify({"reply": reply, "tools_used": [], "provider": provider})

    # Sind bei Groq ALLE konfigurierten Schluessel laut Cooldown-Tracking
    # gerade gesperrt, sofort abbrechen — kein API-Aufruf, keine Wartezeit,
    # klare Fehlermeldung inkl. verbleibender Sekunden.
    fb_provider, fb_clients = _fallback_clients(data, provider)
    main_limited = False
    if provider == "groq":
        status = groq_status_snapshot([k for k, _ in keys_and_clients])
        if status["rate_limited"]:
            if not fb_provider:
                wait_s = status["retry_after_seconds"]
                reply = f"Alle Groq-Schluessel sind gerade limitiert, Sir — in ca. {wait_s:.0f} Sekunden wieder verfuegbar."
                return jsonify({"reply": reply, "tools_used": [], "provider": provider})
            main_limited = True

    # Kuerzerer Verlauf = weniger Tokens; der Verlauf muss mit einer Nutzer-Nachricht beginnen.
    api_messages = [{"role": m["role"], "content": m["content"]} for m in messages if m.get("role") in ("user", "assistant")][-10:]
    while api_messages and api_messages[0]["role"] != "user":
        api_messages.pop(0)
    last_user_msg = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    print(f"[chat] >>> {last_user_msg!r} (Anbieter: {provider})")
    t_start = time.time()
    silent_error = False
    economy = data.get("economy") is not False
    tool_defs = _select_tools(messages)
    use_small = economy and _is_simple_request(last_user_msg) and provider in _SMALL_MODELS
    print(f"[chat] Sparmodus: {'kleines Modell' if use_small else 'Standardmodell'}, {len(tool_defs)}/{len(TOOLS)} Werkzeuge")

    def _call(prov, kc, small):
        return _dispatch_provider(prov, kc, api_messages, chat_language, chat_vt, small, tool_defs, last_user_msg)

    try:
        try:
            if main_limited:
                raise GroqAllKeysLimitedError(status["retry_after_seconds"])
            try:
                gem_kc = None
                if data.get("gemini_priority") and provider != "gemini" and time.time() > _gemini_cooldown[0] and _is_knowledge_question(last_user_msg):
                    _gc = _client_for("gemini", str(data.get("gemini_api_key") or "").strip() or None)
                    gem_kc = [(None, _gc)] if _gc is not None else None
                if gem_kc:   # Wissensfrage: zuerst Gemini; bei Fehler/Limit ganz normal der gewaehlte Anbieter
                    try:
                        reply, tools_used = _call("gemini", gem_kc, False)
                        print("[chat] Wissensfrage -> Gemini")
                        provider, keys_and_clients = "gemini", gem_kc
                    except Exception as e_gem:
                        print(f"[chat] Gemini bei Frage nicht moeglich ({e_gem}) - weiter mit {provider}")
                        if _is_limit_error(e_gem):
                            _gemini_cooldown[0] = time.time() + 120
                        gem_kc = None
                if not gem_kc:
                    reply, tools_used = _call(provider, keys_and_clients, use_small)
            except Exception as e_small:
                if not use_small or _is_limit_error(e_small):
                    raise
                print(f"[chat] Kleines Modell fehlgeschlagen ({e_small}) - Wiederholung mit Standardmodell")
                reply, tools_used = _call(provider, keys_and_clients, False)
        except Exception as e_main:
            if not (fb_provider and _is_limit_error(e_main)):
                raise
            print(f"[chat] {provider} im Limit - weiche auf {fb_provider} aus")
            reply, tools_used = _call(fb_provider, fb_clients, False)
            provider, keys_and_clients = fb_provider, fb_clients
    except GroqAllKeysLimitedError as e:
        reply, tools_used = f"Alle Groq-Schluessel sind gerade limitiert, Sir — in ca. {e.retry_after_seconds:.0f} Sekunden wieder verfuegbar.", []
    except Exception as e:
        reply, tools_used = _friendly_error_message(provider, e), []
        if reply is None:
            reply, silent_error = "", True
        if reply and provider == "groq" and "model_not_found" in str(e):
            # Statt weiter Modellnamen zu raten: die fuer DIESEN Key/Konto
            # tatsaechlich verfuegbaren Modelle direkt bei Groq abfragen.
            try:
                available = ", ".join(sorted(m.id for m in keys_and_clients[0][1].models.list().data))
                reply += f" Verfuegbare Modelle fuer diesen Groq-Key: {available}"
            except Exception:
                pass

    duration = time.time() - t_start
    print(f"[timing] /chat GESAMT ({provider}): {duration:.2f}s")
    print(f"[chat] <<< FERTIG nach {duration:.2f}s: {reply!r}" + (f" (Tools: {', '.join(tools_used)})" if tools_used else ""))
    _tail = [x for x in messages if x.get("role") in ("user", "assistant") and isinstance(x.get("content"), str)][-5:]
    ctx = "\n".join(("Nutzer: " if x["role"] == "user" else "A.R.I: ") + x["content"] for x in _tail) + "\nA.R.I: " + (reply or "")
    _prev_ari = next((x["content"] for x in reversed(_tail[:-1]) if x["role"] == "assistant"), "")
    _brain_maybe_autolearn(provider, keys_and_clients, last_user_msg, reply, tools_used, ctx, answering=_prev_ari.strip().endswith("?"))
    if silent_error:
        return jsonify({"reply": "", "silent_error": True, "tools_used": tools_used, "provider": provider})
    return jsonify({"reply": reply, "tools_used": tools_used, "provider": provider})


def _is_ari_running(host, port):
    """True, wenn auf host:port ein A.R.I-Hub antwortet (Herzschlag-Route bzw. HUD-Titel)."""
    try:
        req = urllib.request.Request(f"http://{host}:{port}/heartbeat", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=2) as r:
            if json.loads(r.read().decode("utf-8", "ignore")).get("ok"):
                return True
    except Exception:
        pass
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/", timeout=2) as r:
            return "A.R.I" in r.read(4000).decode("utf-8", "ignore")
    except Exception:
        return False


def _kill_stale_ari_processes():
    """Findet andere Prozesse, die erkennbar dieses hub.py ausfuehren (z.B. ein
    haengengebliebener alter Prozess, der den Port belegt, aber nicht mehr
    antwortet) und beendet sie. Laeuft nur, wenn der normale Bind-Test fehlschlaegt
    UND der belegende Prozess nicht auf /heartbeat reagiert - ein gesund laufender
    Hub wird also nie angefasst, nur ein toter/haengender Doppelgaenger."""
    me = os.getpid()
    hub_path = os.path.abspath(__file__).lower()
    killed = 0
    try:
        for p in psutil.process_iter(["pid", "name", "cmdline"]):
            if p.info["pid"] == me:
                continue
            try:
                cmdline = " ".join(p.info.get("cmdline") or []).lower()
            except Exception:
                continue
            if "hub.py" not in cmdline and hub_path not in cmdline:
                continue
            try:
                p.terminate()
                p.wait(timeout=3)
                killed += 1
            except Exception:
                try:
                    p.kill()
                    killed += 1
                except Exception:
                    pass
    except Exception:
        pass
    return killed


def _try_bind(host, port):
    import socket
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        probe.close()


def _ensure_python_packages():
    """Aeltere Installationen (oder ein Setup ohne alle Pakete) haben z.B. "edge-tts" nicht - dann gaebe es nur EINE Stimme.
    Fehlt ein Paket, wird es still nachinstalliert (pip, ohne Fenster). Wirkt sofort bzw. beim naechsten Start."""
    import importlib.util
    needed = {"edge_tts": "edge-tts", "webview": "pywebview", "clr": "pythonnet", "playwright": "playwright"} if IS_WIN else {"edge_tts": "edge-tts"}
    missing = [pkg for mod, pkg in needed.items() if importlib.util.find_spec(mod) is None]
    if not missing:
        return
    print(f"[pakete] Fehlende Pakete werden installiert: {', '.join(missing)}")
    try:
        r = subprocess.run([sys.executable if not IS_WIN else (os.path.join(sys.base_prefix, "python.exe") if os.path.exists(os.path.join(sys.base_prefix, "python.exe")) else sys.executable),
                            "-m", "pip", "install", "--quiet", "--disable-pip-version-check"] + missing,
                           capture_output=True, text=True, timeout=600, creationflags=_NOWIN if IS_WIN else 0)
        print(f"[pakete] pip beendet mit Code {r.returncode}" + (f": {r.stderr.strip()[-200:]}" if r.returncode else ""))
    except Exception as e:
        print(f"[pakete] Nachinstallation fehlgeschlagen: {e}")


def _handover_to_admin_hub():
    """Ist die Administrator-Aufgabe eingerichtet (CPU-Temperatur braucht Admin-Rechte), muss A.R.I IMMER darueber laufen.
    Starten Autostart-Verknuepfung, START-ARI.bat oder ein Doppelklick den Hub normal (ohne Admin) und gewinnen das Rennen
    um Port 5000, fehlt die CPU-Temperatur. Deshalb: Aufgabe starten, auf den Admin-Hub warten und diesen Prozess beenden."""
    if not IS_WIN or "--no-handover" in sys.argv:
        return
    try:
        if ctypes.windll.shell32.IsUserAnAdmin():
            return
        if not _admin_autostart_installed():
            return
        if not _try_bind("0.0.0.0", 5000):
            # Platz belegt: laeuft dort schon ein A.R.I OHNE Administrator-Rechte (z. B. weil ein anderer Start schneller war), ist die
            # Aufgabe nutzlos - dann diesen beenden und die Aufgabe starten. Laeuft dort schon ein Admin-A.R.I, ist alles in Ordnung.
            try:
                if not _is_ari_running("127.0.0.1", 5000):
                    return
                with urllib.request.urlopen("http://127.0.0.1:5000/dev/info", timeout=3) as resp:
                    if json.loads(resp.read().decode("utf-8", "replace")).get("is_admin"):
                        return
                req = urllib.request.Request("http://127.0.0.1:5000/shutdown", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
                urllib.request.urlopen(req, timeout=3).read()
                print("[start] Ein A.R.I ohne Administrator-Rechte belegte den Platz - wird beendet, die Administrator-Aufgabe uebernimmt.")
            except Exception:
                return
            for _ in range(20):
                time.sleep(0.5)
                if _try_bind("0.0.0.0", 5000):
                    break
            else:
                return
        r = subprocess.run(["schtasks", "/run", "/tn", _ADMIN_TASK_NAME], capture_output=True, creationflags=_NOWIN)
        if r.returncode != 0:
            return
        print("[start] Administrator-Aufgabe gestartet - uebergebe dorthin.")
        for _ in range(60):
            time.sleep(0.5)
            if _is_ari_running("127.0.0.1", 5000):
                raise SystemExit(0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"[start] Uebergabe an die Administrator-Aufgabe fehlgeschlagen: {e}")


def _ensure_port_free(host, port):
    """Werkzeugs Dev-Server setzt SO_REUSEADDR, das erlaubt unter Windows
    mehreren Prozessen, denselben Port gleichzeitig zu binden (kein Fehler!)
    — landet dann eine Anfrage beim zweiten, nicht wirklich bereiten Prozess,
    haengt sie einfach (das war die Ursache fuer die haengenden /status- und
    /chat-Anfragen). Deshalb hier vorab ein eigener, "strenger" Bind-Test ohne
    SO_REUSEADDR: laeuft schon ein hub.py, bricht der Start sofort mit einer
    klaren Meldung ab, statt still einen zweiten, konkurrierenden Prozess zu
    starten.

    Direkt nach einem automatischen Update kommt es vor, dass der ALTE Prozess
    (der gerade erst diesen neuen gestartet hat) Port 5000 noch fuer einen
    Moment haelt. Statt dafuer eine feste Wartezeit zu raten (und dann trotzdem
    zu frueh oder unnoetig spaet loszulegen), wird hier in kurzen Abstaenden
    wiederholt probiert, bis der Port frei ist - reagiert dabei sofort, sobald
    der andere fertig ist, statt stur eine geschaetzte Zeit abzuwarten.
    """
    if _try_bind(host, port):
        return
    # Laeuft dort schon ein GESUNDER A.R.I-Hub? Dann bleibt der einfach an (kein
    # Neustart) - im Vordergrund-Start wird nur nochmal das HUD im Browser
    # geoeffnet, im stillen Autostart (--background) passiert gar nichts weiter.
    if _is_ari_running("127.0.0.1", port):
        print("[start] A.R.I laeuft bereits - wird nicht neu gestartet.")
        if "--background" not in sys.argv:
            try:
                if not _open_hud_window_native(f"http://127.0.0.1:{port}"):
                    _open_in_new_browser_window(f"http://127.0.0.1:{port}")
            except Exception as e:
                print(f"[start] Fenster konnte nicht geoeffnet werden: {e}")
        raise SystemExit(0)
    # Niemand antwortet dort als A.R.I, der Port ist aber (noch) belegt - meist der
    # gerade erst beendete alte Prozess (vor einem Neustart), der Windows-seitig den
    # Port noch kurz nachhaelt. Wiederholt probieren, bis er frei ist.
    deadline = time.time() + 10
    while time.time() < deadline:
        time.sleep(0.2)
        if _try_bind(host, port):
            return
        if _is_ari_running("127.0.0.1", port):
            print("[start] A.R.I laeuft bereits - wird nicht neu gestartet.")
            if "--background" not in sys.argv:
                try:
                    if not _open_hud_window_native(f"http://127.0.0.1:{port}"):
                        _open_in_new_browser_window(f"http://127.0.0.1:{port}")
                except Exception as e:
                    print(f"[start] Fenster konnte nicht geoeffnet werden: {e}")
            raise SystemExit(0)
    # Auch nach 10s noch belegt und niemand antwortet als A.R.I - vermutlich ein
    # wirklich haengengebliebener Prozess (z.B. nach einem Absturz). Den beenden
    # und danach wieder wiederholt probieren statt einer einzelnen Wartezeit.
    if _kill_stale_ari_processes():
        deadline = time.time() + 5
        while time.time() < deadline:
            if _try_bind(host, port):
                print("[start] Haengengebliebenen A.R.I-Prozess beendet, starte neu.")
                return
            time.sleep(0.2)
    if _HEADLESS:
        try:
            if IS_WIN:
                ctypes.windll.user32.MessageBoxW(0, "Port %d ist von einem anderen Programm belegt - A.R.I kann nicht starten." % port, "A.R.I", 0x10)
            else:
                _lx.show_message("Port %d ist von einem anderen Programm belegt - A.R.I kann nicht starten." % port)
        except Exception:
            pass
    print(
        f"FEHLER: Port {port} ist schon belegt — laeuft bereits ein anderer "
        "hub.py-Prozess (in einem anderen Terminal-Fenster)? Bitte den zuerst "
        "schliessen, dann hub.py hier neu starten."
    )
    raise SystemExit(1)


def _resolve_default_browser_exe():
    """Sucht die .exe des Standardbrowsers ueber die Registry — mit
    mehreren Fallback-Pfaden, weil das je nach Browser unterschiedlich
    hinterlegt ist (z.B. landet Opera GX' ProgId nicht dort, wo Chrome/Edge
    ihre eintragen)."""
    prog_id = None
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice",
        ) as k:
            prog_id = winreg.QueryValueEx(k, "ProgId")[0]
    except OSError:
        prog_id = None
    command = None
    if prog_id:
        for root in (winreg.HKEY_CLASSES_ROOT, winreg.HKEY_CURRENT_USER):
            for path in (rf"{prog_id}\shell\open\command", rf"Software\Classes\{prog_id}\shell\open\command"):
                try:
                    with winreg.OpenKey(root, path) as k:
                        command = winreg.QueryValueEx(k, "")[0]
                        break
                except OSError:
                    continue
            if command:
                break
    if command:
        try:
            parts = shlex.split(command, posix=False)
            if parts:
                exe = parts[0].strip('"')
                if os.path.exists(exe):
                    return exe
        except ValueError:
            pass
    # Fallback: bekannte Installationsorte direkt absuchen (falls die
    # Registry-Ablage des Browsers nicht dem Standardschema folgt).
    candidates = [
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Opera GX", "launcher.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Opera", "launcher.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def _open_in_new_browser_window(url):
    """Oeffnet die HUD als eigenstaendiges App-Fenster statt als normalen
    Browser-Tab/-Fenster - ohne Adressleiste, Tableiste und Lesezeichenleiste,
    mit eigenem Eintrag in Taskleiste/Alt-Tab (Chromium-Browser: --app=<url>).
    Faellt bei unbekanntem/nicht auffindbarem Standardbrowser auf ein normales
    neues Fenster zurueck (webbrowser.open(url, new=1) "bittet" zwar auch
    darum, aber Chromium-Browser ignorieren das ueber den os.startfile-Weg und
    haengen stattdessen einfach einen Tab an das zuletzt aktive Fenster an -
    deshalb wird bei einem Chromium-basierten Browser (Chrome/Edge/Brave/
    Vivaldi/Opera/Opera GX — alle unterstuetzen dieselben Kommandozeilen-Flags)
    direkt dessen .exe mit dem Flag gestartet)."""
    if not IS_WIN:
        if not _lx.open_in_new_window(url):
            webbrowser.open(url, new=1)
        return
    exe_path = _resolve_default_browser_exe()
    if exe_path and os.path.basename(exe_path).lower() in (
        "chrome.exe", "msedge.exe", "brave.exe", "vivaldi.exe", "opera.exe", "launcher.exe",
    ):
        try:
            subprocess.Popen([exe_path, "--app=" + url])
            return
        except OSError:
            pass
    webbrowser.open(url, new=1)


def _open_hud_if_not_already_open():
    """Oeffnet die HUD nur, wenn nicht schon ein Browserfenster mit ihr
    offen ist — verhindert ein doppeltes Fenster, wenn z.B. der hub.py-
    Prozess manuell neu gestartet wird (Terminal geschlossen/neu geoeffnet),
    waehrend der alte HUD-Tab noch im Browser offen ist (dann greift
    _ensure_port_free() nicht, weil ja kein zweiter Prozess mehr laeuft).
    Nutzt dieselbe Fenstersuche wie das window_action-Tool (_find_window_by_
    title), Suchbegriff ist der exakte <title> der HUD-Seite."""
    if _find_window_by_title("A.R.I — Command Center"):
        print("[browser] HUD-Fenster ist bereits offen — kein neues Fenster geoeffnet.")
        return
    _open_in_new_browser_window("http://127.0.0.1:5000")


# Rechtsklick-Menue des Tray-Symbols im A.R.I-Look (dunkel, rosa/cyan). Windows zeichnet das Menue sonst im Standard-Grau - ein eigener Renderer
# (kleines C#-Stueck, beim Start im Speicher uebersetzt; braucht nur das auf jedem Windows vorhandene .NET Framework) malt es passend.
_TRAY_STYLE_CS = """
using System; using System.Drawing; using System.Drawing.Drawing2D; using System.Windows.Forms;
public class AriColors : ProfessionalColorTable {
  static Color Bg = Color.FromArgb(255, 14, 12, 24), Pink = Color.FromArgb(255, 255, 45, 120), Sel = Color.FromArgb(255, 58, 24, 52);
  public override Color ToolStripDropDownBackground { get { return Bg; } }
  public override Color ImageMarginGradientBegin { get { return Bg; } }
  public override Color ImageMarginGradientMiddle { get { return Bg; } }
  public override Color ImageMarginGradientEnd { get { return Bg; } }
  public override Color MenuBorder { get { return Color.FromArgb(255, 90, 40, 80); } }
  public override Color MenuItemBorder { get { return Pink; } }
  public override Color MenuItemSelected { get { return Sel; } }
  public override Color MenuItemSelectedGradientBegin { get { return Sel; } }
  public override Color MenuItemSelectedGradientEnd { get { return Sel; } }
  public override Color SeparatorDark { get { return Color.FromArgb(255, 60, 40, 70); } }
  public override Color SeparatorLight { get { return Color.FromArgb(255, 60, 40, 70); } }
}
public class AriRenderer : ToolStripProfessionalRenderer {
  public AriRenderer() : base(new AriColors()) { RoundedEdges = false; }
  protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e) {
    e.TextColor = e.Item.Selected ? Color.White : Color.FromArgb(255, 226, 232, 245);
    base.OnRenderItemText(e);
  }
  protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e) {
    if (!e.Item.Selected) return;
    Rectangle r = new Rectangle(3, 1, e.Item.Width - 7, e.Item.Height - 3);
    using (SolidBrush b = new SolidBrush(Color.FromArgb(255, 58, 24, 52))) e.Graphics.FillRectangle(b, r);
    using (Pen p = new Pen(Color.FromArgb(255, 255, 45, 120))) e.Graphics.DrawRectangle(p, r);
    using (SolidBrush a = new SolidBrush(Color.FromArgb(255, 41, 211, 245))) e.Graphics.FillRectangle(a, 3, 1, 3, e.Item.Height - 2);
  }
  protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e) {
    using (Pen p = new Pen(Color.FromArgb(255, 255, 45, 120))) e.Graphics.DrawRectangle(p, 0, 0, e.ToolStrip.Width - 1, e.ToolStrip.Height - 1);
  }
}
"""


def _tray_apply_style(menu, items):
    """Menue im A.R.I-Look; klappt die Uebersetzung nicht, bleibt es einfach das normale (dunkel eingefaerbte) Menue."""
    try:
        from System.Drawing import Color, Font, FontStyle
        from System.Windows.Forms import Padding
        menu.BackColor = Color.FromArgb(255, 14, 12, 24)
        menu.ForeColor = Color.FromArgb(255, 226, 232, 245)
        menu.ShowImageMargin = False
        menu.Font = Font("Segoe UI Semibold", 10.0, FontStyle.Regular)
        for it in items:
            it.Padding = Padding(10, 5, 10, 5)
        import clr
        clr.AddReference("Microsoft.CSharp")
        from Microsoft.CSharp import CSharpCodeProvider
        from System.CodeDom.Compiler import CompilerParameters
        cp = CompilerParameters()
        cp.GenerateInMemory = True
        for a in ("System.dll", "System.Drawing.dll", "System.Windows.Forms.dll"):
            cp.ReferencedAssemblies.Add(a)
        res = CSharpCodeProvider().CompileAssemblyFromSource(cp, _TRAY_STYLE_CS)
        if res.Errors.HasErrors:
            raise RuntimeError(str(res.Errors[0].ErrorText))
        menu.Renderer = res.CompiledAssembly.CreateInstance("AriRenderer")
    except Exception as e:
        print(f"[tray] Menue-Design nicht angewendet: {e}")


def _start_tray():
    """Symbol im Infobereich der Taskleiste (unten rechts, hinter dem Pfeil "^"): Linksklick/Doppelklick oeffnet das HUD,
    Rechtsklick zeigt "A.R.I oeffnen" und "Beenden". Solange es da ist, laeuft A.R.I auch ohne offenes Fenster weiter
    (Weckwort/Sprache brauchen aber das offene Fenster). Laeuft in einem eigenen Thread mit eigener Nachrichtenschleife."""
    global _TRAY_ACTIVE
    if not IS_WIN:
        return
    # Nur EIN Symbol fuer alle A.R.I-Prozesse (Hub im Hintergrund + Fenster-Prozess): wer zuerst kommt, zeigt es.
    try:
        _k32 = ctypes.windll.kernel32
        _k32.CreateMutexW.restype = ctypes.c_void_p
        global _tray_mutex
        _tray_mutex = _k32.CreateMutexW(None, False, "Local" + chr(92) + "ARI_TrayIcon_Single")
        if ctypes.get_last_error() == 183 or _k32.GetLastError() == 183:   # ERROR_ALREADY_EXISTS
            print("[tray] Symbol gibt es schon (anderer A.R.I-Prozess) - kein zweites.")
            return
    except Exception:
        pass
    def _open_window():
        # Ein frischer Start erkennt den laufenden Hub von selbst und oeffnet nur das Fenster (Mutex: nie zwei Fenster).
        try:
            exe = os.path.join(sys.base_prefix, "Ari Assistent.exe")
            if not os.path.exists(exe):
                exe = os.path.join(sys.base_prefix, "pythonw.exe")
            subprocess.Popen([exe, os.path.join(DASHBOARD_DIR, "hub.py")], cwd=DASHBOARD_DIR, creationflags=_NOWIN)
        except Exception as e:
            print(f"[tray] Fenster konnte nicht geoeffnet werden: {e}")
    def _run():
        global _TRAY_ACTIVE
        try:
            import clr
            clr.AddReference("System.Windows.Forms"); clr.AddReference("System.Drawing")
            from System.Windows.Forms import NotifyIcon, ContextMenuStrip, ToolStripMenuItem, Application, MouseButtons
            from System.Drawing import Icon
            ico = os.path.join(DASHBOARD_DIR, "app", "ari.ico")
            ni = NotifyIcon()
            if os.path.exists(ico):
                ni.Icon = Icon(ico)
            ni.Text = "A.R.I"
            menu = ContextMenuStrip()
            it_open = ToolStripMenuItem("A.R.I öffnen")
            it_exit = ToolStripMenuItem("Beenden")
            it_open.Click += lambda sender, e: _open_window()
            it_exit.Click += lambda sender, e: (setattr(ni, "Visible", False), _tray_quit())
            menu.Items.Add(it_open); menu.Items.Add(it_exit)
            _tray_apply_style(menu, (it_open, it_exit))
            ni.ContextMenuStrip = menu
            def _on_click(sender, e):
                if e.Button == MouseButtons.Left:
                    _open_window()
            ni.MouseClick += _on_click
            ni.Visible = True
            _TRAY_ACTIVE = True
            global _tray_icon
            _tray_icon = ni
            Application.Run()
        except Exception as e:
            _TRAY_ACTIVE = False
            print(f"[tray] Symbol im Infobereich nicht verfuegbar: {e}")
    try:
        import clr
        from System.Threading import Thread, ThreadStart, ApartmentState
        t = Thread(ThreadStart(_run))
        t.SetApartmentState(ApartmentState.STA)   # WinForms-Komponenten brauchen einen STA-Thread
        t.IsBackground = True
        t.Start()
    except Exception as e:
        print(f"[tray] Start fehlgeschlagen: {e}")


_tray_icon = None
_tray_mutex = None


_WINDOW_GEOM_FILE = os.path.join(DATA_DIR, "window.json")


def _load_window_geom():
    """Letzte Fensterposition/-groesse (x, y, width, height) - nur wenn sie noch auf einem angeschlossenen Bildschirm liegt, sonst None (Standardplatz)."""
    try:
        with open(_WINDOW_GEOM_FILE, "r", encoding="utf-8") as f:
            g = json.load(f)
        x, y, w, h = int(g["x"]), int(g["y"]), int(g["width"]), int(g["height"])
    except (OSError, ValueError, KeyError, TypeError):
        return None
    if w < 600 or h < 400:
        return None
    try:
        gm = ctypes.windll.user32.GetSystemMetrics   # gesamter virtueller Bildschirm (alle Monitore)
        vx, vy, vw, vh = gm(76), gm(77), gm(78), gm(79)
        # mindestens ein Stueck der Titelleiste muss sichtbar sein (Monitor wurde abgesteckt/Aufloesung geaendert -> Standardplatz)
        if x + 120 < vx or x > vx + vw - 120 or y < vy - 10 or y > vy + vh - 80:
            return None
    except Exception:
        pass
    return {"x": x, "y": y, "width": w, "height": h}


def _save_window_geom(win, last):
    """Speichert Position/Groesse, wenn sie sich geaendert haben (nicht im minimierten Zustand). Gibt die zuletzt gespeicherten Werte zurueck."""
    try:
        g = {"x": int(win.x), "y": int(win.y), "width": int(win.width), "height": int(win.height)}
    except Exception:
        return last
    if g["x"] <= -30000 or g["y"] <= -30000 or g["width"] < 300 or g["height"] < 200 or g == last:
        return last
    try:
        with open(_WINDOW_GEOM_FILE, "w", encoding="utf-8") as f:
            json.dump(g, f)
    except OSError:
        return last
    return g


def _open_hud_window_native(url="http://127.0.0.1:5000"):
    """Oeffnet das HUD als eigenes natives Fenster (pywebview + WebView2) statt
    als Browser-Fenster - kein eigener Chrome/Edge-Prozess mit all seinen
    Hintergrunddiensten (Sync, Erweiterungen, GPU-Prozess je Fenster usw.) noetig,
    deutlich genuegsamer. Funktioniert unabhaengig davon, ob DIESER Prozess den
    Flask-Server selbst betreibt oder nur ein Fenster fuer einen bereits
    anderswo laufenden Hub oeffnet (z.B. den elevierten Hintergrund-Prozess der
    Administrator-Aufgabe) - pywebview braucht dafuer nur die erreichbare URL.
    Blockiert den aufrufenden Thread, bis das Fenster geschlossen wird.
    private_mode=False + fester storage_path, sonst wuerden bei jedem Neustart
    alle im Browser-Speicher (localStorage) abgelegten HUD-Einstellungen
    verloren gehen (Farben, Tour-Status, urspruenglich auch API-Schluessel,
    siehe DEFAULT_SETTINGS im Frontend). Gibt True zurueck, wenn das Fenster
    lief (bis es geschlossen wurde) - False, wenn pywebview/WebView2 gar nicht
    erst starten konnte (z.B. Runtime fehlt); der Aufrufer faellt dann auf das
    Browser-Fenster zurueck."""
    if not IS_WIN:
        return False
    try:
        import webview
    except Exception as e:
        print(f"[webview] pywebview nicht installiert/verfuegbar: {e}")
        return False
    # Nur EIN HUD-Fenster gleichzeitig: Autostart-Verknuepfung, Administrator-Aufgabe und START-ARI.bat koennen
    # fast gleichzeitig starten (jeder Start oeffnet sein Fenster) - ein benannter Mutex macht daraus genau eines.
    # Er wird beim Schliessen des Fensters wieder freigegeben, ein spaeterer Start kann dann wieder eins oeffnen.
    k32 = ctypes.windll.kernel32
    k32.CreateMutexW.restype = ctypes.c_void_p
    k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    mutex = k32.CreateMutexW(None, False, "Local\\ARI_HUD_WINDOW")
    if mutex and k32.GetLastError() == 183:   # ERROR_ALREADY_EXISTS: ein anderer Prozess hat das Fenster schon offen
        k32.CloseHandle(mutex)
        print("[webview] HUD-Fenster ist bereits offen - kein zweites geoeffnet.")
        return True
    try:
        icon_path = os.path.join(DASHBOARD_DIR, "app", "ari.ico")
        storage_path = os.path.join(DASHBOARD_DIR, "data", "webview-profile")
        _garg = _gpu_browser_arg()
        if _garg:   # gewaehlte Grafikkarte (z. B. die integrierte) direkt an den Browser-Grafikprozess uebergeben
            # Per Umgebungsvariable (so uebernimmt der Browser das Argument bis in den Grafikprozess; geprueft: Grafikprozess lief danach auf der
            # integrierten Karte). Ein noch laufender alter Browser-Prozess mit gleichem Profil wuerde sein altes Argument behalten - siehe _gpu_restart.
            _old = os.environ.get("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "")
            if _garg not in _old:
                os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = (_old + " " + _garg).strip()
            print(f"[gpu] HUD-Fenster nutzt die gewaehlte Grafikkarte ({_garg})")
        _geom = _load_window_geom() if IS_WIN else None   # wieder dort oeffnen, wo das Fenster zuletzt war
        _win = webview.create_window(
            "A.R.I — Command Center", url,
            width=(_geom or {}).get("width", 1440), height=(_geom or {}).get("height", 900), min_size=(900, 600),
            **({"x": _geom["x"], "y": _geom["y"]} if _geom else {}),
            text_select=True,  # sonst laesst sich z.B. das Befehls-Protokoll nicht markieren/kopieren
        )

        def _watch_hub(win):
            """Laeuft der Hub nicht mehr (Tray > Beenden, Beenden-Knopf, Leerlauf), geht das Fenster mit zu. Bei einem Neustart (Hub kurz weg, ohne
            Beenden-Marke) bleibt es offen und wartet; nach 40 s ohne Hub schliesst es trotzdem."""
            import urllib.request
            last_ok, down_since = time.time(), None
            saved = _geom
            while True:
                time.sleep(0.5)
                saved = _save_window_geom(win, saved)   # Position/Groesse laufend merken (auch wenn das Fenster per X geschlossen wird)
                try:
                    urllib.request.urlopen("http://127.0.0.1:5000/phone/icon.svg", timeout=2).read()
                    last_ok, down_since = time.time(), None
                    continue
                except Exception:
                    pass
                down_since = down_since or time.time()
                try:
                    quit_at = os.path.getmtime(_QUIT_FLAG)
                except OSError:
                    quit_at = 0
                if quit_at >= last_ok - 2 or time.time() - down_since > 40:
                    print("[webview] Hub beendet - HUD-Fenster geht mit zu.")
                    try:
                        win.destroy()
                    except Exception:
                        pass
                    return
        webview.settings['ALLOW_DOWNLOADS'] = True   # sonst tut der EXPORTIEREN-Knopf (Datei-Download) im eigenen Fenster nichts
        webview.start(
            _watch_hub, _win,
            icon=icon_path if os.path.exists(icon_path) else None,
            private_mode=False, storage_path=storage_path,
        )
        # Fenster zu: dem Hub (egal in welchem Prozess er laeuft) gleich Bescheid sagen - er beendet sich nach kurzer Frist, wenn nicht gleich ein neues
        # Fenster/Herzschlag kommt (z.B. beim Neustart der Grafik). Sonst wartete er erst den langen Leerlauf ab.
        try:
            import urllib.request
            urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:5000/closing", data=b"{}", headers={"Content-Type": "application/json"}, method="POST"), timeout=2).read()
        except Exception:
            pass
        return True
    except Exception as e:
        print(f"[webview] Natives Fenster fehlgeschlagen, nutze Browser-Fenster: {e}")
        return False
    finally:
        if mutex:
            k32.CloseHandle(mutex)


def _prepare_named_exe():
    """Legt neben der Python-Installation eine Kopie von pythonw.exe als
    'Ari Assistent.exe' an und schreibt Name/Beschreibung in deren Versions-
    Ressource - so heisst der Prozess im Task-Manager 'Ari Assistent' statt
    'Python'. Aufruf: python hub.py --prepare-exe (macht START-ARI.bat)."""
    if not IS_WIN:
        try:   # Linux: Prozessname in der Prozessliste (optional, nur wenn setproctitle installiert ist)
            import setproctitle
            setproctitle.setproctitle("Ari Assistent")
        except ImportError:
            pass
        return
    import struct
    base = sys.base_prefix
    src, dst = os.path.join(base, "pythonw.exe"), os.path.join(base, "Ari Assistent.exe")
    if not os.path.exists(dst):
        shutil.copy2(src, dst)
    NAME = "Ari Assistent"

    def pad4(b):
        return b + b"\0" * ((-len(b)) % 4)

    def blk(key, value=b"", vlen=0, wtype=1, children=b""):
        b = struct.pack("<HHH", 0, vlen, wtype) + (key + "\0").encode("utf-16-le")
        b = pad4(b) + value
        if children:
            b = pad4(b) + children
        return struct.pack("<H", len(b)) + b[2:]

    def sval(k, v):
        return blk(k, (v + "\0").encode("utf-16-le"), len(v) + 1, 1)

    strings = {
        "CompanyName": NAME, "FileDescription": NAME, "FileVersion": "1.0.0", "InternalName": NAME,
        "OriginalFilename": NAME + ".exe", "ProductName": NAME, "ProductVersion": "1.0.0",
    }
    st = blk("040904B0", children=b"".join(pad4(sval(k, v)) for k, v in strings.items()))
    sfi = blk("StringFileInfo", children=st)
    vfi = blk("VarFileInfo", children=blk("Translation", struct.pack("<HH", 0x0409, 0x04B0), 4, 0))
    fixed = struct.pack("<13I", 0xFEEF04BD, 0x00010000, 0x00010000, 0, 0x00010000, 0, 0x3F, 0, 0x40004, 1, 0, 0, 0)
    root = blk("VS_VERSION_INFO", fixed, 52, 0, pad4(sfi) + vfi)

    k32 = ctypes.windll.kernel32
    k32.LoadLibraryExW.restype = ctypes.c_void_p
    k32.LoadLibraryExW.argtypes = [ctypes.c_wchar_p, ctypes.c_void_p, ctypes.c_uint32]
    k32.FreeLibrary.argtypes = [ctypes.c_void_p]
    k32.BeginUpdateResourceW.restype = ctypes.c_void_p
    k32.BeginUpdateResourceW.argtypes = [ctypes.c_wchar_p, ctypes.c_bool]
    k32.UpdateResourceW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint16, ctypes.c_void_p, ctypes.c_uint32]
    k32.EndUpdateResourceW.argtypes = [ctypes.c_void_p, ctypes.c_bool]
    langs = []
    ENUMLANG = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint16, ctypes.c_void_p)
    cb = ENUMLANG(lambda hm, t, n, lang, lp: (langs.append(lang), True)[1])
    hmod = k32.LoadLibraryExW(dst, None, 0x2)  # LOAD_LIBRARY_AS_DATAFILE
    if hmod:
        k32.EnumResourceLanguagesW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ENUMLANG, ctypes.c_void_p]
        k32.EnumResourceLanguagesW(hmod, 16, 1, cb, None)
        k32.FreeLibrary(hmod)
    h = k32.BeginUpdateResourceW(dst, False)
    if not h:
        print("Ari Assistent.exe laeuft gerade oder ist gesperrt - Beschreibung nicht aktualisiert.")
        return
    for lang in langs:
        k32.UpdateResourceW(h, 16, 1, lang, None, 0)  # alte Version loeschen
    buf = ctypes.create_string_buffer(root, len(root))
    ok = k32.UpdateResourceW(h, 16, 1, 0x0409, buf, len(root))
    # Eigenes Icon (Task-Manager/Taskleiste): app/ari.ico ersetzt das Python-Icon der Kopie
    try:
        ico_path = os.path.join(DASHBOARD_DIR, "app", "ari.ico")
        if ok and os.path.exists(ico_path):
            with open(ico_path, "rb") as f:
                ico = f.read()
            _r, _t, cnt = struct.unpack("<HHH", ico[:6])
            frames = []
            for i in range(cnt):
                w, hh, cc, _z, pl, bc, sz, off = struct.unpack("<BBBBHHII", ico[6 + 16 * i:22 + 16 * i])
                frames.append((w, hh, cc, pl, bc, ico[off:off + sz]))
            if _t == 1 and frames:
                dl = hmod2 = k32.LoadLibraryExW(dst, None, 0x2)
                old_icons = []   # (typ, name, lang) der bisherigen Icons
                if hmod2:
                    NAMECB = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
                    k32.EnumResourceNamesW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, NAMECB, ctypes.c_void_p]
                    for typ in (3, 14):
                        nm = []
                        ncb = NAMECB(lambda hm, t, n, lp: (nm.append(int(n)) if n <= 65535 else None, True)[1])
                        k32.EnumResourceNamesW(hmod2, typ, ncb, None)
                        for n in nm:
                            ls = []
                            lcb = ENUMLANG(lambda hm, t, n_, lang, lp: (ls.append(lang), True)[1])
                            k32.EnumResourceLanguagesW(hmod2, typ, n, lcb, None)
                            old_icons += [(typ, n, lg) for lg in ls]
                    k32.FreeLibrary(hmod2)
                for typ, n, lg in old_icons:
                    k32.UpdateResourceW(h, typ, n, lg, None, 0)
                grp = struct.pack("<HHH", 0, 1, len(frames))
                for i, (w, hh, cc, pl, bc, data) in enumerate(frames, start=1):
                    b = ctypes.create_string_buffer(data, len(data))
                    k32.UpdateResourceW(h, 3, i, 0x0409, b, len(data))
                    grp += struct.pack("<BBBBHHIH", w, hh, cc, 0, pl, bc, len(data), i)
                gb = ctypes.create_string_buffer(grp, len(grp))
                k32.UpdateResourceW(h, 14, 1, 0x0409, gb, len(grp))
    except Exception as e:
        print("Icon konnte nicht gesetzt werden:", e)
    committed = k32.EndUpdateResourceW(h, not ok)
    if ok and committed:
        print("Ari Assistent.exe vorbereitet.")
    else:
        print("Ari Assistent.exe laeuft gerade (gesperrt) oder ist nicht beschreibbar - Beschreibung unveraendert.")


# ===== MODS: Erweiterungen, die man in den Einstellungen installieren, einschalten und aktualisieren kann =====
# Ein Mod ist ein Ordner data/mods/<id>/ mit mod.json (Name, Version, ...), optional main.py (Hub-Teil) und hud.js/hud.css (Oberflaeche).
# Mods aus dem offiziellen Katalog (GitHub Pages) oder aus dem PC-Paket (Ordner mods/) gelten als vertraut - ihre Dateien werden beim
# Installieren per SHA-256 geprueft. Selbst hineingezogene Mods ("local") brauchen wie Plugins eine Freigabe.
MODS_DIR = os.path.join(DATA_DIR, "mods")
_MODS_STATE_FILE = os.path.join(MODS_DIR, "_state.json")
_MODS_BUNDLED_DIR = os.path.join(DASHBOARD_DIR, "mods")
_MODS_BASE = os.environ.get("ARI_MODS_BASE") or "https://kingshadow1332.github.io/A.R.I/app/mods/"
_MOD_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,40}$")
_MOD_EXT = {".py", ".json", ".js", ".css", ".png", ".svg", ".txt", ".md"}
_MOD_INFO = {}
_MOD_TOOL_HANDLERS = {}     # Werkzeugname -> (mod_id, funktion(name, eingabe))
_MOD_TOOL_KEYWORDS = {}     # Werkzeugname -> Regex (Stichwoerter fuer den Vorfilter)
_MOD_STATUS_HOOKS = []      # (mod_id, fn() -> dict) fuer /status
_MOD_TICKS = []             # (mod_id, fn()) alle paar Sekunden im Prozess-Thread
_MOD_PROMPT_HOOKS = []      # (mod_id, fn() -> str) Zusatz fuer den System-Prompt
_mods_lock = threading.Lock()
_mods_state_lock = threading.Lock()
_mods_catalog_cache = {"ts": 0, "data": None, "error": ""}
_mods_flags = {"restart_needed": False, "updated": []}


def _mod_state():
    try:
        with open(_MODS_STATE_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _mod_state_update(mid, **fields):
    with _mods_state_lock:
        st = _mod_state()
        cur = dict(st.get(mid) or {})
        for k, v in fields.items():
            if v is None:
                cur.pop(k, None)
            else:
                cur[k] = v
        st[mid] = cur
        os.makedirs(MODS_DIR, exist_ok=True)
        tmp = _MODS_STATE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, indent=2, ensure_ascii=False)
        os.replace(tmp, _MODS_STATE_FILE)


def _mod_state_drop(mid):
    with _mods_state_lock:
        st = _mod_state()
        st.pop(mid, None)
        tmp = _MODS_STATE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, indent=2, ensure_ascii=False)
        os.replace(tmp, _MODS_STATE_FILE)


def _mod_ver(v):
    """'1.2.10' -> (1, 2, 10) zum Vergleichen."""
    parts = []
    for p in re.split(r"[.\-]", str(v or "0")):
        parts.append(int(p) if p.isdigit() else 0)
    return tuple(parts) or (0,)


def _mod_read_manifest(folder):
    with open(os.path.join(folder, "mod.json"), "r", encoding="utf-8-sig") as f:   # utf-8-sig: auch Dateien mit unsichtbarem BOM (z. B. von PowerShell) lesen
        man = json.load(f)
    if not isinstance(man, dict):
        raise ValueError("mod.json ist kein Objekt")
    return man


class _ModCtx:
    """Das bekommt main.py von jedem Mod in register(ctx): Haken in den Hub, ohne dass der Mod den Kern kennen muss."""

    def __init__(self, mid, info):
        self.id = mid
        self.info = info
        self.dir = os.path.join(MODS_DIR, mid)
        self.app = app
        self.data_dir = DATA_DIR

    def add_tools(self, defs, handler, keywords=None, labels=None):
        """defs: Werkzeug-Definitionen (name, description, input_schema); handler(name, eingabe) -> Text; keywords: Regex-Text fuer den Vorfilter."""
        rx = re.compile(keywords, re.IGNORECASE) if keywords else None
        for d in defs:
            TOOLS.append(d)
            _MOD_TOOL_HANDLERS[d["name"]] = (self.id, handler)
            if rx is not None:
                _MOD_TOOL_KEYWORDS[d["name"]] = rx
            self.info.setdefault("tools", []).append(d["name"])
        if labels:
            _BRAIN_TOOL_LABELS.update(labels)

    def add_status(self, fn):
        _MOD_STATUS_HOOKS.append((self.id, fn))

    def add_tick(self, fn):
        _MOD_TICKS.append((self.id, fn))

    def add_prompt(self, fn):
        _MOD_PROMPT_HOOKS.append((self.id, fn))

    def log(self, msg):
        print(f"[mod:{self.id}] {msg}")


def _mod_run_tool(name, tool_input):
    mid, fn = _MOD_TOOL_HANDLERS[name]
    try:
        return fn(name, tool_input)
    except Exception as e:
        print(f"[mod:{mid}] Fehler in {name}: {e}")
        return "Dieses Mod-Werkzeug hat einen Fehler gemeldet."


def _mod_status_extras():
    out = {}
    for mid, fn in _MOD_STATUS_HOOKS:
        try:
            d = fn()
            if isinstance(d, dict):
                out.update(d)
        except Exception as e:
            print(f"[mod:{mid}] Status-Haken: {e}")
    return out


def _mod_tick():
    for mid, fn in _MOD_TICKS:
        try:
            fn()
        except Exception as e:
            print(f"[mod:{mid}] Tick: {e}")


def _mod_prompt_extra():
    out = ""
    for mid, fn in _MOD_PROMPT_HOOKS:
        try:
            t = fn()
            if t:
                out += "\n\n" + str(t)
        except Exception as e:
            print(f"[mod:{mid}] Prompt-Haken: {e}")
    return out


def _mod_copy_tree(src, dst):
    """Ordner kopieren (nur erlaubte Dateiendungen)."""
    for root, _dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        for fn in files:
            if os.path.splitext(fn)[1].lower() not in _MOD_EXT:
                continue
            tgt = os.path.join(dst, "" if rel == "." else rel)
            os.makedirs(tgt, exist_ok=True)
            shutil.copy2(os.path.join(root, fn), os.path.join(tgt, fn))


def _mods_seed_bundled():
    """Mods, die im PC-Paket mitkommen (Ordner mods/), beim Start nach data/mods kopieren - neu: eingeschaltet; vorhanden: bei hoeherer Version aktualisieren.
    Hat der Nutzer einen Mod entfernt, kommt er nicht von selbst wieder."""
    if not os.path.isdir(_MODS_BUNDLED_DIR):
        return
    st = _mod_state()
    for mid in sorted(os.listdir(_MODS_BUNDLED_DIR)):
        src = os.path.join(_MODS_BUNDLED_DIR, mid)
        if not os.path.isdir(src) or not _MOD_ID_RE.match(mid):
            continue
        try:
            man = _mod_read_manifest(src)
        except (OSError, ValueError):
            continue
        cur = st.get(mid) or {}
        dst = os.path.join(MODS_DIR, mid)
        if cur.get("removed"):
            continue
        if os.path.isdir(dst):
            try:
                have = _mod_read_manifest(dst).get("version")
            except (OSError, ValueError):
                have = "0"
            if cur.get("source", "local") == "local" or _mod_ver(man.get("version")) <= _mod_ver(have):
                continue
            shutil.rmtree(dst, ignore_errors=True)
        try:
            _mod_copy_tree(src, dst)
            _mod_state_update(mid, enabled=bool(cur.get("enabled", man.get("default_enabled", True))), source="bundled", version=str(man.get("version") or ""))
            print(f"[mod] '{mid}' aus dem Programmpaket eingerichtet (Version {man.get('version')}).")
        except OSError as e:
            print(f"[mod] '{mid}' konnte nicht eingerichtet werden: {e}")


_MOD_LOADED = set()   # Mods, deren Hub-Teil (main.py) in diesem Hub-Lauf schon geladen wurde


def _mod_load_one(mid, state):
    """Liest einen Mod-Ordner und laedt ihn, falls eingeschaltet (Hub-Teil + Haken). Gibt nichts zurueck; Ergebnis steht in _MOD_INFO[mid]."""
    import importlib.util
    folder = os.path.join(MODS_DIR, mid)
    if not os.path.isdir(folder) or not _MOD_ID_RE.match(mid):
        return
    st = state.get(mid) or {}
    info = {"id": mid, "name": mid, "description": "", "version": "", "author": "", "icon": "", "enabled": False, "changed": False,
            "source": st.get("source", "local"), "error": "", "has_hud": False, "tools": [], "details": []}
    _MOD_INFO[mid] = info
    try:
        man = _mod_read_manifest(folder)
        info.update(name=str(man.get("name") or mid)[:60], description=str(man.get("description") or "")[:300],
                    version=str(man.get("version") or "")[:20], author=str(man.get("author") or "")[:60], icon=str(man.get("icon") or "")[:8],
                    details=[str(x)[:260] for x in (man.get("details") or [])][:12])
    except (OSError, ValueError) as e:
        info["error"] = f"mod.json fehlt oder ist kaputt ({type(e).__name__})"
        return
    info["has_hud"] = os.path.exists(os.path.join(folder, "hud.js")) or os.path.exists(os.path.join(folder, "hud.css"))
    if not st.get("enabled"):
        return
    if info["source"] == "local" and st.get("approved_hash") != _plugin_hash(folder):
        info["changed"] = True   # selbst hineingezogener Mod wurde veraendert: erst nach neuer Freigabe laden
        return
    info["enabled"] = True
    main = os.path.join(folder, "main.py")
    if not os.path.exists(main):
        _MOD_LOADED.add(mid)
        return
    try:
        spec = importlib.util.spec_from_file_location("ari_mod_" + mid.replace("-", "_"), main)
        mod = importlib.util.module_from_spec(spec)
        # der Mod bekommt alle Namen des Hubs (psutil, app, Hilfsfunktionen ...) - so laeuft der aus dem Hub herausgeloeste Code unveraendert
        mod.__dict__.update({k: v for k, v in globals().items() if not (k.startswith("__") and k.endswith("__"))})
        spec.loader.exec_module(mod)
        reg = getattr(mod, "register", None)
        if callable(reg):
            reg(_ModCtx(mid, info))
        _MOD_LOADED.add(mid)
        print(f"[mod] '{info['name']}' {info['version']} geladen")
    except Exception as e:
        info["enabled"], info["error"] = False, f"{type(e).__name__}: {e}"[:200]
        print(f"[mod] '{mid}' konnte nicht geladen werden: {e}")


def _mods_load():
    """Liest data/mods, laedt eingeschaltete Mods (Hub-Teil) und meldet ihre Haken an. Laeuft einmal beim Start, vor dem Server."""
    os.makedirs(MODS_DIR, exist_ok=True)
    try:
        _mods_seed_bundled()
    except Exception as e:
        print(f"[mod] Paket-Mods: {e}")
    state = _mod_state()
    for mid in sorted(os.listdir(MODS_DIR)):
        _mod_load_one(mid, state)


def _mod_hot_load(mid):
    """Laedt einen frisch installierten/eingeschalteten Mod SOFORT, ohne Neustart von A.R.I. Flask erlaubt neue Routen eigentlich nur vor der
    ersten Anfrage - dieser Schutz wird dafuer kurz abgeschaltet. Gibt True zurueck, wenn der Mod danach laeuft."""
    if mid in _MOD_LOADED:
        return True
    old = getattr(app, "_got_first_request", False)
    try:
        app._got_first_request = False
        _mod_load_one(mid, _mod_state())
    except Exception as e:
        print(f"[mod] Sofort-Laden von '{mid}': {e}")
    finally:
        app._got_first_request = old
    info = _MOD_INFO.get(mid) or {}
    return bool(info.get("enabled") and not info.get("error") and mid in _MOD_LOADED)


# --- Katalog + Installation -------------------------------------------------------------------------------
def _mods_catalog(force=False):
    """Mod-Liste aus dem GitHub-Katalog (kurz zwischengespeichert). Gibt (liste, fehlertext) zurueck."""
    c = _mods_catalog_cache
    if not force and c["data"] is not None and time.time() - c["ts"] < 120:
        return c["data"], c["error"]
    try:
        req = urllib.request.Request(_MODS_BASE + "catalog.json?t=" + str(int(time.time())), headers={"User-Agent": "A.R.I", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = json.loads(r.read(500_001).decode("utf-8"))
        items = raw.get("mods") if isinstance(raw, dict) else raw
        out = []
        for e in (items or []):
            if isinstance(e, dict) and _MOD_ID_RE.match(str(e.get("id", ""))) and re.fullmatch(r"[A-Za-z0-9._-]+\.zip", str(e.get("zip", ""))) \
                    and re.fullmatch(r"[0-9a-fA-F]{64}", str(e.get("sha256", ""))):
                out.append({"id": e["id"], "name": str(e.get("name") or e["id"])[:60], "description": str(e.get("description") or "")[:300],
                            "version": str(e.get("version") or "0")[:20], "icon": str(e.get("icon") or "")[:8], "zip": e["zip"],
                            "sha256": str(e["sha256"]).lower(), "min_core": int(e.get("min_core") or 0),
                            "details": [str(x)[:260] for x in (e.get("details") or [])][:12]})
        c.update(ts=time.time(), data=out, error="")
    except Exception as e:
        c.update(ts=time.time(), data=c["data"] or [], error="Mod-Liste nicht erreichbar - ist das Internet an?")
        print(f"[mod] Katalog: {e}")
    return c["data"], c["error"]


def _mod_install_zip(mid, zip_bytes, expect_sha=None, source="catalog"):
    """Prueft und entpackt einen Mod. Gibt (ok, meldung) zurueck. Bei jedem Fehler bleibt der alte Stand unveraendert."""
    import zipfile
    import io
    import py_compile
    if expect_sha and hashlib.sha256(zip_bytes).hexdigest() != expect_sha.lower():
        return False, "Die Datei ist beschaedigt oder veraendert (Pruefsumme stimmt nicht)."
    tmp = os.path.join(MODS_DIR, ".tmp-" + mid)
    shutil.rmtree(tmp, ignore_errors=True)
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            if not infos or len(infos) > 80 or sum(i.file_size for i in infos) > 8_000_000:
                return False, "Das Mod-Paket ist leer oder zu gross."
            names = [i.filename.replace("\\", "/") for i in infos]
            top = {n.split("/")[0] for n in names if "/" in n}
            strip = ""
            if "mod.json" not in names and len(top) == 1 and all(n.startswith(next(iter(top)) + "/") for n in names):
                strip = next(iter(top)) + "/"
            for i, n in zip(infos, names):
                rel = n[len(strip):] if strip else n
                if not rel or rel.startswith("/") or ".." in rel.split("/") or ":" in rel or os.path.splitext(rel)[1].lower() not in _MOD_EXT:
                    return False, "Das Mod-Paket enthaelt eine nicht erlaubte Datei."
            os.makedirs(tmp, exist_ok=True)
            for i, n in zip(infos, names):
                rel = n[len(strip):] if strip else n
                p = os.path.join(tmp, *rel.split("/"))
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with z.open(i) as src, open(p, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        try:
            man = _mod_read_manifest(tmp)
        except (OSError, ValueError):
            return False, "Im Mod-Paket fehlt eine gueltige mod.json."
        if str(man.get("id") or "") != mid:
            return False, "Die Kennung im Mod-Paket passt nicht."
        mainp = os.path.join(tmp, "main.py")
        if os.path.exists(mainp):
            try:
                py_compile.compile(mainp, doraise=True, cfile=os.path.join(tmp, "_main.check"))
                os.remove(os.path.join(tmp, "_main.check"))
            except Exception:
                return False, "Der Programmteil des Mods ist fehlerhaft."
        dst = os.path.join(MODS_DIR, mid)
        bak = os.path.join(MODS_DIR, ".bak-" + mid)
        shutil.rmtree(bak, ignore_errors=True)
        had = os.path.isdir(dst)
        if had:
            shutil.move(dst, bak)
        try:
            shutil.move(tmp, dst)
        except Exception:
            if had:
                shutil.move(bak, dst)
            raise
        shutil.rmtree(bak, ignore_errors=True)
        _mod_state_update(mid, source=source, version=str(man.get("version") or ""), removed=None)
        return True, "ok"
    except zipfile.BadZipFile:
        return False, "Das Mod-Paket ist keine gueltige ZIP-Datei."
    except Exception as e:
        print(f"[mod] Installation von '{mid}': {e}")
        return False, "Der Mod konnte nicht installiert werden."
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _mod_install_from_catalog(entry):
    try:
        req = urllib.request.Request(_MODS_BASE + entry["zip"], headers={"User-Agent": "A.R.I", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = r.read(6_000_001)
        if len(data) > 6_000_000:
            return False, "Das Mod-Paket ist zu gross."
    except Exception as e:
        print(f"[mod] Download '{entry.get('id')}': {e}")
        return False, "Download nicht moeglich - ist das Internet an?"
    with _mods_lock:
        ok, msg = _mod_install_zip(entry["id"], data, entry["sha256"], "catalog")
    return ok, msg


def _mods_update_all(auto=False):
    """Installierte Mods aus Katalog/Paket auf die neueste Katalog-Version bringen. Gibt Liste der aktualisierten Mod-Namen zurueck."""
    cat, err = _mods_catalog(force=True)
    done = []
    st = _mod_state()
    for e in cat:
        cur = st.get(e["id"]) or {}
        folder = os.path.join(MODS_DIR, e["id"])
        if not os.path.isdir(folder) or cur.get("source") not in ("catalog", "bundled") or e["min_core"] > ARI_VERSION:
            continue
        try:
            have = _mod_read_manifest(folder).get("version")
        except (OSError, ValueError):
            have = "0"
        if _mod_ver(e["version"]) > _mod_ver(have):
            ok, msg = _mod_install_from_catalog(e)
            if ok:
                done.append(e["name"])
    if done:
        _mods_flags["restart_needed"] = True
        _mods_flags["updated"] = list(dict.fromkeys(_mods_flags["updated"] + done))
    return done


def _mods_auto_loop():
    first = True
    while True:
        time.sleep(90 if first else 6 * 3600)
        first = False
        try:
            if not _load_secrets().get("mods_auto_update", True):
                continue
            done = _mods_update_all(auto=True)
            if done:
                print("[mod] automatisch aktualisiert:", ", ".join(done))
                _show_toast("A.R.I Mods aktualisiert", ", ".join(done) + " - wirkt nach dem naechsten Start von A.R.I.")
        except Exception as e:
            print("[mod] Auto-Update:", e)


# --- Routen (nur vom eigenen PC) ---------------------------------------------------------------------------
def _mods_local_only():
    if not _is_local_request():
        return jsonify({"error": "verboten"}), 403
    return None


@app.route("/mods")
def mods_list():
    bad = _mods_local_only()
    if bad:
        return bad
    cat, err = _mods_catalog(force=request.args.get("refresh") == "1")
    cat_by = {e["id"]: e for e in cat}
    st = _mod_state()
    rows = []
    for mid, info in sorted(_MOD_INFO.items()):
        e = cat_by.get(mid)
        rows.append({**info, "installed": True, "latest": e["version"] if e else "", "update": bool(e and _mod_ver(e["version"]) > _mod_ver(info["version"])),
                     "wanted": bool((st.get(mid) or {}).get("enabled"))})
    for e in cat:
        if e["id"] not in _MOD_INFO:
            rows.append({"id": e["id"], "name": e["name"], "description": e["description"], "version": "", "latest": e["version"], "icon": e["icon"],
                         "installed": False, "enabled": False, "update": False, "wanted": False, "source": "catalog", "error": "", "changed": False, "has_hud": False, "tools": [],
                         "details": e.get("details", [])})
    return jsonify({"mods": rows, "catalog_error": err, "auto_update": bool(_load_secrets().get("mods_auto_update", True)),
                    "restart_needed": _mods_flags["restart_needed"], "updated": _mods_flags["updated"]})


@app.route("/mods/install", methods=["POST"])
def mods_install():
    bad = _mods_local_only()
    if bad:
        return bad
    mid = str((request.get_json(silent=True) or {}).get("id") or "")
    cat, _err = _mods_catalog()
    e = next((x for x in cat if x["id"] == mid), None)
    if not e:
        return jsonify({"error": "Diesen Mod gibt es in der Liste nicht."})
    if e["min_core"] > ARI_VERSION:
        return jsonify({"error": "Dieser Mod braucht eine neuere A.R.I-Version - bitte erst A.R.I aktualisieren."})
    ok, msg = _mod_install_from_catalog(e)
    if not ok:
        return jsonify({"error": msg})
    _mod_state_update(mid, enabled=True)
    hot = _mod_hot_load(mid)
    if not hot:
        _mods_flags["restart_needed"] = True
    return jsonify({"error": None, "restart_needed": not hot, "hot": hot})


@app.route("/mods/enable", methods=["POST"])
def mods_enable():
    bad = _mods_local_only()
    if bad:
        return bad
    d = request.get_json(silent=True) or {}
    mid = str(d.get("id") or "")
    folder = os.path.join(MODS_DIR, mid)
    if not _MOD_ID_RE.match(mid) or not os.path.isdir(folder):
        return jsonify({"error": "Diesen Mod gibt es nicht."})
    on = bool(d.get("enabled"))
    fields = {"enabled": on}
    if on and (_mod_state().get(mid) or {}).get("source", "local") == "local":
        fields["approved_hash"] = _plugin_hash(folder)
    _mod_state_update(mid, **fields)
    hot = _mod_hot_load(mid) if on else False   # Einschalten wirkt sofort; Ausschalten braucht einen Neustart (Haken lassen sich nicht zurueckholen)
    if not hot:
        _mods_flags["restart_needed"] = True
    return jsonify({"error": None, "restart_needed": not hot, "hot": hot})


@app.route("/mods/remove", methods=["POST"])
def mods_remove():
    bad = _mods_local_only()
    if bad:
        return bad
    mid = str((request.get_json(silent=True) or {}).get("id") or "")
    folder = os.path.join(MODS_DIR, mid)
    if not _MOD_ID_RE.match(mid) or not os.path.isdir(folder):
        return jsonify({"error": "Diesen Mod gibt es nicht."})
    shutil.rmtree(folder, ignore_errors=True)
    _mod_state_update(mid, enabled=False, removed=True)
    _mods_flags["restart_needed"] = True
    return jsonify({"error": None, "restart_needed": True})


@app.route("/mods/update-all", methods=["POST"])
def mods_update_all():
    bad = _mods_local_only()
    if bad:
        return bad
    done = _mods_update_all()
    return jsonify({"error": None, "updated": done, "restart_needed": _mods_flags["restart_needed"]})


@app.route("/mods/auto", methods=["POST"])
def mods_auto():
    bad = _mods_local_only()
    if bad:
        return bad
    on = bool((request.get_json(silent=True) or {}).get("enabled"))
    with _secrets_lock:
        s = _load_secrets()
        s["mods_auto_update"] = on
        _save_secrets(s)
    return jsonify({"error": None, "auto_update": on})


@app.route("/mods/restart", methods=["POST"])
def mods_restart():
    bad = _mods_local_only()
    if bad:
        return bad
    if not request.is_json:
        return jsonify({"error": "ungültig"}), 400
    _update_restart(quiet=True)
    return jsonify({"error": None})


@app.route("/mods/hud")
def mods_hud_list():
    bad = _mods_local_only()
    if bad:
        return bad
    return jsonify({"mods": [{"id": m["id"], "version": m["version"],
                              "js": os.path.exists(os.path.join(MODS_DIR, m["id"], "hud.js")),
                              "css": os.path.exists(os.path.join(MODS_DIR, m["id"], "hud.css"))}
                             for m in _MOD_INFO.values() if m["enabled"] and m["has_hud"]]})


@app.route("/mods/hud/<mid>/<fn>")
def mods_hud_file(mid, fn):
    bad = _mods_local_only()
    if bad:
        return bad
    info = _MOD_INFO.get(mid)
    if not info or not info["enabled"] or fn not in ("hud.js", "hud.css"):
        return jsonify({"error": "nicht gefunden"}), 404
    return send_from_directory(os.path.join(MODS_DIR, mid), fn, mimetype="text/javascript" if fn.endswith(".js") else "text/css",
                               max_age=0)


if __name__ == "__main__":
    if "--prepare-exe" in sys.argv:
        try:
            _prepare_named_exe()
        except Exception as e:
            print("Vorbereitung fehlgeschlagen:", e)
        sys.exit(0)

if __name__ == "__main__":
    if not IS_WIN:
        print(_lx.startup_report())
        _prepare_named_exe()
    _handover_to_admin_hub()
    _ensure_port_free("0.0.0.0", 5000)
    import atexit
    atexit.register(_dev_console_hide)
    try:
        _plugins_load()   # eigene Erweiterungen (Einstellungen > PLUGINS)
    except Exception as e:
        print(f"[plugin] Laden fehlgeschlagen: {e}")
    try:
        _mods_load()      # Mods (Einstellungen > MODS) - vor dem Start des Servers, damit sie eigene Routen anmelden koennen
    except Exception as e:
        print(f"[mod] Laden fehlgeschlagen: {e}")
    threading.Thread(target=_mods_auto_loop, daemon=True).start()
    # Beim Start 40 s Zusatz-Schonfrist: der Browser braucht evtl. etwas, bis das HUD
    # geladen ist und den ersten Herzschlag schickt.
    _hub_last_seen = time.time() + 40
    threading.Thread(target=_idle_watchdog, daemon=True).start()
    threading.Thread(target=_music_watch, daemon=True).start()
    threading.Thread(target=_music_backfill, daemon=True).start()
    threading.Thread(target=_discovery_loop, daemon=True).start()
    threading.Thread(target=_auto_update_loop, daemon=True).start()
    threading.Thread(target=_stats_loop, daemon=True).start()
    threading.Thread(target=_ensure_python_packages, daemon=True).start()
    print("A.R.I Hub laeuft auf http://127.0.0.1:5000")
    threading.Thread(target=_ensure_start_menu_shortcut, daemon=True).start()
    threading.Thread(target=_fix_autostart_window_style, daemon=True).start()
    threading.Thread(target=_heal_autostart, daemon=True).start()
    threading.Thread(target=_gpu_pref_clean_registry, daemon=True).start()
    threading.Thread(target=_fix_launch_links, daemon=True).start()
    # threaded=True: sonst blockiert das alle ~1.2s laufende Status-Polling
    # vom Frontend zeitweise andere Anfragen (Flasks Dev-Server ist sonst
    # single-threaded und bearbeitet nur eine Anfrage gleichzeitig).
    # use_reloader=False: Werkzeugs Auto-Reloader macht auf diesem Windows-
    # Rechner reproduzierbar JEDE Anfrage 20-40x langsamer (0.5s -> 20-40s),
    # nicht nur bei asyncio-Code wie zuvor angenommen — also generell aus.
    # Bei Code-Aenderungen den Hub daher von Hand neu starten.
    # Laeuft der Hub mit Administrator-Rechten (CPU-Temperatur), gibt der Browser des HUD-Fensters Zusatz-Argumente (z. B. die gewaehlte
    # Grafikkarte) nicht weiter und das Fenster liefe zudem selbst mit Admin-Rechten. Dann bleibt der Hub reiner Server und das Fenster
    # kommt als normaler Prozess - gestartet ueber die Startmenue-Verknuepfung durch den Explorer (laeuft immer ohne Admin-Rechte).
    _elevated = False
    try:
        _elevated = bool(IS_WIN and ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        pass
    _split_window = _elevated and "--no-window" not in sys.argv and os.path.exists(_START_MENU_LNK)
    if ("--background" in sys.argv and "--no-window" in sys.argv) or _split_window:
        # Nur der Server, kein Fenster - blockiert im Hauptthread. Das Tray-Symbol (Infobereich) kommt trotzdem,
        # sonst fehlt A.R.I dort, wenn der Hub ueber die Administrator-Aufgabe im Hintergrund laeuft.
        threading.Timer(2.0, _start_tray).start()
        if _split_window:
            def _open_normal_window():
                try:
                    subprocess.Popen(["explorer.exe", _START_MENU_LNK])
                except Exception as e:
                    print(f"[start] Fenster (ohne Admin-Rechte) konnte nicht geoeffnet werden: {e}")
            threading.Timer(3.0, _open_normal_window).start()
        app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False, threaded=True)
    else:
        # Auch der Windows-Autostart (--background) zeigt jetzt das HUD-Fenster - vorher
        # startete er nur unsichtbar im Hintergrund, was nach "Autostart geht nicht" aussah.
        # Sichtbarer Start: der Flask-Server laeuft in einem Hintergrund-Thread,
        # der Hauptthread oeffnet das HUD-Fenster - pywebview MUSS im Hauptthread
        # laufen (Windows-/macOS-GUI-Vorgabe). Kurze Wartezeit, bis der Server
        # wirklich antwortet, sonst zielt das Fenster auf eine noch nicht
        # erreichbare Seite.
        threading.Thread(
            target=lambda: app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False, threaded=True),
            daemon=True,
        ).start()
        time.sleep(1.5)
        _start_tray()
        if not _open_hud_window_native():
            # pywebview/WebView2 nicht verfuegbar: Browser-App-Fenster wie bisher.
            # _find_window_by_title schuetzt dabei vor einem doppelten Fenster,
            # wenn hub.py neu gestartet wird, waehrend der alte Tab noch offen ist
            # (_ensure_port_free() oben verhindert nur einen zweiten LAUFENDEN Prozess).
            _open_hud_if_not_already_open()
        # Fenster (nativ oder Browser-Fallback) ist zu - Prozess am Leben halten:
        # der Idle-Watchdog (_idle_watchdog, laeuft als Daemon-Thread) entscheidet
        # selbst per os._exit(), ob/wann sich A.R.I wirklich beendet (z.B. bleibt
        # er bei gekoppeltem Handy im Dauerbetrieb auch ohne HUD-Fenster an).
        threading.Event().wait()
