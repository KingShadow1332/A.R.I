@echo off
cd /d "%~dp0"
REM Startet A.R.I ohne Konsolenfenster (Log: data\hub.log).
REM Der Prozess heisst im Task-Manager "Ari Assistent" (Kopie von pythonw.exe).
REM Das HUD-Fenster selbst oeffnet hub.py (siehe _open_hud_window_native/
REM _open_hud_if_not_already_open) als eigenes natives Fenster (pywebview) statt
REM als Browser-Fenster - das gilt auch, wenn hier nur ein bereits laufender
REM Hub (siehe unten, Administrator-Aufgabe) ein Fenster bekommen soll.
REM Laeuft A.R.I mit Administrator-Rechten (fuer die CPU-Temperatur, in den Einstellungen
REM einmalig einrichtbar), dann zuerst den eigentlichen Hub ueber die geplante Aufgabe
REM starten statt direkt - die fragt nicht jedes Mal per UAC-Fenster nach (im Gegensatz
REM zu "Als Administrator ausfuehren"). Das Fenster oeffnet trotzdem der normale
REM Start unten (erkennt den bereits laufenden Hub von selbst, siehe hub.py).
REM Die Desktop-/Startmenue-Verknuepfungen starten inzwischen direkt das Programm (kein Konsolenfenster);
REM diese Datei bleibt fuer den Start per Hand und beendet sich sofort.
schtasks /query /tn "A.R.I Hub (Admin)" >nul 2>nul
if not errorlevel 1 (
    schtasks /run /tn "A.R.I Hub (Admin)" >nul 2>nul
    timeout /t 2 >nul
)
set "PYHOME="
for /f "delims=" %%i in ('py -c "import sys;print(sys.base_prefix)" 2^>nul') do set "PYHOME=%%i"
if not defined PYHOME for /f "delims=" %%i in ('python -c "import sys;print(sys.base_prefix)" 2^>nul') do set "PYHOME=%%i"
if defined PYHOME (
    python hub.py --prepare-exe >nul 2>nul || py hub.py --prepare-exe >nul 2>nul
    if exist "%PYHOME%\Ari Assistent.exe" (
        start "" "%PYHOME%\Ari Assistent.exe" hub.py
        goto :started
    )
)
where pyw >nul 2>nul && (start "" pyw hub.py & goto :started)
where pythonw >nul 2>nul && (start "" pythonw hub.py & goto :started)
echo Python wurde nicht gefunden - bitte zuerst ARI-Setup.exe starten.
pause
exit /b 1
:started
exit /b 0
