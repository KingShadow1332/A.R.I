"""Browser-gesteuerte Einrichtung: A.R.I oeffnet einen eigenen Browser (Edge/Chrome, eigenes Profil), der Nutzer meldet sich dort
EINMAL an (und stimmt am Ende zu) - alles andere (Developer-App anlegen, Felder ausfuellen, Schluessel auslesen und in A.R.I
eintragen) macht A.R.I selbst.

Aufbau:
  * Der Browser wird ganz normal gestartet (mit Debug-Port), NICHT von der Automatisierung - so akzeptieren Google & Co. die
    Anmeldung ("Dieser Browser ist nicht sicher" erscheint bei automatisiert gestarteten Browsern). Danach haengt sich Playwright
    ueber den Debug-Port daran (connect_over_cdp).
  * Jeder Ablauf ("Flow") besteht aus Schritten. Klappt ein Schritt automatisch nicht (Seite hat sich geaendert, anderes
    Konto-Layout ...), faellt er auf "bitte selbst machen" zurueck: das HUD zeigt die Anweisung, A.R.I wartet, bis es
    erledigt ist (oder der Nutzer auf "Weiter" klickt) und macht dann automatisch weiter.
  * Zustand wird per status() vom HUD abgefragt; Ergebnisse (z.B. Schluessel) gibt der Flow im "result" zurueck.
"""
import os
import re
import socket
import subprocess
import threading
import time
import urllib.request

_lock = threading.Lock()
_state = {"flow": "", "state": "idle", "step": 0, "total": 0, "title": "", "message": "", "note": "", "needs_user": False,
          "hint": "", "result": None, "error": "", "updated": 0.0, "say": "", "say_id": 0}
_cancel = threading.Event()
_cont = threading.Event()
_thread = None
_proc = None


class Cancelled(Exception):
    pass


def status():
    with _lock:
        return dict(_state)


def _set(**kw):
    with _lock:
        _state.update(kw)
        _state["updated"] = time.time()


def _say(text):
    """Kurze Ansage, die das HUD zusaetzlich vorliest (A.R.I sagt, was es gleich tut oder was der Nutzer tun muss)."""
    with _lock:
        _state["say"] = str(text)
        _state["say_id"] = int(_state.get("say_id", 0)) + 1


def _check():
    if _cancel.is_set():
        raise Cancelled()


def cancel():
    _cancel.set()
    _cont.set()


def user_continue():
    _cont.set()


def running():
    return _thread is not None and _thread.is_alive()


# ----------------------------------------------------------------------------------------- Browser
def _find_browser():
    pf, pf86, local = os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("LOCALAPPDATA", "")
    for p in (os.path.join(pf86, "Microsoft", "Edge", "Application", "msedge.exe"),
              os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
              os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
              os.path.join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
              os.path.join(local, "Google", "Chrome", "Application", "chrome.exe")):
        if os.path.exists(p):
            return p
    return None


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _launch_browser(profile_dir, url="about:blank"):
    global _proc, _profile
    _profile = profile_dir
    exe = _find_browser()
    if not exe:
        raise RuntimeError("Weder Microsoft Edge noch Google Chrome gefunden.")
    port = _free_port()
    os.makedirs(profile_dir, exist_ok=True)
    args = [exe, f"--remote-debugging-port={port}", f"--user-data-dir={profile_dir}", "--no-first-run", "--no-default-browser-check",
            "--lang=en-US", "--accept-lang=en-US", "--window-size=1240,900", url]
    _proc = subprocess.Popen(args)
    for _ in range(80):
        _check()
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1).read()
            return port
        except Exception:
            time.sleep(0.25)
    raise RuntimeError("Der Browser hat sich nicht gemeldet.")


_profile = None


def _close_browser():
    """Beendet den Einrichtungs-Browser samt aller Hilfsprozesse (alles, was das eigene Profil-Verzeichnis benutzt)."""
    global _proc
    p, _proc = _proc, None
    if p is not None and p.poll() is None:
        try:
            p.terminate()
        except Exception:
            pass
    if _profile:
        try:
            import psutil
            needle = os.path.normcase(os.path.abspath(_profile))
            victims = []
            for pr in psutil.process_iter(["cmdline"]):
                try:
                    if any(needle in os.path.normcase(part) for part in (pr.info["cmdline"] or [])):
                        victims.append(pr)
                except Exception:
                    pass
            for pr in victims:
                try:
                    pr.kill()
                except Exception:
                    pass
        except Exception:
            pass


# ------------------------------------------------------------------------------------------ Helfer
def _debug_dump(page, tag):
    """Bei einem fehlgeschlagenen Schritt Bild + Seitentext + Elementliste ablegen (data/setup-debug), damit der Fehler spaeter genau
    nachvollziehbar ist. Enthaelt nur den sichtbaren Seiteninhalt, keine Passwoerter (die tippt A.R.I nie)."""
    try:
        base = os.path.join(os.path.dirname(os.path.abspath(_profile)) if _profile else ".", "setup-debug")
        os.makedirs(base, exist_ok=True)
        name = time.strftime("%H%M%S") + "-" + re.sub(r"[^A-Za-z0-9]+", "_", str(tag))[:30]
        try:
            page.screenshot(path=os.path.join(base, name + ".png"))
        except Exception:
            pass
        nl = chr(10)
        try:
            snap = page.evaluate(_SNAP_JS)
            els = nl.join('[%s] %s "%s"' % (e["i"], e["role"], e["name"]) for e in snap["els"])
            txt = nl.join(["URL: " + snap["url"], "Title: " + snap["title"], "", "Text:", snap["text"], "", "Elements:", els])
        except Exception as e:
            txt = "URL: " + str(page.url) + nl + "(Snapshot fehlgeschlagen: " + str(e) + ")"
        open(os.path.join(base, name + ".txt"), "w", encoding="utf-8").write(txt)
        for old in sorted(os.listdir(base), key=lambda n: os.path.getmtime(os.path.join(base, n)))[:-40]:
            try:
                os.remove(os.path.join(base, old))
            except Exception:
                pass
    except Exception:
        pass


class Ctx:
    """Handwerkszeug fuer die Flows (Seite + Warten/Nachfragen)."""

    def __init__(self, page, hub):
        self.page = page
        self.hub = hub or {}
        # Der Nutzer hat VORAB im HUD erlaubt, dass A.R.I Zustimmungen/Bedingungen fuer ihn anklickt (Anmelden, Bezahlen,
        # Loeschen und Passwoerter bleiben immer ausgenommen).
        self.consent = bool(self.hub.get("consent"))

    def step(self, n, total, title, message=""):
        """Neuer Schritt: erst ansagen (Text im HUD + gesprochen), dann ausfuehren."""
        _check()
        _set(step=n, total=total, title=title, message=message or title, note="", needs_user=False, hint="")
        _say(title)   # gesprochen nur der kurze Titel, Details stehen nur in der Karte

    def wait_for(self, pred, timeout=900, poll=0.5):
        """Wartet, bis pred() wahr wird (Fehler in pred zaehlen als 'noch nicht')."""
        end = time.time() + timeout
        while time.time() < end:
            _check()
            try:
                if pred():
                    return True
            except Exception:
                pass
            self.page.wait_for_timeout(int(poll * 1000))
        return False

    def visible(self, locator, timeout=0):
        try:
            if timeout:
                locator.first.wait_for(state="visible", timeout=int(timeout * 1000))
                return True
            return locator.first.is_visible()
        except Exception:
            return False

    def ask_user(self, hint, done_pred=None, timeout=1200):
        """Nutzer muss etwas selbst tun (Anmelden, Zustimmen, ...). Wartet auf done_pred oder 'Weiter' im HUD."""
        _cont.clear()
        _set(needs_user=True, hint=hint)
        low = hint.lower()
        _say("Bitte melde dich an." if re.search(r"melde dich|anmeld|log in|einloggen", low) else
             "Bitte bestätige das selbst." if re.search(r"häkchen|zustimm|agree|bedingung|bestätig", low) else
             "Bitte hilf mir kurz im Browserfenster.")
        end = time.time() + timeout
        ok = False
        while time.time() < end:
            _check()
            if _cont.is_set():
                ok = True
                break
            try:
                if done_pred and done_pred():
                    ok = True
                    break
            except Exception:
                pass
            self.page.wait_for_timeout(500)
        _cont.clear()
        _set(needs_user=False, hint="")
        if not ok:
            raise RuntimeError("Zeitueberschreitung beim Warten auf den Nutzer.")

    def auto(self, fn, manual_hint, done_pred=None, goal=None):
        """Schritt automatisch versuchen; klappt er nicht, hilft die KI des Nutzers (Agent: liest die Seite und entscheidet jeden
        Schritt neu); klappt auch das nicht, wird der Nutzer gebeten - danach geht es automatisch weiter."""
        try:
            return fn()
        except Cancelled:
            raise
        except Exception as e:
            why = str(e).splitlines()[0][:120] if str(e) else e.__class__.__name__
            print(f"[einrichtung] Schritt fehlgeschlagen ({_state.get('title')}): {e.__class__.__name__}: {why}")
            _debug_dump(self.page, _state.get('title'))
            _set(note="Automatisch ging das nicht (" + why + ").")   # ergaenzt den Schritt, ersetzt ihn nicht
            if self.hub.get("llm"):
                try:
                    if agent_run(self, goal or manual_hint, done_pred):
                        return None
                except Cancelled:
                    raise
                except Exception as e2:
                    why2 = str(e2).splitlines()[0][:160]
                    print(f"[einrichtung] KI-Hilfe fehlgeschlagen ({_state.get('title')}): {why2}")
                    _set(note="Automatisch ging das nicht (" + why + "). Auch die KI-Hilfe kam nicht weiter (" + why2 + ").")
            self.ask_user(manual_hint, done_pred)
            return None

    def click_any(self, *locators, timeout=8):
        """Klickt das erste sichtbare von mehreren moeglichen Elementen."""
        end = time.time() + timeout
        while time.time() < end:
            _check()
            for loc in locators:
                try:
                    if loc.first.is_visible():
                        loc.first.click()
                        return True
                except Exception:
                    pass
            self.page.wait_for_timeout(300)
        raise RuntimeError("Knopf nicht gefunden")

    def text(self):
        try:
            return self.page.inner_text("body", timeout=3000)
        except Exception:
            return ""


def _I(s):
    return re.compile(s, re.I)


# Google verlangt fuer Projekt-/App-/Client-Namen mindestens 4 Buchstaben und keine Sonderzeichen ("ARI" ist zu kurz)
G_NAME = "ARIAssistant"
ANDROID_PACKAGE = "com.ari.assistant"
ANDROID_SHA1 = "B6:AF:C9:89:4F:7A:A9:4E:0B:8B:E7:A2:A2:A7:72:D9:0E:B8:2E:48"   # Signatur der A.R.I-App (gleicher Wert wie in der Anleitung)

# ------------------------------------------------------------------------------------------ KI-Agent
_SNAP_JS = r"""() => {
  const sel = 'a[href],button,input,select,textarea,summary,[role=button],[role=link],[role=checkbox],[role=radio],[role=option],[role=combobox],[role=tab],[role=menuitem],[role=switch]';
  document.querySelectorAll('[data-ari-i]').forEach(e => e.removeAttribute('data-ari-i'));
  const out = []; let n = 0;
  for (const el of document.querySelectorAll(sel)) {
    const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
    if (r.width < 2 || r.height < 2 || cs.visibility === 'hidden' || cs.display === 'none') continue;
    const tag = el.tagName.toLowerCase(), type = (el.getAttribute('type') || '').toLowerCase();
    let name = el.getAttribute('aria-label') || '';
    if (!name && el.labels && el.labels.length) name = el.labels[0].innerText;
    if (!name) name = el.innerText || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('alt') || el.getAttribute('name') || el.getAttribute('value') || '';
    name = name.replace(/\s+/g, ' ').trim().slice(0, 90);
    if (!name && tag === 'a') name = (el.getAttribute('href') || '').slice(0, 60);
    const role = el.getAttribute('role') || (tag === 'a' ? 'link' : tag === 'button' ? 'button' : tag === 'select' ? 'select' : tag === 'textarea' ? 'textbox' : tag === 'input' ? (type === 'checkbox' ? 'checkbox' : type === 'radio' ? 'radio' : type === 'submit' || type === 'button' ? 'button' : 'textbox') : tag);
    const e = { i: ++n, role, name, type, disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true' };
    if (role === 'checkbox' || role === 'radio' || role === 'switch') e.checked = !!el.checked || el.getAttribute('aria-checked') === 'true';
    if (role === 'textbox' && type !== 'password') e.value = String(el.value || '').slice(0, 60);
    el.setAttribute('data-ari-i', String(n)); out.push(e);
    if (n >= 110) break;
  }
  return { url: location.href, title: document.title, text: (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 1500), els: out };
}"""

def _agent_system(consent):
    if consent:   # Zustimmung vorab gegeben: ueberschreibt die Regel "Zustimmung = ask_user"
        return _AGENT_SYSTEM + (" OVERRIDE: The user GAVE CONSENT IN ADVANCE. You MAY tick terms/consent checkboxes and click Agree/Accept/Allow/Authorize/Confirm/Publish "
                                "buttons that belong to the requested setup WITHOUT asking (do not use ask_user for them). Use ask_user only for login, 2-factor codes, "
                                "captcha and passwords. Still never pay, subscribe or delete anything.")
    return _AGENT_SYSTEM


_AGENT_SYSTEM = (
    "You operate a web browser step by step to reach a GOAL for the user. Each turn you get the current page: URL, title, visible text and a numbered list "
    "of the interactive elements. Reply with exactly ONE JSON object and nothing else, one of:\n"
    '{"action":"click","id":N} | {"action":"fill","id":N,"text":"..."} | {"action":"check","id":N} | {"action":"select","id":N,"text":"option text"} | '
    '{"action":"press","text":"Enter"} | {"action":"goto","url":"https://..."} | {"action":"scroll"} | {"action":"wait"} | '
    '{"action":"ask_user","message":"what the user must do themselves"} | {"action":"done"} | {"action":"fail","message":"why"}\n'
    "Rules: One action per turn. Never click help/learn-more/documentation/privacy links (they only open new tabs). Pages may be in English or German (Google follows the account language) - read both. OAuth scopes must always be FULL URLs starting with https://. ALWAYS write the message text of ask_user and fail in GERMAN (the user speaks German), short and friendly, addressed to the user (starting with Bitte). Never write English there. NEVER type passwords, codes or secrets. If a login, 2-factor code, captcha, terms/consent checkbox, "
    '"Agree/Accept/Allow/Authorize" button, payment or anything legally binding is needed, use ask_user and describe it for the user. Do not leave the '
    "allowed websites. When the goal is reached (or the requested secret/key is visible on screen), answer done. Think briefly; keep the JSON short."
)
_CONSENT_WORDS = re.compile(r"\b(agree|accept|allow|authori[sz]e|i understand|consent|confirm|zustimm|erlaub|akzeptier|bestätig|publish|veröffentlich)", re.I)
_NEVER_WORDS = re.compile(r"\b(pay|buy|purchase|subscribe|upgrade|delete|remove|deactivate|bezahl|kaufen|abonnier|lösch|entfern|deaktivier)", re.I)


_HELP_LINK = re.compile(r"learn more|weitere informationen|mehr erfahren|hilfe|help|docs|documentation|dokumentation|support center|feedback|datenschutz|privacy|nutzungsbedingungen|terms of service", re.I)


def _is_never(name):
    """Knopf, den A.R.I nie allein anklickt (Bezahlen/Loeschen). 'Bereiche hinzufuegen oder entfernen' (Add or remove scopes) ist
    dagegen harmlos - das Wort 'entfernen' steht dort nur in der Beschriftung einer Auswahl, geloescht wird nichts."""
    if re.search(r"hinzufüg|add|scope|range|bereich|zugriff|berechtigung|filter|auswahl", name or "", re.I):
        return False
    return bool(_NEVER_WORDS.search(name or ""))

_SECRETISH = re.compile(r"pass(word|wort)|secret|token|otp|verification|2fa|code", re.I)
_LIMIT = re.compile(r"429|rate.?limit|quota|too many requests|resource.?exhausted|overloaded|\b529\b|\b503\b|tokens? per (minute|day)|limit (reached|exceeded)|usage limit", re.I)


def _wait_retry(c, err, attempt):
    """Limit (Rate-Limit/Kontingent/Ueberlastung) erreicht: warten und danach GENAU an dieser Stelle weitermachen."""
    msg = str(err)
    secs = 20.0 * min(attempt, 6)
    m = re.search(r"(?:try again|retry)[^0-9]{0,20}(\d+(?:\.\d+)?)\s*(ms|s|sec|m|min)?", msg, re.I) or re.search(r"(\d+(?:\.\d+)?)\s*(ms|s|sec|m|min)\b", msg, re.I)
    if m:
        v, unit = float(m.group(1)), (m.group(2) or "s").lower()
        secs = v / 1000.0 if unit == "ms" else v * 60 if unit in ("m", "min") else v
        secs += 1.5
    secs = max(5.0, min(secs, 180.0))
    end = time.time() + secs
    while time.time() < end:
        _check()
        _set(note=f"KI-Limit erreicht - A.R.I wartet {int(end - time.time()) + 1} s und macht dann automatisch an derselben Stelle weiter.")
        c.page.wait_for_timeout(1000)
    _set(note="")


def _ask_llm(c, system, user, image):
    """KI-Anfrage mit automatischem Warten bei Limit/Ueberlastung (hoechstens ca. 90 Sekunden insgesamt), danach bekommt der Nutzer die Anleitung zum Selbermachen."""
    llm = c.hub["llm"]
    started = time.time()
    attempt = 0
    while True:
        _check()
        try:
            return llm(system, user, image)
        except Cancelled:
            raise
        except Exception as e:
            attempt += 1
            if not _LIMIT.search(str(e)) or time.time() - started > 90:   # laenger nicht abwarten: dann bittet A.R.I dich, den Schritt kurz selbst zu machen
                raise
            _wait_retry(c, e, attempt)


def _parse_action(text):
    import json
    t = (text or "").strip()
    m = re.search(r"\{.*\}", t, re.S)
    if not m:
        raise ValueError("keine Aktion in der Antwort")
    return json.loads(m.group(0))


def agent_run(c, goal, until=None, max_steps=30):
    """KI-Agent: liest die Seite (Elementliste + Text + Screenshot), laesst die KI des Nutzers den naechsten Schritt waehlen, fuehrt ihn
    aus und schaut danach wieder hin - wie ein Mensch. Anmeldung, Zustimmung, Bezahlen und Passwoerter bleiben beim Nutzer."""
    page = c.page
    hosts = c.hub.get("hosts") or []
    history = []
    _set(note="Die KI schaut sich die Seite an ...")
    _say("Die KI übernimmt kurz.")
    for step in range(max_steps):
        _check()
        if until:
            try:
                if until():
                    return True
            except Exception:
                pass
        try:
            snap = page.evaluate(_SNAP_JS)
        except Exception:
            page.wait_for_timeout(800)
            continue
        host = re.sub(r"^https?://([^/]+).*$", r"\1", snap["url"])
        if hosts and not any(host == h or host.endswith("." + h) for h in hosts) and not snap["url"].startswith(("about:", "data:")):
            try:
                page.go_back()
            except Exception:
                pass
            history.append("left the allowed site -> went back")
            continue
        lines = []
        for e in snap["els"]:
            extra = (" checked" if e.get("checked") else "") + (" DISABLED" if e.get("disabled") else "") + (f' value="{e["value"]}"' if e.get("value") else "")
            lines.append(f'[{e["i"]}] {e["role"]} "{e["name"]}"{extra}')
        user = (f"GOAL: {goal}\nAllowed websites: {', '.join(hosts) or 'any'}\nRecent actions: {' | '.join(history[-6:]) or '-'}\n\n"
                f"URL: {snap['url']}\nTitle: {snap['title']}\nVisible text: {snap['text']}\n\nElements:\n" + "\n".join(lines))
        image = None
        try:
            import base64
            image = base64.b64encode(page.screenshot(type="jpeg", quality=55)).decode()
        except Exception:
            pass
        raw = _ask_llm(c, _agent_system(c.consent), user, image)
        try:
            act = _parse_action(raw)
        except Exception:
            history.append("invalid answer")
            continue
        kind = str(act.get("action") or "").lower()
        el = None
        if "id" in act:
            el = next((e for e in snap["els"] if e["i"] == int(act["id"])), None)
        name = (el or {}).get("name", "")
        history.append(f'{kind} {act.get("id", "")} {name[:40]}'.strip())
        _check()
        if kind == "done":
            if until is None or (until and until()):
                return True
            history.append("done was not confirmed by the page")
            continue
        if kind == "fail":
            raise RuntimeError(str(act.get("message") or "KI sagt: nicht machbar"))
        if kind == "ask_user":
            _set(message="")
            c.ask_user(str(act.get("message") or "Bitte im Browserfenster weitermachen."), lambda: bool(until and until()))
            continue
        if kind in ("click", "check", "fill", "select") and el is None:
            history.append("unknown element")
            continue
        if kind == "click" and el is not None and _HELP_LINK.search(name or "") and not _CONSENT_WORDS.search(name or ""):
            history.append("refused help/info link: " + name[:40])   # Hilfe-/Infolinks oeffnen nur neue Tabs
            continue
        never = _is_never(name)
        if kind in ("click", "check") and (never or (_CONSENT_WORDS.search(name) and not c.consent)):
            why = "Bezahlen/Löschen macht A.R.I nie allein" if never else "du hast die automatische Zustimmung nicht erlaubt"
            c.ask_user(f"Bitte klicke im Browserfenster selbst auf '{name}' ({why}).", lambda: bool(until and until()))
            continue
        if kind in ("fill", "select") and (el.get("type") == "password" or _SECRETISH.search(name)):
            c.ask_user(f"Bitte trage das Feld '{name}' im Browserfenster selbst ein (Passwörter/Codes tippt A.R.I nie).", lambda: bool(until and until()))
            continue
        sel = f'[data-ari-i="{el["i"]}"]' if el else None
        _set(note={"click": f"Klicke: {name}", "check": f"Hake an: {name}", "fill": f"Fülle aus: {name}", "select": f"Wähle: {name}",
                      "goto": "Öffne Seite ...", "press": "Drücke Taste ...", "scroll": "Scrolle ...", "wait": "Warte ..."}.get(kind, "Arbeite ..."))
        try:
            if kind == "click":
                page.locator(sel).first.click(timeout=6000)
            elif kind == "check":
                page.locator(sel).first.check(timeout=6000)
            elif kind == "fill":
                page.locator(sel).first.fill(str(act.get("text") or "")[:200], timeout=6000)
            elif kind == "select":
                page.locator(sel).first.select_option(label=str(act.get("text") or ""), timeout=6000)
            elif kind == "press":
                page.keyboard.press(str(act.get("text") or "Enter")[:20])
            elif kind == "goto":
                url = str(act.get("url") or "")
                h2 = re.sub(r"^https?://([^/]+).*$", r"\1", url)
                if url.startswith("https://") and (not hosts or any(h2 == h or h2.endswith("." + h) for h in hosts)):
                    page.goto(url, wait_until="domcontentloaded")
                else:
                    history.append("goto refused")
            elif kind == "scroll":
                page.mouse.wheel(0, 600)
            else:
                page.wait_for_timeout(1500)
        except Cancelled:
            raise
        except Exception as e:
            history.append("failed: " + str(e).splitlines()[0][:50])
        page.wait_for_timeout(900)
    return bool(until and until())



# ------------------------------------------------------------------------------------------- Flows
def flow_mock(c):
    """Testablauf gegen eine eingebaute Beispielseite (DEV-Knopf): Anmeldung abwarten, Formular, Schluessel auslesen."""
    page = c.page
    c.step(1, 3, "Beispielseite", "Test mit eingebauter Seite.")
    page.set_content("""<html><body style="font:16px sans-serif;padding:30px"><h2 id=t>Mock-Dienst</h2>
      <button id=login onclick="document.getElementById('app').style.display='block';this.style.display='none';document.getElementById('t').textContent='Dashboard'">Log in</button>
      <div id=app style="display:none"><button id=create onclick="document.getElementById('form').style.display='block'">Create app</button>
      <div id=form style="display:none"><label>App name <input id=name></label><br><label>Redirect URI <input id=ru></label><br>
      <label><input type=checkbox id=web> Web API</label><br><button id=save onclick="document.getElementById('out').textContent='Client ID: '+'a'.repeat(32)+' Secret: '+'b'.repeat(32)">Save</button><p id=out></p></div></div></body></html>""")
    c.step(2, 3, "Anmelden", "Bitte im Browserfenster auf 'Log in' klicken (Test).")
    c.ask_user("Klicke im geöffneten Fenster auf 'Log in'.", lambda: c.visible(page.get_by_role("button", name="Create app")))
    c.step(3, 3, "Formular ausfüllen", "A.R.I füllt das Formular aus ...")
    page.get_by_role("button", name="Create app").click()
    page.get_by_label("App name").fill("ARI")
    page.get_by_label("Redirect URI").fill("http://127.0.0.1:5000/spotify/callback")
    page.get_by_label(_I("Web API")).check()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector("#out:has-text('Client ID')", timeout=5000)
    ids = re.findall(r"\b[0-9a-f]{32}\b", c.text())
    return {"mock": {"clientId": ids[0], "clientSecret": ids[1]}}


def flow_spotify(c):
    page = c.page
    redirect = "http://127.0.0.1:5000/spotify/callback"
    total = 5
    c.step(1, total, "Spotify-Dashboard öffnen", "A.R.I öffnet die Spotify-Entwicklerseite.")
    page.goto("https://developer.spotify.com/dashboard", wait_until="domcontentloaded")
    create_btn = page.get_by_role("button", name=_I(r"create app"))
    create_link = page.get_by_role("link", name=_I(r"create app"))
    on_dashboard = lambda: c.visible(create_btn) or c.visible(create_link)
    if not c.visible(create_btn, 5) and not c.visible(create_link, 1):
        c.step(2, total, "Anmelden", "Bitte melde dich im geöffneten Browserfenster bei Spotify an.")
        c.auto(lambda: c.click_any(page.get_by_role("button", name=_I(r"^log ?in")), page.get_by_role("link", name=_I(r"^log ?in")), timeout=4),
               "Klicke im Browserfenster auf 'Log in' und melde dich bei Spotify an.", on_dashboard)
        c.ask_user("Melde dich im Browserfenster bei Spotify an (und stimme den Entwickler-Bedingungen zu, falls Spotify danach fragt). "
                   "Danach macht A.R.I automatisch weiter.", on_dashboard)
    c.step(3, total, "App anlegen", "A.R.I legt die Spotify-App 'ARI' an ...")

    def create():
        existing = page.get_by_role("link", name=re.compile(r"^ARI$"))
        if c.visible(existing, 1):
            existing.first.click()
            return
        c.click_any(create_btn, create_link)
        page.get_by_label(_I(r"app name")).first.fill("ARI")
        page.get_by_label(_I(r"app description")).first.fill("Persoenlicher Assistent ARI")
        ru = page.get_by_label(_I(r"redirect uri")).first
        ru.fill(redirect)
        try:
            page.get_by_role("button", name=_I(r"^add$")).first.click()
        except Exception:
            ru.press("Enter")
        try:
            page.get_by_label(_I(r"web api")).first.check()
        except Exception:
            pass
        _set(note="Alles ausgefüllt.")
        if c.consent:   # Nutzer hat vorab erlaubt, die Entwickler-Bedingungen fuer ihn zu bestaetigen
            page.get_by_label(_I(r"developer terms|terms of service")).first.check()
        else:
            c.ask_user("Setze im Browserfenster das Häkchen bei den Entwickler-Bedingungen (Developer Terms) und klicke auf 'Save'.",
                       lambda: bool(re.search(r"/dashboard/[0-9a-f]{32}", page.url)))
        if not re.search(r"/dashboard/[0-9a-f]{32}", page.url):
            page.get_by_role("button", name=_I(r"^save$")).click()
        page.wait_for_url(re.compile(r"/dashboard/[0-9a-f]{32}"), timeout=15000)

    c.auto(create, "Lege die App selbst an: 'Create app', Name 'ARI', Redirect URI " + redirect + " (mit 'Add'), 'Web API' ankreuzen, Bedingungen "
           "bestätigen, 'Save'. Klicke danach auf 'Weiter'.", lambda: bool(re.search(r"/dashboard/[0-9a-f]{32}", page.url)))
    c.step(4, total, "Schlüssel auslesen", "A.R.I liest Client-ID und Secret aus ...")
    holder = {}

    def read():
        try:
            c.click_any(page.get_by_role("link", name=_I(r"^settings$")), page.get_by_role("button", name=_I(r"^settings$")), timeout=4)
        except Exception:
            pass
        page.wait_for_timeout(800)
        try:
            c.click_any(page.get_by_text(_I(r"view client secret")), timeout=4)
        except Exception:
            pass
        page.wait_for_timeout(800)
        ids = []
        _debug_dump(page, 'spotify-settings')
        for x in re.findall(r"\b[0-9a-f]{32}\b", c.text()):
            if x not in ids:
                ids.append(x)
        if len(ids) < 2:
            raise RuntimeError("Client-ID/Secret nicht gefunden")
        holder["id"], holder["secret"] = ids[0], ids[1]

    c.auto(read, "Öffne in der App die 'Settings', klicke 'View client secret' und lass beides sichtbar. Klicke dann 'Weiter'.")
    if "id" not in holder:
        read()
    c.step(5, total, "Mit Spotify verbinden", "A.R.I trägt die Daten ein und öffnet den Zustimmungs-Dialog.")
    auth_url = c.hub["save_spotify"](holder["id"], holder["secret"])
    page.goto(auth_url, wait_until="domcontentloaded")
    if c.consent:   # Zugriff fuer A.R.I erlauben (Zustimmung wurde vorab gegeben)
        try:
            c.click_any(page.get_by_role("button", name=_I(r"agree|zustimmen|accept|allow|erlauben")), timeout=15)
        except Exception:
            pass
    c.ask_user("Klicke im Browserfenster auf 'Agree' / 'Zustimmen', um A.R.I den Zugriff zu erlauben.",
               lambda: "127.0.0.1:5000/spotify/callback" in page.url)
    return {"spotify": {"clientId": holder["id"], "clientSecret": holder["secret"]}}


def flow_groq(c):
    page = c.page
    c.step(1, 3, "Groq öffnen", "A.R.I öffnet die Groq-Konsole.")
    page.goto("https://console.groq.com/keys", wait_until="domcontentloaded")
    create = page.get_by_role("button", name=_I(r"create api key|api-schlüssel erstellen"))
    if not c.visible(create, 6):
        c.step(2, 3, "Anmelden", "Bitte melde dich im Browserfenster bei Groq an (Google, GitHub oder E-Mail).")
        c.ask_user("Melde dich im Browserfenster bei Groq an oder erstelle ein kostenloses Konto (am schnellsten mit Google). Ein „Ich bin kein Roboter“ klickst du selbst. Danach macht A.R.I automatisch weiter.",
                   lambda: c.visible(create))
    c.step(3, 3, "Schlüssel erstellen", "A.R.I erstellt den Schlüssel ...")
    holder = {}

    def make():
        create.first.click()
        page.get_by_placeholder(_I(r"name")).first.fill("ARI")
        c.click_any(page.get_by_role("button", name=_I(r"^submit$")), page.get_by_role("button", name=_I(r"create")))
        end = time.time() + 12
        while time.time() < end:
            m = re.search(r"gsk_[A-Za-z0-9]{20,}", c.text())
            if m:
                holder["key"] = m.group(0)
                return
            page.wait_for_timeout(400)
        raise RuntimeError("Schlüssel nicht gefunden")

    c.auto(make, "Klicke 'Create API Key', gib den Namen 'ARI' ein und bestätige. Lass den angezeigten Schlüssel (beginnt mit gsk_) sichtbar.",
           lambda: bool(re.search(r"gsk_[A-Za-z0-9]{20,}", c.text())))
    if "key" not in holder:
        m = re.search(r"gsk_[A-Za-z0-9]{20,}", c.text())
        if not m:
            raise RuntimeError("Kein Schlüssel gefunden")
        holder["key"] = m.group(0)
    return {"apikey": {"provider": "groq", "key": holder["key"]}}


def flow_groq_all(c):
    """Alle freien Groq-Plaetze auf einmal fuellen: einmal anmelden, dann erstellt A.R.I nacheinander bis zu 5 Schluessel."""
    page = c.page
    want = max(1, min(5, int(c.hub.get("count") or 5)))
    total = 2 + want
    c.step(1, total, "Groq öffnen", "A.R.I öffnet die Groq-Konsole.")
    page.goto("https://console.groq.com/keys", wait_until="domcontentloaded")
    create = page.get_by_role("button", name=_I(r"create api key|api-schlüssel erstellen"))
    if not c.visible(create, 6):
        c.step(2, total, "Anmelden", "Bitte melde dich im Browserfenster bei Groq an (Google, GitHub oder E-Mail).")
        c.ask_user("Melde dich im Browserfenster bei Groq an oder erstelle ein kostenloses Konto (am schnellsten mit Google). Ein „Ich bin kein Roboter“ klickst du selbst. Danach erstellt A.R.I alle Schlüssel automatisch.",
                   lambda: c.visible(create))
    pat = r"gsk_[A-Za-z0-9]{20,}"
    seen = set(re.findall(pat, c.text()))
    keys = []

    def new_key_on_page():
        for k in re.findall(pat, c.text()):
            if k not in seen:
                return k
        return None

    def close_dialog():
        for nm in (r"^(done|fertig|close|schließen|ok)$",):
            try:
                b = page.get_by_role("button", name=_I(nm))
                if c.visible(b):
                    b.first.click()
                    break
            except Exception:
                pass
        try:
            page.keyboard.press("Escape")
        except Exception:
            pass
        page.wait_for_timeout(700)

    for n in range(1, want + 1):
        c.step(2 + n, total, f"Schlüssel {n} von {want}", f"A.R.I erstellt Schlüssel {n} von {want} ...")

        def make(n=n):
            create.first.click()
            page.get_by_placeholder(_I(r"name")).first.fill(f"ARI {n}")
            c.click_any(page.get_by_role("button", name=_I(r"^(submit|absenden)$")), page.get_by_role("button", name=_I(r"create|erstellen")))
            end = time.time() + 12
            while time.time() < end:
                k = new_key_on_page()
                if k:
                    keys.append(k)
                    seen.add(k)
                    return
                page.wait_for_timeout(400)
            raise RuntimeError("Schlüssel nicht gefunden")

        c.auto(make, f"Klicke 'Create API Key', gib den Namen 'ARI {n}' ein und bestätige. Lass den angezeigten neuen Schlüssel (gsk_) sichtbar.",
               lambda: new_key_on_page() is not None,
               goal=f"On the Groq keys page create ONE new API key named 'ARI {n}' (button 'Create API Key', enter the name, submit). Stop when the new key (starting with gsk_) is visible.")
        if len(keys) < n:
            k = new_key_on_page()
            if k:
                keys.append(k)
                seen.add(k)
        close_dialog()
    if not keys:
        raise RuntimeError("Kein Schlüssel erstellt")
    return {"apikeys": [{"provider": "groq", "key": k} for k in keys]}


def flow_gemini(c):
    page = c.page
    c.step(1, 3, "Google AI Studio öffnen", "A.R.I öffnet die Seite für Gemini-Schlüssel.")
    page.goto("https://aistudio.google.com/apikey", wait_until="domcontentloaded")
    create = page.get_by_role("button", name=_I(r"create api key|api-schlüssel erstellen"))
    if not c.visible(create, 8):
        c.step(2, 3, "Anmelden", "Bitte melde dich im Browserfenster mit deinem Google-Konto an.")
        c.ask_user("Melde dich im Browserfenster mit deinem Google-Konto an und stimme den Bedingungen zu, falls gefragt. "
                   "Danach macht A.R.I automatisch weiter.", lambda: c.visible(create))
    c.step(3, 3, "Schlüssel erstellen", "A.R.I erstellt den Schlüssel ...")
    holder = {}
    pat = r"AIza[0-9A-Za-z_\-]{35}"

    def make():
        create.first.click()
        page.wait_for_timeout(1000)
        try:
            c.click_any(page.get_by_text(_I(r"create api key in new project|api-schlüssel in neuem projekt erstellen")), page.get_by_role("option").first, timeout=4)
        except Exception:
            pass
        try:
            c.click_any(page.get_by_role("button", name=_I(r"^(create key|schlüssel erstellen)$")), page.get_by_role("button", name=_I(r"create api key|api-schlüssel erstellen")), timeout=4)
        except Exception:
            pass
        end = time.time() + 15
        while time.time() < end:
            m = re.search(pat, c.text())
            if m:
                holder["key"] = m.group(0)
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Schlüssel nicht gefunden")

    c.auto(make, "Klicke 'Create API key' und bestätige. Lass den angezeigten Schlüssel (beginnt mit AIza) sichtbar.",
           lambda: bool(re.search(pat, c.text())))
    if "key" not in holder:
        m = re.search(pat, c.text())
        if not m:
            raise RuntimeError("Kein Schlüssel gefunden")
        holder["key"] = m.group(0)
    return {"apikey": {"provider": "gemini", "key": holder["key"]}}


def flow_yahoo(c):
    page = c.page
    c.step(1, 3, "Yahoo öffnen", "A.R.I öffnet die Yahoo-Sicherheitsseite.")
    page.goto("https://login.yahoo.com/account/security/app-passwords", wait_until="domcontentloaded")
    gen_btn = page.get_by_role("button", name=_I(r"generate|create|generieren|erstellen"))
    if not c.visible(gen_btn, 6):
        c.step(2, 3, "Anmelden", "Bitte melde dich im Browserfenster bei Yahoo an.")
        c.ask_user("Melde dich im Browserfenster bei Yahoo an (inkl. Bestätigungscode). Danach macht A.R.I automatisch weiter.",
                   lambda: c.visible(gen_btn) or "app-passwords" in page.url and "login" not in page.url.split("?")[0].split("/")[-1])
    c.step(3, 3, "App-Passwort erzeugen", "A.R.I erzeugt das App-Passwort ...")
    holder = {}
    pat = r"\b([a-z]{4}) ?([a-z]{4}) ?([a-z]{4}) ?([a-z]{4})\b"

    def make():
        try:
            page.get_by_text(_I(r"other app|andere app")).first.click()
        except Exception:
            pass
        try:
            page.get_by_role("textbox").first.fill("ARI")
        except Exception:
            pass
        c.click_any(page.get_by_role("button", name=_I(r"generate|generieren")), page.get_by_role("button", name=_I(r"create")))
        end = time.time() + 12
        while time.time() < end:
            m = re.search(pat, c.text())
            if m:
                holder["pw"] = "".join(m.groups())
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Passwort nicht gefunden")

    c.auto(make, "Wähle 'Other app', gib 'ARI' ein und klicke 'Generate'. Lass das angezeigte Passwort sichtbar.",
           lambda: bool(re.search(pat, c.text())))
    if "pw" not in holder:
        m = re.search(pat, c.text())
        if not m:
            raise RuntimeError("Kein Passwort gefunden")
        holder["pw"] = "".join(m.groups())
    mail = re.search(r"[\w.\-+]+@(?:yahoo|ymail|rocketmail)\.[a-z.]+", c.text(), re.I)
    return {"yahoo": {"appPassword": holder["pw"], "email": mail.group(0) if mail else ""}}


def _click_save(page, timeout=6):
    """Das sichtbare, aktive 'Save'/'Speichern' anklicken (es gibt oft mehrere gleichnamige Knoepfe, auch verdeckte)."""
    end = time.time() + timeout
    while time.time() < end:
        _check()
        for b in (page.get_by_text(re.compile(r"^(save|speichern)$", re.I)).all()[::-1]
                  + page.get_by_role("button", name=re.compile(r"^(save|speichern)$", re.I)).all()[::-1]):   # zuletzt im Dokument = oberstes Fenster (Seitenleiste)

            try:
                b.scroll_into_view_if_needed(timeout=2000)
                if b.is_visible() and b.is_enabled():
                    b.click(timeout=3000)
                    return True
            except Exception:
                continue
        page.wait_for_timeout(400)
    return False


def flow_google(c):
    """Google-Cloud-Projekt, Kalender-/Gmail-API, Zustimmungsbildschirm und OAuth-Client. Die Konsole ist komplex - jeder Schritt
    hat die Rueckfall-Anweisung 'bitte selbst'."""
    page = c.page
    total = 10
    c.step(1, total, "Google Cloud öffnen", "A.R.I öffnet die Google-Cloud-Konsole.")
    page.goto("https://console.cloud.google.com/projectcreate", wait_until="domcontentloaded")
    name_box = page.get_by_label(_I(r"project name|projektname"))
    if not c.visible(name_box, 8):
        c.step(2, total, "Anmelden", "Bitte melde dich im Browserfenster mit deinem Google-Konto an.")
        c.ask_user("Melde dich im Browserfenster mit deinem Google-Konto an und stimme den Google-Cloud-Bedingungen zu (falls gefragt). "
                   "Danach macht A.R.I automatisch weiter.", lambda: c.visible(name_box) or "console.cloud.google.com" in page.url and "accounts.google" not in page.url)
    c.step(3, total, "Projekt prüfen", "Projekt prüfen ...")
    holder = {}
    saved_file = os.path.join(_profile or ".", "ari_google_project.txt")

    def project_id_from_url():
        m = re.search(r"[?&]project=([a-z0-9\-]+)", page.url)
        return m.group(1) if m else None

    def project_usable(pid_):
        """Gibt es das Projekt noch und gehoert es zu diesem Konto? (Seite der Zielgruppe laedt ohne 'nicht gefunden')"""
        page.goto(f"https://console.cloud.google.com/auth/overview?project={pid_}", wait_until="domcontentloaded")
        page.wait_for_timeout(5000)
        t = c.text().lower()
        if len(t) < 400:   # Seite noch nicht fertig geladen - nicht voreilig 'gibt es nicht' sagen
            page.wait_for_timeout(5000)
            t = c.text().lower()
        return not re.search(r"not found|nicht gefunden|no access|kein zugriff|permission|berechtigung|deleted|gelöscht|doesn.t exist|existiert nicht|"
                             r"zugriff anfordern|request access|zusätzlichen zugriff|additional access|you need access|sie benötigen", t)

    def find_existing():
        # 1) vom letzten Mal gemerkt
        try:
            if os.path.exists(saved_file):
                pid_ = open(saved_file, encoding="utf-8").read().strip()
                if pid_ and project_usable(pid_):
                    return pid_
                if pid_:
                    os.remove(saved_file)   # gemerktes Projekt ist nicht (mehr) nutzbar -> vergessen
        except Exception:
            pass
        # Nie ein fremdes/eigenes aelteres Projekt des Nutzers uebernehmen - nur das, das A.R.I selbst angelegt und gemerkt hat.
        return None

    existing = None
    try:
        existing = find_existing()
    except Cancelled:
        raise
    except Exception:
        existing = None
    if existing:
        holder["pid"] = existing
        _set(note="Das von A.R.I angelegte Projekt gibt es schon (" + existing + ") - A.R.I nutzt es weiter, es wird kein neues angelegt.")
    else:
        c.step(3, total, "Projekt anlegen", "A.R.I legt das Projekt '" + G_NAME + "' an ...")

        def create_project():
            page.goto("https://console.cloud.google.com/projectcreate", wait_until="domcontentloaded")
            name_box.first.wait_for(state="visible", timeout=15000)
            name_box.first.fill(G_NAME)
            page.wait_for_timeout(1500)
            # Die neue Projekt-ID steht schon vor dem Erstellen unter dem Namensfeld ("Projekt-ID: xyz. Sie kann spaeter nicht geaendert werden").
            # Aus der Adresse darf sie NICHT gelesen werden: die Konsole haengt dort immer das zuletzt benutzte (alte) Projekt an.
            m = re.search(r"(?:project id|projekt-?id)\s*:?\s*([a-z][a-z0-9\-]{4,28}[a-z0-9])", c.text(), re.I)
            if not m:
                raise RuntimeError("Projekt-ID nicht gefunden")
            new_id = m.group(1).lower()
            page.get_by_role("button", name=_I(r"^(create|erstellen)$")).first.click()
            page.wait_for_timeout(4000)
            holder["pid"] = new_id

        c.auto(create_project, "Gib den Projektnamen '" + G_NAME + "' ein und klicke 'Create'. Warte, bis das Projekt fertig ist. Klicke dann 'Weiter'.",
               lambda: bool(holder.get("pid")))
    pid = holder.get("pid") or project_id_from_url()
    if pid:
        try:
            os.makedirs(os.path.dirname(saved_file) or ".", exist_ok=True)
            open(saved_file, "w", encoding="utf-8").write(pid)
        except Exception:
            pass
    if not pid:
        c.ask_user("Wähle oben in der Konsole dein Projekt '" + G_NAME + "' aus und klicke dann 'Weiter'.")
        pid = project_id_from_url()
    c.step(4, total, "Kalender- und Gmail-API einschalten", "A.R.I schaltet die beiden Schnittstellen ein ...")
    for api, label in (("calendar-json.googleapis.com", "Google Calendar API"), ("gmail.googleapis.com", "Gmail API")):
        def enable(api=api, label=label):
            page.goto(f"https://console.cloud.google.com/apis/library/{api}?project={pid}", wait_until="domcontentloaded")
            en = page.get_by_role("button", name=_I(r"^(enable|aktivieren)$"))
            on = page.get_by_role("button", name=_I(r"manage|disable|verwalten|deaktivieren"))
            on_link = page.get_by_role("link", name=_I(r"manage|verwalten"))
            end = time.time() + 60
            clicked = False
            while time.time() < end:
                _check()
                page.wait_for_timeout(1200)
                if c.visible(on, 1) or c.visible(on_link, 1) or re.search(r"api (enabled|aktiviert)|api ist aktiviert", c.text(), re.I):
                    return   # wirklich eingeschaltet (nicht nur 'nichts gefunden')
                if not clicked and c.visible(en, 1):
                    en.first.click()
                    clicked = True
                    page.wait_for_timeout(2500)
            raise RuntimeError(f"{label} ließ sich nicht einschalten")
        c.auto(enable, f"Öffne die '{label}' und klicke 'Enable'. Wenn dort 'Manage' steht, ist sie schon an. Klicke dann 'Weiter'.")
    c.step(5, total, "Zustimmungsbildschirm", "A.R.I richtet den Zustimmungsbildschirm ein ...")

    def consent():
        page.goto(f"https://console.cloud.google.com/auth/overview?project={pid}", wait_until="domcontentloaded")
        gs_re = _I(r"get started|erste schritte|jetzt starten|los geht|konfigurieren|configure")
        gs = page.get_by_role("button", name=gs_re)
        gs_link = page.get_by_role("link", name=gs_re)
        page.wait_for_timeout(2500)
        unconfigured = bool(re.search(r"noch nicht konfiguriert|not (yet )?configured", c.text(), re.I)) or c.visible(gs, 6) or c.visible(gs_link, 1)
        if not unconfigured:
            return   # schon eingerichtet
        if "/create" not in page.url:
            c.click_any(gs, gs_link, page.get_by_text(gs_re), timeout=10)
        page.get_by_label(_I(r"app name|app-name|anwendungsname|app-?name")).first.fill(G_NAME)
        try:   # Support-E-Mail: erste Auswahl
            page.get_by_label(_I(r"user support email|nutzersupport|support-e-mail")).first.click()
            page.get_by_role("option").first.click()
        except Exception:
            pass
        c.click_any(page.get_by_role("button", name=_I(r"^(next|weiter)$")))
        c.click_any(page.get_by_label(_I(r"external|extern")), page.get_by_text(_I(r"^(external|extern)$")))
        c.click_any(page.get_by_role("button", name=_I(r"^(next|weiter)$")))
        mail = page.get_by_role("textbox", name=_I(r"email|e-mail"))
        try:   # Konto-Adresse steht im Beschriftungstext des Konto-Knopfes oben rechts
            ok_mail = page.evaluate(r"""() => { for (const e of document.querySelectorAll('[aria-label*="@"], [title*="@"]')) {
                const m = ((e.getAttribute('aria-label') || '') + ' ' + (e.getAttribute('title') || '')).match(/[\w.+-]+@[\w.-]+\.[a-z]+/i);
                if (m) return m[0]; } return ''; }""")
        except Exception:
            ok_mail = ""
        mail.last.fill(ok_mail or "")
        page.keyboard.press("Enter")
        c.click_any(page.get_by_role("button", name=_I(r"^(next|weiter)$")))
        _debug_dump(page, "wizard-vor-zustimmung")
        if c.consent:   # Nutzer hat vorab erlaubt, die Google-Richtlinie fuer ihn zu bestaetigen
            page.get_by_label(_I(r"agree|accept|akzeptier|stimme|zustimm|einverstanden")).first.check()
        else:
            c.ask_user("Setze im Browserfenster das Häkchen bei der Google-API-Nutzerdatenrichtlinie (agree) und klicke 'Continue'.",
                       lambda: any(cb.is_checked() for cb in page.get_by_role("checkbox").all()))
        c.click_any(page.get_by_role("button", name=_I(r"^(continue|fortfahren|weiter)$")), timeout=2) if c.visible(page.get_by_role("button", name=_I(r"^(continue|fortfahren|weiter)$"))) else None
        _debug_dump(page, "wizard-vor-erstellen")
        c.click_any(page.get_by_role("button", name=_I(r"^(create|erstellen)$")))
        page.wait_for_timeout(4000)
        _debug_dump(page, "wizard-nach-erstellen")
        page.goto(f"https://console.cloud.google.com/auth/overview?project={pid}", wait_until="domcontentloaded")
        page.wait_for_timeout(2500)
        if re.search(r"noch nicht konfiguriert|not (yet )?configured", c.text(), re.I):
            raise RuntimeError("Zustimmungsbildschirm ist noch nicht eingerichtet")

    c.auto(consent, "Richte den Zustimmungsbildschirm ein: App-Name '" + G_NAME + "', Zielgruppe 'Extern', deine E-Mail als Kontakt, Bedingungen bestätigen, "
           "'Create'. Danach unter 'Zielgruppe' (Audience) dich selbst als Testnutzer hinzufügen. Klicke dann 'Weiter'.")
    c.step(6, total, "Zugriffsbereiche eintragen", "Kalender- und Gmail-Zugriff eintragen ...")
    scopes = ["https://www.googleapis.com/auth/calendar.events",
              "https://www.googleapis.com/auth/gmail.readonly",
              "https://www.googleapis.com/auth/gmail.send"]

    def add_scopes():
        page.goto(f"https://console.cloud.google.com/auth/scopes?project={pid}", wait_until="domcontentloaded")
        page.wait_for_timeout(3500)
        sc_re = _I(r"add or remove (scopes|ranges)|bereiche hinzufügen|hinzufügen oder entfernen|scopes? (hinzu|add)")
        c.click_any(page.get_by_role("button", name=sc_re), page.get_by_role("link", name=sc_re), page.get_by_text(sc_re))
        page.wait_for_timeout(1800)
        box = page.get_by_label(_I(r"manually (add|paste|enter) scopes|bereiche manuell"))
        if not c.visible(box, 3):
            box = page.locator("textarea").last
        _debug_dump(page, "scopes-sheet")
        box.fill("\n".join(scopes))   # volle Adressen, eine pro Zeile (Kurznamen wie 'gmail.send' lehnt Google als ungueltig ab)
        print("[scopes] eingefuegt")
        c.click_any(page.get_by_role("button", name=_I(r"add to table|zu tabelle hinzufügen|zur tabelle")))
        print("[scopes] zur Tabelle")
        page.wait_for_timeout(1500)
        if re.search(r"ungültig|invalid", c.text(), re.I) and not c.visible(page.get_by_role("button", name=_I(r"update|aktualisieren"))):
            raise RuntimeError("Google hat die Bereiche abgelehnt")
        try:   # 'Aktualisieren' im Seitenfenster - falls es schon zu ist, weiter mit Speichern
            c.click_any(page.get_by_role("button", name=_I(r"^(update|aktualisieren|übernehmen|apply)$")), timeout=5)
        except RuntimeError:
            pass
        page.wait_for_timeout(1500)
        print("[scopes] aktualisiert")
        saved = False
        for b in page.get_by_role("button", name=_I(r"^(save|speichern)$")).all():   # es gibt mehrere 'Save' - das aktive, sichtbare nehmen
            try:
                b.scroll_into_view_if_needed(timeout=3000)
                if b.is_visible() and b.is_enabled():
                    b.click(timeout=4000)
                    saved = True
                    break
            except Exception:
                continue
        if not saved:
            saved = bool(page.evaluate("""() => { for (const b of document.querySelectorAll('button')) { const t = (b.innerText || '').trim();
                if (/^(save|speichern)$/i.test(t) && !b.disabled) { b.scrollIntoView(); b.click(); return true; } } return false; }"""))
        if not saved:
            raise RuntimeError("Speichern-Knopf nicht gefunden")
        print("[scopes] gespeichert")
        page.wait_for_timeout(2000)

    full = "\n".join(scopes)
    c.auto(add_scopes, "Öffne unter 'Datenzugriff' (Data Access) 'Bereiche hinzufügen oder entfernen' (Add or remove scopes). Füge im Feld 'Bereiche manuell hinzufügen' "
           "diese drei VOLLSTÄNDIGEN Adressen ein (je eine pro Zeile, mit https://):\n" + full + "\nKlicke 'Zu Tabelle hinzufügen', dann 'Aktualisieren' und 'Speichern'. Klicke danach 'Weiter'.",
           goal="On the Google Auth Platform 'Data Access' page, click 'Add or remove scopes'. In the box 'Manually add scopes' paste these three FULL scope URLs, one per line "
                "(they must start with https://, short names like gmail.send are rejected):\n" + full + "\nThen click 'Add to table', then 'Update' and finally 'Save'.")
    c.step(7, total, "Dich als Testnutzer eintragen", "Dein Konto als Testnutzer eintragen ...")

    def account_email():
        try:   # Konto-Knopf oben rechts erscheint erst nach dem Laden der Seite
            page.wait_for_selector('[aria-label*="@"], [title*="@"]', timeout=12000, state="attached")
        except Exception:
            pass
        js = r"""() => {
          const els = [...document.querySelectorAll('[aria-label*="@"], [title*="@"], [data-email]')];
          for (const e of els) {
            const t = (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('data-email') || '');
            const m = t.match(/[\w.+-]+@[\w.-]+\.[a-z]+/i);
            if (m) return m[0];
          }
          return '';
        }"""
        try:
            t = page.evaluate(js)
        except Exception:
            t = ""
        if t:
            return t
        m = re.search(r"[\w.+\-]+@(?:gmail|googlemail)\.com", c.text(), re.I)
        return m.group(0) if m else ""

    def add_test_user():
        page.goto(f"https://console.cloud.google.com/auth/audience?project={pid}", wait_until="domcontentloaded")
        mail = account_email()
        if not mail:
            raise RuntimeError("Konto-E-Mail nicht erkannt")
        holder["mail"] = mail
        c.click_any(page.get_by_role("button", name=_I(r"add users|nutzer hinzufügen")), page.get_by_text(_I(r"^(add users|nutzer hinzufügen)$")))
        page.wait_for_timeout(1500)
        box = page.get_by_role("textbox", name=_I(r"e-?mail")).last
        box.click()
        box.fill(mail)
        page.keyboard.press("Enter")
        page.wait_for_timeout(800)
        _debug_dump(page, 'testnutzer-eingegeben')
        if not _click_save(page):
            raise RuntimeError("Speichern-Knopf nicht gefunden")
        page.wait_for_timeout(3500)
        if re.search(r"nutzer hinzufügen\s+im veröffentlichungsstatus", c.text(), re.I):   # Fenster noch offen: Speichern hat nicht gegriffen
            _debug_dump(page, 'testnutzer-noch-offen')
            try:
                sv = page.get_by_role("button", name=_I(r"^(save|speichern)$")).last
                sv.focus()
                page.keyboard.press("Enter")
            except Exception:
                pass
            page.wait_for_timeout(4000)
        _debug_dump(page, 'testnutzer-gespeichert')
        if not re.search(r"[1-9]\d* (testnutzer|test users?)", c.text(), re.I):
            raise RuntimeError("Testnutzer nicht eingetragen")

    c.auto(add_test_user, "Öffne unter 'Zielgruppe' (Audience) den Bereich 'Testnutzer' (Test users), klicke 'Add users' und trage DEINE Google-E-Mail-Adresse ein, "
           "mit der du dich später verbindest. Klicke 'Save'. Sonst blockiert Google den Zugriff (Fehler 403: access_denied).",
           lambda: holder.get("mail") is not None and holder["mail"].lower() in c.text().lower())
    c.step(8, total, "Branding abschließen", "Branding ausfüllen ...")

    def branding():
        page.goto(f"https://console.cloud.google.com/auth/branding?project={pid}", wait_until="domcontentloaded")
        page.wait_for_timeout(2500)
        mail = holder.get("mail") or account_email()
        an = page.get_by_role("textbox", name=_I(r"app name|app-name|anwendungsname")).first
        if c.visible(an, 6) and not (an.input_value() or "").strip():
            an.fill(G_NAME)
        try:   # Support-E-Mail: erste Auswahl
            sup = page.get_by_label(_I(r"user support email|nutzersupport|support-e-mail")).first
            if c.visible(sup, 3):
                sup.click()
                page.get_by_role("option").first.click()
        except Exception:
            pass
        try:   # Kontakt-E-Mail des Entwicklers
            dev = page.get_by_label(_I(r"email addresses|e-mail-adressen")).last
            if mail and c.visible(dev, 3):
                dev.fill(mail)
                page.keyboard.press("Enter")
        except Exception:
            pass
        _debug_dump(page, 'branding-vor-speichern')
        _click_save(page, 4)   # (kein Fehler, wenn nichts zu speichern ist)
        page.wait_for_timeout(3000)
        _debug_dump(page, 'branding-nach-speichern')
        page.wait_for_timeout(2500)

    c.auto(branding, "Öffne unter 'Branding' die Seite und fülle App-Name, E-Mail für Nutzersupport und Kontakt-E-Mail des Entwicklers aus. Klicke 'Speichern'. Klicke danach 'Weiter'.",
           goal="On the Google Auth Platform 'Branding' page make sure all required fields are filled: App name 'ARIAssistant', a User support email (pick the first option) and the Developer contact email (the account email). "
                "Then click Save. Do not click help or learn-more links.")
    c.step(9, total, "App veröffentlichen", "App veröffentlichen ...")

    def publish():
        page.goto(f"https://console.cloud.google.com/auth/audience?project={pid}", wait_until="domcontentloaded")
        if c.visible(page.get_by_text(_I(r"in production|in produktion")), 4):
            return   # schon veroeffentlicht
        pb = page.get_by_role("button", name=_I(r"publish app|app veröffentlichen")).first
        for _try in range(4):   # Google braucht nach dem Speichern von Branding einen Moment - neu laden und erneut schauen
            page.wait_for_timeout(3500)
            if c.visible(pb, 4) and pb.is_enabled():
                break
            page.reload(wait_until="domcontentloaded")
        if not c.visible(pb, 6) or not pb.is_enabled():
            _debug_dump(page, "publish-nicht-aktiv")
            _set(note="Veröffentlichen war nicht möglich - kein Problem, die Verbindung klappt trotzdem (Google fragt dann nur nach 7 Tagen neu).")
            return
        pb.click()
        page.wait_for_timeout(1200)
        c.click_any(page.get_by_role("button", name=_I(r"^(confirm|bestätigen)$")), timeout=6)
        end = time.time() + 15
        while time.time() < end:
            if c.visible(page.get_by_text(_I(r"in production|in produktion"))):
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Status 'In production' nicht gesehen")

    c.auto(publish, "Öffne unter 'Zielgruppe' (Audience) den Knopf 'Publish app' und bestätige mit 'Confirm'. Dann steht dort 'In production'. "
           "Klicke danach 'Weiter'. (Beim Verbinden zeigt Google später 'Google hat diese App nicht überprüft' - dort 'Erweitert' und 'Weiter zu ARIAssistant' wählen.)")
    c.step(10, total, "OAuth-Client erstellen", "A.R.I erstellt den Zugangs-Client und liest ihn aus ...")

    def client():
        page.goto(f"https://console.cloud.google.com/auth/clients/create?project={pid}", wait_until="domcontentloaded")
        page.wait_for_timeout(3500)
        c.click_any(page.get_by_label(_I(r"application type|anwendungstyp")), page.get_by_role("combobox").last)
        page.wait_for_timeout(800)
        c.click_any(page.get_by_role("option", name=_I(r"desktop")), page.get_by_text(_I(r"desktop app|desktop-app|desktop")))
        page.wait_for_timeout(800)
        nm = page.get_by_role("textbox", name=_I(r"^name")).first
        c.visible(nm, 6)
        nm.fill(G_NAME)
        _debug_dump(page, "client-formular")
        c.click_any(page.get_by_role("button", name=_I(r"^(create|erstellen)$")))
        end = time.time() + 25
        while time.time() < end:
            t = c.text()
            cid = re.search(r"\d{6,}-[a-z0-9]+\.apps\.googleusercontent\.com", t)
            sec = re.search(r"GOCSPX-[\w\-]+", t)
            if cid and sec:
                holder["cid"], holder["secret"] = cid.group(0), sec.group(0)
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Client-Daten nicht gefunden")

    c.auto(client, "Erstelle unter 'Clients' einen OAuth-Client vom Typ 'Desktop app' (Name '" + G_NAME + "'). Lass das Fenster mit Client-ID und -Secret offen.",
           lambda: bool(re.search(r"GOCSPX-[\w\-]+", c.text())))
    if "cid" not in holder:
        t = c.text()
        cid = re.search(r"\d{6,}-[a-z0-9]+\.apps\.googleusercontent\.com", t)
        sec = re.search(r"GOCSPX-[\w\-]+", t)
        if not (cid and sec):
            raise RuntimeError("Client-ID/Secret nicht gefunden")
        holder["cid"], holder["secret"] = cid.group(0), sec.group(0)
    return {"google": {"clientId": holder["cid"], "clientSecret": holder["secret"]}}


def flow_mock_agent(c):
    """Testablauf mit anders benannten Knoepfen: die festen Schritte finden nichts, die KI-Hilfe muss die Seite lesen."""
    page = c.page
    c.step(1, 2, "Beispielseite (KI-Hilfe)", "Test mit eingebauter Seite.")
    page.set_content("""<html><body style="font:16px sans-serif;padding:30px"><h2>Mock-Dienst</h2>
      <button id=go onclick="document.getElementById('form').style.display='block'">Make a new project</button>
      <div id=form style="display:none"><label>Title of project <input id=title></label><br><label>Return address <input id=ret></label><br>
      <label><input type=checkbox id=api> Use the web interface</label><br>
      <button id=agree onclick="document.getElementById('store').disabled=false">Agree to terms</button><br>
      <button id=store disabled onclick="document.getElementById('out').textContent='Client ID: '+'c'.repeat(32)+' Secret: '+'d'.repeat(32)">Store</button><p id=out></p></div></body></html>""")
    c.step(2, 2, "Formular", "A.R.I versucht es automatisch ...")
    done = lambda: "Client ID" in c.text()

    def fixed():
        page.get_by_role("button", name="Create app").click(timeout=1500)   # existiert nicht -> Fehler -> KI-Hilfe

    c.auto(fixed, "Klicke 'Make a new project', fülle das Formular aus und klicke 'Store'.", done,
           goal="Create a new project: click 'Make a new project', set the title to ARI, the return address to http://127.0.0.1:5000/spotify/callback, tick the web interface checkbox, click Agree to terms and click Store.")
    ids = re.findall(r"\b[0-9a-f]{32}\b", c.text())
    return {"mock": {"clientId": ids[0], "clientSecret": ids[1]}}


HOSTS = {"mock": [], "mock_agent": [], "spotify": ["developer.spotify.com", "accounts.spotify.com", "spotify.com", "127.0.0.1"],
         "google": ["console.cloud.google.com", "accounts.google.com", "console.developers.google.com", "google.com"],
         "yahoo": ["login.yahoo.com", "yahoo.com"], "groq": ["console.groq.com", "groq.com"], "groq_new": ["console.groq.com", "groq.com"], "groq_all": ["console.groq.com", "groq.com"], "gemini": ["aistudio.google.com", "accounts.google.com", "google.com"]}
FLOWS = {"mock": flow_mock, "mock_agent": flow_mock_agent, "groq_new": flow_groq, "groq_all": flow_groq_all, "spotify": flow_spotify, "groq": flow_groq, "gemini": flow_gemini, "yahoo": flow_yahoo, "google": flow_google}
TITLES = {"groq_all": "Alle Groq-Schlüssel", "groq_new": "Weiterer Groq-Schlüssel", "mock": "Test", "mock_agent": "Test (KI-Hilfe)", "spotify": "Spotify", "groq": "Groq-Schlüssel", "gemini": "Gemini-Schlüssel", "yahoo": "Yahoo Mail", "google": "Google Kalender & Gmail"}


def register_flow(name, fn, title, hosts):
    """Mods koennen hier eigene Einrichtungs-Ablaeufe anmelden (z. B. 'discord'): fn(Ctx) -> Ergebnis-Dict, hosts = erlaubte Webseiten."""
    FLOWS[name] = fn
    TITLES[name] = title
    HOSTS[name] = list(hosts)


# ------------------------------------------------------------------------------------- Steuerung
def _run(flow, hub, profile_dir):
    pw = None
    try:
        from playwright.sync_api import sync_playwright
        _set(state="starting", message="Browser wird gestartet ...")
        port = _launch_browser(profile_dir)
        pw = sync_playwright().start()
        browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
        ctx = browser.contexts[0] if browser.contexts else browser.new_context()
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(8000)

        def _no_extra_tabs(newp):
            """Links wie 'Weitere Informationen' oeffnen neue Tabs - die brauchen wir nie und schliessen sie sofort (nicht 1000 Seiten)."""
            try:
                if newp != page:
                    newp.close()
            except Exception:
                pass
        ctx.on("page", _no_extra_tabs)
        for extra in list(ctx.pages):
            if extra != page:
                try:
                    extra.close()
                except Exception:
                    pass
        try:   # feste Seitengroesse: jede Webseite zeigt dann dasselbe Layout (kein eingeklapptes Handy-Menue bei kleinen Fenstern)
            page.set_viewport_size({"width": 1280, "height": 900})
        except Exception:
            pass
        _set(state="running")
        hub = dict(hub or {})
        hub["hosts"] = HOSTS.get(flow, [])
        result = FLOWS[flow](Ctx(page, hub))
        if flow == "groq_new" and isinstance(result, dict) and "apikey" in result:
            result["apikey"]["extra"] = True   # HUD traegt ihn in den naechsten freien Platz ein
        if flow == "google":
            _say("Jetzt ist alles eingerichtet und bereit zum Verbinden.")
        _set(state="done", message="Fertig!", note="", result=result, needs_user=False, hint="")
    except Cancelled:
        _set(state="cancelled", message="Abgebrochen.", needs_user=False, hint="")
    except Exception as e:
        _set(state="error", error=str(e) or e.__class__.__name__, message="Das hat nicht geklappt.", needs_user=False, hint="")
    finally:
        try:
            if pw is not None:
                pw.stop()
        except Exception:
            pass
        _close_browser()
        if flow == "groq_new" and _profile and "-konto-" in _profile:
            try:
                import shutil
                shutil.rmtree(_profile, ignore_errors=True)
            except Exception:
                pass


def start(flow, hub, profile_dir):
    """Startet einen Ablauf im Hintergrund. hub = Rueckrufe (z.B. {'save_spotify': fn})."""
    global _thread
    if flow == "groq_new":   # eigenes, frisches Profil: dort kann man sich mit einem ANDEREN Konto anmelden
        profile_dir = profile_dir + "-konto-" + str(int(time.time()))
    if flow not in FLOWS:
        return False, "Unbekannter Ablauf."
    if running():
        return False, "Es läuft schon eine Einrichtung."
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False, "Das Paket 'playwright' fehlt (wird beim nächsten Start nachinstalliert)."
    _cancel.clear()
    _cont.clear()
    _say("")   # alte Ansage verwerfen (das HUD liest nur NEUE vor)
    _set(flow=flow, state="starting", step=0, total=0, title=TITLES.get(flow, flow), message="Starte ...", note="", needs_user=False, hint="", result=None, error="")
    _thread = threading.Thread(target=_run, args=(flow, hub, profile_dir), daemon=True)
    _thread.start()
    return True, None
