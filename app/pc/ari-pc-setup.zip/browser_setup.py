"""Browser-gesteuerte Einrichtung: A.R.I oeffnet einen eigenen Browser (Edge/Chrome, eigenes Profil), der Nutzer meldet sich dort
EINMAL an (und stimmt am Ende zu) - alles andere (Developer-App anlegen, Felder ausfuellen, Schluessel auslesen und in A.R.I
eintragen) macht A.R.I selbst.

Aufbau:
  * Der Browser wird ganz normal gestartet (mit Debug-Port), NICHT von der Automatisierung - so akzeptieren Google & Co. die
    Anmeldung ("Dieser Browser ist nicht sicher" erscheint bei automatisiert gestarteten Browsern). Danach haengt sich Playwright
    ueber den Debug-Port daran (connect_over_cdp).
  * Jeder Ablauf ("Flow") besteht aus Schritten. Klappt ein Schritt automatisch nicht (Seite hat sich geaendert, anderes
    Konto-Layout ...), faellt er auf "bitte selbst machen" zurueck: das HUD zeigt die Anweisung, A.R.I wartet, bis es
    erledigt ist (oder der Nutzer auf "Weiter" klickt) und macht dann automatisch weiter.
  * Zustand wird per status() vom HUD abgefragt; Ergebnisse (z.B. Schluessel) gibt der Flow im "result" zurueck.
"""
import os
import re
import socket
import subprocess
import threading
import time
import urllib.request

_lock = threading.Lock()
_state = {"flow": "", "state": "idle", "step": 0, "total": 0, "title": "", "message": "", "note": "", "needs_user": False,
          "hint": "", "result": None, "error": "", "updated": 0.0, "say": "", "say_id": 0}
_cancel = threading.Event()
_cont = threading.Event()
_thread = None
_proc = None


class Cancelled(Exception):
    pass


def status():
    with _lock:
        return dict(_state)


def _set(**kw):
    with _lock:
        _state.update(kw)
        _state["updated"] = time.time()


def _say(text):
    """Kurze Ansage, die das HUD zusaetzlich vorliest (A.R.I sagt, was es gleich tut oder was der Nutzer tun muss)."""
    with _lock:
        _state["say"] = str(text)
        _state["say_id"] = int(_state.get("say_id", 0)) + 1


def _check():
    if _cancel.is_set():
        raise Cancelled()


def cancel():
    _cancel.set()
    _cont.set()


def user_continue():
    _cont.set()


def running():
    return _thread is not None and _thread.is_alive()


# ----------------------------------------------------------------------------------------- Browser
def _find_browser():
    pf, pf86, local = os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("LOCALAPPDATA", "")
    for p in (os.path.join(pf86, "Microsoft", "Edge", "Application", "msedge.exe"),
              os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
              os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
              os.path.join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
              os.path.join(local, "Google", "Chrome", "Application", "chrome.exe")):
        if os.path.exists(p):
            return p
    return None


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _launch_browser(profile_dir, url="about:blank"):
    global _proc, _profile
    _profile = profile_dir
    exe = _find_browser()
    if not exe:
        raise RuntimeError("Weder Microsoft Edge noch Google Chrome gefunden.")
    port = _free_port()
    os.makedirs(profile_dir, exist_ok=True)
    args = [exe, f"--remote-debugging-port={port}", f"--user-data-dir={profile_dir}", "--no-first-run", "--no-default-browser-check",
            "--lang=en-US", "--accept-lang=en-US", "--window-size=1240,900", url]
    _proc = subprocess.Popen(args)
    for _ in range(80):
        _check()
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1).read()
            return port
        except Exception:
            time.sleep(0.25)
    raise RuntimeError("Der Browser hat sich nicht gemeldet.")


_profile = None


def _close_browser():
    """Beendet den Einrichtungs-Browser samt aller Hilfsprozesse (alles, was das eigene Profil-Verzeichnis benutzt)."""
    global _proc
    p, _proc = _proc, None
    if p is not None and p.poll() is None:
        try:
            p.terminate()
        except Exception:
            pass
    if _profile:
        try:
            import psutil
            needle = os.path.normcase(os.path.abspath(_profile))
            victims = []
            for pr in psutil.process_iter(["cmdline"]):
                try:
                    if any(needle in os.path.normcase(part) for part in (pr.info["cmdline"] or [])):
                        victims.append(pr)
                except Exception:
                    pass
            for pr in victims:
                try:
                    pr.kill()
                except Exception:
                    pass
        except Exception:
            pass


# ------------------------------------------------------------------------------------------ Helfer
class Ctx:
    """Handwerkszeug fuer die Flows (Seite + Warten/Nachfragen)."""

    def __init__(self, page, hub):
        self.page = page
        self.hub = hub or {}

    def step(self, n, total, title, message=""):
        """Neuer Schritt: erst ansagen (Text im HUD + gesprochen), dann ausfuehren."""
        _check()
        _set(step=n, total=total, title=title, message=message or title, note="", needs_user=False, hint="")
        _say(message or title)

    def wait_for(self, pred, timeout=900, poll=0.5):
        """Wartet, bis pred() wahr wird (Fehler in pred zaehlen als 'noch nicht')."""
        end = time.time() + timeout
        while time.time() < end:
            _check()
            try:
                if pred():
                    return True
            except Exception:
                pass
            self.page.wait_for_timeout(int(poll * 1000))
        return False

    def visible(self, locator, timeout=0):
        try:
            if timeout:
                locator.first.wait_for(state="visible", timeout=int(timeout * 1000))
                return True
            return locator.first.is_visible()
        except Exception:
            return False

    def ask_user(self, hint, done_pred=None, timeout=1200):
        """Nutzer muss etwas selbst tun (Anmelden, Zustimmen, ...). Wartet auf done_pred oder 'Weiter' im HUD."""
        _cont.clear()
        _set(needs_user=True, hint=hint)
        _say("Dein Einsatz: " + hint)
        end = time.time() + timeout
        ok = False
        while time.time() < end:
            _check()
            if _cont.is_set():
                ok = True
                break
            try:
                if done_pred and done_pred():
                    ok = True
                    break
            except Exception:
                pass
            self.page.wait_for_timeout(500)
        _cont.clear()
        _set(needs_user=False, hint="")
        if not ok:
            raise RuntimeError("Zeitueberschreitung beim Warten auf den Nutzer.")

    def auto(self, fn, manual_hint, done_pred=None, goal=None):
        """Schritt automatisch versuchen; klappt er nicht, hilft die KI des Nutzers (Agent: liest die Seite und entscheidet jeden
        Schritt neu); klappt auch das nicht, wird der Nutzer gebeten - danach geht es automatisch weiter."""
        try:
            return fn()
        except Cancelled:
            raise
        except Exception as e:
            _set(note="Automatisch ging das nicht (" + str(e).splitlines()[0][:90] + ").")   # ergaenzt den Schritt, ersetzt ihn nicht
            if self.hub.get("llm"):
                try:
                    if agent_run(self, goal or manual_hint, done_pred):
                        return None
                except Cancelled:
                    raise
                except Exception as e2:
                    _set(note="Auch die KI-Hilfe kam nicht weiter (" + str(e2).splitlines()[0][:80] + ").")
            self.ask_user(manual_hint, done_pred)
            return None

    def click_any(self, *locators, timeout=8):
        """Klickt das erste sichtbare von mehreren moeglichen Elementen."""
        end = time.time() + timeout
        while time.time() < end:
            _check()
            for loc in locators:
                try:
                    if loc.first.is_visible():
                        loc.first.click()
                        return True
                except Exception:
                    pass
            self.page.wait_for_timeout(300)
        raise RuntimeError("Knopf nicht gefunden")

    def text(self):
        try:
            return self.page.inner_text("body", timeout=3000)
        except Exception:
            return ""


def _I(s):
    return re.compile(s, re.I)


# Google verlangt fuer Projekt-/App-/Client-Namen mindestens 4 Buchstaben und keine Sonderzeichen ("ARI" ist zu kurz)
G_NAME = "ARIAssistant"

# ------------------------------------------------------------------------------------------ KI-Agent
_SNAP_JS = r"""() => {
  const sel = 'a[href],button,input,select,textarea,summary,[role=button],[role=link],[role=checkbox],[role=radio],[role=option],[role=combobox],[role=tab],[role=menuitem],[role=switch]';
  document.querySelectorAll('[data-ari-i]').forEach(e => e.removeAttribute('data-ari-i'));
  const out = []; let n = 0;
  for (const el of document.querySelectorAll(sel)) {
    const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
    if (r.width < 2 || r.height < 2 || cs.visibility === 'hidden' || cs.display === 'none') continue;
    const tag = el.tagName.toLowerCase(), type = (el.getAttribute('type') || '').toLowerCase();
    let name = el.getAttribute('aria-label') || '';
    if (!name && el.labels && el.labels.length) name = el.labels[0].innerText;
    if (!name) name = el.innerText || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('alt') || el.getAttribute('name') || el.getAttribute('value') || '';
    name = name.replace(/\s+/g, ' ').trim().slice(0, 90);
    if (!name && tag === 'a') name = (el.getAttribute('href') || '').slice(0, 60);
    const role = el.getAttribute('role') || (tag === 'a' ? 'link' : tag === 'button' ? 'button' : tag === 'select' ? 'select' : tag === 'textarea' ? 'textbox' : tag === 'input' ? (type === 'checkbox' ? 'checkbox' : type === 'radio' ? 'radio' : type === 'submit' || type === 'button' ? 'button' : 'textbox') : tag);
    const e = { i: ++n, role, name, type, disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true' };
    if (role === 'checkbox' || role === 'radio' || role === 'switch') e.checked = !!el.checked || el.getAttribute('aria-checked') === 'true';
    if (role === 'textbox' && type !== 'password') e.value = String(el.value || '').slice(0, 60);
    el.setAttribute('data-ari-i', String(n)); out.push(e);
    if (n >= 110) break;
  }
  return { url: location.href, title: document.title, text: (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 1500), els: out };
}"""

_AGENT_SYSTEM = (
    "You operate a web browser step by step to reach a GOAL for the user. Each turn you get the current page: URL, title, visible text and a numbered list "
    "of the interactive elements. Reply with exactly ONE JSON object and nothing else, one of:\n"
    '{"action":"click","id":N} | {"action":"fill","id":N,"text":"..."} | {"action":"check","id":N} | {"action":"select","id":N,"text":"option text"} | '
    '{"action":"press","text":"Enter"} | {"action":"goto","url":"https://..."} | {"action":"scroll"} | {"action":"wait"} | '
    '{"action":"ask_user","message":"what the user must do themselves"} | {"action":"done"} | {"action":"fail","message":"why"}\n'
    "Rules: One action per turn. Pages are in English. NEVER type passwords, codes or secrets. If a login, 2-factor code, captcha, terms/consent checkbox, "
    '"Agree/Accept/Allow/Authorize" button, payment or anything legally binding is needed, use ask_user and describe it for the user. Do not leave the '
    "allowed websites. When the goal is reached (or the requested secret/key is visible on screen), answer done. Think briefly; keep the JSON short."
)
_DANGEROUS = re.compile(r"\b(agree|accept|allow|authori[sz]e|i understand|consent|zustimm|erlaub|akzeptier|pay|buy|purchase|subscribe|upgrade|delete|remove|deactivate)\b", re.I)
_SECRETISH = re.compile(r"pass(word|wort)|secret|token|otp|verification|2fa|code", re.I)
_LIMIT = re.compile(r"429|rate.?limit|quota|too many requests|resource.?exhausted|overloaded|\b529\b|\b503\b|tokens? per (minute|day)|limit (reached|exceeded)|usage limit", re.I)


def _wait_retry(c, err, attempt):
    """Limit (Rate-Limit/Kontingent/Ueberlastung) erreicht: warten und danach GENAU an dieser Stelle weitermachen."""
    msg = str(err)
    secs = 20.0 * min(attempt, 6)
    m = re.search(r"(?:try again|retry)[^0-9]{0,20}(\d+(?:\.\d+)?)\s*(ms|s|sec|m|min)?", msg, re.I) or re.search(r"(\d+(?:\.\d+)?)\s*(ms|s|sec|m|min)\b", msg, re.I)
    if m:
        v, unit = float(m.group(1)), (m.group(2) or "s").lower()
        secs = v / 1000.0 if unit == "ms" else v * 60 if unit in ("m", "min") else v
        secs += 1.5
    secs = max(5.0, min(secs, 180.0))
    end = time.time() + secs
    while time.time() < end:
        _check()
        _set(note=f"KI-Limit erreicht - A.R.I wartet {int(end - time.time()) + 1} s und macht dann automatisch an derselben Stelle weiter.")
        c.page.wait_for_timeout(1000)
    _set(note="")


def _ask_llm(c, system, user, image):
    """KI-Anfrage mit automatischem Warten bei Limit/Ueberlastung (bis ca. 25 Minuten insgesamt), danach weiter wie zuvor."""
    llm = c.hub["llm"]
    started = time.time()
    attempt = 0
    while True:
        _check()
        try:
            return llm(system, user, image)
        except Cancelled:
            raise
        except Exception as e:
            attempt += 1
            if not _LIMIT.search(str(e)) or time.time() - started > 1500:
                raise
            _wait_retry(c, e, attempt)


def _parse_action(text):
    import json
    t = (text or "").strip()
    m = re.search(r"\{.*\}", t, re.S)
    if not m:
        raise ValueError("keine Aktion in der Antwort")
    return json.loads(m.group(0))


def agent_run(c, goal, until=None, max_steps=30):
    """KI-Agent: liest die Seite (Elementliste + Text + Screenshot), laesst die KI des Nutzers den naechsten Schritt waehlen, fuehrt ihn
    aus und schaut danach wieder hin - wie ein Mensch. Anmeldung, Zustimmung, Bezahlen und Passwoerter bleiben beim Nutzer."""
    page = c.page
    hosts = c.hub.get("hosts") or []
    history = []
    _set(note="Die KI schaut sich die Seite an ...")
    _say("Das hat nicht automatisch geklappt. Ich übernehme jetzt mit der KI und schaue mir die Seite an.")
    for step in range(max_steps):
        _check()
        if until:
            try:
                if until():
                    return True
            except Exception:
                pass
        try:
            snap = page.evaluate(_SNAP_JS)
        except Exception:
            page.wait_for_timeout(800)
            continue
        host = re.sub(r"^https?://([^/]+).*$", r"\1", snap["url"])
        if hosts and not any(host == h or host.endswith("." + h) for h in hosts) and not snap["url"].startswith(("about:", "data:")):
            try:
                page.go_back()
            except Exception:
                pass
            history.append("left the allowed site -> went back")
            continue
        lines = []
        for e in snap["els"]:
            extra = (" checked" if e.get("checked") else "") + (" DISABLED" if e.get("disabled") else "") + (f' value="{e["value"]}"' if e.get("value") else "")
            lines.append(f'[{e["i"]}] {e["role"]} "{e["name"]}"{extra}')
        user = (f"GOAL: {goal}\nAllowed websites: {', '.join(hosts) or 'any'}\nRecent actions: {' | '.join(history[-6:]) or '-'}\n\n"
                f"URL: {snap['url']}\nTitle: {snap['title']}\nVisible text: {snap['text']}\n\nElements:\n" + "\n".join(lines))
        image = None
        try:
            import base64
            image = base64.b64encode(page.screenshot(type="jpeg", quality=55)).decode()
        except Exception:
            pass
        raw = _ask_llm(c, _AGENT_SYSTEM, user, image)
        try:
            act = _parse_action(raw)
        except Exception:
            history.append("invalid answer")
            continue
        kind = str(act.get("action") or "").lower()
        el = None
        if "id" in act:
            el = next((e for e in snap["els"] if e["i"] == int(act["id"])), None)
        name = (el or {}).get("name", "")
        history.append(f'{kind} {act.get("id", "")} {name[:40]}'.strip())
        _check()
        if kind == "done":
            if until is None or (until and until()):
                return True
            history.append("done was not confirmed by the page")
            continue
        if kind == "fail":
            raise RuntimeError(str(act.get("message") or "KI sagt: nicht machbar"))
        if kind == "ask_user":
            _set(message="")
            c.ask_user(str(act.get("message") or "Bitte im Browserfenster weitermachen."), lambda: bool(until and until()))
            continue
        if kind in ("click", "check", "fill", "select") and el is None:
            history.append("unknown element")
            continue
        if kind in ("click", "check") and _DANGEROUS.search(name):
            c.ask_user(f"Bitte klicke im Browserfenster selbst auf '{name}' (Zustimmung/Bezahlen macht A.R.I nie allein).", lambda: bool(until and until()))
            continue
        if kind in ("fill", "select") and (el.get("type") == "password" or _SECRETISH.search(name)):
            c.ask_user(f"Bitte trage das Feld '{name}' im Browserfenster selbst ein (Passwörter/Codes tippt A.R.I nie).", lambda: bool(until and until()))
            continue
        sel = f'[data-ari-i="{el["i"]}"]' if el else None
        _set(note={"click": f"Klicke: {name}", "check": f"Hake an: {name}", "fill": f"Fülle aus: {name}", "select": f"Wähle: {name}",
                      "goto": "Öffne Seite ...", "press": "Drücke Taste ...", "scroll": "Scrolle ...", "wait": "Warte ..."}.get(kind, "Arbeite ..."))
        try:
            if kind == "click":
                page.locator(sel).first.click(timeout=6000)
            elif kind == "check":
                page.locator(sel).first.check(timeout=6000)
            elif kind == "fill":
                page.locator(sel).first.fill(str(act.get("text") or "")[:200], timeout=6000)
            elif kind == "select":
                page.locator(sel).first.select_option(label=str(act.get("text") or ""), timeout=6000)
            elif kind == "press":
                page.keyboard.press(str(act.get("text") or "Enter")[:20])
            elif kind == "goto":
                url = str(act.get("url") or "")
                h2 = re.sub(r"^https?://([^/]+).*$", r"\1", url)
                if url.startswith("https://") and (not hosts or any(h2 == h or h2.endswith("." + h) for h in hosts)):
                    page.goto(url, wait_until="domcontentloaded")
                else:
                    history.append("goto refused")
            elif kind == "scroll":
                page.mouse.wheel(0, 600)
            else:
                page.wait_for_timeout(1500)
        except Cancelled:
            raise
        except Exception as e:
            history.append("failed: " + str(e).splitlines()[0][:50])
        page.wait_for_timeout(900)
    return bool(until and until())



# ------------------------------------------------------------------------------------------- Flows
def flow_mock(c):
    """Testablauf gegen eine eingebaute Beispielseite (DEV-Knopf): Anmeldung abwarten, Formular, Schluessel auslesen."""
    page = c.page
    c.step(1, 3, "Beispielseite", "Test mit eingebauter Seite.")
    page.set_content("""<html><body style="font:16px sans-serif;padding:30px"><h2 id=t>Mock-Dienst</h2>
      <button id=login onclick="document.getElementById('app').style.display='block';this.style.display='none';document.getElementById('t').textContent='Dashboard'">Log in</button>
      <div id=app style="display:none"><button id=create onclick="document.getElementById('form').style.display='block'">Create app</button>
      <div id=form style="display:none"><label>App name <input id=name></label><br><label>Redirect URI <input id=ru></label><br>
      <label><input type=checkbox id=web> Web API</label><br><button id=save onclick="document.getElementById('out').textContent='Client ID: '+'a'.repeat(32)+' Secret: '+'b'.repeat(32)">Save</button><p id=out></p></div></div></body></html>""")
    c.step(2, 3, "Anmelden", "Bitte im Browserfenster auf 'Log in' klicken (Test).")
    c.ask_user("Klicke im geöffneten Fenster auf 'Log in'.", lambda: c.visible(page.get_by_role("button", name="Create app")))
    c.step(3, 3, "Formular ausfüllen", "A.R.I füllt das Formular aus ...")
    page.get_by_role("button", name="Create app").click()
    page.get_by_label("App name").fill("ARI")
    page.get_by_label("Redirect URI").fill("http://127.0.0.1:5000/spotify/callback")
    page.get_by_label(_I("Web API")).check()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector("#out:has-text('Client ID')", timeout=5000)
    ids = re.findall(r"\b[0-9a-f]{32}\b", c.text())
    return {"mock": {"clientId": ids[0], "clientSecret": ids[1]}}


def flow_spotify(c):
    page = c.page
    redirect = "http://127.0.0.1:5000/spotify/callback"
    total = 5
    c.step(1, total, "Spotify-Dashboard öffnen", "A.R.I öffnet die Spotify-Entwicklerseite.")
    page.goto("https://developer.spotify.com/dashboard", wait_until="domcontentloaded")
    create_btn = page.get_by_role("button", name=_I(r"create app"))
    create_link = page.get_by_role("link", name=_I(r"create app"))
    on_dashboard = lambda: c.visible(create_btn) or c.visible(create_link)
    if not c.visible(create_btn, 5) and not c.visible(create_link, 1):
        c.step(2, total, "Anmelden", "Bitte melde dich im geöffneten Browserfenster bei Spotify an.")
        c.auto(lambda: c.click_any(page.get_by_role("button", name=_I(r"^log ?in")), page.get_by_role("link", name=_I(r"^log ?in")), timeout=4),
               "Klicke im Browserfenster auf 'Log in' und melde dich bei Spotify an.", on_dashboard)
        c.ask_user("Melde dich im Browserfenster bei Spotify an (und stimme den Entwickler-Bedingungen zu, falls Spotify danach fragt). "
                   "Danach macht A.R.I automatisch weiter.", on_dashboard)
    c.step(3, total, "App anlegen", "A.R.I legt die Spotify-App 'ARI' an ...")

    def create():
        existing = page.get_by_role("link", name=re.compile(r"^ARI$"))
        if c.visible(existing, 1):
            existing.first.click()
            return
        c.click_any(create_btn, create_link)
        page.get_by_label(_I(r"app name")).fill("ARI")
        page.get_by_label(_I(r"app description")).fill("Persoenlicher Assistent ARI")
        ru = page.get_by_label(_I(r"redirect uri"))
        ru.fill(redirect)
        try:
            page.get_by_role("button", name=_I(r"^add$")).first.click()
        except Exception:
            ru.press("Enter")
        try:
            page.get_by_label(_I(r"web api")).check()
        except Exception:
            pass
        # Die Entwickler-Bedingungen bestaetigt der Nutzer selbst (rechtliche Zustimmung gehoert ihm), danach "Save".
        _set(message="Alles ausgefüllt.")
        c.ask_user("Setze im Browserfenster das Häkchen bei den Entwickler-Bedingungen (Developer Terms) und klicke auf 'Save'.",
                   lambda: bool(re.search(r"/dashboard/[0-9a-f]{32}", page.url)))
        page.wait_for_url(re.compile(r"/dashboard/[0-9a-f]{32}"), timeout=15000)

    c.auto(create, "Lege die App selbst an: 'Create app', Name 'ARI', Redirect URI " + redirect + " (mit 'Add'), 'Web API' ankreuzen, Bedingungen "
           "bestätigen, 'Save'. Klicke danach auf 'Weiter'.", lambda: bool(re.search(r"/dashboard/[0-9a-f]{32}", page.url)))
    c.step(4, total, "Schlüssel auslesen", "A.R.I liest Client-ID und Secret aus ...")
    holder = {}

    def read():
        try:
            c.click_any(page.get_by_role("link", name=_I(r"^settings$")), page.get_by_role("button", name=_I(r"^settings$")), timeout=4)
        except Exception:
            pass
        page.wait_for_timeout(800)
        try:
            c.click_any(page.get_by_text(_I(r"view client secret")), timeout=4)
        except Exception:
            pass
        page.wait_for_timeout(800)
        ids = []
        for x in re.findall(r"\b[0-9a-f]{32}\b", c.text()):
            if x not in ids:
                ids.append(x)
        if len(ids) < 2:
            raise RuntimeError("Client-ID/Secret nicht gefunden")
        holder["id"], holder["secret"] = ids[0], ids[1]

    c.auto(read, "Öffne in der App die 'Settings', klicke 'View client secret' und lass beides sichtbar. Klicke dann 'Weiter'.")
    if "id" not in holder:
        read()
    c.step(5, total, "Mit Spotify verbinden", "A.R.I trägt die Daten ein und öffnet den Zustimmungs-Dialog.")
    auth_url = c.hub["save_spotify"](holder["id"], holder["secret"])
    page.goto(auth_url, wait_until="domcontentloaded")
    c.ask_user("Klicke im Browserfenster auf 'Agree' / 'Zustimmen', um A.R.I den Zugriff zu erlauben.",
               lambda: "127.0.0.1:5000/spotify/callback" in page.url)
    return {"spotify": {"clientId": holder["id"], "clientSecret": holder["secret"]}}


def flow_groq(c):
    page = c.page
    c.step(1, 3, "Groq öffnen", "A.R.I öffnet die Groq-Konsole.")
    page.goto("https://console.groq.com/keys", wait_until="domcontentloaded")
    create = page.get_by_role("button", name=_I(r"create api key"))
    if not c.visible(create, 6):
        c.step(2, 3, "Anmelden", "Bitte melde dich im Browserfenster bei Groq an (Google, GitHub oder E-Mail).")
        c.ask_user("Melde dich im Browserfenster bei Groq an (oder erstelle ein kostenloses Konto). Danach macht A.R.I automatisch weiter.",
                   lambda: c.visible(create))
    c.step(3, 3, "Schlüssel erstellen", "A.R.I erstellt den Schlüssel ...")
    holder = {}

    def make():
        create.first.click()
        page.get_by_placeholder(_I(r"name")).first.fill("ARI")
        c.click_any(page.get_by_role("button", name=_I(r"^submit$")), page.get_by_role("button", name=_I(r"create")))
        end = time.time() + 12
        while time.time() < end:
            m = re.search(r"gsk_[A-Za-z0-9]{20,}", c.text())
            if m:
                holder["key"] = m.group(0)
                return
            page.wait_for_timeout(400)
        raise RuntimeError("Schlüssel nicht gefunden")

    c.auto(make, "Klicke 'Create API Key', gib den Namen 'ARI' ein und bestätige. Lass den angezeigten Schlüssel (beginnt mit gsk_) sichtbar.",
           lambda: bool(re.search(r"gsk_[A-Za-z0-9]{20,}", c.text())))
    if "key" not in holder:
        m = re.search(r"gsk_[A-Za-z0-9]{20,}", c.text())
        if not m:
            raise RuntimeError("Kein Schlüssel gefunden")
        holder["key"] = m.group(0)
    return {"apikey": {"provider": "groq", "key": holder["key"]}}


def flow_gemini(c):
    page = c.page
    c.step(1, 3, "Google AI Studio öffnen", "A.R.I öffnet die Seite für Gemini-Schlüssel.")
    page.goto("https://aistudio.google.com/apikey", wait_until="domcontentloaded")
    create = page.get_by_role("button", name=_I(r"create api key"))
    if not c.visible(create, 8):
        c.step(2, 3, "Anmelden", "Bitte melde dich im Browserfenster mit deinem Google-Konto an.")
        c.ask_user("Melde dich im Browserfenster mit deinem Google-Konto an und stimme den Bedingungen zu, falls gefragt. "
                   "Danach macht A.R.I automatisch weiter.", lambda: c.visible(create))
    c.step(3, 3, "Schlüssel erstellen", "A.R.I erstellt den Schlüssel ...")
    holder = {}
    pat = r"AIza[0-9A-Za-z_\-]{35}"

    def make():
        create.first.click()
        page.wait_for_timeout(1000)
        try:
            c.click_any(page.get_by_text(_I(r"create api key in new project")), page.get_by_role("option").first, timeout=4)
        except Exception:
            pass
        try:
            c.click_any(page.get_by_role("button", name=_I(r"^create key$")), page.get_by_role("button", name=_I(r"create api key")), timeout=4)
        except Exception:
            pass
        end = time.time() + 15
        while time.time() < end:
            m = re.search(pat, c.text())
            if m:
                holder["key"] = m.group(0)
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Schlüssel nicht gefunden")

    c.auto(make, "Klicke 'Create API key' und bestätige. Lass den angezeigten Schlüssel (beginnt mit AIza) sichtbar.",
           lambda: bool(re.search(pat, c.text())))
    if "key" not in holder:
        m = re.search(pat, c.text())
        if not m:
            raise RuntimeError("Kein Schlüssel gefunden")
        holder["key"] = m.group(0)
    return {"apikey": {"provider": "gemini", "key": holder["key"]}}


def flow_yahoo(c):
    page = c.page
    c.step(1, 3, "Yahoo öffnen", "A.R.I öffnet die Yahoo-Sicherheitsseite.")
    page.goto("https://login.yahoo.com/account/security/app-passwords", wait_until="domcontentloaded")
    gen_btn = page.get_by_role("button", name=_I(r"generate|create"))
    if not c.visible(gen_btn, 6):
        c.step(2, 3, "Anmelden", "Bitte melde dich im Browserfenster bei Yahoo an.")
        c.ask_user("Melde dich im Browserfenster bei Yahoo an (inkl. Bestätigungscode). Danach macht A.R.I automatisch weiter.",
                   lambda: c.visible(gen_btn) or "app-passwords" in page.url and "login" not in page.url.split("?")[0].split("/")[-1])
    c.step(3, 3, "App-Passwort erzeugen", "A.R.I erzeugt das App-Passwort ...")
    holder = {}
    pat = r"\b([a-z]{4}) ?([a-z]{4}) ?([a-z]{4}) ?([a-z]{4})\b"

    def make():
        try:
            page.get_by_text(_I(r"other app")).first.click()
        except Exception:
            pass
        try:
            page.get_by_role("textbox").first.fill("ARI")
        except Exception:
            pass
        c.click_any(page.get_by_role("button", name=_I(r"generate")), page.get_by_role("button", name=_I(r"create")))
        end = time.time() + 12
        while time.time() < end:
            m = re.search(pat, c.text())
            if m:
                holder["pw"] = "".join(m.groups())
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Passwort nicht gefunden")

    c.auto(make, "Wähle 'Other app', gib 'ARI' ein und klicke 'Generate'. Lass das angezeigte Passwort sichtbar.",
           lambda: bool(re.search(pat, c.text())))
    if "pw" not in holder:
        m = re.search(pat, c.text())
        if not m:
            raise RuntimeError("Kein Passwort gefunden")
        holder["pw"] = "".join(m.groups())
    mail = re.search(r"[\w.\-+]+@(?:yahoo|ymail|rocketmail)\.[a-z.]+", c.text(), re.I)
    return {"yahoo": {"appPassword": holder["pw"], "email": mail.group(0) if mail else ""}}


def flow_google(c):
    """Google-Cloud-Projekt, Kalender-/Gmail-API, Zustimmungsbildschirm und OAuth-Client. Die Konsole ist komplex - jeder Schritt
    hat die Rueckfall-Anweisung 'bitte selbst'."""
    page = c.page
    total = 9
    c.step(1, total, "Google Cloud öffnen", "A.R.I öffnet die Google-Cloud-Konsole.")
    page.goto("https://console.cloud.google.com/projectcreate", wait_until="domcontentloaded")
    name_box = page.get_by_label(_I(r"project name"))
    if not c.visible(name_box, 8):
        c.step(2, total, "Anmelden", "Bitte melde dich im Browserfenster mit deinem Google-Konto an.")
        c.ask_user("Melde dich im Browserfenster mit deinem Google-Konto an und stimme den Google-Cloud-Bedingungen zu (falls gefragt). "
                   "Danach macht A.R.I automatisch weiter.", lambda: c.visible(name_box) or "console.cloud.google.com" in page.url and "accounts.google" not in page.url)
    c.step(3, total, "Projekt anlegen", "A.R.I legt das Projekt 'ARI' an ...")
    holder = {}

    def project_id_from_url():
        m = re.search(r"[?&]project=([a-z0-9\-]+)", page.url)
        return m.group(1) if m else None

    def create_project():
        if not c.visible(name_box, 5):
            page.goto("https://console.cloud.google.com/projectcreate", wait_until="domcontentloaded")
        name_box.first.fill(G_NAME)
        page.get_by_role("button", name=_I(r"^create$")).first.click()
        c.wait_for(lambda: project_id_from_url(), timeout=60)
        holder["pid"] = project_id_from_url()

    c.auto(create_project, "Gib den Projektnamen '" + G_NAME + "' ein und klicke 'Create'. Warte, bis das Projekt fertig ist. Klicke dann 'Weiter'.",
           lambda: bool(project_id_from_url()))
    pid = holder.get("pid") or project_id_from_url()
    if not pid:
        c.ask_user("Wähle oben in der Konsole dein Projekt '" + G_NAME + "' aus und klicke dann 'Weiter'.")
        pid = project_id_from_url()
    c.step(4, total, "Kalender- und Gmail-API einschalten", "A.R.I schaltet die beiden Schnittstellen ein ...")
    for api, label in (("calendar-json.googleapis.com", "Google Calendar API"), ("gmail.googleapis.com", "Gmail API")):
        def enable(api=api):
            page.goto(f"https://console.cloud.google.com/apis/library/{api}?project={pid}", wait_until="domcontentloaded")
            en = page.get_by_role("button", name=_I(r"^enable$"))
            if c.visible(en, 10):
                en.first.click()
                c.wait_for(lambda: c.visible(page.get_by_role("button", name=_I(r"manage|disable"))) or "metrics" in page.url or "overview" in page.url, timeout=40)
        c.auto(enable, f"Öffne die '{label}' und klicke 'Enable'. Wenn dort 'Manage' steht, ist sie schon an. Klicke dann 'Weiter'.")
    c.step(5, total, "Zustimmungsbildschirm", "A.R.I richtet den Zustimmungsbildschirm ein ...")

    def consent():
        page.goto(f"https://console.cloud.google.com/auth/overview?project={pid}", wait_until="domcontentloaded")
        gs = page.get_by_role("button", name=_I(r"get started"))
        if not c.visible(gs, 8):
            return   # schon eingerichtet
        gs.first.click()
        page.get_by_label(_I(r"app name")).first.fill(G_NAME)
        try:   # Support-E-Mail: erste Auswahl
            page.get_by_label(_I(r"user support email")).first.click()
            page.get_by_role("option").first.click()
        except Exception:
            pass
        c.click_any(page.get_by_role("button", name=_I(r"^next$")))
        c.click_any(page.get_by_label(_I(r"external")), page.get_by_text(_I(r"^external$")))
        c.click_any(page.get_by_role("button", name=_I(r"^next$")))
        mail = page.get_by_label(_I(r"email addresses"))
        try:
            ok_mail = page.evaluate("() => { const m = (document.body.innerText.match(/[\\w.+-]+@[\\w.-]+\\.[a-z]+/i)||[])[0]; return m || ''; }")
        except Exception:
            ok_mail = ""
        mail.first.fill(ok_mail or "")
        page.keyboard.press("Enter")
        c.click_any(page.get_by_role("button", name=_I(r"^next$")))
        c.ask_user("Setze im Browserfenster das Häkchen bei der Google-API-Nutzerdatenrichtlinie (agree) und klicke 'Continue'.",
                   lambda: c.visible(page.get_by_role("button", name=_I(r"^create$"))))
        c.click_any(page.get_by_role("button", name=_I(r"^continue$")), timeout=2) if c.visible(page.get_by_role("button", name=_I(r"^continue$"))) else None
        c.click_any(page.get_by_role("button", name=_I(r"^create$")))
        page.wait_for_timeout(2500)

    c.auto(consent, "Richte den Zustimmungsbildschirm ein: App-Name '" + G_NAME + "', Zielgruppe 'Extern', deine E-Mail als Kontakt, Bedingungen bestätigen, "
           "'Create'. Danach unter 'Zielgruppe' (Audience) dich selbst als Testnutzer hinzufügen. Klicke dann 'Weiter'.")
    c.step(6, total, "Zugriffsbereiche eintragen", "A.R.I trägt alle Zugriffsbereiche ein, die es braucht: Kalender (Termine ansehen und ändern), Gmail lesen und Gmail senden.")
    scopes = ["https://www.googleapis.com/auth/calendar.events",
              "https://www.googleapis.com/auth/gmail.readonly",
              "https://www.googleapis.com/auth/gmail.send"]

    def add_scopes():
        page.goto(f"https://console.cloud.google.com/auth/scopes?project={pid}", wait_until="domcontentloaded")
        c.click_any(page.get_by_role("button", name=_I(r"add or remove scopes")), page.get_by_text(_I(r"add or remove scopes")))
        page.wait_for_timeout(1500)
        for sc in scopes:
            flt = page.get_by_placeholder(_I(r"filter|enter property name or value")).last
            flt.fill("")
            flt.fill(sc)
            page.keyboard.press("Enter")
            page.wait_for_timeout(1200)
            row = page.get_by_role("row").filter(has_text=sc.rsplit("/", 1)[-1]).first
            cb = row.get_by_role("checkbox").first
            if not cb.is_checked():
                cb.check()
        c.click_any(page.get_by_role("button", name=_I(r"^update$")))
        page.wait_for_timeout(1500)
        c.click_any(page.get_by_role("button", name=_I(r"^save$")))
        page.wait_for_timeout(2000)

    c.auto(add_scopes, "Öffne unter 'Datenzugriff' (Data Access) 'Add or remove scopes' und hake diese drei an: " + ", ".join(sc.rsplit("/", 1)[-1] for sc in scopes) +
           " (zum Finden in das Filterfeld einfügen). Klicke 'Update' und danach 'Save'. Klicke dann 'Weiter'.")
    c.step(7, total, "Dich als Testnutzer eintragen", "A.R.I trägt dein Google-Konto als Testnutzer ein, sonst blockiert Google den Zugriff (Fehler 403).")

    def account_email():
        js = r"""() => {
          const els = [...document.querySelectorAll('[aria-label*="@"], [title*="@"], [data-email]')];
          for (const e of els) {
            const t = (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('data-email') || '');
            const m = t.match(/[\w.+-]+@[\w.-]+\.[a-z]+/i);
            if (m) return m[0];
          }
          return '';
        }"""
        try:
            t = page.evaluate(js)
        except Exception:
            t = ""
        if t:
            return t
        m = re.search(r"[\w.+\-]+@(?:gmail|googlemail)\.com", c.text(), re.I)
        return m.group(0) if m else ""

    def add_test_user():
        page.goto(f"https://console.cloud.google.com/auth/audience?project={pid}", wait_until="domcontentloaded")
        mail = account_email()
        if not mail:
            raise RuntimeError("Konto-E-Mail nicht erkannt")
        holder["mail"] = mail
        c.click_any(page.get_by_role("button", name=_I(r"add users")), page.get_by_text(_I(r"^add users$")))
        box = page.get_by_role("textbox").last
        box.fill(mail)
        page.keyboard.press("Enter")
        c.click_any(page.get_by_role("button", name=_I(r"^save$")))
        page.wait_for_timeout(2000)
        if mail.lower() not in c.text().lower():
            raise RuntimeError("Testnutzer nicht sichtbar")

    c.auto(add_test_user, "Öffne unter 'Zielgruppe' (Audience) den Bereich 'Testnutzer' (Test users), klicke 'Add users' und trage DEINE Google-E-Mail-Adresse ein, "
           "mit der du dich später verbindest. Klicke 'Save'. Sonst blockiert Google den Zugriff (Fehler 403: access_denied).",
           lambda: holder.get("mail") is not None and holder["mail"].lower() in c.text().lower())
    c.step(8, total, "App veröffentlichen", "A.R.I stellt die App von Test auf Produktion um, damit deine Anmeldung nicht nach 7 Tagen abläuft.")

    def publish():
        page.goto(f"https://console.cloud.google.com/auth/audience?project={pid}", wait_until="domcontentloaded")
        if c.visible(page.get_by_text(_I(r"in production")), 4):
            return   # schon veroeffentlicht
        c.click_any(page.get_by_role("button", name=_I(r"publish app")))
        page.wait_for_timeout(1200)
        c.click_any(page.get_by_role("button", name=_I(r"^confirm$")), timeout=6)
        end = time.time() + 15
        while time.time() < end:
            if c.visible(page.get_by_text(_I(r"in production"))):
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Status 'In production' nicht gesehen")

    c.auto(publish, "Öffne unter 'Zielgruppe' (Audience) den Knopf 'Publish app' und bestätige mit 'Confirm'. Dann steht dort 'In production'. "
           "Klicke danach 'Weiter'. (Beim Verbinden zeigt Google später 'Google hat diese App nicht überprüft' - dort 'Erweitert' und 'Weiter zu ARIAssistant' wählen.)")
    c.step(9, total, "OAuth-Client erstellen", "A.R.I erstellt den Zugangs-Client und liest ihn aus ...")

    def client():
        page.goto(f"https://console.cloud.google.com/auth/clients/create?project={pid}", wait_until="domcontentloaded")
        c.click_any(page.get_by_label(_I(r"application type")), page.get_by_role("combobox").first)
        c.click_any(page.get_by_role("option", name=_I(r"desktop")), page.get_by_text(_I(r"desktop app")))
        page.get_by_label(_I(r"^name")).first.fill(G_NAME)
        c.click_any(page.get_by_role("button", name=_I(r"^create$")))
        end = time.time() + 25
        while time.time() < end:
            t = c.text()
            cid = re.search(r"\d{6,}-[a-z0-9]+\.apps\.googleusercontent\.com", t)
            sec = re.search(r"GOCSPX-[\w\-]+", t)
            if cid and sec:
                holder["cid"], holder["secret"] = cid.group(0), sec.group(0)
                return
            page.wait_for_timeout(500)
        raise RuntimeError("Client-Daten nicht gefunden")

    c.auto(client, "Erstelle unter 'Clients' einen OAuth-Client vom Typ 'Desktop app' (Name '" + G_NAME + "'). Lass das Fenster mit Client-ID und -Secret offen.",
           lambda: bool(re.search(r"GOCSPX-[\w\-]+", c.text())))
    if "cid" not in holder:
        t = c.text()
        cid = re.search(r"\d{6,}-[a-z0-9]+\.apps\.googleusercontent\.com", t)
        sec = re.search(r"GOCSPX-[\w\-]+", t)
        if not (cid and sec):
            raise RuntimeError("Client-ID/Secret nicht gefunden")
        holder["cid"], holder["secret"] = cid.group(0), sec.group(0)
    return {"google": {"clientId": holder["cid"], "clientSecret": holder["secret"]}}


def flow_mock_agent(c):
    """Testablauf mit anders benannten Knoepfen: die festen Schritte finden nichts, die KI-Hilfe muss die Seite lesen."""
    page = c.page
    c.step(1, 2, "Beispielseite (KI-Hilfe)", "Test mit eingebauter Seite.")
    page.set_content("""<html><body style="font:16px sans-serif;padding:30px"><h2>Mock-Dienst</h2>
      <button id=go onclick="document.getElementById('form').style.display='block'">Make a new project</button>
      <div id=form style="display:none"><label>Title of project <input id=title></label><br><label>Return address <input id=ret></label><br>
      <label><input type=checkbox id=api> Use the web interface</label><br>
      <button id=store onclick="document.getElementById('out').textContent='Client ID: '+'c'.repeat(32)+' Secret: '+'d'.repeat(32)">Store</button><p id=out></p></div></body></html>""")
    c.step(2, 2, "Formular", "A.R.I versucht es automatisch ...")
    done = lambda: "Client ID" in c.text()

    def fixed():
        page.get_by_role("button", name="Create app").click(timeout=1500)   # existiert nicht -> Fehler -> KI-Hilfe

    c.auto(fixed, "Klicke 'Make a new project', fülle das Formular aus und klicke 'Store'.", done,
           goal="Create a new project: click 'Make a new project', set the title to ARI, the return address to http://127.0.0.1:5000/spotify/callback, tick the web interface checkbox and click Store.")
    ids = re.findall(r"\b[0-9a-f]{32}\b", c.text())
    return {"mock": {"clientId": ids[0], "clientSecret": ids[1]}}


HOSTS = {"mock": [], "mock_agent": [], "spotify": ["developer.spotify.com", "accounts.spotify.com", "spotify.com", "127.0.0.1"],
         "google": ["console.cloud.google.com", "accounts.google.com", "console.developers.google.com", "google.com"],
         "yahoo": ["login.yahoo.com", "yahoo.com"], "groq": ["console.groq.com", "groq.com"], "gemini": ["aistudio.google.com", "accounts.google.com", "google.com"]}
FLOWS = {"mock": flow_mock, "mock_agent": flow_mock_agent, "spotify": flow_spotify, "groq": flow_groq, "gemini": flow_gemini, "yahoo": flow_yahoo, "google": flow_google}
TITLES = {"mock": "Test", "mock_agent": "Test (KI-Hilfe)", "spotify": "Spotify", "groq": "Groq-Schlüssel", "gemini": "Gemini-Schlüssel", "yahoo": "Yahoo Mail", "google": "Google Kalender & Gmail"}


# ------------------------------------------------------------------------------------- Steuerung
def _run(flow, hub, profile_dir):
    pw = None
    try:
        from playwright.sync_api import sync_playwright
        _set(state="starting", message="Browser wird gestartet ...")
        port = _launch_browser(profile_dir)
        pw = sync_playwright().start()
        browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
        ctx = browser.contexts[0] if browser.contexts else browser.new_context()
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(8000)
        try:   # feste Seitengroesse: jede Webseite zeigt dann dasselbe Layout (kein eingeklapptes Handy-Menue bei kleinen Fenstern)
            page.set_viewport_size({"width": 1280, "height": 900})
        except Exception:
            pass
        _set(state="running")
        hub = dict(hub or {})
        hub["hosts"] = HOSTS.get(flow, [])
        result = FLOWS[flow](Ctx(page, hub))
        _set(state="done", message="Fertig!", note="", result=result, needs_user=False, hint="")
    except Cancelled:
        _set(state="cancelled", message="Abgebrochen.", needs_user=False, hint="")
    except Exception as e:
        _set(state="error", error=str(e) or e.__class__.__name__, message="Das hat nicht geklappt.", needs_user=False, hint="")
    finally:
        try:
            if pw is not None:
                pw.stop()
        except Exception:
            pass
        _close_browser()


def start(flow, hub, profile_dir):
    """Startet einen Ablauf im Hintergrund. hub = Rueckrufe (z.B. {'save_spotify': fn})."""
    global _thread
    if flow not in FLOWS:
        return False, "Unbekannter Ablauf."
    if running():
        return False, "Es läuft schon eine Einrichtung."
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False, "Das Paket 'playwright' fehlt (wird beim nächsten Start nachinstalliert)."
    _cancel.clear()
    _cont.clear()
    _say("")   # alte Ansage verwerfen (das HUD liest nur NEUE vor)
    _set(flow=flow, state="starting", step=0, total=0, title=TITLES.get(flow, flow), message="Starte ...", note="", needs_user=False, hint="", result=None, error="")
    _thread = threading.Thread(target=_run, args=(flow, hub, profile_dir), daemon=True)
    _thread.start()
    return True, None
